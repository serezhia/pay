package com.yandex.finsdtechsdk.adapters.passport.sdk.api.uid

public sealed interface UidState {

    public data object Initial : UidState

    public data object NoUid : UidState

    public data class UidProvided(public val uid: Long) : UidState
}
