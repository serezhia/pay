package com.yandex.finsdtechsdk.adapters.passport.sdk.api

import android.content.Context
import android.content.Intent

public interface PassportAdapter {

    public fun createLoginIntent(context: Context, isTestEnvironment: Boolean): Intent

    public fun getUrlWithAuth(context: Context, url: String, uid: Long, tld: String, isTestEnvironment: Boolean): String?

    public fun extractUid(loginIntent: Intent): Long

    public fun requestNewToken(
        context: Context,
        uid: Long,
        clientId: String,
        secretId: String,
        isTestEnvironment: Boolean,
        isDropTokenForced: Boolean,
    ): String
}
