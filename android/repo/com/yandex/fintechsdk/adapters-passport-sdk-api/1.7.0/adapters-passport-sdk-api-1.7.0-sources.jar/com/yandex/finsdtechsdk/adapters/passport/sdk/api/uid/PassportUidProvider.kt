package com.yandex.finsdtechsdk.adapters.passport.sdk.api.uid

import kotlinx.coroutines.flow.StateFlow

public interface PassportUidProvider {
    public val uidState: StateFlow<UidState>
}
