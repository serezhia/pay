package com.yandex.finsdtechsdk.adapters.passport.sdk.api.performance

/**
 * Creates a [PassportPerformanceCallback] instance with the provided callbacks.
 *
 * @param onTokenDropCompleted Callback invoked when token drop operation completes.
 * @param onTokenRequestCompleted Callback invoked when token request operation completes.
 */
public fun createPassportPerformanceCallback(
    onTokenDropCompleted: (durationMs: Long) -> Unit,
    onTokenRequestCompleted: (durationMs: Long) -> Unit,
): PassportPerformanceCallback {
    return object : PassportPerformanceCallback {
        override fun onTokenDropCompleted(durationMs: Long) {
            onTokenDropCompleted(durationMs)
        }

        override fun onTokenRequestCompleted(durationMs: Long) {
            onTokenRequestCompleted(durationMs)
        }
    }
}
