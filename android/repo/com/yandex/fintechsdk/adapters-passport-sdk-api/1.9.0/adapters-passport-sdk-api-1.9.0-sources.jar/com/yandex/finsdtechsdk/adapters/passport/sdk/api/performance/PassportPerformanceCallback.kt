package com.yandex.finsdtechsdk.adapters.passport.sdk.api.performance

public interface PassportPerformanceCallback {
    public fun onTokenDropCompleted(durationMs: Long)
    public fun onTokenRequestCompleted(durationMs: Long)
}
