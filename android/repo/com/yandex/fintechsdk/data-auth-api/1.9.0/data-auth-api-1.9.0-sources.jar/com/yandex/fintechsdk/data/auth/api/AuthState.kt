package com.yandex.fintechsdk.data.auth.api

import com.yandex.fintechsdk.entities.auth.AccountCredentials

public enum class TokenSource(public val analyticsValue: String) {
    HOST_PASSPORT("HOST_PASSPORT"),
    PASSPORT("PASSPORT"),
    LOGIN_SDK("LOGIN_SDK")
}

public sealed interface AuthState {

    public data object Initial : AuthState

    public data object Unauthorized : AuthState

    public data class GotUid(public val uid: Long) : AuthState

    public data class Authorized(
        public val credentials: AccountCredentials,
        public val source: TokenSource = TokenSource.PASSPORT,
    ) : AuthState
}
