package com.yandex.fintechsdk.data.auth.api

import kotlinx.coroutines.flow.StateFlow

public interface AuthRepository {

    public val authState: StateFlow<AuthState>

    public val uidState: StateFlow<Long?>

    public fun setAuthState(authState: AuthState)

    public fun clearCredentials()
}
