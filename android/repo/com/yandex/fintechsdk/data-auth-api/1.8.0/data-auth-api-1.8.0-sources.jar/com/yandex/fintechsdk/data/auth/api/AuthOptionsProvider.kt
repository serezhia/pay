package com.yandex.fintechsdk.data.auth.api

public interface AuthOptionsProvider {
    /**
     * Determines whether auth token caching is enabled for this flow.
     * If true, credentials will be saved to and loaded from secure storage.
     * If false, credentials will not be persisted and will always start with Initial state.
     */
    public fun isAuthTokenCachingEnabled(): Boolean
}
