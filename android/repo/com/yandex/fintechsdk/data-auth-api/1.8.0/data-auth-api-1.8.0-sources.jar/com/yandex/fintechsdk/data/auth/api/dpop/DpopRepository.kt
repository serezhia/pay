package com.yandex.fintechsdk.data.auth.api.dpop

import androidx.fragment.app.FragmentActivity

public interface DpopRepository {

    public fun getCachedAuthSession(): String?

    public fun clearCachedAuthSession()

    public suspend fun bindAuth(): Result<Unit>

    public suspend fun revokeToken(token: String): Result<Unit>

    public suspend fun generateAuthSession(
        activity: FragmentActivity,
        authToken: String,
        merchantId: String,
    ): Result<String>
}
