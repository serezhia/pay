package com.yandex.fintechsdk.core.navigation.api

public interface Router {

    public fun back()

    public fun toScreen(route: String, args: Map<String, String> = emptyMap(), navOptions: FintechNavOptions? = null)
}
