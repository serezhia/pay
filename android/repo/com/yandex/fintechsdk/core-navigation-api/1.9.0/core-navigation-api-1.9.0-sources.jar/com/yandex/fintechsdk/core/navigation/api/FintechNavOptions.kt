package com.yandex.fintechsdk.core.navigation.api

import androidx.annotation.AnimRes
import androidx.annotation.AnimatorRes
import com.yandex.fintechsdk.resources.api.ResAnimator

public class FintechNavOptions(
    public val singleTop: Boolean = false,
    public val restoreState: Boolean = false,
    public val popUpToRoute: String? = null,
    public val popUpToInclusive: Boolean = false,
    public val popUpToSaveState: Boolean = false,
    @AnimRes @AnimatorRes public val enterAnim: Int? = ResAnimator.finsdk_slide_in_to_left,
    @AnimRes @AnimatorRes public val exitAnim: Int? = ResAnimator.finsdk_slide_out_to_left,
    @AnimRes @AnimatorRes public val popEnterAnim: Int? = ResAnimator.finsdk_slide_in_to_right,
    @AnimRes @AnimatorRes public val popExitAnim: Int? = ResAnimator.finsdk_slide_out_to_right,
)
