package com.yandex.fintechsdk.core.divkit.impl.internal.action.openflex;

import com.yandex.fintechsdk.core.divkit.api.action.DivActionsDelegate;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class OpenFlexScreenActionHandler_Factory implements Factory<OpenFlexScreenActionHandler> {
  private final Provider<DivActionsDelegate> delegateProvider;

  private OpenFlexScreenActionHandler_Factory(Provider<DivActionsDelegate> delegateProvider) {
    this.delegateProvider = delegateProvider;
  }

  @Override
  public OpenFlexScreenActionHandler get() {
    return newInstance(delegateProvider.get());
  }

  public static OpenFlexScreenActionHandler_Factory create(
      Provider<DivActionsDelegate> delegateProvider) {
    return new OpenFlexScreenActionHandler_Factory(delegateProvider);
  }

  public static OpenFlexScreenActionHandler newInstance(DivActionsDelegate delegate) {
    return new OpenFlexScreenActionHandler(delegate);
  }
}
