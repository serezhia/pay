package com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.requester

import com.yandex.fintechsdk.core.divkit.api.network.RemoteActionBaseQueriesProvider
import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import kotlinx.serialization.json.JsonObject
import java.net.URLEncoder
import javax.inject.Inject

internal class DivRemoteActionRequester @Inject constructor(
    private val api: FrontbackNetworkApi,
    private val baseQueriesProvider: RemoteActionBaseQueriesProvider,
) : Requester<DivRemoteActionParams, DivRemoteActionRequest, JsonObject, JsonObject>() {

    override fun createRequest(params: DivRemoteActionParams): DivRemoteActionRequest {
        val actionQueryItems: Map<String, String> = params.queries?.mapNotNull { (key, values) ->
            values.firstOrNull()?.let { value ->
                key to URLEncoder.encode(value, ENCODING)
            }
        }?.toMap().orEmpty()

        val baseQueries = baseQueriesProvider.getBaseQueries().mapValues { (_, value) ->
            URLEncoder.encode(value, ENCODING)
        }

        val mergedQueries = baseQueries + actionQueryItems

        return DivRemoteActionRequest(
            method = params.method,
            requestPath = params.path,
            body = params.body,
            headers = params.headers,
            queries = mergedQueries.ifEmpty { null },
        )
    }

    override suspend fun executeRequest(request: DivRemoteActionRequest): Result<JsonObject> {
        return api.sendRequest(request = request)
    }

    override fun transformResponse(response: JsonObject): JsonObject {
        return response
    }

    private companion object {
        const val ENCODING = "UTF-8"
    }
}

