package com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.requester

import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject

internal class DivRemoteActionRequest(
    override val method: RestMethod,
    override val requestPath: String,
    private val body: Map<String, Any?>? = null,
    private val headers: Map<String, String>? = null,
    private val queries: Map<String, String>? = null,
) : Request(
    configure = { isAuthNeeded = false }
) {
    override val requestName: String = "div_remote_action-$requestPath"

    override fun headers(): Map<String, String> {
        return headers.orEmpty()
    }

    override fun queries(): Map<String, String> {
        return queries.orEmpty()
    }

    override fun body(): JsonObject? {
        return body?.let {
            buildJsonObject {
                it.forEach { (key, value) ->
                    when (value) {
                        null -> put(key, null as String?)
                        is String -> put(key, value)
                        is Number -> put(key, value)
                        is Boolean -> put(key, value)
                        is Map<*, *> -> putJsonObject(key) {
                            @Suppress("UNCHECKED_CAST")
                            (value as Map<String, Any?>).forEach { (k, v) ->
                                when (v) {
                                    null -> put(k, null as String?)
                                    is String -> put(k, v)
                                    is Number -> put(k, v)
                                    is Boolean -> put(k, v)
                                    else -> put(k, v.toString())
                                }
                            }
                        }
                        else -> put(key, value.toString())
                    }
                }
            }
        }
    }
}

