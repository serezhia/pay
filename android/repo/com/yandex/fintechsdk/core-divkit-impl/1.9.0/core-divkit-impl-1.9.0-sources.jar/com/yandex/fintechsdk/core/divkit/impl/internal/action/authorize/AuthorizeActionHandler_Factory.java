package com.yandex.fintechsdk.core.divkit.impl.internal.action.authorize;

import com.yandex.fintechsdk.core.divkit.api.action.DivActionsDelegate;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class AuthorizeActionHandler_Factory implements Factory<AuthorizeActionHandler> {
  private final Provider<DivActionsDelegate> delegateProvider;

  private AuthorizeActionHandler_Factory(Provider<DivActionsDelegate> delegateProvider) {
    this.delegateProvider = delegateProvider;
  }

  @Override
  public AuthorizeActionHandler get() {
    return newInstance(delegateProvider.get());
  }

  public static AuthorizeActionHandler_Factory create(
      Provider<DivActionsDelegate> delegateProvider) {
    return new AuthorizeActionHandler_Factory(delegateProvider);
  }

  public static AuthorizeActionHandler newInstance(DivActionsDelegate delegate) {
    return new AuthorizeActionHandler(delegate);
  }
}
