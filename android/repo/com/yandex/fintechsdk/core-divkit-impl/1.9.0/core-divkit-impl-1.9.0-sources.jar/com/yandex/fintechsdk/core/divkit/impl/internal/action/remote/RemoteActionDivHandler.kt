package com.yandex.fintechsdk.core.divkit.impl.internal.action.remote

import com.yandex.fintechsdk.core.divkit.api.action.DivActionsDelegate
import com.yandex.fintechsdk.core.divkit.api.action.DivCallbackAction
import com.yandex.fintechsdk.core.divkit.api.action.DivAction
import com.yandex.fintechsdk.core.divkit.api.action.DivActionExecutor
import com.yandex.fintechsdk.core.divkit.api.action.DivActionHandler
import com.yandex.fintechsdk.core.divkit.api.di.DivkitCoroutineScope
import com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.requester.DivRemoteActionParams
import com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.requester.DivRemoteActionRequester
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import javax.inject.Inject

internal class RemoteActionDivHandler @Inject constructor(
    private val divActionsDelegate: DivActionsDelegate,
    private val requester: DivRemoteActionRequester,
    @DivkitCoroutineScope private val coroutineScope: CoroutineScope,
) : DivActionHandler {
    override val actionType: String = ACTION_TYPE

    override fun handle(divAction: DivAction, actionExecutor: DivActionExecutor) {
        coroutineScope.launch {
            val params = extractParams(payload = divAction.payload) ?: return@launch

            val onSuccessAction = DivCallbackAction.fromPayload(payload = divAction.payload, key = KEY_ON_SUCCESS)
            val onFailureAction = DivCallbackAction.fromPayload(payload = divAction.payload, key = KEY_ON_FAILURE)

            requester.execute(params = params)
                .onSuccess {
                    divActionsDelegate.onRemoteAction(path = params.path)
                    onSuccessAction?.let { action ->
                        actionExecutor.executeAction(action = action)
                    }
                }
                .onFailure {
                    onFailureAction?.let { action ->
                        actionExecutor.executeAction(action = action)
                    }
                    // TODO: Report in FINSDK-460
                }
        }
    }

    private fun extractParams(payload: Map<String, Any?>): DivRemoteActionParams? {
        val path = payload[KEY_PATH] as? String ?: return null

        val methodString = payload[KEY_METHOD] as? String ?: DEFAULT_METHOD
        val method = when (methodString.uppercase()) {
            HTTP_METHOD_GET -> RestMethod.GET
            HTTP_METHOD_POST -> RestMethod.POST
            HTTP_METHOD_PUT -> RestMethod.PUT
            HTTP_METHOD_PATCH -> RestMethod.PATCH
            HTTP_METHOD_DELETE -> RestMethod.DELETE
            else -> RestMethod.POST
        }

        @Suppress("UNCHECKED_CAST")
        val queries = payload[KEY_PARAMS] as? Map<String, List<String>>

        @Suppress("UNCHECKED_CAST")
        val headers = payload[KEY_HEADERS] as? Map<String, String>

        @Suppress("UNCHECKED_CAST")
        val body = payload[KEY_BODY] as? Map<String, Any?>

        return DivRemoteActionParams(
            method = method,
            path = path,
            body = body,
            headers = headers,
            queries = queries,
        )
    }

    companion object {
        const val ACTION_TYPE: String = "remote_action"

        private const val HTTP_METHOD_DELETE = "DELETE"
        private const val HTTP_METHOD_GET = "GET"
        private const val HTTP_METHOD_PATCH = "PATCH"
        private const val HTTP_METHOD_POST = "POST"
        private const val HTTP_METHOD_PUT = "PUT"

        private const val DEFAULT_METHOD = HTTP_METHOD_POST

        private const val KEY_BODY = "body"
        private const val KEY_HEADERS = "headers"
        private const val KEY_METHOD = "method"
        private const val KEY_ON_FAILURE = "on_fail"
        private const val KEY_ON_SUCCESS = "on_success"
        private const val KEY_PARAMS = "params"
        private const val KEY_PATH = "path"
    }
}
