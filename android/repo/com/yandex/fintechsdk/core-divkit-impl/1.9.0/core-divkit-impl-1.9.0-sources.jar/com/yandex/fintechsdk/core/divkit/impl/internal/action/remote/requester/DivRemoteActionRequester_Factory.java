package com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.requester;

import com.yandex.fintechsdk.core.divkit.api.network.RemoteActionBaseQueriesProvider;
import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DivRemoteActionRequester_Factory implements Factory<DivRemoteActionRequester> {
  private final Provider<FrontbackNetworkApi> apiProvider;

  private final Provider<RemoteActionBaseQueriesProvider> baseQueriesProvider;

  private DivRemoteActionRequester_Factory(Provider<FrontbackNetworkApi> apiProvider,
      Provider<RemoteActionBaseQueriesProvider> baseQueriesProvider) {
    this.apiProvider = apiProvider;
    this.baseQueriesProvider = baseQueriesProvider;
  }

  @Override
  public DivRemoteActionRequester get() {
    return newInstance(apiProvider.get(), baseQueriesProvider.get());
  }

  public static DivRemoteActionRequester_Factory create(Provider<FrontbackNetworkApi> apiProvider,
      Provider<RemoteActionBaseQueriesProvider> baseQueriesProvider) {
    return new DivRemoteActionRequester_Factory(apiProvider, baseQueriesProvider);
  }

  public static DivRemoteActionRequester newInstance(FrontbackNetworkApi api,
      RemoteActionBaseQueriesProvider baseQueriesProvider) {
    return new DivRemoteActionRequester(api, baseQueriesProvider);
  }
}
