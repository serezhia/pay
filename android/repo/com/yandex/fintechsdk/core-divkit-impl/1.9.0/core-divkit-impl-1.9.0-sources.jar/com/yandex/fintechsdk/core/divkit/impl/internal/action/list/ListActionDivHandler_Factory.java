package com.yandex.fintechsdk.core.divkit.impl.internal.action.list;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ListActionDivHandler_Factory implements Factory<ListActionDivHandler> {
  @Override
  public ListActionDivHandler get() {
    return newInstance();
  }

  public static ListActionDivHandler_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ListActionDivHandler newInstance() {
    return new ListActionDivHandler();
  }

  private static final class InstanceHolder {
    static final ListActionDivHandler_Factory INSTANCE = new ListActionDivHandler_Factory();
  }
}
