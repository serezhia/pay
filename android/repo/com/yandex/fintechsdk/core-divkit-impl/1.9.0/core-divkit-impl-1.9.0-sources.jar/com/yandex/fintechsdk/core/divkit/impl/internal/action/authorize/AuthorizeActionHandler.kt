package com.yandex.fintechsdk.core.divkit.impl.internal.action.authorize

import com.yandex.fintechsdk.core.divkit.api.action.DivAction
import com.yandex.fintechsdk.core.divkit.api.action.DivActionExecutor
import com.yandex.fintechsdk.core.divkit.api.action.DivActionHandler
import com.yandex.fintechsdk.core.divkit.api.action.DivActionsDelegate
import javax.inject.Inject

internal class AuthorizeActionHandler @Inject constructor(
    private val delegate: DivActionsDelegate,
) : DivActionHandler {

    override val actionType: String = ACTION_TYPE

    override fun handle(divAction: DivAction, actionExecutor: DivActionExecutor) {
        delegate.authorize()
    }

    internal companion object {
        const val ACTION_TYPE = "authorize"
    }
}

