package com.yandex.fintechsdk.core.divkit.impl.api.di

import com.yandex.fintechsdk.core.divkit.api.action.DivActionHandler
import com.yandex.fintechsdk.core.divkit.impl.internal.action.authorize.AuthorizeActionHandler
import com.yandex.fintechsdk.core.divkit.impl.internal.action.list.ListActionDivHandler
import com.yandex.fintechsdk.core.divkit.impl.internal.action.openflex.OpenFlexScreenActionHandler
import com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.RemoteActionDivHandler
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap
import dagger.multibindings.StringKey

@Module
public abstract class DivkitModule {

    @Binds
    @IntoMap
    @StringKey(AuthorizeActionHandler.ACTION_TYPE)
    internal abstract fun bindAuthorizeActionHandler(handler: AuthorizeActionHandler): DivActionHandler

    @Binds
    @IntoMap
    @StringKey(RemoteActionDivHandler.ACTION_TYPE)
    internal abstract fun bindRemoteActionHandler(handler: RemoteActionDivHandler): DivActionHandler

    @Binds
    @IntoMap
    @StringKey(OpenFlexScreenActionHandler.ACTION_TYPE)
    internal abstract fun bindOpenFlexScreenActionHandler(handler: OpenFlexScreenActionHandler): DivActionHandler

    @Binds
    @IntoMap
    @StringKey(ListActionDivHandler.ACTION_TYPE)
    internal abstract fun bindListActionHandler(handler: ListActionDivHandler): DivActionHandler
}

