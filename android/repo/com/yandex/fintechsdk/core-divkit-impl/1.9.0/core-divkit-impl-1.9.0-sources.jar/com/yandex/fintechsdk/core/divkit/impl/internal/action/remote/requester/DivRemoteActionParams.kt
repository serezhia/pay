package com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.requester

import com.yandex.fintechsdk.core.network.api.request.RestMethod

internal class DivRemoteActionParams(
    val method: RestMethod,
    val path: String,
    val body: Map<String, Any?>? = null,
    val headers: Map<String, String>? = null,
    val queries: Map<String, List<String>>? = null,
)

