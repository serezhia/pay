package com.yandex.fintechsdk.core.divkit.impl.internal.action.openflex

import com.yandex.fintechsdk.core.divkit.api.action.DivAction
import com.yandex.fintechsdk.core.divkit.api.action.DivActionExecutor
import com.yandex.fintechsdk.core.divkit.api.action.DivActionHandler
import com.yandex.fintechsdk.core.divkit.api.action.DivActionsDelegate
import javax.inject.Inject

internal class OpenFlexScreenActionHandler @Inject constructor(
    private val delegate: DivActionsDelegate,
) : DivActionHandler {

    override val actionType: String = ACTION_TYPE

    override fun handle(divAction: DivAction, actionExecutor: DivActionExecutor) {
        val path = divAction.payload[KEY_PATH] as? String ?: return
        val params = extractMapFromPayload(payload = divAction.payload, key = KEY_PARAMS)
        val headers = extractMapFromPayload(payload = divAction.payload, key = KEY_HEADERS)

        delegate.openFlexScreen(
            endpoint = path.trimStart('/'),
            query = params,
            headers = headers,
        )
    }

    private fun extractMapFromPayload(payload: Map<String, Any?>, key: String): Map<String, String> {
        @Suppress("UNCHECKED_CAST")
        return (payload[key] as? Map<*, *>)
            ?.mapKeys { it.key.toString() }
            ?.mapValues { it.value.toString() }
            ?: emptyMap()
    }

    internal companion object {
        const val ACTION_TYPE = "open_flex_screen"

        private const val KEY_HEADERS = "headers"
        private const val KEY_PARAMS = "params"
        private const val KEY_PATH = "path"
    }
}
