package com.yandex.fintechsdk.core.divkit.impl.internal.action.list

import com.yandex.fintechsdk.core.divkit.api.action.DivCallbackAction
import com.yandex.fintechsdk.core.divkit.api.action.DivAction
import com.yandex.fintechsdk.core.divkit.api.action.DivActionExecutor
import com.yandex.fintechsdk.core.divkit.api.action.DivActionHandler
import javax.inject.Inject

internal class ListActionDivHandler @Inject constructor() : DivActionHandler {

    override val actionType: String = ACTION_TYPE

    override fun handle(divAction: DivAction, actionExecutor: DivActionExecutor) {
        val actions = DivCallbackAction.listFromPayload(payload = divAction.payload, key = KEY_ACTIONS) ?: return

        for (action in actions) {
            try {
                actionExecutor.executeAction(action = action)
            } catch (_: Throwable) {
                // Continue with other actions
                // TODO: Report error in FINSDK-460
            }
        }
    }

    companion object {
        const val ACTION_TYPE: String = "list_action"
        private const val KEY_ACTIONS = "actions"
    }
}
