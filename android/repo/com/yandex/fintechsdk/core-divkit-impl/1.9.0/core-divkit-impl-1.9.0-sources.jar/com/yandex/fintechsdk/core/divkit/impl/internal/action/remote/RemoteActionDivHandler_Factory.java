package com.yandex.fintechsdk.core.divkit.impl.internal.action.remote;

import com.yandex.fintechsdk.core.divkit.api.action.DivActionsDelegate;
import com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.requester.DivRemoteActionRequester;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlinx.coroutines.CoroutineScope;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.divkit.api.di.DivkitCoroutineScope")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RemoteActionDivHandler_Factory implements Factory<RemoteActionDivHandler> {
  private final Provider<DivActionsDelegate> divActionsDelegateProvider;

  private final Provider<DivRemoteActionRequester> requesterProvider;

  private final Provider<CoroutineScope> coroutineScopeProvider;

  private RemoteActionDivHandler_Factory(Provider<DivActionsDelegate> divActionsDelegateProvider,
      Provider<DivRemoteActionRequester> requesterProvider,
      Provider<CoroutineScope> coroutineScopeProvider) {
    this.divActionsDelegateProvider = divActionsDelegateProvider;
    this.requesterProvider = requesterProvider;
    this.coroutineScopeProvider = coroutineScopeProvider;
  }

  @Override
  public RemoteActionDivHandler get() {
    return newInstance(divActionsDelegateProvider.get(), requesterProvider.get(), coroutineScopeProvider.get());
  }

  public static RemoteActionDivHandler_Factory create(
      Provider<DivActionsDelegate> divActionsDelegateProvider,
      Provider<DivRemoteActionRequester> requesterProvider,
      Provider<CoroutineScope> coroutineScopeProvider) {
    return new RemoteActionDivHandler_Factory(divActionsDelegateProvider, requesterProvider, coroutineScopeProvider);
  }

  public static RemoteActionDivHandler newInstance(DivActionsDelegate divActionsDelegate,
      DivRemoteActionRequester requester, CoroutineScope coroutineScope) {
    return new RemoteActionDivHandler(divActionsDelegate, requester, coroutineScope);
  }
}
