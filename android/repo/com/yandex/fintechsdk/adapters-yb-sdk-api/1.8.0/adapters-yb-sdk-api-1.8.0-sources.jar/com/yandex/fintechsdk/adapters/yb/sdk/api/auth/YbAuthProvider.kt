package com.yandex.fintechsdk.adapters.yb.sdk.api.auth

import kotlinx.coroutines.flow.StateFlow

public interface YbAuthProvider {
    public fun getUidFlow(): StateFlow<Long?>
}
