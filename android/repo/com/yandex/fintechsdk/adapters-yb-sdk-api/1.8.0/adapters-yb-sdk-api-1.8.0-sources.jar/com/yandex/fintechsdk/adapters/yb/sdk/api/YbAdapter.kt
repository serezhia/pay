package com.yandex.fintechsdk.adapters.yb.sdk.api

import android.content.Context
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import com.yandex.fintechsdk.adapters.yb.sdk.api.auth.YbAuthProvider
import com.yandex.fintechsdk.entities.card.PayCard
import java.math.BigDecimal
import java.util.Locale

public interface YbAdapter {

    public fun init(
        context: Context,
        isTestEnvironment: Boolean,
        isNightMode: Boolean,
        authProvider: YbAuthProvider,
        userAgent: String,
        locale: Locale?,
    )

    public suspend fun openPayCard(fragmentActivity: FragmentActivity, container: ViewGroup)

    public suspend fun topUpPayCard(
        topUpSum: BigDecimal?,
        fragmentActivity: FragmentActivity,
        container: ViewGroup,
    )

    public suspend fun getPayCardInfo(): PayCard?
}
