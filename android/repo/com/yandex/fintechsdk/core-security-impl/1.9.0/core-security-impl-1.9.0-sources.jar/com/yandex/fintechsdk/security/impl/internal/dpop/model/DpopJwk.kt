package com.yandex.fintechsdk.security.impl.internal.dpop.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class DpopJwk(
    @SerialName("crv")
    val crv: String,

    @SerialName("kty")
    val kty: String,

    @SerialName("x")
    val x: String,

    @SerialName("y")
    val y: String,
)
