package com.yandex.fintechsdk.security.impl.internal.devicechallenge;

import android.content.Context;
import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.analytics.api.identifiers.IdentifiersProvider;
import com.yandex.fintechsdk.core.security.api.devicechallenge.DeviceChallengeFlagsProvider;
import com.yandex.fintechsdk.core.security.api.devicechallenge.UserUidProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceChallengeHelperImpl_Factory implements Factory<DeviceChallengeHelperImpl> {
  private final Provider<Analytics> analyticsProvider;

  private final Provider<Context> contextProvider;

  private final Provider<DeviceChallengeFlagsProvider> deviceChallengeFlagsProvider;

  private final Provider<IdentifiersProvider> identifiersProvider;

  private final Provider<UserUidProvider> userUidProvider;

  private DeviceChallengeHelperImpl_Factory(Provider<Analytics> analyticsProvider,
      Provider<Context> contextProvider,
      Provider<DeviceChallengeFlagsProvider> deviceChallengeFlagsProvider,
      Provider<IdentifiersProvider> identifiersProvider,
      Provider<UserUidProvider> userUidProvider) {
    this.analyticsProvider = analyticsProvider;
    this.contextProvider = contextProvider;
    this.deviceChallengeFlagsProvider = deviceChallengeFlagsProvider;
    this.identifiersProvider = identifiersProvider;
    this.userUidProvider = userUidProvider;
  }

  @Override
  public DeviceChallengeHelperImpl get() {
    return newInstance(analyticsProvider.get(), contextProvider.get(), deviceChallengeFlagsProvider.get(), identifiersProvider.get(), userUidProvider.get());
  }

  public static DeviceChallengeHelperImpl_Factory create(Provider<Analytics> analyticsProvider,
      Provider<Context> contextProvider,
      Provider<DeviceChallengeFlagsProvider> deviceChallengeFlagsProvider,
      Provider<IdentifiersProvider> identifiersProvider,
      Provider<UserUidProvider> userUidProvider) {
    return new DeviceChallengeHelperImpl_Factory(analyticsProvider, contextProvider, deviceChallengeFlagsProvider, identifiersProvider, userUidProvider);
  }

  public static DeviceChallengeHelperImpl newInstance(Analytics analytics, Context context,
      DeviceChallengeFlagsProvider deviceChallengeFlagsProvider,
      IdentifiersProvider identifiersProvider, UserUidProvider userUidProvider) {
    return new DeviceChallengeHelperImpl(analytics, context, deviceChallengeFlagsProvider, identifiersProvider, userUidProvider);
  }
}
