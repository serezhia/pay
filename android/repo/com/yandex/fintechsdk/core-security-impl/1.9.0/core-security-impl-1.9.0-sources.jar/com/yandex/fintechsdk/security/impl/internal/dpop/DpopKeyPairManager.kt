package com.yandex.fintechsdk.security.impl.internal.dpop

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyInfo
import android.security.keystore.KeyProperties
import android.security.keystore.StrongBoxUnavailableException
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.security.impl.internal.dpop.analytics.DpopInsecureKey
import com.yandex.fintechsdk.security.impl.internal.dpop.analytics.DpopKeyGenerated
import com.yandex.fintechsdk.core.utils.api.environment.DebugEnvironmentChecker
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.spec.ECGenParameterSpec
import javax.inject.Inject

internal class DpopKeyPairManager @Inject constructor(
    private val analytics: Analytics,
    private val debugEnvironmentChecker: DebugEnvironmentChecker,
) {

    fun loadOrCreateKeyPair(): KeyPair? {
        return loadKeyPair() ?: createKeyPair()
    }

    private fun loadKeyPair(): KeyPair? {
        val keyStore = getKeyStore()

        val entry = keyStore.getEntry(
            /* alias = */ DPOP_KEY_ALIAS,
            /* protParam = */ null,
        )

        if (entry !is KeyStore.PrivateKeyEntry) return null

        // Delete key, if its level of security is low
        if (!isSecure(privateKey = entry.privateKey)) {
            reportInsecureKeyEvent()
            deleteKeyFromKeystore()
            return null
        }

        return KeyPair(
            entry.certificate.publicKey,
            entry.privateKey,
        )
    }

    private fun createKeyPair(): KeyPair? {
        val keyPairGenerator = KeyPairGenerator.getInstance(
            /* algorithm = */ KeyProperties.KEY_ALGORITHM_EC,
            /* provider = */ ANDROID_KEYSTORE,
        )

        var spec: KeyGenParameterSpec?
        var keyPair: KeyPair? = null

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                // Try to use StrongBox key
                spec = getKeyGenSpecBuilder()
                    .setIsStrongBoxBacked(true)
                    .build()

                keyPairGenerator.initialize(spec)

                keyPair = keyPairGenerator.generateKeyPair()
            } catch (e: StrongBoxUnavailableException) {
                analytics.reportRuntimeError(
                    key = "dpop_strongbox_unavailable",
                    exception = e,
                )
                spec = getKeyGenSpecBuilder()
                    .build()

                keyPairGenerator.initialize(spec)

                keyPair = keyPairGenerator.generateKeyPair()
            }
        }

        keyPair ?: return null

        // Delete key, if its level of security is low
        if (!isSecure(privateKey = keyPair.private)) {
            reportInsecureKeyEvent()
            deleteKeyFromKeystore()
            return null
        }

        return keyPair.also {
            analytics.reportProductEvent(
                event = DpopKeyGenerated(),
            )
        }
    }

    private fun getKeyGenSpecBuilder(): KeyGenParameterSpec.Builder {
        return KeyGenParameterSpec.Builder(
            /* keystoreAlias = */ DPOP_KEY_ALIAS,
            /* purposes = */ KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY,
        ).apply {
            setAlgorithmParameterSpec(ECGenParameterSpec(CURVE))
            setDigests(KeyProperties.DIGEST_SHA256)
            setUserAuthenticationRequired(true)
            setInvalidatedByBiometricEnrollment(true)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // API 30+: use method with explicit authentication types
                setUserAuthenticationParameters(
                    /* timeout = */ USER_AUTHENTICATION_TIMEOUT_SECONDS,
                    /* type = */ KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL,
                )
            } else {
                // API 24-29: use deprecated method with timeout > 0
                // This automatically allows both biometric and device credentials (PIN/pattern/password)
                @Suppress("DEPRECATION")
                setUserAuthenticationValidityDurationSeconds(/* timeout = */ USER_AUTHENTICATION_TIMEOUT_SECONDS)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                setUnlockedDeviceRequired(true)
            }
        }
    }

    private fun isSecure(privateKey: PrivateKey): Boolean {
        if (shouldBypassSecurityCheck()) {
            return true
        }

        val keyFactory = KeyFactory.getInstance(
            /* algorithm = */ privateKey.algorithm,
            /* provider = */ ANDROID_KEYSTORE,
        )

        val info = keyFactory.getKeySpec(
            /* key = */ privateKey,
            /* keySpec = */ KeyInfo::class.java,
        )

        // Hardware-level security
        return info.isInsideSecureHardware
    }

    private fun shouldBypassSecurityCheck(): Boolean {
        return debugEnvironmentChecker.isDebugEnvironment()
    }

    private fun deleteKeyFromKeystore() {
        runCatching {
            val keyStore = getKeyStore()
            keyStore.deleteEntry(DPOP_KEY_ALIAS)
        }
    }

    private fun getKeyStore(): KeyStore {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
        keyStore.load(null)

        return keyStore
    }

    private fun reportInsecureKeyEvent() {
        analytics.reportProductEvent(
            event = DpopInsecureKey(),
        )
    }

    private companion object {
        // KeyStore values
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val DPOP_KEY_ALIAS = "dpopKey"

        // Key values
        private const val CURVE = "secp256r1"
        private const val USER_AUTHENTICATION_TIMEOUT_SECONDS = 300
    }
}
