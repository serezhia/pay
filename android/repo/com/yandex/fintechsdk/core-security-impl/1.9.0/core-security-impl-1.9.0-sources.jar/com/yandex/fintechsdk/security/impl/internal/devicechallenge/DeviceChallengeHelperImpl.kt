package com.yandex.fintechsdk.security.impl.internal.devicechallenge

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.analytics.api.identifiers.IdentifiersProvider
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.security.api.devicechallenge.DeviceChallengeFlagsProvider
import com.yandex.fintechsdk.core.security.api.devicechallenge.DeviceChallengeHelper
import com.yandex.fintechsdk.core.security.api.devicechallenge.UserUidProvider
import com.yandex.fintechsdk.resources.api.ResStrings
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometryAvailableOnDevice
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometryGenerateKeyPairError
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometryGenerateKeyPairStart
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometryGenerateKeyPairSuccess
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometryPublicKeyExists
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometrySignatureData
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometrySignatureError
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometrySignatureStart
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometrySignatureSuccess
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey
import java.security.Signature
import java.util.concurrent.TimeUnit
import javax.inject.Inject

private const val KEY_STORE_TYPE = "AndroidKeyStore"
private const val CRYPTO_MODE_ECDSA = "SHA256withECDSA"

private const val KEY_PURCHASE_TOKEN = "purchase_token"
private const val KEY_PAYMENT_METHOD_ID = "payment_method_id"
private const val KEY_TIMESTAMP = "timestamp"

private const val ERROR_KEY_PAIR_GENERATION_FAILED = "KeyPairGenerator.generateKeyPair() returned null"
private const val ERROR_ANDROID_VERSION_LOWER = "Android version lower"

internal class DeviceChallengeHelperImpl @Inject constructor(
    private val analytics: Analytics,
    @ApplicationContext private val context: Context,
    private val deviceChallengeFlagsProvider: DeviceChallengeFlagsProvider,
    private val identifiersProvider: IdentifiersProvider,
    private val userUidProvider: UserUidProvider,
): DeviceChallengeHelper {
    override fun getPublicKeyBase64(): String? {
        if (!deviceChallengeFlagsProvider.isBiometryEnabled()) {
            return null
        }

        val isBiometryAvailable = isBiometryAvailable()

        analytics.reportProductEvent(
            event = BiometryAvailableOnDevice(
                isAvailable = isBiometryAvailable,
            ),
        )

        if (isBiometryAvailable) {
            getPublicKeyECDSA()?.let { publicKey ->
                return Base64.encodeToString(publicKey.encoded, Base64.NO_WRAP)
            }
        }

        return null
    }

    override fun getSignature(
        activity: FragmentActivity,
        deviceChallengePostDelay: Int,
        deviceChallengeStartDelay: Int,
        paymentMethodId: String,
        purchaseToken: String,
        completion: (data: String?, signature: String?) -> Unit,
    ) {
        if (!deviceChallengeFlagsProvider.isBiometryEnabled() || !isBiometryAvailable()) {
            completion(null, null)
            return
        }

        val data = getSignatureData(purchaseToken = purchaseToken, paymentMethodId = paymentMethodId)
        val dataBase64 = Base64.encodeToString(data, Base64.NO_WRAP)

        analytics.reportProductEvent(event = BiometrySignatureStart)

        activity.lifecycleScope.launch {
            delayIfNeeded(delay = deviceChallengeStartDelay)
            val signature = buildSignature()
            openBiometryScreen(
                activity = activity,
                cryptoObject = BiometricPrompt.CryptoObject(signature),
                onSuccess = { cryptoObject ->
                    onBiometrySuccess(
                        activity = activity,
                        cryptoObject = cryptoObject,
                        data = data,
                        dataBase64 = dataBase64,
                        delay = deviceChallengePostDelay,
                        completion = completion,
                    )
                },
                onFailure = {
                    completionWithDelay(
                        activity = activity,
                        data = dataBase64,
                        delay = deviceChallengePostDelay,
                        signature = null,
                        completion = completion,
                    )
                },
            )
        }
    }

    private fun onBiometrySuccess(
        activity: FragmentActivity,
        cryptoObject: BiometricPrompt.CryptoObject,
        data: ByteArray,
        dataBase64: String,
        delay: Int,
        completion: (data: String?, signature: String?) -> Unit,
    ) {
        try {
            cryptoObject.signature?.let { authSignature ->
                val signatureBase64 = signatureToBase64(signature = authSignature, data = data)
                reportSignatureSuccess(signature = signatureBase64)
                completionWithDelay(
                    activity = activity,
                    data = dataBase64,
                    delay = delay,
                    signature = signatureBase64,
                    completion = completion,
                )
            }
        } catch (e: Exception) {
            reportSignatureError(error = e.message.toString())
            completionWithDelay(
                activity = activity,
                data = dataBase64,
                delay = delay,
                signature = null,
                completion = completion,
            )
        }
    }

    private fun completionWithDelay(
        activity: FragmentActivity,
        data: String,
        delay: Int,
        signature: String?,
        completion: (data: String?, signature: String?) -> Unit,
    ) {
        activity.lifecycleScope.launch {
            delayIfNeeded(delay = delay)
            completion(data, signature)
        }
    }

    private suspend fun delayIfNeeded(delay: Int) {
        if (delay > 0) {
            delay(delay.toLong())
        }
    }

    private fun reportSignatureSuccess(signature: String) {
        analytics.reportProductEvent(
            event = BiometrySignatureSuccess(
                signature = signature,
            ),
        )
    }

    private fun reportSignatureError(error: String) {
        analytics.reportProductEvent(
            event = BiometrySignatureError(
                error = error,
            ),
        )
    }

    private fun getPublicKeyECDSA(): PublicKey? {
        try {
            if (hasKey()) {
                analytics.reportProductEvent(event = BiometryPublicKeyExists)
                val publicKey = getPublicKey()
                return publicKey
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                analytics.reportProductEvent(event = BiometryGenerateKeyPairStart)
                val publicKey = generateKeyPairAndGetPublicKey()
                if (publicKey != null) {
                    analytics.reportProductEvent(event = BiometryGenerateKeyPairSuccess)
                } else {
                    reportKeyPairGenerationError(error = ERROR_KEY_PAIR_GENERATION_FAILED)
                }
                return publicKey
            } else {
                reportKeyPairGenerationError(error = "$ERROR_ANDROID_VERSION_LOWER ${Build.VERSION_CODES.M}")
                return null
            }
        } catch (e: Exception) {
            reportKeyPairGenerationError(error = e.message.toString())
            return null
        }
    }

    private fun generateKeyPairAndGetPublicKey(): PublicKey? {
        val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, KEY_STORE_TYPE)
        val builder = KeyGenParameterSpec.Builder(getAlias(), KeyProperties.PURPOSE_SIGN).run {
            setDigests(KeyProperties.DIGEST_SHA256)
            setUserAuthenticationRequired(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                setUserAuthenticationParameters(
                    0,
                    KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL,
                )
            } else {
                @Suppress("DEPRECATION")
                setUserAuthenticationValidityDurationSeconds(-1)
            }
        }
        kpg.initialize(builder.build())
        return kpg.generateKeyPair().public
    }

    private fun reportKeyPairGenerationError(error: String) {
        analytics.reportProductEvent(
            event = BiometryGenerateKeyPairError(
                error = error,
            ),
        )
    }

    private fun getAlias(): String {
        return "${userUidProvider.getUserUid()}-${identifiersProvider.getUuid().orEmpty()}"
    }

    private fun isBiometryAvailable(): Boolean {
        val bm = BiometricManager.from(context)
        val canAuthenticate = bm.canAuthenticate(BIOMETRIC_STRONG)
        return canAuthenticate == BiometricManager.BIOMETRIC_SUCCESS
    }

    private fun hasKey(): Boolean {
        return getKeyStore().containsAlias(getAlias())
    }

    private fun getKeyStore(): KeyStore {
        return KeyStore.getInstance(KEY_STORE_TYPE).apply { load(null) }
    }

    private fun getPublicKey(): PublicKey {
        val ks = getKeyStore()
        val cert = ks.getCertificate(getAlias())
        return cert.publicKey
    }

    private fun getPrivateKey(): PrivateKey {
        val ks = getKeyStore()
        val entry = ks.getEntry(getAlias(), null) as KeyStore.PrivateKeyEntry
        return entry.privateKey
    }

    private fun getSignatureData(purchaseToken: String, paymentMethodId: String): ByteArray {
        val json = JSONObject().apply {
            put(KEY_PURCHASE_TOKEN, purchaseToken)
            put(KEY_PAYMENT_METHOD_ID, paymentMethodId)
            put(KEY_TIMESTAMP, TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()))
        }
        val jsonString = json.toString()

        analytics.reportProductEvent(
            event = BiometrySignatureData(
                data = jsonString,
            ),
        )

        return jsonString.toByteArray(Charsets.UTF_8)
    }

    private fun openBiometryScreen(
        activity: FragmentActivity,
        cryptoObject: BiometricPrompt.CryptoObject,
        onSuccess: (BiometricPrompt.CryptoObject) -> Unit,
        onFailure: () -> Unit,
    ) {
        BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            DeviceChallengeAuthenticationCallback(
                analytics = analytics,
                onFailure = onFailure,
                onSuccess = onSuccess,
            ),
        ).authenticate(
            getPromptInfo(),
            cryptoObject,
        )
    }

    private fun signatureToBase64(signature: Signature, data: ByteArray): String {
        signature.update(data)
        val sign = signature.sign()
        return Base64.encodeToString(sign, Base64.NO_WRAP)
    }

    private fun buildSignature(): Signature {
        val privateKey = getPrivateKey()
        val signature = Signature.getInstance(CRYPTO_MODE_ECDSA)
        signature.initSign(privateKey)
        return signature
    }

    private fun getPromptInfo(): BiometricPrompt.PromptInfo {
        val title = context.getString(ResStrings.finsdk_confirm_the_payment)
        val buttonText = context.getString(ResStrings.finsdk_cancel)

        return BiometricPrompt.PromptInfo.Builder()
            .setTitle(title).run {
                when (deviceChallengeFlagsProvider.isBiometryWithPasswordEnabled()) {
                    true -> setAllowedAuthenticators(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)
                    false -> setAllowedAuthenticators(BIOMETRIC_STRONG)
                        .setNegativeButtonText(buttonText)
                }
            }
            .build()
    }
}
