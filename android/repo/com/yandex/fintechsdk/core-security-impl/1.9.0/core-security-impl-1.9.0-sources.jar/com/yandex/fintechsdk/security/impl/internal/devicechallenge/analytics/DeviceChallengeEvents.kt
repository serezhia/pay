package com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics

import com.yandex.fintechsdk.core.analytics.api.event.Event

private const val KEY_DESCRIPTION = "description"
private const val KEY_ERROR_CODE = "error_code"
private const val KEY_REASON = "reason"
private const val KEY_SIGNATURE = "signature"
private const val KEY_VALUE = "value"

private const val NAME_BIOMETRY_AVAILABLE_ON_DEVICE = "biometry_available_on_device"
private const val NAME_BIOMETRY_PUBLIC_KEY_EXISTS = "biometry_public_key_exists"
private const val NAME_BIOMETRY_GENERATE_KEY_PAIR_START = "biometry_generate_key_pair_start"
private const val NAME_BIOMETRY_GENERATE_KEY_PAIR_SUCCESS = "biometry_generate_key_pair_success"
private const val NAME_BIOMETRY_GENERATE_KEY_PAIR_ERROR = "biometry_generate_key_pair_error"
private const val NAME_BIOMETRY_SIGNATURE_START = "biometry_signature_start"
private const val NAME_BIOMETRY_SIGNATURE_SUCCESS = "biometry_signature_success"
private const val NAME_BIOMETRY_SIGNATURE_ERROR = "biometry_signature_error"
private const val NAME_BIOMETRY_SIGNATURE_DATA = "biometry_signature_data"

private const val DESCRIPTION_BIOMETRY_AVAILABLE_ON_DEVICE = "Доступна ли биометрия на устройстве"
private const val DESCRIPTION_BIOMETRY_PUBLIC_KEY_EXISTS = "Публичный ключ существует"
private const val DESCRIPTION_BIOMETRY_GENERATE_KEY_PAIR_START = "Начало генерации ключевой пары"
private const val DESCRIPTION_BIOMETRY_GENERATE_KEY_PAIR_SUCCESS = "Успешная генерации ключевой пары"
private const val DESCRIPTION_BIOMETRY_GENERATE_KEY_PAIR_ERROR = "Ошибка генерации ключевой пары"
private const val DESCRIPTION_BIOMETRY_SIGNATURE_START = "Начало формирования подписи"
private const val DESCRIPTION_BIOMETRY_SIGNATURE_SUCCESS = "Успешное формирование подписи"
private const val DESCRIPTION_BIOMETRY_SIGNATURE_ERROR = "Ошибка формирования подписи"
private const val DESCRIPTION_BIOMETRY_SIGNATURE_DATA = "Данные для подписания"

private const val SECURE_SIGNATURE_LENGTH = 10

internal data class BiometryAvailableOnDevice(
    val isAvailable: Boolean,
) : Event(
    name = NAME_BIOMETRY_AVAILABLE_ON_DEVICE,
    params = mapOf(
        KEY_DESCRIPTION
            to "${DESCRIPTION_BIOMETRY_AVAILABLE_ON_DEVICE}: ${if (isAvailable) "доступна" else "не доступна"}",
        KEY_VALUE to isAvailable.toString(),
    ),
)

internal data object BiometryPublicKeyExists : Event(
    name = NAME_BIOMETRY_PUBLIC_KEY_EXISTS,
    params = mapOf(
        KEY_DESCRIPTION to DESCRIPTION_BIOMETRY_PUBLIC_KEY_EXISTS,
    ),
)

internal data object BiometryGenerateKeyPairStart : Event(
    name = NAME_BIOMETRY_GENERATE_KEY_PAIR_START,
    params = mapOf(
        KEY_DESCRIPTION to DESCRIPTION_BIOMETRY_GENERATE_KEY_PAIR_START,
    ),
)

internal data object BiometryGenerateKeyPairSuccess : Event(
    name = NAME_BIOMETRY_GENERATE_KEY_PAIR_SUCCESS,
    params = mapOf(
        KEY_DESCRIPTION to DESCRIPTION_BIOMETRY_GENERATE_KEY_PAIR_SUCCESS,
    ),
)

internal data class BiometryGenerateKeyPairError(
    val error: String,
) : Event(
    name = NAME_BIOMETRY_GENERATE_KEY_PAIR_ERROR,
    params = mapOf(
        KEY_DESCRIPTION to "$DESCRIPTION_BIOMETRY_GENERATE_KEY_PAIR_ERROR: $error",
        KEY_REASON to error,
    ),
)

internal data object BiometrySignatureStart : Event(
    name = NAME_BIOMETRY_SIGNATURE_START,
    params = mapOf(
        KEY_DESCRIPTION to DESCRIPTION_BIOMETRY_SIGNATURE_START,
    ),
)

internal data class BiometrySignatureSuccess(
    val signature: String,
) : Event(
    name = NAME_BIOMETRY_SIGNATURE_SUCCESS,
    params = mapOf(
        KEY_DESCRIPTION to "$DESCRIPTION_BIOMETRY_SIGNATURE_SUCCESS: ${getSecureSignature(signature = signature)}",
        KEY_SIGNATURE to getSecureSignature(signature = signature),
    ),
)

internal data class BiometrySignatureError(
    val error: String,
) : Event(
    name = NAME_BIOMETRY_SIGNATURE_ERROR,
    params = mapOf(
        KEY_DESCRIPTION to "$DESCRIPTION_BIOMETRY_SIGNATURE_ERROR: $error",
        KEY_REASON to error,
    ),
)

internal data class BiometrySignatureErrorWithCode(
    val error: String,
    val errorCode: Int
) : Event(
    name = NAME_BIOMETRY_SIGNATURE_ERROR,
    params = mapOf(
        KEY_DESCRIPTION to "$DESCRIPTION_BIOMETRY_SIGNATURE_ERROR: $error, $KEY_ERROR_CODE = $errorCode",
        KEY_REASON to error,
        KEY_ERROR_CODE to errorCode.toString(),
    ),
)

internal data class BiometrySignatureData(
    val data: String,
) : Event(
    name = NAME_BIOMETRY_SIGNATURE_DATA,
    params = mapOf(
        KEY_DESCRIPTION to "$DESCRIPTION_BIOMETRY_SIGNATURE_DATA: $data",
        KEY_VALUE to data,
    ),
)

private fun getSecureSignature(signature: String): String {
    return signature.take(SECURE_SIGNATURE_LENGTH) + "***"
}
