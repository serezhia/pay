package com.yandex.fintechsdk.security.impl.internal.dpop

import android.security.keystore.UserNotAuthenticatedException
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.utils.api.time.millisToSeconds
import com.yandex.fintechsdk.resources.api.ResStrings
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.SignatureException
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executor
import javax.inject.Inject

internal class DpopHeaderCreator @Inject constructor(
    private val analytics: Analytics,
    private val encoder: DpopEncoder,
) {

    suspend fun createDpopHeader(
        activity: FragmentActivity,
        authToken: String,
        jwk: String,
        method: String,
        path: String,
        privateKey: PrivateKey,
    ): String {
        val headerJson = createHeaderJson(jwk = jwk)

        val payloadJson = createPayloadJson(
            authToken = authToken,
            method = method,
            path = path,
        )

        val headerEncoded = encoder.toBase64String(byteArray = headerJson.toByteArray())
        val payloadEncoded = encoder.toBase64String(byteArray = payloadJson.toByteArray())

        val signingInput = "$headerEncoded.$payloadEncoded".toByteArray()

        // signed is in DER format (Distinguished Encoding Rules)
        val signed = awaitSign(activity = activity, privateKey = privateKey, signingInput = signingInput)
        val signatureRaw = encoder.ecdsaToJose(array = signed, size = 32)
        val sb64 = encoder.toBase64String(byteArray = signatureRaw)

        return "$headerEncoded.$payloadEncoded.$sb64" // DPoP header.payload.signature
    }

    private fun createHeaderJson(jwk: String): String {
        return JSONObject().apply {
            put(HEADER_TYPE_KEY, HEADER_TYPE_VALUE)
            put(HEADER_ALGORITHM_KEY, HEADER_ALGORITHM_VALUE)
            put(HEADER_JWK_KEY, JSONObject(jwk))
        }.toString()
    }

    private fun createPayloadJson(
        authToken: String,
        method: String,
        path: String,
    ): String {
        return JSONObject().apply {
            put(PAYLOAD_METHOD_KEY, method.uppercase(Locale.ROOT))
            put(PAYLOAD_PATH_KEY, path)
            put(PAYLOAD_ISSUED_AT_KEY, System.currentTimeMillis().millisToSeconds())
            put(PAYLOAD_JWT_ID_KEY, UUID.randomUUID().toString())
            put(PAYLOAD_AUTHENTICATION_TOKEN_KEY, createAuthTokenValue(authToken = authToken))
        }.toString()
    }

    private fun createAuthTokenValue(authToken: String): String {
        val sha256 = sha256(byteArray = authToken.toByteArray())

        return encoder.toBase64String(byteArray = sha256)
    }

    private fun sha256(byteArray: ByteArray): ByteArray {
        return MessageDigest.getInstance(SHA256).digest(byteArray)
    }

    private suspend fun awaitSign(activity: FragmentActivity, privateKey: PrivateKey, signingInput: ByteArray): ByteArray {
        // Try silent sign first (within DEVICE_CREDENTIAL auth window)
        return try {
            sign(privateKey = privateKey, signingInput = signingInput)
        } catch (e: UserNotAuthenticatedException) {
            // For auth exceptions show biometric prompt
            awaitBiometricPrompt(activity = activity) {
                sign(privateKey = privateKey, signingInput = signingInput)
            }
        } catch (e: SignatureException) {
            // For auth exceptions show biometric prompt
            awaitBiometricPrompt(activity = activity) {
                sign(privateKey = privateKey, signingInput = signingInput)
            }
        }
    }

    private suspend fun awaitBiometricPrompt(
        activity: FragmentActivity,
        sign: () -> ByteArray,
    ): ByteArray = suspendCancellableCoroutine { continuation ->
        val executor: Executor = ContextCompat.getMainExecutor(activity)

        val callback = DpopBiometricPromptCallback(
            analytics = analytics,
            continuation = continuation,
            sign = sign,
        )

        val prompt = BiometricPrompt(activity, executor, callback)

        val title = activity.getString(ResStrings.finsdk_pass_the_verification)
        val subtitle = activity.getString(ResStrings.finsdk_to_use_the_quick_payment)

        val info = BiometricPrompt.PromptInfo.Builder()
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .setConfirmationRequired(false)
            .setTitle(title)
            .setSubtitle(subtitle)
            // Don't use setNegativeButtonText() - incompatible with DEVICE_CREDENTIAL
            // System will add cancel button and PIN fallback button automatically
            .build()

        prompt.authenticate(info)
        continuation.invokeOnCancellation { prompt.cancelAuthentication() }
    }

    private fun sign(privateKey: PrivateKey, signingInput: ByteArray): ByteArray {
        val signature = Signature.getInstance(SHA256_WITH_ECDSA).apply {
            initSign(privateKey)
            update(signingInput)
        }
        return signature.sign()
    }

    private companion object {
        // Algorithms
        private const val SHA256 = "SHA256"
        private const val SHA256_WITH_ECDSA = "SHA256withECDSA"

        // Header values
        private const val HEADER_ALGORITHM_KEY = "alg"
        private const val HEADER_ALGORITHM_VALUE = "ES256"
        private const val HEADER_JWK_KEY = "jwk"
        private const val HEADER_TYPE_KEY = "typ"
        private const val HEADER_TYPE_VALUE = "dpop+jwt"

        // Payload values
        private const val PAYLOAD_AUTHENTICATION_TOKEN_KEY = "ath"
        private const val PAYLOAD_ISSUED_AT_KEY = "iat"
        private const val PAYLOAD_JWT_ID_KEY = "jti"
        private const val PAYLOAD_METHOD_KEY = "htm"
        private const val PAYLOAD_PATH_KEY = "htu"
    }
}
