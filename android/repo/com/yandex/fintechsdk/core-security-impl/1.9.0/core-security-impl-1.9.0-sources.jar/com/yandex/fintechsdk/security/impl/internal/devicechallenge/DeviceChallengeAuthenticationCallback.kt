package com.yandex.fintechsdk.security.impl.internal.devicechallenge

import androidx.biometric.BiometricPrompt
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometrySignatureError
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.analytics.BiometrySignatureErrorWithCode

private const val ERROR_AUTHENTICATION_FAILED = "AuthenticationFailed"
private const val ERROR_CRYPTO_OBJECT_IS_NULL = "CryptoObject is null"

internal class DeviceChallengeAuthenticationCallback(
    private val analytics: Analytics,
    private val onFailure: () -> Unit,
    private val onSuccess: (BiometricPrompt.CryptoObject) -> Unit,
) : BiometricPrompt.AuthenticationCallback() {
    override fun onAuthenticationError(
        errorCode: Int,
        errString: CharSequence
    ) {
        super.onAuthenticationError(errorCode, errString)
        reportError(error = errString.toString(), errorCode = errorCode)
        onFailure()
    }

    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
        super.onAuthenticationSucceeded(result)
        result.cryptoObject?.let {
            onSuccess(it)
        } ?: {
            reportError(error = ERROR_CRYPTO_OBJECT_IS_NULL)
        }
    }

    override fun onAuthenticationFailed() {
        super.onAuthenticationFailed()
        reportError(error = ERROR_AUTHENTICATION_FAILED)
    }

    private fun reportError(error: String) {
        analytics.reportProductEvent(
            event = BiometrySignatureError(
                error = error,
            ),
        )
    }

    private fun reportError(error: String, errorCode: Int) {
        analytics.reportProductEvent(
            event = BiometrySignatureErrorWithCode(
                error = error,
                errorCode = errorCode,
            ),
        )
    }
}
