package com.yandex.fintechsdk.security.impl.internal.dpop

import com.yandex.fintechsdk.security.impl.internal.dpop.model.DpopJwk
import java.math.BigInteger
import java.security.interfaces.ECPublicKey
import javax.inject.Inject

internal class DpopJwkCreator @Inject constructor(
    private val encoder: DpopEncoder,
) {

    fun createJwk(publicKey: ECPublicKey): DpopJwk {
        val x = bigIntToFixedByteArray(bigint = publicKey.w.affineX)
        val y = bigIntToFixedByteArray(bigint = publicKey.w.affineY)
        return DpopJwk(
            crv = JWK_CURVE_VALUE,
            kty = JWK_KEY_TYPE_VALUE,
            x = encoder.toBase64String(byteArray = x),
            y = encoder.toBase64String(byteArray = y),
        )
    }

    private fun bigIntToFixedByteArray(bigint: BigInteger): ByteArray {
        val bytes = bigint.toByteArray()
        return when {
            bytes.size == JWK_BIG_INT_MAX_SIZE_BYTES -> bytes
            bytes.size == JWK_BIG_INT_MAX_SIZE_BYTES + 1 && bytes[0] == 0.toByte() -> bytes.copyOfRange(1, bytes.size)
            bytes.size < JWK_BIG_INT_MAX_SIZE_BYTES -> ByteArray(JWK_BIG_INT_MAX_SIZE_BYTES - bytes.size) + bytes
            else -> bytes.copyOfRange(bytes.size - JWK_BIG_INT_MAX_SIZE_BYTES, bytes.size)
        }
    }

    private companion object {
        // Jwk values
        private const val JWK_BIG_INT_MAX_SIZE_BYTES = 32
        private const val JWK_KEY_TYPE_VALUE = "EC"
        private const val JWK_CURVE_VALUE = "P-256"
    }
}
