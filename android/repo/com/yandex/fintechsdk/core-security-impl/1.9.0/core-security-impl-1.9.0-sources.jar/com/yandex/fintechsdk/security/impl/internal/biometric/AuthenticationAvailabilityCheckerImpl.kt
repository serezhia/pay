package com.yandex.fintechsdk.security.impl.internal.biometric

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED
import androidx.biometric.BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE
import androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS
import androidx.core.content.ContextCompat
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.security.api.biometric.AuthenticationAvailabilityChecker
import com.yandex.fintechsdk.core.security.api.biometric.AuthenticationStatus
import javax.inject.Inject

internal class AuthenticationAvailabilityCheckerImpl @Inject constructor(
    @ApplicationContext private val context: Context,
) : AuthenticationAvailabilityChecker {

    override fun checkAuthenticationAvailability(): AuthenticationStatus {
        val biometricManager = BiometricManager.from(context)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            checkAuthenticationAvailabilityModern(biometricManager)
        } else {
            checkAuthenticationAvailabilityLegacy(biometricManager)
        }
    }

    private fun checkAuthenticationAvailabilityModern(biometricManager: BiometricManager): AuthenticationStatus {
        // Android 11+: Use combined authenticators (BIOMETRIC_STRONG or DEVICE_CREDENTIAL)
        return when (biometricManager.canAuthenticate(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)) {
            BIOMETRIC_SUCCESS -> AuthenticationStatus.Available
            BIOMETRIC_ERROR_NO_HARDWARE -> AuthenticationStatus.NoHardware
            BIOMETRIC_ERROR_NONE_ENROLLED -> AuthenticationStatus.NotEnrolled
            else -> AuthenticationStatus.Unavailable
        }
    }

    private fun checkAuthenticationAvailabilityLegacy(biometricManager: BiometricManager): AuthenticationStatus {
        // Android 10 and below: Check biometric first, then fallback to device credentials
        val biometricStatus = biometricManager.canAuthenticate(BIOMETRIC_STRONG)
        return when {
            biometricStatus == BIOMETRIC_SUCCESS -> AuthenticationStatus.Available
            biometricStatus == BIOMETRIC_ERROR_NO_HARDWARE && isDeviceSecure() -> AuthenticationStatus.Available
            biometricStatus == BIOMETRIC_ERROR_NONE_ENROLLED && isDeviceSecure() -> AuthenticationStatus.Available
            biometricStatus == BIOMETRIC_ERROR_NO_HARDWARE -> AuthenticationStatus.NoHardware
            biometricStatus == BIOMETRIC_ERROR_NONE_ENROLLED -> AuthenticationStatus.NotEnrolled
            else -> AuthenticationStatus.Unavailable
        }
    }

    private fun isDeviceSecure(): Boolean {
        val keyguardManager = ContextCompat.getSystemService(context, KeyguardManager::class.java)
        return keyguardManager?.isDeviceSecure ?: false
    }
}

