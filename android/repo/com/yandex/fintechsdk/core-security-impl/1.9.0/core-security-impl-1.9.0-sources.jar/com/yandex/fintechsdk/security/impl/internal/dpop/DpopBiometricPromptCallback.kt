package com.yandex.fintechsdk.security.impl.internal.dpop

import androidx.biometric.BiometricPrompt
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.security.impl.internal.dpop.analytics.DpopBiometricPromptFailure
import com.yandex.fintechsdk.security.impl.internal.dpop.analytics.DpopBiometricPromptSuccess
import kotlinx.coroutines.CancellableContinuation
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal class DpopBiometricPromptCallback(
    private val analytics: Analytics,
    private val continuation: CancellableContinuation<ByteArray>,
    private val sign: () -> ByteArray,
) : BiometricPrompt.AuthenticationCallback() {

    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
        try {
            val signed = sign()
            analytics.reportProductEvent(
                event = DpopBiometricPromptSuccess(),
            )
            continuation.resume(signed)
        } catch (exception: Throwable) {
            analytics.reportProductEvent(event = DpopBiometricPromptFailure())
            analytics.reportRuntimeError(key = ERROR_EVENT_KEY, exception = exception)
            continuation.resumeWithException(exception)
        }
    }

    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
        val exception = RuntimeException(errString.toString())

        analytics.reportProductEvent(event = DpopBiometricPromptFailure())
        analytics.reportRuntimeError(key = ERROR_EVENT_KEY, exception = exception)

        continuation.resumeWithException(exception = exception)
    }

    private companion object {
        const val ERROR_EVENT_KEY = "dpop_biometric_prompt_exception"
    }
}
