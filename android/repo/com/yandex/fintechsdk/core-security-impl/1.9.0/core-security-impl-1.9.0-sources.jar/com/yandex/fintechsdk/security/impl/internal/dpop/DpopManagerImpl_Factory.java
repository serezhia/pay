package com.yandex.fintechsdk.security.impl.internal.dpop;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DpopManagerImpl_Factory implements Factory<DpopManagerImpl> {
  private final Provider<DpopHeaderCreator> headerCreatorProvider;

  private final Provider<DpopJwkCreator> jwkCreatorProvider;

  private final Provider<DpopKeyPairManager> keyPairManagerProvider;

  private DpopManagerImpl_Factory(Provider<DpopHeaderCreator> headerCreatorProvider,
      Provider<DpopJwkCreator> jwkCreatorProvider,
      Provider<DpopKeyPairManager> keyPairManagerProvider) {
    this.headerCreatorProvider = headerCreatorProvider;
    this.jwkCreatorProvider = jwkCreatorProvider;
    this.keyPairManagerProvider = keyPairManagerProvider;
  }

  @Override
  public DpopManagerImpl get() {
    return newInstance(headerCreatorProvider.get(), jwkCreatorProvider.get(), keyPairManagerProvider.get());
  }

  public static DpopManagerImpl_Factory create(Provider<DpopHeaderCreator> headerCreatorProvider,
      Provider<DpopJwkCreator> jwkCreatorProvider,
      Provider<DpopKeyPairManager> keyPairManagerProvider) {
    return new DpopManagerImpl_Factory(headerCreatorProvider, jwkCreatorProvider, keyPairManagerProvider);
  }

  public static DpopManagerImpl newInstance(DpopHeaderCreator headerCreator,
      DpopJwkCreator jwkCreator, DpopKeyPairManager keyPairManager) {
    return new DpopManagerImpl(headerCreator, jwkCreator, keyPairManager);
  }
}
