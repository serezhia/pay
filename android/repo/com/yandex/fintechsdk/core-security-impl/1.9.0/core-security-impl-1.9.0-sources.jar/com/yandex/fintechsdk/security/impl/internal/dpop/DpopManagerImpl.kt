package com.yandex.fintechsdk.security.impl.internal.dpop

import androidx.fragment.app.FragmentActivity
import com.yandex.fintechsdk.core.security.api.dpop.DpopManager
import com.yandex.fintechsdk.core.security.api.dpop.Jwk
import kotlinx.serialization.json.Json
import java.security.interfaces.ECPublicKey
import java.util.Locale
import javax.inject.Inject

internal class DpopManagerImpl @Inject constructor(
    private val headerCreator: DpopHeaderCreator,
    private val jwkCreator: DpopJwkCreator,
    private val keyPairManager: DpopKeyPairManager,
): DpopManager {

    override fun getDpopJwk(): Result<Jwk> {
        val keyPair = keyPairManager.loadOrCreateKeyPair() ?: return Result.failure(
            IllegalStateException("KeyPair is null"),
        )

        val publicKey = keyPair.public as? ECPublicKey ?: return Result.failure(
            exception = IllegalStateException("Public key is not ECPublicKey"),
        )

        val dpopJwk = jwkCreator.createJwk(publicKey = publicKey)

        return Result.success(
            value = Jwk(
                crv = dpopJwk.crv,
                kty = dpopJwk.kty,
                x = dpopJwk.x,
                y = dpopJwk.y,
            ),
        )
    }

    override suspend fun createDpopHeader(
        activity: FragmentActivity,
        authToken: String,
        restMethod: String,
        path: String,
    ): Result<String> {
        val keyPair = keyPairManager.loadOrCreateKeyPair() ?: return Result.failure(
            IllegalStateException("KeyPair is null"),
        )

        val publicKey = keyPair.public as? ECPublicKey ?: return Result.failure(
            exception = IllegalStateException("Public key is not ECPublicKey"),
        )

        val jwk = jwkCreator.createJwk(publicKey = publicKey)

        return Result.success(
            value = headerCreator.createDpopHeader(
                activity = activity,
                authToken = authToken,
                jwk = Json.encodeToString(value = jwk),
                method = restMethod.uppercase(Locale.ROOT),
                path = path,
                privateKey = keyPair.private,
            ),
        )
    }
}
