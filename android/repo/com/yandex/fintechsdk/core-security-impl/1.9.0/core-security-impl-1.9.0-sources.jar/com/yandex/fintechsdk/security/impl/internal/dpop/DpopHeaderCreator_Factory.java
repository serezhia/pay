package com.yandex.fintechsdk.security.impl.internal.dpop;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DpopHeaderCreator_Factory implements Factory<DpopHeaderCreator> {
  private final Provider<Analytics> analyticsProvider;

  private final Provider<DpopEncoder> encoderProvider;

  private DpopHeaderCreator_Factory(Provider<Analytics> analyticsProvider,
      Provider<DpopEncoder> encoderProvider) {
    this.analyticsProvider = analyticsProvider;
    this.encoderProvider = encoderProvider;
  }

  @Override
  public DpopHeaderCreator get() {
    return newInstance(analyticsProvider.get(), encoderProvider.get());
  }

  public static DpopHeaderCreator_Factory create(Provider<Analytics> analyticsProvider,
      Provider<DpopEncoder> encoderProvider) {
    return new DpopHeaderCreator_Factory(analyticsProvider, encoderProvider);
  }

  public static DpopHeaderCreator newInstance(Analytics analytics, DpopEncoder encoder) {
    return new DpopHeaderCreator(analytics, encoder);
  }
}
