package com.yandex.fintechsdk.security.impl.internal.dpop;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DpopEncoder_Factory implements Factory<DpopEncoder> {
  @Override
  public DpopEncoder get() {
    return newInstance();
  }

  public static DpopEncoder_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DpopEncoder newInstance() {
    return new DpopEncoder();
  }

  private static final class InstanceHolder {
    static final DpopEncoder_Factory INSTANCE = new DpopEncoder_Factory();
  }
}
