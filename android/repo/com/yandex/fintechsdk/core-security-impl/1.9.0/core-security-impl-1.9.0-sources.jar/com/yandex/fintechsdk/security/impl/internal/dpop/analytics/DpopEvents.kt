package com.yandex.fintechsdk.security.impl.internal.dpop.analytics

import com.yandex.fintechsdk.core.analytics.api.event.Event

internal class DpopKeyGenerated : Event(
    name = "dpop_key_generated",
)

internal class DpopInsecureKey : Event(
    name = "dpop_insecure_key",
)

internal class DpopBiometricPromptSuccess : Event(
    name = "dpop_biometric_prompt_success",
)

internal class DpopBiometricPromptFailure : Event(
    name = "dpop_biometric_prompt_failure",
)
