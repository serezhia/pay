package com.yandex.fintechsdk.security.impl.internal.biometric;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class AuthenticationAvailabilityCheckerImpl_Factory implements Factory<AuthenticationAvailabilityCheckerImpl> {
  private final Provider<Context> contextProvider;

  private AuthenticationAvailabilityCheckerImpl_Factory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public AuthenticationAvailabilityCheckerImpl get() {
    return newInstance(contextProvider.get());
  }

  public static AuthenticationAvailabilityCheckerImpl_Factory create(
      Provider<Context> contextProvider) {
    return new AuthenticationAvailabilityCheckerImpl_Factory(contextProvider);
  }

  public static AuthenticationAvailabilityCheckerImpl newInstance(Context context) {
    return new AuthenticationAvailabilityCheckerImpl(context);
  }
}
