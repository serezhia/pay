package com.yandex.fintechsdk.security.impl.api

import com.yandex.fintechsdk.core.security.api.biometric.AuthenticationAvailabilityChecker
import com.yandex.fintechsdk.core.security.api.devicechallenge.DeviceChallengeHelper
import com.yandex.fintechsdk.core.security.api.dpop.DpopManager
import com.yandex.fintechsdk.security.impl.internal.biometric.AuthenticationAvailabilityCheckerImpl
import com.yandex.fintechsdk.security.impl.internal.devicechallenge.DeviceChallengeHelperImpl
import com.yandex.fintechsdk.security.impl.internal.dpop.DpopManagerImpl
import dagger.Binds
import dagger.Module

@Module
public abstract class SecurityModule {

    @Binds
    internal abstract fun bindAuthenticationAvailabilityChecker(
        impl: AuthenticationAvailabilityCheckerImpl,
    ): AuthenticationAvailabilityChecker

    @Binds
    internal abstract fun bindDpopManager(impl: DpopManagerImpl): DpopManager

    @Binds
    internal abstract fun bindDeviceChallengeHelper(impl: DeviceChallengeHelperImpl): DeviceChallengeHelper
}
