package com.yandex.fintechsdk.security.impl.internal.dpop

import android.util.Base64
import javax.inject.Inject

internal class DpopEncoder @Inject constructor() {

    fun toBase64String(byteArray: ByteArray): String {
        return Base64.encodeToString(
            /* input = */ byteArray,
            /* flags = */ Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING,
        )
    }

    fun ecdsaToJose(array: ByteArray, size: Int): ByteArray {
        var offset = 0
        // Check that the first byte indicates a SEQUENCE in DER encoding
        require(array[offset++] == 0x30.toByte()) { "Not a SEQUENCE" }

        // Read the length of the SEQUENCE and update the offset
        val sequenceLen = readDerLength(array, offset).also { offset = it.second }.first

        // Verify that the SEQUENCE length matches the array size
        require(offset + sequenceLen == array.size) { "Invalid SEQUENCE length" }

        // r and s — are two parts of ECDSA-sign
        require(array[offset++] == 0x02.toByte()) { "Expected INTEGER (r)" }

        // Read the 'r' value
        val rLengthPair = readDerLength(der = array, offset)
        val rLength = rLengthPair.first
        offset = rLengthPair.second
        val rBytes = array.copyOfRange(fromIndex = offset, toIndex = offset + rLength)
        offset += rLength

        // Read the 's' value
        require(array[offset++] == 0x02.toByte()) { "Expected INTEGER (s)" }
        val sLengthPair = readDerLength(array, offset)
        val sLen = sLengthPair.first
        offset = sLengthPair.second
        val sBytes = array.copyOfRange(fromIndex = offset, toIndex = offset + sLen)

        // Process 'r' and 's' bytes by trimming leading zeros and adjusting the length
        val r = trimOrPadInteger(bytes = rBytes, size = size)
        val s = trimOrPadInteger(bytes = sBytes, size = size)

        return r + s
    }

    @Suppress("MagicNumber") // TODO: define numbers as well named constant
    private fun readDerLength(der: ByteArray, offset: Int): Pair<Int, Int> {
        var offset = offset

        // Read the first byte of the length and increment the offset
        val firstByte = der[offset++].toInt() and 0xFF

        // Return the length and offset if the length is one byte
        if ((firstByte and 0x80) == 0) {
            return firstByte to offset
        }

        // Determine the number of bytes for the length
        val numberOfBytes = firstByte and 0x7F
        var length = 0

        // Loop to read the remaining bytes of the length
        repeat(numberOfBytes) {
            // Combine the bytes into a single length value
            length = (length shl 8) or (der[offset++].toInt() and 0xFF)
        }

        // Return the calculated length and the updated offset
        return length to offset
    }

    private fun trimOrPadInteger(bytes: ByteArray, size: Int): ByteArray {
        var bytes = bytes
        // Loop to remove leading zeros
        while (bytes.isNotEmpty() && bytes[0] == 0.toByte()) {
            bytes = bytes.copyOfRange(1, bytes.size)
        }
        return when {
            // Return the array if its size matches the desired size
            bytes.size == size -> bytes

            // Pad the array with leading zeros if it's shorter than the desired size
            bytes.size < size -> ByteArray(size - bytes.size) + bytes

            // Trim the array to the desired size if it's longer
            else -> bytes.copyOfRange(fromIndex = bytes.size - size, toIndex = bytes.size)
        }
    }
}
