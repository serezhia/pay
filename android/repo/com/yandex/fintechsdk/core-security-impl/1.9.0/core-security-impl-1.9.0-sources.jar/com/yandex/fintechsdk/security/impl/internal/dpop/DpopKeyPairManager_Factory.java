package com.yandex.fintechsdk.security.impl.internal.dpop;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.utils.api.environment.DebugEnvironmentChecker;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DpopKeyPairManager_Factory implements Factory<DpopKeyPairManager> {
  private final Provider<Analytics> analyticsProvider;

  private final Provider<DebugEnvironmentChecker> debugEnvironmentCheckerProvider;

  private DpopKeyPairManager_Factory(Provider<Analytics> analyticsProvider,
      Provider<DebugEnvironmentChecker> debugEnvironmentCheckerProvider) {
    this.analyticsProvider = analyticsProvider;
    this.debugEnvironmentCheckerProvider = debugEnvironmentCheckerProvider;
  }

  @Override
  public DpopKeyPairManager get() {
    return newInstance(analyticsProvider.get(), debugEnvironmentCheckerProvider.get());
  }

  public static DpopKeyPairManager_Factory create(Provider<Analytics> analyticsProvider,
      Provider<DebugEnvironmentChecker> debugEnvironmentCheckerProvider) {
    return new DpopKeyPairManager_Factory(analyticsProvider, debugEnvironmentCheckerProvider);
  }

  public static DpopKeyPairManager newInstance(Analytics analytics,
      DebugEnvironmentChecker debugEnvironmentChecker) {
    return new DpopKeyPairManager(analytics, debugEnvironmentChecker);
  }
}
