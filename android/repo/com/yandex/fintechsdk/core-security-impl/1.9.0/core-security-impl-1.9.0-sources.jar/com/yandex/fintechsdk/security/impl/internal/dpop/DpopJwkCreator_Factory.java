package com.yandex.fintechsdk.security.impl.internal.dpop;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DpopJwkCreator_Factory implements Factory<DpopJwkCreator> {
  private final Provider<DpopEncoder> encoderProvider;

  private DpopJwkCreator_Factory(Provider<DpopEncoder> encoderProvider) {
    this.encoderProvider = encoderProvider;
  }

  @Override
  public DpopJwkCreator get() {
    return newInstance(encoderProvider.get());
  }

  public static DpopJwkCreator_Factory create(Provider<DpopEncoder> encoderProvider) {
    return new DpopJwkCreator_Factory(encoderProvider);
  }

  public static DpopJwkCreator newInstance(DpopEncoder encoder) {
    return new DpopJwkCreator(encoder);
  }
}
