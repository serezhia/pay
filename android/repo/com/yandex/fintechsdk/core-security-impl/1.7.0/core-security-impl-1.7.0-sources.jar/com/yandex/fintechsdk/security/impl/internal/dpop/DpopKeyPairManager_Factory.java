package com.yandex.fintechsdk.security.impl.internal.dpop;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DpopKeyPairManager_Factory implements Factory<DpopKeyPairManager> {
  private final Provider<Analytics> analyticsProvider;

  private DpopKeyPairManager_Factory(Provider<Analytics> analyticsProvider) {
    this.analyticsProvider = analyticsProvider;
  }

  @Override
  public DpopKeyPairManager get() {
    return newInstance(analyticsProvider.get());
  }

  public static DpopKeyPairManager_Factory create(Provider<Analytics> analyticsProvider) {
    return new DpopKeyPairManager_Factory(analyticsProvider);
  }

  public static DpopKeyPairManager newInstance(Analytics analytics) {
    return new DpopKeyPairManager(analytics);
  }
}
