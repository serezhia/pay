package com.yandex.fintechsdk.adapters.login.sdk.impl

import android.content.Context
import androidx.activity.result.ActivityResultCaller
import com.yandex.authsdk.YandexAuthOptions
import com.yandex.authsdk.YandexAuthResult
import com.yandex.authsdk.YandexAuthSdk
import com.yandex.fintechsdk.adapters.login.sdk.impl.auth.AuthLauncherImpl
import com.yandex.fitnechsdk.adapters.login.sdk.api.LoginAdapter
import com.yandex.fitnechsdk.adapters.login.sdk.api.auth.AuthLauncher

public class LoginAdapterImpl : LoginAdapter {

    override fun createAuthLauncher(
        activityResultCaller: ActivityResultCaller,
        context: Context,
        onGetToken: (token: String?) -> Unit,
    ): AuthLauncher {
        val options = YandexAuthOptions(context = context)

        val sdk = YandexAuthSdk.create(options = options)

        val launcher = activityResultCaller.registerForActivityResult(sdk.contract) { result ->
            val token = if (result is YandexAuthResult.Success) {
                result.token.value
            } else {
                null
            }

            onGetToken(token)
        }

        return AuthLauncherImpl(launcher = launcher)
    }
}
