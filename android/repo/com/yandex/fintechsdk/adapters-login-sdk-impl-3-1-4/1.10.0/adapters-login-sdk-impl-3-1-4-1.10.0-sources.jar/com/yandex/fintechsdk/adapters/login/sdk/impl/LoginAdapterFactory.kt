package com.yandex.fintechsdk.adapters.login.sdk.impl

import com.yandex.fitnechsdk.adapters.login.sdk.api.LoginAdapter

public class LoginAdapterFactory {

    public fun create(): LoginAdapter {
        return LoginAdapterImpl()
    }
}
