package com.yandex.fintechsdk.adapters.login.sdk.impl.auth

import androidx.activity.result.ActivityResultLauncher
import com.yandex.authsdk.YandexAuthLoginOptions
import com.yandex.fitnechsdk.adapters.login.sdk.api.auth.AuthLauncher

internal class AuthLauncherImpl(
    private val launcher: ActivityResultLauncher<YandexAuthLoginOptions>,
) : AuthLauncher {

    override fun launchAuth() {
        val loginOptions = YandexAuthLoginOptions()
        launcher.launch(loginOptions)
    }
}
