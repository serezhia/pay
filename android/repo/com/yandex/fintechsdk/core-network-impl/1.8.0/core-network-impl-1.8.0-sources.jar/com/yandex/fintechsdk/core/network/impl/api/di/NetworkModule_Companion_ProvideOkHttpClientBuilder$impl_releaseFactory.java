package com.yandex.fintechsdk.core.network.impl.api.di;

import com.yandex.fintechsdk.core.network.impl.internal.interceptor.OverrideTovarischUrlInterceptor;
import com.yandex.fintechsdk.core.telemetry.api.OpenTelemetryTracer;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.Optional;
import javax.annotation.processing.Generated;
import okhttp3.OkHttpClient;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory implements Factory<OkHttpClient.Builder> {
  private final Provider<OverrideTovarischUrlInterceptor> overrideTovarischUrlInterceptorProvider;

  private final Provider<Optional<OpenTelemetryTracer>> openTelemetryTracerProvider;

  private NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory(
      Provider<OverrideTovarischUrlInterceptor> overrideTovarischUrlInterceptorProvider,
      Provider<Optional<OpenTelemetryTracer>> openTelemetryTracerProvider) {
    this.overrideTovarischUrlInterceptorProvider = overrideTovarischUrlInterceptorProvider;
    this.openTelemetryTracerProvider = openTelemetryTracerProvider;
  }

  @Override
  public OkHttpClient.Builder get() {
    return provideOkHttpClientBuilder$impl_release(overrideTovarischUrlInterceptorProvider.get(), openTelemetryTracerProvider.get());
  }

  public static NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory create(
      Provider<OverrideTovarischUrlInterceptor> overrideTovarischUrlInterceptorProvider,
      Provider<Optional<OpenTelemetryTracer>> openTelemetryTracerProvider) {
    return new NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory(overrideTovarischUrlInterceptorProvider, openTelemetryTracerProvider);
  }

  public static OkHttpClient.Builder provideOkHttpClientBuilder$impl_release(
      OverrideTovarischUrlInterceptor overrideTovarischUrlInterceptor,
      Optional<OpenTelemetryTracer> openTelemetryTracer) {
    return Preconditions.checkNotNullFromProvides(NetworkModule.Companion.provideOkHttpClientBuilder$impl_release(overrideTovarischUrlInterceptor, openTelemetryTracer));
  }
}
