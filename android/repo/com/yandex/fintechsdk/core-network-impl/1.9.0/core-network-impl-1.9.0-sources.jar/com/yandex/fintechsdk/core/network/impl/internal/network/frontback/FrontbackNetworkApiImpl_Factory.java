package com.yandex.fintechsdk.core.network.impl.internal.network.frontback;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.network.api.host.FrontbackUrlProvider;
import com.yandex.fintechsdk.core.network.impl.api.frontback.FrontbackServiceTokenProvider;
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor;
import com.yandex.fintechsdk.entities.environment.PayEnvironment;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FrontbackNetworkApiImpl_Factory implements Factory<FrontbackNetworkApiImpl> {
  private final Provider<FrontbackUrlProvider> frontbackUrlProvider;

  private final Provider<RequestExecutor> requestExecutorProvider;

  private final Provider<Analytics> analyticsProvider;

  private final Provider<PayEnvironment> environmentProvider;

  private final Provider<FrontbackServiceTokenProvider> serviceTokenProvider;

  private FrontbackNetworkApiImpl_Factory(Provider<FrontbackUrlProvider> frontbackUrlProvider,
      Provider<RequestExecutor> requestExecutorProvider, Provider<Analytics> analyticsProvider,
      Provider<PayEnvironment> environmentProvider,
      Provider<FrontbackServiceTokenProvider> serviceTokenProvider) {
    this.frontbackUrlProvider = frontbackUrlProvider;
    this.requestExecutorProvider = requestExecutorProvider;
    this.analyticsProvider = analyticsProvider;
    this.environmentProvider = environmentProvider;
    this.serviceTokenProvider = serviceTokenProvider;
  }

  @Override
  public FrontbackNetworkApiImpl get() {
    return newInstance(frontbackUrlProvider.get(), requestExecutorProvider.get(), analyticsProvider.get(), environmentProvider.get(), serviceTokenProvider.get());
  }

  public static FrontbackNetworkApiImpl_Factory create(
      Provider<FrontbackUrlProvider> frontbackUrlProvider,
      Provider<RequestExecutor> requestExecutorProvider, Provider<Analytics> analyticsProvider,
      Provider<PayEnvironment> environmentProvider,
      Provider<FrontbackServiceTokenProvider> serviceTokenProvider) {
    return new FrontbackNetworkApiImpl_Factory(frontbackUrlProvider, requestExecutorProvider, analyticsProvider, environmentProvider, serviceTokenProvider);
  }

  public static FrontbackNetworkApiImpl newInstance(FrontbackUrlProvider frontbackUrlProvider,
      RequestExecutor requestExecutor, Analytics analytics, PayEnvironment environment,
      FrontbackServiceTokenProvider serviceTokenProvider) {
    return new FrontbackNetworkApiImpl(frontbackUrlProvider, requestExecutor, analytics, environment, serviceTokenProvider);
  }
}
