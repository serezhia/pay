package com.yandex.fintechsdk.core.network.impl.internal.executor

import com.yandex.fintechsdk.core.network.api.auth.AuthTokenProvider
import com.yandex.fintechsdk.core.network.api.exception.NetworkException
import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.impl.api.headers.BaseHeadersProvider
import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.impl.internal.model.MimeType
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Headers
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import javax.inject.Inject
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import okhttp3.Request as OkHttpRequest

internal class RequestExecutor @Inject constructor(
    private val authTokenProvider: AuthTokenProvider,
    private val baseHeadersProvider: BaseHeadersProvider,
    private val okHttpClient: OkHttpClient,
    private val userAgentProvider: UserAgentProvider,
) {

    suspend fun executeRequest(request: Request, baseUrl: String, headers: Map<String, String>): Response = suspendCancellableCoroutine { continuation ->
        val call = okHttpClient.newCall(request.toOkHttpRequest(baseUrl = baseUrl, additionalHeaders = headers))

        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                continuation.resumeWithException(
                    NetworkException.OkHttpCommonException(requestName = request.requestName, message = e.message)
                )
            }

            override fun onResponse(call: Call, response: Response) {
                continuation.resume(response)
            }
        })

        continuation.invokeOnCancellation {
            try {
                call.cancel()
            } catch (_: Throwable) {
            }
        }
    }

    private fun Request.toOkHttpRequest(baseUrl: String, additionalHeaders: Map<String, String>): OkHttpRequest {
        val body = body()?.toString()?.toRequestBody(contentType = MimeType.APPLICATION_JSON.asMediaType())
        val queries = queries()
        val headers = createHeaders(
            isAuthHeaderNeeded = configuration.isAuthNeeded,
            body = body,
            additionalHeaders = buildMap {
                putAll(baseHeadersProvider.getHeaders())
                putAll(additionalHeaders)
                putAll(headers())
            },
        )

        val urlString = joinUrl(baseUrl = baseUrl, path = requestPath)

        val url = urlString.toHttpUrl().newBuilder()
            .addQueryParameters(queries)
            .build()

        return OkHttpRequest.Builder()
            .url(url)
            .headers(headers)
            .method(
                method.name,
                body,
            )
            .build()
    }

    private fun createHeaders(
        isAuthHeaderNeeded: Boolean,
        body: RequestBody?,
        additionalHeaders: Map<String, String>,
    ): Headers {
        val headerBuilder = Headers.Builder()
            .addAll(additionalHeaders)

        if (isAuthHeaderNeeded) {
            val token = authTokenProvider.getToken() ?: error("Missing auth token")
            headerBuilder.add(Header.OAuthToken.key, token)
            headerBuilder.add(Header.Authorization.key, AUTHORIZATION_HEADER_VALUE.format(token))
        }

        headerBuilder.add(Header.UserAgent.key, userAgentProvider.get())

        body?.let {
            headerBuilder.add(Header.ContentType.key, body.contentType().toString())
        }

        return headerBuilder.build()
    }

    private fun joinUrl(baseUrl: String, path: String): String {
        return "${baseUrl.trimEnd('/')}/${path.trimStart('/')}"
    }

    private fun HttpUrl.Builder.addQueryParameters(parameters: Map<String, String>): HttpUrl.Builder {
        parameters.entries.forEach { entry -> addQueryParameter(entry.key, entry.value) }
        return this
    }

    private fun Headers.Builder.addAll(headers: Map<String, String>): Headers.Builder {
        headers.keys.forEach { key -> add(key, headers[key]!!) }
        return this
    }

    private companion object {
        // Headers
        const val AUTHORIZATION_HEADER_VALUE = "OAuth %s"
    }
}
