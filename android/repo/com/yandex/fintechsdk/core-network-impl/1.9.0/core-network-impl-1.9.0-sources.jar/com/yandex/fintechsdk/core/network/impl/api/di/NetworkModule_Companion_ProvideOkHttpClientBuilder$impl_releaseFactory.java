package com.yandex.fintechsdk.core.network.impl.api.di;

import com.yandex.fintechsdk.core.network.api.interceptor.PrioritizedInterceptor;
import com.yandex.fintechsdk.core.network.impl.internal.interceptor.OverrideTovarischUrlInterceptor;
import com.yandex.fintechsdk.core.network.impl.internal.interceptor.RetryInterceptor;
import com.yandex.fintechsdk.core.telemetry.api.OpenTelemetryTracer;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.Optional;
import java.util.Set;
import javax.annotation.processing.Generated;
import okhttp3.OkHttpClient;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory implements Factory<OkHttpClient.Builder> {
  private final Provider<OverrideTovarischUrlInterceptor> overrideTovarischUrlInterceptorProvider;

  private final Provider<Optional<OpenTelemetryTracer>> openTelemetryTracerProvider;

  private final Provider<RetryInterceptor> retryInterceptorProvider;

  private final Provider<Set<PrioritizedInterceptor>> interceptorsProvider;

  private NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory(
      Provider<OverrideTovarischUrlInterceptor> overrideTovarischUrlInterceptorProvider,
      Provider<Optional<OpenTelemetryTracer>> openTelemetryTracerProvider,
      Provider<RetryInterceptor> retryInterceptorProvider,
      Provider<Set<PrioritizedInterceptor>> interceptorsProvider) {
    this.overrideTovarischUrlInterceptorProvider = overrideTovarischUrlInterceptorProvider;
    this.openTelemetryTracerProvider = openTelemetryTracerProvider;
    this.retryInterceptorProvider = retryInterceptorProvider;
    this.interceptorsProvider = interceptorsProvider;
  }

  @Override
  public OkHttpClient.Builder get() {
    return provideOkHttpClientBuilder$impl_release(overrideTovarischUrlInterceptorProvider.get(), openTelemetryTracerProvider.get(), retryInterceptorProvider.get(), interceptorsProvider.get());
  }

  public static NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory create(
      Provider<OverrideTovarischUrlInterceptor> overrideTovarischUrlInterceptorProvider,
      Provider<Optional<OpenTelemetryTracer>> openTelemetryTracerProvider,
      Provider<RetryInterceptor> retryInterceptorProvider,
      Provider<Set<PrioritizedInterceptor>> interceptorsProvider) {
    return new NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory(overrideTovarischUrlInterceptorProvider, openTelemetryTracerProvider, retryInterceptorProvider, interceptorsProvider);
  }

  public static OkHttpClient.Builder provideOkHttpClientBuilder$impl_release(
      OverrideTovarischUrlInterceptor overrideTovarischUrlInterceptor,
      Optional<OpenTelemetryTracer> openTelemetryTracer, RetryInterceptor retryInterceptor,
      Set<PrioritizedInterceptor> interceptors) {
    return Preconditions.checkNotNullFromProvides(NetworkModule.Companion.provideOkHttpClientBuilder$impl_release(overrideTovarischUrlInterceptor, openTelemetryTracer, retryInterceptor, interceptors));
  }
}
