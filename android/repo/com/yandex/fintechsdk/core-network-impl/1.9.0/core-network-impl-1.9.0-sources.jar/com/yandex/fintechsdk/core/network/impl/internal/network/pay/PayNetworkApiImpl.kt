package com.yandex.fintechsdk.core.network.impl.internal.network.pay

import android.os.Build
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.network.api.host.PayUrlProvider
import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.api.network.PayNetworkApi
import com.yandex.fintechsdk.core.network.impl.BuildConfig
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor
import com.yandex.fintechsdk.core.network.impl.internal.network.DefaultNetworkApiImpl
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.serializer
import okhttp3.ResponseBody
import javax.inject.Inject
import kotlin.reflect.KType

internal class PayNetworkApiImpl @Inject constructor(
    payUrlProvider: PayUrlProvider,
    requestExecutor: RequestExecutor,
    analytics: Analytics,
) : DefaultNetworkApiImpl(
    hostUrlProvider = payUrlProvider,
    requestExecutor = requestExecutor,
    analytics = analytics,
), PayNetworkApi {

    override fun createNetworkApiHeaders(): Map<String, String> {
        return mapOf(
            Header.PlatformVersion.key to Build.VERSION.SDK_INT.toString(),
            Header.SdkPlatform.key to ANDROID,
            Header.SdkVersion.key to BuildConfig.VERSION_NAME,
        )
    }

    override fun <T : Any> dataFromResponseBody(responseBody: ResponseBody, returnType: KType): T {
        // Pay responses are wrapped in "data" field, so we have to unwrap it before parsing
        val responseJson = json.decodeFromString(JsonObject.serializer(), responseBody.string())
        val data = responseJson[RESPONSE_DATA_KEY] ?: error("Null data field in pay network api response")
        return json.decodeFromJsonElement(serializer(returnType), data) as T
    }

    private companion object {
        // Headers value
        const val ANDROID = "android"

        // Keys
        const val RESPONSE_DATA_KEY = "data"
    }
}
