package com.yandex.fintechsdk.core.network.impl.internal.network.diehard

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.api.network.DiehardNetworkApi
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor
import com.yandex.fintechsdk.core.network.impl.internal.host.EmptyHostUrlProvider
import com.yandex.fintechsdk.core.network.impl.internal.network.DefaultNetworkApiImpl
import javax.inject.Inject
import kotlin.math.abs
import kotlin.random.Random

/**
 * Implementation of [DiehardNetworkApi] that extends [DefaultNetworkApiImpl].
 *
 * The hostUrlProvider is intentionally passed as [EmptyHostUrlProvider] because it is expected
 * that the Diehard base URL will be overridden in the corresponding requests in [com.yandex.fintechsdk.core.network.api.request.Request.baseUrl] field.
 */
internal class DiehardNetworkApiImpl @Inject constructor(
    requestExecutor: RequestExecutor,
    analytics: Analytics,
) : DefaultNetworkApiImpl(
    hostUrlProvider = EmptyHostUrlProvider,
    requestExecutor = requestExecutor,
    analytics = analytics,
), DiehardNetworkApi {

    override fun createNetworkApiHeaders(): Map<String, String> {
        return mapOf(
            Header.RequestId.key to abs(
                Random.nextLong(from = MIN_REQUEST_ID, until = Long.MAX_VALUE),
            ).toString(),
        )
    }

    private companion object {
        // Headers value
        const val MIN_REQUEST_ID = 1000000000000000000L
    }
}
