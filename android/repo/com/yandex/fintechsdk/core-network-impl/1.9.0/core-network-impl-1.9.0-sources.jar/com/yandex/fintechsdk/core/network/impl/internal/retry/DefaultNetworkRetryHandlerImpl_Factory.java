package com.yandex.fintechsdk.core.network.impl.internal.retry;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DefaultNetworkRetryHandlerImpl_Factory implements Factory<DefaultNetworkRetryHandlerImpl> {
  @Override
  public DefaultNetworkRetryHandlerImpl get() {
    return newInstance();
  }

  public static DefaultNetworkRetryHandlerImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DefaultNetworkRetryHandlerImpl newInstance() {
    return new DefaultNetworkRetryHandlerImpl();
  }

  private static final class InstanceHolder {
    static final DefaultNetworkRetryHandlerImpl_Factory INSTANCE = new DefaultNetworkRetryHandlerImpl_Factory();
  }
}
