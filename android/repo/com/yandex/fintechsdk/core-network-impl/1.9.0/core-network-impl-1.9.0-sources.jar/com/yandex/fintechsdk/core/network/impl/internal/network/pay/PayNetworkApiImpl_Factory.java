package com.yandex.fintechsdk.core.network.impl.internal.network.pay;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.network.api.host.PayUrlProvider;
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class PayNetworkApiImpl_Factory implements Factory<PayNetworkApiImpl> {
  private final Provider<PayUrlProvider> payUrlProvider;

  private final Provider<RequestExecutor> requestExecutorProvider;

  private final Provider<Analytics> analyticsProvider;

  private PayNetworkApiImpl_Factory(Provider<PayUrlProvider> payUrlProvider,
      Provider<RequestExecutor> requestExecutorProvider, Provider<Analytics> analyticsProvider) {
    this.payUrlProvider = payUrlProvider;
    this.requestExecutorProvider = requestExecutorProvider;
    this.analyticsProvider = analyticsProvider;
  }

  @Override
  public PayNetworkApiImpl get() {
    return newInstance(payUrlProvider.get(), requestExecutorProvider.get(), analyticsProvider.get());
  }

  public static PayNetworkApiImpl_Factory create(Provider<PayUrlProvider> payUrlProvider,
      Provider<RequestExecutor> requestExecutorProvider, Provider<Analytics> analyticsProvider) {
    return new PayNetworkApiImpl_Factory(payUrlProvider, requestExecutorProvider, analyticsProvider);
  }

  public static PayNetworkApiImpl newInstance(PayUrlProvider payUrlProvider,
      RequestExecutor requestExecutor, Analytics analytics) {
    return new PayNetworkApiImpl(payUrlProvider, requestExecutor, analytics);
  }
}
