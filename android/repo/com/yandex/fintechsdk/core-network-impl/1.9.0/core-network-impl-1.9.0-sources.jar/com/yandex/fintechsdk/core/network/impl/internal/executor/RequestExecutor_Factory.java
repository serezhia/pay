package com.yandex.fintechsdk.core.network.impl.internal.executor;

import com.yandex.fintechsdk.core.network.api.auth.AuthTokenProvider;
import com.yandex.fintechsdk.core.network.impl.api.headers.BaseHeadersProvider;
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import okhttp3.OkHttpClient;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RequestExecutor_Factory implements Factory<RequestExecutor> {
  private final Provider<AuthTokenProvider> authTokenProvider;

  private final Provider<BaseHeadersProvider> baseHeadersProvider;

  private final Provider<OkHttpClient> okHttpClientProvider;

  private final Provider<UserAgentProvider> userAgentProvider;

  private RequestExecutor_Factory(Provider<AuthTokenProvider> authTokenProvider,
      Provider<BaseHeadersProvider> baseHeadersProvider,
      Provider<OkHttpClient> okHttpClientProvider, Provider<UserAgentProvider> userAgentProvider) {
    this.authTokenProvider = authTokenProvider;
    this.baseHeadersProvider = baseHeadersProvider;
    this.okHttpClientProvider = okHttpClientProvider;
    this.userAgentProvider = userAgentProvider;
  }

  @Override
  public RequestExecutor get() {
    return newInstance(authTokenProvider.get(), baseHeadersProvider.get(), okHttpClientProvider.get(), userAgentProvider.get());
  }

  public static RequestExecutor_Factory create(Provider<AuthTokenProvider> authTokenProvider,
      Provider<BaseHeadersProvider> baseHeadersProvider,
      Provider<OkHttpClient> okHttpClientProvider, Provider<UserAgentProvider> userAgentProvider) {
    return new RequestExecutor_Factory(authTokenProvider, baseHeadersProvider, okHttpClientProvider, userAgentProvider);
  }

  public static RequestExecutor newInstance(AuthTokenProvider authTokenProvider,
      BaseHeadersProvider baseHeadersProvider, OkHttpClient okHttpClient,
      UserAgentProvider userAgentProvider) {
    return new RequestExecutor(authTokenProvider, baseHeadersProvider, okHttpClient, userAgentProvider);
  }
}
