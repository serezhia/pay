package com.yandex.fintechsdk.core.network.impl.internal.host;

import com.yandex.fintechsdk.core.network.impl.internal.host.custom.CustomBackendUrlProvider;
import com.yandex.fintechsdk.entities.environment.PayEnvironment;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class PayUrlProviderImpl_Factory implements Factory<PayUrlProviderImpl> {
  private final Provider<CustomBackendUrlProvider> customBackendUrlProvider;

  private final Provider<PayEnvironment> environmentProvider;

  private PayUrlProviderImpl_Factory(Provider<CustomBackendUrlProvider> customBackendUrlProvider,
      Provider<PayEnvironment> environmentProvider) {
    this.customBackendUrlProvider = customBackendUrlProvider;
    this.environmentProvider = environmentProvider;
  }

  @Override
  public PayUrlProviderImpl get() {
    return newInstance(customBackendUrlProvider.get(), environmentProvider.get());
  }

  public static PayUrlProviderImpl_Factory create(
      Provider<CustomBackendUrlProvider> customBackendUrlProvider,
      Provider<PayEnvironment> environmentProvider) {
    return new PayUrlProviderImpl_Factory(customBackendUrlProvider, environmentProvider);
  }

  public static PayUrlProviderImpl newInstance(CustomBackendUrlProvider customBackendUrlProvider,
      PayEnvironment environment) {
    return new PayUrlProviderImpl(customBackendUrlProvider, environment);
  }
}
