package com.yandex.fintechsdk.core.network.impl.internal.host

import com.yandex.fintechsdk.core.network.api.host.FrontbackUrlProvider
import com.yandex.fintechsdk.core.network.impl.internal.host.custom.CustomBackendUrlProvider
import com.yandex.fintechsdk.entities.environment.PayEnvironment
import javax.inject.Inject

internal class FrontbackUrlProviderImpl @Inject constructor(
    private val customBackendUrlProvider: CustomBackendUrlProvider,
    private val environment: PayEnvironment,
) : FrontbackUrlProvider {

    override fun getHostUrl(): String {
        val customUrl = customBackendUrlProvider.getCustomFrontbackUrl()
        if (customUrl != null) {
            return customUrl
        }
        return when (environment) {
            PayEnvironment.TESTING -> FRONTBACK_URL_DEV
            PayEnvironment.PRODUCTION -> FRONTBACK_URL_PROD
            PayEnvironment.SANDBOX -> FRONTBACK_URL_SANDBOX
        }
    }

    private companion object {
        const val FRONTBACK_URL_DEV = "https://mobpayment-test.yandex-team.ru"
        const val FRONTBACK_URL_PROD = "https://mobpayment.yandex.net"
        const val FRONTBACK_URL_SANDBOX = "https://sandbox.mobile.pay.yandex.ru"
    }
}
