package com.yandex.fintechsdk.core.network.impl.internal.host

import com.yandex.fintechsdk.core.network.api.host.PayUrlProvider
import com.yandex.fintechsdk.core.network.impl.internal.host.custom.CustomBackendUrlProvider
import com.yandex.fintechsdk.entities.environment.PayEnvironment
import javax.inject.Inject

internal class PayUrlProviderImpl @Inject constructor(
    private val customBackendUrlProvider: CustomBackendUrlProvider,
    private val environment: PayEnvironment,
) : PayUrlProvider {

    override fun getHostUrl(): String {
        val customUrl = customBackendUrlProvider.getCustomPayBackendUrl()
        if (customUrl != null) {
            return customUrl
        }
        return when (environment) {
            PayEnvironment.PRODUCTION -> PAY_PRODUCTION_URL
            PayEnvironment.SANDBOX -> PAY_SANDBOX_URL
            PayEnvironment.TESTING -> PAY_TESTING_URL
        }
    }

    private companion object {
        const val PAY_TESTING_URL = "https://test.pay.yandex.ru/"
        const val PAY_SANDBOX_URL = "https://sandbox.pay.yandex.ru/"
        const val PAY_PRODUCTION_URL = "https://pay.yandex.ru/"
    }
}
