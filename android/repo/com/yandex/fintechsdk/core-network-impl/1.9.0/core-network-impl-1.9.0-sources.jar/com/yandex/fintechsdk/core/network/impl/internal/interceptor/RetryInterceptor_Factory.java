package com.yandex.fintechsdk.core.network.impl.internal.interceptor;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.network.api.retry.NetworkRetryHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.Set;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RetryInterceptor_Factory implements Factory<RetryInterceptor> {
  private final Provider<Analytics> analyticsProvider;

  private final Provider<Set<NetworkRetryHandler>> handlersProvider;

  private RetryInterceptor_Factory(Provider<Analytics> analyticsProvider,
      Provider<Set<NetworkRetryHandler>> handlersProvider) {
    this.analyticsProvider = analyticsProvider;
    this.handlersProvider = handlersProvider;
  }

  @Override
  public RetryInterceptor get() {
    return newInstance(analyticsProvider.get(), handlersProvider.get());
  }

  public static RetryInterceptor_Factory create(Provider<Analytics> analyticsProvider,
      Provider<Set<NetworkRetryHandler>> handlersProvider) {
    return new RetryInterceptor_Factory(analyticsProvider, handlersProvider);
  }

  public static RetryInterceptor newInstance(Analytics analytics,
      Set<NetworkRetryHandler> handlers) {
    return new RetryInterceptor(analytics, handlers);
  }
}
