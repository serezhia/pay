package com.yandex.fintechsdk.core.network.impl.internal.host.custom;

import android.content.SharedPreferences;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CustomBackendUrlProvider_Factory implements Factory<CustomBackendUrlProvider> {
  private final Provider<SharedPreferences> sharedPreferencesProvider;

  private CustomBackendUrlProvider_Factory(Provider<SharedPreferences> sharedPreferencesProvider) {
    this.sharedPreferencesProvider = sharedPreferencesProvider;
  }

  @Override
  public CustomBackendUrlProvider get() {
    return newInstance(sharedPreferencesProvider.get());
  }

  public static CustomBackendUrlProvider_Factory create(
      Provider<SharedPreferences> sharedPreferencesProvider) {
    return new CustomBackendUrlProvider_Factory(sharedPreferencesProvider);
  }

  public static CustomBackendUrlProvider newInstance(SharedPreferences sharedPreferences) {
    return new CustomBackendUrlProvider(sharedPreferences);
  }
}
