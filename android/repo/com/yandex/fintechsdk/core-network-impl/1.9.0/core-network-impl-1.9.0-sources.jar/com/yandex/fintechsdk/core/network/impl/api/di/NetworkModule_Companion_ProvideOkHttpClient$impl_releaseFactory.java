package com.yandex.fintechsdk.core.network.impl.api.di;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import okhttp3.OkHttpClient;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class NetworkModule_Companion_ProvideOkHttpClient$impl_releaseFactory implements Factory<OkHttpClient> {
  private final Provider<OkHttpClient.Builder> builderProvider;

  private NetworkModule_Companion_ProvideOkHttpClient$impl_releaseFactory(
      Provider<OkHttpClient.Builder> builderProvider) {
    this.builderProvider = builderProvider;
  }

  @Override
  public OkHttpClient get() {
    return provideOkHttpClient$impl_release(builderProvider.get());
  }

  public static NetworkModule_Companion_ProvideOkHttpClient$impl_releaseFactory create(
      Provider<OkHttpClient.Builder> builderProvider) {
    return new NetworkModule_Companion_ProvideOkHttpClient$impl_releaseFactory(builderProvider);
  }

  public static OkHttpClient provideOkHttpClient$impl_release(OkHttpClient.Builder builder) {
    return Preconditions.checkNotNullFromProvides(NetworkModule.Companion.provideOkHttpClient$impl_release(builder));
  }
}
