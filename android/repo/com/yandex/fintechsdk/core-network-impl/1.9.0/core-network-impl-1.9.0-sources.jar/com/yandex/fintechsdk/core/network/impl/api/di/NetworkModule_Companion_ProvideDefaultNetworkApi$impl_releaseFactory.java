package com.yandex.fintechsdk.core.network.impl.api.di;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.network.api.network.DefaultNetworkApi;
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class NetworkModule_Companion_ProvideDefaultNetworkApi$impl_releaseFactory implements Factory<DefaultNetworkApi> {
  private final Provider<Analytics> analyticsProvider;

  private final Provider<RequestExecutor> requestExecutorProvider;

  private NetworkModule_Companion_ProvideDefaultNetworkApi$impl_releaseFactory(
      Provider<Analytics> analyticsProvider, Provider<RequestExecutor> requestExecutorProvider) {
    this.analyticsProvider = analyticsProvider;
    this.requestExecutorProvider = requestExecutorProvider;
  }

  @Override
  public DefaultNetworkApi get() {
    return provideDefaultNetworkApi$impl_release(analyticsProvider.get(), requestExecutorProvider.get());
  }

  public static NetworkModule_Companion_ProvideDefaultNetworkApi$impl_releaseFactory create(
      Provider<Analytics> analyticsProvider, Provider<RequestExecutor> requestExecutorProvider) {
    return new NetworkModule_Companion_ProvideDefaultNetworkApi$impl_releaseFactory(analyticsProvider, requestExecutorProvider);
  }

  public static DefaultNetworkApi provideDefaultNetworkApi$impl_release(Analytics analytics,
      RequestExecutor requestExecutor) {
    return Preconditions.checkNotNullFromProvides(NetworkModule.Companion.provideDefaultNetworkApi$impl_release(analytics, requestExecutor));
  }
}
