package com.yandex.fintechsdk.core.network.impl.internal.network.frontback

import android.os.Build
import androidx.core.net.toUri
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.network.api.host.FrontbackUrlProvider
import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.impl.BuildConfig
import com.yandex.fintechsdk.core.network.impl.api.frontback.FrontbackServiceTokenProvider
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor
import com.yandex.fintechsdk.core.network.impl.internal.host.custom.CustomBackendUrlProvider
import com.yandex.fintechsdk.core.network.impl.internal.network.DefaultNetworkApiImpl
import com.yandex.fintechsdk.entities.environment.PayEnvironment
import javax.inject.Inject

internal class FrontbackNetworkApiImpl @Inject constructor(
    frontbackUrlProvider: FrontbackUrlProvider,
    requestExecutor: RequestExecutor,
    analytics: Analytics,
    private val environment: PayEnvironment,
    private val serviceTokenProvider: FrontbackServiceTokenProvider,
    private val customBackendUrlProvider: CustomBackendUrlProvider,
) : DefaultNetworkApiImpl(
    hostUrlProvider = frontbackUrlProvider,
    requestExecutor = requestExecutor,
    analytics = analytics,
), FrontbackNetworkApi {

    override fun createNetworkApiHeaders(): Map<String, String> {
        return buildMap {
            put(Header.ServiceToken.key, serviceTokenProvider.getServiceToken(environment = environment))
            put(Header.Connection.key, CONNECTION_VALUE)
            put(Header.PlatformVersion.key, Build.VERSION.SDK_INT.toString())
            put(Header.SdkPlatform.key, ANDROID)
            put(Header.SdkVersion.key, BuildConfig.VERSION_NAME)
            customBackendUrlProvider.getCustomFrontbackUrl()
                ?.toUri()
                ?.host
                ?.let { host -> put(Header.RealIp.key, host) }
        }
    }

    private companion object {
        const val CONNECTION_VALUE = "keep-alive"
        const val ANDROID = "android"
    }
}
