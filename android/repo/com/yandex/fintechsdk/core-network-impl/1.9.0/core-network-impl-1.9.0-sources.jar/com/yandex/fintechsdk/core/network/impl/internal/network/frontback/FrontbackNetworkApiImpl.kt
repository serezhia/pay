package com.yandex.fintechsdk.core.network.impl.internal.network.frontback

import android.os.Build
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.network.api.host.FrontbackUrlProvider
import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.impl.BuildConfig
import com.yandex.fintechsdk.core.network.impl.api.frontback.FrontbackServiceTokenProvider
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor
import com.yandex.fintechsdk.core.network.impl.internal.network.DefaultNetworkApiImpl
import com.yandex.fintechsdk.entities.environment.PayEnvironment
import javax.inject.Inject

internal class FrontbackNetworkApiImpl @Inject constructor(
    frontbackUrlProvider: FrontbackUrlProvider,
    requestExecutor: RequestExecutor,
    analytics: Analytics,
    private val environment: PayEnvironment,
    private val serviceTokenProvider: FrontbackServiceTokenProvider,
) : DefaultNetworkApiImpl(
    hostUrlProvider = frontbackUrlProvider,
    requestExecutor = requestExecutor,
    analytics = analytics,
), FrontbackNetworkApi {

    override fun createNetworkApiHeaders(): Map<String, String> {
        return mapOf(
            Header.ServiceToken.key to serviceTokenProvider.getServiceToken(environment = environment),
            Header.Connection.key to CONNECTION_VALUE,
            Header.PlatformVersion.key to Build.VERSION.SDK_INT.toString(),
            Header.SdkPlatform.key to ANDROID,
            Header.SdkVersion.key to BuildConfig.VERSION_NAME,
        )
    }

    private companion object {
        // Headers value
        const val CONNECTION_VALUE = "keep-alive"
        const val ANDROID = "android"
    }
}
