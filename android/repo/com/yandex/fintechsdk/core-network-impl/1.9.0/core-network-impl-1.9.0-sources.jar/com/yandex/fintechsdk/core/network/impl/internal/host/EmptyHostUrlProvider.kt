package com.yandex.fintechsdk.core.network.impl.internal.host

import com.yandex.fintechsdk.core.network.api.host.HostUrlProvider

internal object EmptyHostUrlProvider : HostUrlProvider {
    override fun getHostUrl(): String = ""
}
