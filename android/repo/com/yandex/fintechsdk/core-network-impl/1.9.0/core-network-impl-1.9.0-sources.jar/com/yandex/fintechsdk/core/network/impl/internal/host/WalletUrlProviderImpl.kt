package com.yandex.fintechsdk.core.network.impl.internal.host

import com.yandex.fintechsdk.core.network.api.host.WalletUrlProvider
import com.yandex.fintechsdk.core.network.impl.internal.host.custom.CustomBackendUrlProvider
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment
import javax.inject.Inject

internal class WalletUrlProviderImpl @Inject constructor(
    private val customBackendUrlProvider: CustomBackendUrlProvider,
    private val environment: DefaultEnvironment,
) : WalletUrlProvider {

    override fun getHostUrl(): String {
        val customUrl = customBackendUrlProvider.getCustomWalletUrl()
        if (customUrl != null) {
            return customUrl
        }
        return when (environment) {
            DefaultEnvironment.TESTING -> WALLET_URL_TESTING
            DefaultEnvironment.PRODUCTION -> WALLET_URL_PROD
        }
    }

    private companion object {
        const val WALLET_URL_TESTING = "https://test.wallet.yandex.ru"
        const val WALLET_URL_PROD = "https://wallet.yandex.ru"
    }
}

