package com.yandex.fintechsdk.core.network.impl.internal.host;

import com.yandex.fintechsdk.core.network.impl.internal.host.custom.CustomBackendUrlProvider;
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class WalletUrlProviderImpl_Factory implements Factory<WalletUrlProviderImpl> {
  private final Provider<CustomBackendUrlProvider> customBackendUrlProvider;

  private final Provider<DefaultEnvironment> environmentProvider;

  private WalletUrlProviderImpl_Factory(Provider<CustomBackendUrlProvider> customBackendUrlProvider,
      Provider<DefaultEnvironment> environmentProvider) {
    this.customBackendUrlProvider = customBackendUrlProvider;
    this.environmentProvider = environmentProvider;
  }

  @Override
  public WalletUrlProviderImpl get() {
    return newInstance(customBackendUrlProvider.get(), environmentProvider.get());
  }

  public static WalletUrlProviderImpl_Factory create(
      Provider<CustomBackendUrlProvider> customBackendUrlProvider,
      Provider<DefaultEnvironment> environmentProvider) {
    return new WalletUrlProviderImpl_Factory(customBackendUrlProvider, environmentProvider);
  }

  public static WalletUrlProviderImpl newInstance(CustomBackendUrlProvider customBackendUrlProvider,
      DefaultEnvironment environment) {
    return new WalletUrlProviderImpl(customBackendUrlProvider, environment);
  }
}
