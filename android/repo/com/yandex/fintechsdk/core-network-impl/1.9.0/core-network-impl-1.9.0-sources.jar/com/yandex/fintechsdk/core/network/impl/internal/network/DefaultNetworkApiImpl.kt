package com.yandex.fintechsdk.core.network.impl.internal.network

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.network.api.exception.NetworkException
import com.yandex.fintechsdk.core.network.api.host.HostUrlProvider
import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.api.network.DefaultNetworkApi
import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor
import com.yandex.fintechsdk.core.network.impl.internal.interceptor.RetryAttemptTag
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.serializer
import okhttp3.Response
import okhttp3.ResponseBody
import kotlin.reflect.KType
import kotlin.reflect.typeOf

internal open class DefaultNetworkApiImpl(
    hostUrlProvider: HostUrlProvider,
    private val analytics: Analytics,
    private val requestExecutor: RequestExecutor,
) : DefaultNetworkApi {

    private val baseUrl: String = hostUrlProvider.getHostUrl()

    protected val json: Json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    protected open fun createNetworkApiHeaders(): Map<String, String> = emptyMap()

    override suspend fun <T : Any> sendRequest(request: Request, returnType: KType): Result<T> {
        val result: Result<T> = runCatching {
            getResponseFor(request = request, returnType = returnType)
        }

        result.onFailure { exception ->
            analytics.reportRuntimeError(key = "network_error", exception = exception)
        }

        return result
    }

    @Suppress("UNCHECKED_CAST")
    protected open fun <T : Any> dataFromResponseBody(responseBody: ResponseBody, returnType: KType): T {
        return json.decodeFromString(serializer(returnType), responseBody.string()) as T
    }

    private suspend fun <T : Any> getResponseFor(request: Request, returnType: KType): T {
        val response = requestExecutor.executeRequest(
            baseUrl = request.baseUrl ?: baseUrl,
            request = request,
            headers = createNetworkApiHeaders(),
        )
        
        return response.use {
            // Read attempt number from OkHttp Request
            val retryAttempt = response.request.tag(RetryAttemptTag::class.java)?.attempt ?: 0
            
            val body = response.body ?: throw NetworkException.EmptyBodyException(
                requestName = request.requestName,
                requestId = response.requestId(),
                retryAttempt = retryAttempt,
            )

            if (!response.isSuccessful) {
                throw NetworkException.BadCodeException(
                    requestName = request.requestName,
                    requestId = response.requestId(),
                    code = response.code,
                    body = runCatching {
                        dataFromResponseBody<JsonObject>(
                            responseBody = body,
                            returnType = typeOf<JsonObject>(),
                        )
                    }.getOrNull(),
                    retryAttempt = retryAttempt,
                )
            }

            dataFromResponseBody(responseBody = body, returnType = returnType)
        }
    }

    private fun Response.requestId(): String = header(Header.RequestId.key, null).orEmpty()
}
