package com.yandex.fintechsdk.core.network.impl.internal.interceptor;

import com.yandex.fintechsdk.core.network.api.host.FrontbackUrlProvider;
import com.yandex.fintechsdk.core.network.impl.internal.host.custom.CustomBackendUrlProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class OverrideTovarischUrlInterceptor_Factory implements Factory<OverrideTovarischUrlInterceptor> {
  private final Provider<CustomBackendUrlProvider> customBackendUrlProvider;

  private final Provider<FrontbackUrlProvider> frontbackUrlProvider;

  private OverrideTovarischUrlInterceptor_Factory(
      Provider<CustomBackendUrlProvider> customBackendUrlProvider,
      Provider<FrontbackUrlProvider> frontbackUrlProvider) {
    this.customBackendUrlProvider = customBackendUrlProvider;
    this.frontbackUrlProvider = frontbackUrlProvider;
  }

  @Override
  public OverrideTovarischUrlInterceptor get() {
    return newInstance(customBackendUrlProvider.get(), frontbackUrlProvider.get());
  }

  public static OverrideTovarischUrlInterceptor_Factory create(
      Provider<CustomBackendUrlProvider> customBackendUrlProvider,
      Provider<FrontbackUrlProvider> frontbackUrlProvider) {
    return new OverrideTovarischUrlInterceptor_Factory(customBackendUrlProvider, frontbackUrlProvider);
  }

  public static OverrideTovarischUrlInterceptor newInstance(
      CustomBackendUrlProvider customBackendUrlProvider,
      FrontbackUrlProvider frontbackUrlProvider) {
    return new OverrideTovarischUrlInterceptor(customBackendUrlProvider, frontbackUrlProvider);
  }
}
