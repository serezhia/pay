package com.yandex.fintechsdk.core.network.impl.api.di

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.network.api.host.FrontbackUrlProvider
import com.yandex.fintechsdk.core.network.api.host.PayUrlProvider
import com.yandex.fintechsdk.core.network.api.host.WalletUrlProvider
import com.yandex.fintechsdk.core.network.api.interceptor.PrioritizedInterceptor
import com.yandex.fintechsdk.core.network.api.network.DefaultNetworkApi
import com.yandex.fintechsdk.core.network.api.retry.NetworkRetryHandler
import com.yandex.fintechsdk.core.network.api.network.DiehardNetworkApi
import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.api.network.PayNetworkApi
import com.yandex.fintechsdk.core.network.impl.BuildConfig
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor
import com.yandex.fintechsdk.core.network.impl.internal.host.EmptyHostUrlProvider
import com.yandex.fintechsdk.core.network.impl.internal.host.FrontbackUrlProviderImpl
import com.yandex.fintechsdk.core.network.impl.internal.host.PayUrlProviderImpl
import com.yandex.fintechsdk.core.network.impl.internal.host.WalletUrlProviderImpl
import com.yandex.fintechsdk.core.network.impl.internal.interceptor.OverrideTovarischUrlInterceptor
import com.yandex.fintechsdk.core.network.impl.internal.interceptor.RetryInterceptor
import com.yandex.fintechsdk.core.network.impl.internal.network.DefaultNetworkApiImpl
import com.yandex.fintechsdk.core.network.impl.internal.retry.DefaultNetworkRetryHandlerImpl
import com.yandex.fintechsdk.core.network.impl.internal.network.diehard.DiehardNetworkApiImpl
import com.yandex.fintechsdk.core.network.impl.internal.network.frontback.FrontbackNetworkApiImpl
import com.yandex.fintechsdk.core.network.impl.internal.network.pay.PayNetworkApiImpl
import com.yandex.fintechsdk.core.network.impl.internal.ssl.trustAllSslContext
import com.yandex.fintechsdk.core.telemetry.api.OpenTelemetryInterceptor
import com.yandex.fintechsdk.core.telemetry.api.OpenTelemetryTracer
import dagger.Binds
import dagger.BindsOptionalOf
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoSet
import dagger.multibindings.Multibinds
import okhttp3.OkHttpClient
import java.util.Optional

@Module
public abstract class NetworkModule {

    @Binds
    internal abstract fun bindDiehardNetworkApi(impl: DiehardNetworkApiImpl): DiehardNetworkApi

    @Binds
    internal abstract fun bindFrontbackNetworkApi(impl: FrontbackNetworkApiImpl): FrontbackNetworkApi

    @Binds
    internal abstract fun bindPayNetworkApi(impl: PayNetworkApiImpl): PayNetworkApi

    @Binds
    internal abstract fun bindPayUrlProvider(impl: PayUrlProviderImpl): PayUrlProvider

    @Binds
    internal abstract fun bindFrontbackUrlProvider(impl: FrontbackUrlProviderImpl): FrontbackUrlProvider

    @Binds
    internal abstract fun bindWalletUrlProvider(impl: WalletUrlProviderImpl): WalletUrlProvider

    @BindsOptionalOf
    internal abstract fun bindOptionalOpenTelemetryTracer(): OpenTelemetryTracer

    /**
     * Default handler that never retries.
     * Flows can add their own handlers via @IntoSet in their modules.
     */
    @Binds
    @IntoSet
    internal abstract fun bindDefaultNetworkRetryHandler(impl: DefaultNetworkRetryHandlerImpl): NetworkRetryHandler

    @Multibinds
    internal abstract fun bindInterceptors(): Set<PrioritizedInterceptor>

    public companion object {

        @Provides
        internal fun provideOkHttpClientBuilder(
            overrideTovarischUrlInterceptor: OverrideTovarischUrlInterceptor,
            openTelemetryTracer: Optional<OpenTelemetryTracer>,
            retryInterceptor: RetryInterceptor,
            interceptors: Set<@JvmSuppressWildcards PrioritizedInterceptor>,
        ): OkHttpClient.Builder {
            val isDebug = BuildConfig.DEBUG
            val builder = OkHttpClient.Builder()

            if (isDebug) {
                builder.trustAllSslContext()
                builder.addInterceptor(overrideTovarischUrlInterceptor)
            }
            if (openTelemetryTracer.isPresent) {
                builder.addInterceptor(OpenTelemetryInterceptor(openTelemetryTracer.get()))
            }

            // Add external interceptors (e.g. logging) sorted by priority
            interceptors
                .sortedBy { it.priority }
                .forEach { builder.addInterceptor(it.interceptor) }

            // IMPORTANT: add LAST among application interceptors
            // so retries work after all other processing
            builder.addInterceptor(retryInterceptor)

            return builder
        }

        @Provides
        internal fun provideOkHttpClient(builder: OkHttpClient.Builder): OkHttpClient {
            return builder.build()
        }

        @Provides
        internal fun provideDefaultNetworkApi(analytics: Analytics, requestExecutor: RequestExecutor): DefaultNetworkApi {
            return DefaultNetworkApiImpl(
                analytics = analytics,
                hostUrlProvider = EmptyHostUrlProvider,
                requestExecutor = requestExecutor,
            )
        }
    }
}

