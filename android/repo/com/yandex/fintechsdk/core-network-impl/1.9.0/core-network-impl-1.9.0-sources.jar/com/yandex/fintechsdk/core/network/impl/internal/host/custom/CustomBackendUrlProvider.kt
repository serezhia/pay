package com.yandex.fintechsdk.core.network.impl.internal.host.custom

import android.content.SharedPreferences
import com.yandex.fintechsdk.core.network.impl.BuildConfig
import javax.inject.Inject

internal class CustomBackendUrlProvider @Inject constructor(
    private val sharedPreferences: SharedPreferences,
) {

    internal fun getCustomFrontbackUrl(): String? {
        if (!BuildConfig.DEBUG) return null
        val raw = sharedPreferences.getString(KEY_CUSTOM_FRONTBACK_URL, null)
        return raw?.processRawUrl()
    }

    internal fun getCustomPayBackendUrl(): String? {
        if (!BuildConfig.DEBUG) return null
        val raw = sharedPreferences.getString(KEY_CUSTOM_PAY_BACKEND_URL, null)
        return raw?.processRawUrl()
    }

    internal fun getCustomTovarischUrl(): String? {
        if (!BuildConfig.DEBUG) return null
        val raw = sharedPreferences.getString(KEY_CUSTOM_TOVARISCH_URL, null)
        return raw?.processRawUrl()
    }

    internal fun getCustomWalletUrl(): String? {
        if (!BuildConfig.DEBUG) return null
        val raw = sharedPreferences.getString(KEY_CUSTOM_WALLET_URL, null)
        return raw?.processRawUrl()
    }

    private fun String.processRawUrl() = this.trim().takeIf { it.isNotBlank() }

    private companion object {
        const val KEY_CUSTOM_FRONTBACK_URL = "finsdk_custom_frontback_url"
        const val KEY_CUSTOM_PAY_BACKEND_URL = "finsdk_custom_pay_backend_url"
        const val KEY_CUSTOM_TOVARISCH_URL = "finsdk_custom_tovarisch_url"
        const val KEY_CUSTOM_WALLET_URL = "finsdk_custom_wallet_url"
    }
}
