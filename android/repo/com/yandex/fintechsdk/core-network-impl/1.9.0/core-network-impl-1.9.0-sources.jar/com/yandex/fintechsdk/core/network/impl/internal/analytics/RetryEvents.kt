package com.yandex.fintechsdk.core.network.impl.internal.analytics

import com.yandex.fintechsdk.core.analytics.api.event.Event

internal data class RetryHandlerError(
    val attempt: Int,
    val baseUrl: String,
    val errorMessage: String?,
    val errorType: String,
    val handlerName: String,
    val path: String,
    val requestId: String,
) : Event(
    name = EVENT_NAME,
    params = buildMap {
        put(KEY_DESCRIPTION, DESCRIPTION)
        put(KEY_ATTEMPT, attempt.toString())
        put(KEY_BASE_URL, baseUrl)
        errorMessage?.let { put(KEY_ERROR_MESSAGE, it) }
        put(KEY_ERROR_TYPE, errorType)
        put(KEY_HANDLER_NAME, handlerName)
        put(KEY_PATH, path)
        put(KEY_REQUEST_ID, requestId)
    },
) {
    private companion object {
        const val EVENT_NAME = "retry_handler_error"
        const val DESCRIPTION = "Ошибка в обработчике повторных запросов"
        const val KEY_DESCRIPTION = "description"
        const val KEY_ATTEMPT = "attempt"
        const val KEY_BASE_URL = "base_url"
        const val KEY_ERROR_MESSAGE = "error_message"
        const val KEY_ERROR_TYPE = "error_type"
        const val KEY_HANDLER_NAME = "handler_name"
        const val KEY_PATH = "path"
        const val KEY_REQUEST_ID = "request_id"
    }
}
