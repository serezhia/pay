package com.yandex.fintechsdk.core.network.impl.internal.interceptor

import androidx.core.net.toUri
import com.yandex.fintechsdk.core.network.api.host.FrontbackUrlProvider
import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.impl.internal.host.custom.CustomBackendUrlProvider
import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject

internal class OverrideTovarischUrlInterceptor @Inject constructor(
    private val customBackendUrlProvider: CustomBackendUrlProvider,
    private val frontbackUrlProvider: FrontbackUrlProvider,
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val host = original.url.host

        val requestBuilder = original.newBuilder()

        val frontbackHost = frontbackUrlProvider.getHostUrl().toUri().host
        val customTovarischUrl = customBackendUrlProvider.getCustomTovarischUrl()
        if (host == frontbackHost && customTovarischUrl != null) {
            requestBuilder.header(name = Header.TovarischBaseUrl.key, value = customTovarischUrl)
        }

        return chain.proceed(requestBuilder.build())
    }
}
