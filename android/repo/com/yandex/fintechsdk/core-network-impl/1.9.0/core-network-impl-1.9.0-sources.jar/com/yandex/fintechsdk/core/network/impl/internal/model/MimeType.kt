package com.yandex.fintechsdk.core.network.impl.internal.model

import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull

internal enum class MimeType(val value: String) {
    APPLICATION_JSON("application/json");

    fun asMediaType(): MediaType? = value.toMediaTypeOrNull()
}
