package com.yandex.fintechsdk.core.network.impl.api.frontback

import com.yandex.fintechsdk.entities.environment.PayEnvironment

public interface FrontbackServiceTokenProvider {
    public fun getServiceToken(environment: PayEnvironment): String
}
