package com.yandex.fintechsdk.core.network.impl.api.headers

public interface BaseHeadersProvider {
    public fun getHeaders(): Map<String, String>
}
