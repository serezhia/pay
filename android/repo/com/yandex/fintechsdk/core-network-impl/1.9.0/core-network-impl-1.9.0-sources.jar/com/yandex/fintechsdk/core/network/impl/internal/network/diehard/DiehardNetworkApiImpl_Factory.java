package com.yandex.fintechsdk.core.network.impl.internal.network.diehard;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DiehardNetworkApiImpl_Factory implements Factory<DiehardNetworkApiImpl> {
  private final Provider<RequestExecutor> requestExecutorProvider;

  private final Provider<Analytics> analyticsProvider;

  private DiehardNetworkApiImpl_Factory(Provider<RequestExecutor> requestExecutorProvider,
      Provider<Analytics> analyticsProvider) {
    this.requestExecutorProvider = requestExecutorProvider;
    this.analyticsProvider = analyticsProvider;
  }

  @Override
  public DiehardNetworkApiImpl get() {
    return newInstance(requestExecutorProvider.get(), analyticsProvider.get());
  }

  public static DiehardNetworkApiImpl_Factory create(
      Provider<RequestExecutor> requestExecutorProvider, Provider<Analytics> analyticsProvider) {
    return new DiehardNetworkApiImpl_Factory(requestExecutorProvider, analyticsProvider);
  }

  public static DiehardNetworkApiImpl newInstance(RequestExecutor requestExecutor,
      Analytics analytics) {
    return new DiehardNetworkApiImpl(requestExecutor, analytics);
  }
}
