package com.yandex.fintechsdk.core.network.impl.internal.interceptor

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.network.api.extensions.baseUrl
import com.yandex.fintechsdk.core.network.api.extensions.path
import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.api.retry.NetworkRetryHandler
import com.yandex.fintechsdk.core.network.api.retry.RetryDecision
import com.yandex.fintechsdk.core.network.impl.internal.analytics.RetryHandlerError
import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject

/**
 * Universal interceptor for retries.
 * Executes registered NetworkRetryHandler instances.
 *
 * Stores attempt number in Request.tag() for use
 * in DefaultNetworkApiImpl when creating NetworkException.
 */
internal class RetryInterceptor @Inject constructor(
    private val analytics: Analytics,
    private val handlers: Set<@JvmSuppressWildcards NetworkRetryHandler>,
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        var originalRequest = chain.request()
        val maxAttempts = calculateMaxAttempts()
        var attempt = 0

        while (attempt < maxAttempts) {
            val request = prepareRequest(attempt = attempt, originalRequest = originalRequest)
            val response = chain.proceed(request)

            // Last attempt: return response without retry check
            if (attempt + 1 >= maxAttempts) {
                return response
            }

            // Check if any handler wants to retry
            val decision = shouldRetry(
                attempt = attempt,
                originalRequest = originalRequest,
                response = response,
            )

            when (decision) {
                RetryDecision.NoRetry -> return response
                RetryDecision.RetryWithOriginalRequest -> response.close()
                is RetryDecision.RetryWithModifiedRequest -> {
                    response.close()
                    originalRequest = decision.modifiedRequest
                }
            }

            attempt++
        }

        return chain.proceed(
            request = prepareRequest(
                attempt = attempt,
                originalRequest = originalRequest,
            )
        )
    }

    private fun calculateMaxAttempts(): Int {
        // Take maximum maxAttempts from all handlers, but at least 1 attempt
        val maxFromHandlers = handlers.maxOfOrNull { it.maxAttempts } ?: DEFAULT_MAX_ATTEMPTS
        return maxFromHandlers.coerceAtLeast(minimumValue = 1)
    }

    private fun prepareRequest(attempt: Int, originalRequest: okhttp3.Request): okhttp3.Request {
        return originalRequest.newBuilder()
            .tag(
                tag = RetryAttemptTag(attempt = attempt),
                type = RetryAttemptTag::class.java,
            )
            .build()
    }

    private fun shouldRetry(
        attempt: Int,
        originalRequest: okhttp3.Request,
        response: Response,
    ): RetryDecision {
        val bodyPeek = response.peekBody(Long.MAX_VALUE).string()
        val activeHandlers = getActiveHandlers(attempt = attempt)

        for (handler in activeHandlers) {
            val decision = checkHandler(
                handler = handler,
                attempt = attempt,
                bodyPeek = bodyPeek,
                originalRequest = originalRequest,
                response = response,
            )

            when (decision) {
                null, RetryDecision.NoRetry -> continue
                else -> return decision
            }
        }

        return RetryDecision.NoRetry
    }

    private fun getActiveHandlers(attempt: Int): Sequence<NetworkRetryHandler> {
        return handlers.asSequence()
            .filter { handler -> attempt < handler.maxAttempts }
    }

    private fun checkHandler(
        attempt: Int,
        bodyPeek: String,
        handler: NetworkRetryHandler,
        originalRequest: okhttp3.Request,
        response: Response,
    ): RetryDecision? {
        return runCatching {
            handler.shouldRetry(
                attempt = attempt,
                bodyPeek = bodyPeek,
                request = originalRequest,
                response = response,
            )
        }.onFailure { exception ->
            analytics.reportProductEvent(
                event = RetryHandlerError(
                    attempt = attempt + 1,
                    baseUrl = originalRequest.baseUrl,
                    errorMessage = exception.message,
                    errorType = exception::class.simpleName ?: UNKNOWN_ERROR_TYPE,
                    handlerName = handler::class.simpleName ?: UNKNOWN_HANDLER_NAME,
                    path = originalRequest.path,
                    requestId = response.header(Header.RequestId.key) ?: UNKNOWN_REQUEST_ID,
                )
            )
        }.getOrNull()
    }

    private companion object {
        const val TAG = "RetryInterceptor"
        const val DEFAULT_MAX_ATTEMPTS = 1
        const val UNKNOWN_REQUEST_ID = ""
        const val UNKNOWN_HANDLER_NAME = ""
        const val UNKNOWN_ERROR_TYPE = ""
    }
}

/**
 * Tag for storing attempt number in Request.
 */
internal data class RetryAttemptTag(val attempt: Int)
