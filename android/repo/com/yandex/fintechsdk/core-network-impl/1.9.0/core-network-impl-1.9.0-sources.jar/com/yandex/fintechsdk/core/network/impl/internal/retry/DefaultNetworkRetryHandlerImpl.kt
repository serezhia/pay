package com.yandex.fintechsdk.core.network.impl.internal.retry

import com.yandex.fintechsdk.core.network.api.retry.NetworkRetryHandler
import com.yandex.fintechsdk.core.network.api.retry.RetryDecision
import okhttp3.Request
import okhttp3.Response
import javax.inject.Inject

/**
 * Default implementation that never retries.
 * Needed so Dagger can create Set<NetworkRetryHandler>,
 * even if flows don't provide their own handlers.
 */
internal class DefaultNetworkRetryHandlerImpl @Inject constructor() : NetworkRetryHandler {

    override val maxAttempts: Int = 1

    override fun shouldRetry(
        attempt: Int,
        bodyPeek: String,
        request: Request,
        response: Response,
    ): RetryDecision {
        return RetryDecision.NoRetry
    }
}
