package com.yandex.fintechsdk.core.utils.impl.internal.adapter;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class AdapterFinderImpl_Factory implements Factory<AdapterFinderImpl> {
  private final Provider<Analytics> analyticsProvider;

  private AdapterFinderImpl_Factory(Provider<Analytics> analyticsProvider) {
    this.analyticsProvider = analyticsProvider;
  }

  @Override
  public AdapterFinderImpl get() {
    return newInstance(analyticsProvider.get());
  }

  public static AdapterFinderImpl_Factory create(Provider<Analytics> analyticsProvider) {
    return new AdapterFinderImpl_Factory(analyticsProvider);
  }

  public static AdapterFinderImpl newInstance(Analytics analytics) {
    return new AdapterFinderImpl(analytics);
  }
}
