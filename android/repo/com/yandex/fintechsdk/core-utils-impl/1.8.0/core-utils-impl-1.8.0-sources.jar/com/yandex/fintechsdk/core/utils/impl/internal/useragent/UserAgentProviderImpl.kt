package com.yandex.fintechsdk.core.utils.impl.internal.useragent

import android.content.Context
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider
import com.yandex.fintechsdk.core.utils.impl.BuildConfig
import javax.inject.Inject

internal class UserAgentProviderImpl @Inject constructor(
    @ApplicationContext private val context: Context,
) : UserAgentProvider {

    override fun get(): String {
        return buildString {
            append("FintechSDK/${BuildConfig.VERSION_NAME}")

            try {
                val packageName = context.packageName
                val versionName = context.packageManager.getPackageInfo(context.packageName, 0).versionName
                append(" ")
                append("$packageName/$versionName")
            } catch (_: Throwable) {}
        }
    }
}
