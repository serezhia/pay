package com.yandex.fintechsdk.core.utils.impl.internal.environment;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DebugEnvironmentCheckerImpl_Factory implements Factory<DebugEnvironmentCheckerImpl> {
  private final Provider<Context> contextProvider;

  private DebugEnvironmentCheckerImpl_Factory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public DebugEnvironmentCheckerImpl get() {
    return newInstance(contextProvider.get());
  }

  public static DebugEnvironmentCheckerImpl_Factory create(Provider<Context> contextProvider) {
    return new DebugEnvironmentCheckerImpl_Factory(contextProvider);
  }

  public static DebugEnvironmentCheckerImpl newInstance(Context context) {
    return new DebugEnvironmentCheckerImpl(context);
  }
}
