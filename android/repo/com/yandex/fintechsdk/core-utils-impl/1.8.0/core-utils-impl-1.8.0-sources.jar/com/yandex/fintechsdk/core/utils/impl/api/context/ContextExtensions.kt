package com.yandex.fintechsdk.core.utils.impl.api.context

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

public fun Context.isNightMode(): Boolean {
    return resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
}

public fun Context.currentLocale(): Locale {
    return resources.configuration.locales[0]
}
