package com.yandex.fintechsdk.core.utils.impl.internal.environment

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.utils.api.environment.DebugEnvironmentChecker
import com.yandex.fintechsdk.core.utils.impl.BuildConfig
import java.io.ByteArrayInputStream
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import javax.inject.Inject
import javax.security.auth.x500.X500Principal

internal class DebugEnvironmentCheckerImpl @Inject constructor(
    @ApplicationContext private val context: Context,
) : DebugEnvironmentChecker {
    private val debugCertificateSubject = X500Principal(DEBUG_CERTIFICATE_NAME)

    override fun isDebugEnvironment(): Boolean {
        return isBuildConfigDebug() && isDebuggableFlag() && isDebugCertificate() && isEmulator()
    }

    private fun isBuildConfigDebug(): Boolean {
        return BuildConfig.DEBUG
    }

    private fun isDebuggableFlag(): Boolean {
        return (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
    }

    @SuppressLint("PackageManagerGetSignatures")
    private fun isDebugCertificate(): Boolean {
        return runCatching {
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val signingInfo = context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNING_CERTIFICATES,
                ).signingInfo
                signingInfo?.apkContentsSigners ?: return@runCatching false
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.GET_SIGNATURES,
                ).signatures ?: return@runCatching false
            }

            val certificateFactory = CertificateFactory.getInstance(DEBUG_CERTIFICATE_TYPE)

            signatures.any { signature ->
                val certInputStream = ByteArrayInputStream(signature.toByteArray())
                val certificate = certificateFactory.generateCertificate(certInputStream) as X509Certificate

                debugCertificateSubject == certificate.subjectX500Principal
            }
        }.getOrDefault(false)
    }

    private fun isEmulator(): Boolean {
        return Build.HARDWARE in EMULATOR_HARDWARE
    }

    private companion object {
        private val EMULATOR_HARDWARE = listOf("goldfish", "ranchu")

        private const val DEBUG_CERTIFICATE_TYPE = "X509"

        private const val DEBUG_CERTIFICATE_NAME =
            "CN=Android Developer," +
                "OU=Development Certificate: do not use it in production," +
                "O=Yandex," +
                "L=Development Certificate: do not use it in production," +
                "ST=Development Certificate: do not use it in production," +
                "C=US"
    }
}
