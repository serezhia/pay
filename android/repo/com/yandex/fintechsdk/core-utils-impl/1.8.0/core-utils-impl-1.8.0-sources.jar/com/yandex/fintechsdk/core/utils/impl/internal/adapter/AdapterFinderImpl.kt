package com.yandex.fintechsdk.core.utils.impl.internal.adapter

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.utils.api.adapter.AdapterFinder
import javax.inject.Inject

internal class AdapterFinderImpl @Inject constructor(
    private val analytics: Analytics,
) : AdapterFinder {

    override fun <T> find(adapterClass: Class<T>, factoryClassName: String): T? {
        return try {
            val clazz = Class.forName(factoryClassName)
            val factoryConstructor = clazz.getConstructor()
            val factory = factoryConstructor.newInstance()
            val createAdapter = clazz.getMethod("create")
            if (adapterClass.isAssignableFrom(createAdapter.returnType)) {
                createAdapter.invoke(factory) as T
            } else {
                null
            }
        } catch (e: Exception) {
            analytics.reportRuntimeError(
                key = "adapter_creation_failed",
                exception = e,
            )
            null
        }
    }
}
