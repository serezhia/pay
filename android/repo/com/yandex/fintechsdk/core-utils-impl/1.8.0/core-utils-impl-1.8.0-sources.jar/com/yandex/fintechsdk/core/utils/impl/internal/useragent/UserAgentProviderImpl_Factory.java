package com.yandex.fintechsdk.core.utils.impl.internal.useragent;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UserAgentProviderImpl_Factory implements Factory<UserAgentProviderImpl> {
  private final Provider<Context> contextProvider;

  private UserAgentProviderImpl_Factory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public UserAgentProviderImpl get() {
    return newInstance(contextProvider.get());
  }

  public static UserAgentProviderImpl_Factory create(Provider<Context> contextProvider) {
    return new UserAgentProviderImpl_Factory(contextProvider);
  }

  public static UserAgentProviderImpl newInstance(Context context) {
    return new UserAgentProviderImpl(context);
  }
}
