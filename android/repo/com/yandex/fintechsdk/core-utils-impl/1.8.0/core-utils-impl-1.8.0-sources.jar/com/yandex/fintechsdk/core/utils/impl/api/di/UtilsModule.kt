package com.yandex.fintechsdk.core.utils.impl.api.di

import com.yandex.fintechsdk.core.utils.api.adapter.AdapterFinder
import com.yandex.fintechsdk.core.utils.api.environment.DebugEnvironmentChecker
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider
import com.yandex.fintechsdk.core.utils.impl.internal.adapter.AdapterFinderImpl
import com.yandex.fintechsdk.core.utils.impl.internal.environment.DebugEnvironmentCheckerImpl
import com.yandex.fintechsdk.core.utils.impl.internal.useragent.UserAgentProviderImpl
import dagger.Binds
import dagger.Module

@Module
public abstract class UtilsModule {

    @Binds
    internal abstract fun bindUserAgentProvider(impl: UserAgentProviderImpl): UserAgentProvider

    @Binds
    internal abstract fun bindAdapterFinder(impl: AdapterFinderImpl): AdapterFinder

    @Binds
    internal abstract fun bindDebugEnvironmentChecker(impl: DebugEnvironmentCheckerImpl): DebugEnvironmentChecker
}
