package com.yandex.fintechsdk.core.telemetry.api

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.RUNTIME)
public annotation class OpenTelemetryCoroutineScope
