package com.yandex.fintechsdk.core.telemetry.api

public interface OpenTelemetryTracer {

    /**
     * Возвращает билдер для создания нового спана.
     */
    public fun spanBuilder(spanName: String): Span.SpanBuilder

    /**
     * Запускает отправку спанов.
     */
    public fun startTrace()

    /**
     * Приостанавливает отправку спанов.
     * Отправка будет возобновлена автоматически при создании спана
     */
    public fun stopTrace()

    /**
     * Останавливает отправку событий.
     * Отправка не может быть возобновлена.
     * Все не отправленные события будут потеряны
     */
    public fun destroy()
}
