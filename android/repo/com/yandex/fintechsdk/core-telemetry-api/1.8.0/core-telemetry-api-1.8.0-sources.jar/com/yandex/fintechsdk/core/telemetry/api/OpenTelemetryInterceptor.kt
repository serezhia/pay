package com.yandex.fintechsdk.core.telemetry.api

import com.yandex.fintechsdk.core.telemetry.api.Span.Companion.generateSpanIdHexString
import okhttp3.Interceptor
import okhttp3.Response

public class OpenTelemetryInterceptor(
    private val tracer: OpenTelemetryTracer,
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val requestBuilder = original.newBuilder()

        val span = tracer
            .spanBuilder(REQUEST_SPAN_NAME)
            .setSpanId(generateSpanIdHexString())
            .start()
        val traceId = span.traceId
        val spanId = span.spanId

        // Header allows us to link native spans with backend spans
        requestBuilder.header(name = HEADER_NAME, value = "00-$traceId-$spanId-01")

        val response = chain.proceed(requestBuilder.build())

        span.setAttributes(
            mapOf(
                URL_KEY.to(original.url.toString()),
                IS_SUCCESSFUL_KEY.to(response.isSuccessful.toString()),
                RESPONSE_CODE_KEY.to(response.code.toString())
            )
        ).end()
        return response
    }

    private companion object {
        private const val REQUEST_SPAN_NAME = "make_request"
        private const val HEADER_NAME = "traceparent"
        private const val URL_KEY = "url"
        private const val IS_SUCCESSFUL_KEY = "isSuccessful"
        private const val RESPONSE_CODE_KEY = "response_code"
    }
}
