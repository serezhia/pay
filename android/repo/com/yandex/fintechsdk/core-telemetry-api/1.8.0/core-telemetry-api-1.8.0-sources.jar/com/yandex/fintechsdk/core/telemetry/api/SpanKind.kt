package com.yandex.fintechsdk.core.telemetry.api


public enum class SpanKind {
    /**
     * <pre>
     * Unspecified. Do NOT use as default.
     * Implementations MAY assume SpanKind to be INTERNAL when receiving UNSPECIFIED.
     */
    SPAN_KIND_UNSPECIFIED,

    /**
     * <pre>
     * Indicates that the span represents an internal operation within an application,
     * as opposed to an operation happening at the boundaries. Default value.
     */
    SPAN_KIND_INTERNAL,

    /**
     * <pre>
     * Indicates that the span covers server-side handling of an RPC or other
     * remote network request.
     */
    SPAN_KIND_SERVER,

    /**
     * <pre>
     * Indicates that the span describes a request to some remote service.
     */
    SPAN_KIND_CLIENT,

    /**
     * <pre>
     * Indicates that the span describes a producer sending a message to a broker.
     * Unlike CLIENT and SERVER, there is often no direct critical path latency relationship
     * between producer and consumer spans. A PRODUCER span ends when the message was accepted
     * by the broker while the logical processing of the message might span a much longer time.
     */
    SPAN_KIND_PRODUCER,

    /**
     * <pre>
     * Indicates that the span describes consumer receiving a message from a broker.
     * Like the PRODUCER kind, there is often no direct critical path latency relationship
     * between producer and consumer spans.
     */
    SPAN_KIND_CONSUMER,


    UNRECOGNIZED,
}
