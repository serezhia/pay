package com.yandex.fintechsdk.core.telemetry.api

import kotlin.random.Random

public class Span private constructor(
    public val spanName: String,
    public val traceId: String,
    public val spanId: String,
    public val kind: SpanKind,
    public val parentSpanId: String?,
    public val attributes: Map<String, String>,
    public val startTimeNanos: Long,
    public val endTimeNanos: Long,
) {

    public class SpanBuilder(
        private val spanName: String,
        public val traceId: String,
        private val sendSpan: (Span) -> Unit,
    ) {
        public var spanId: String? = null
        private var kind: SpanKind = SpanKind.SPAN_KIND_INTERNAL
        private var parentSpanId: String? = null
        private var attributes: MutableMap<String, String> = mutableMapOf()
        private var startTimeNanos: Long = 0L
        private var endTimeNanos: Long = 0L

        public fun setSpanId(spanId: String): SpanBuilder = apply {
            this.spanId = spanId
        }

        public fun setKind(kind: SpanKind): SpanBuilder = apply {
            this.kind = kind
        }

        public fun setParentId(parentSpanId: String): SpanBuilder = apply {
            this.parentSpanId = parentSpanId
        }

        public fun setAttributes(attributes: Map<String, String>): SpanBuilder = apply {
            this.attributes.putAll(attributes)
        }

        public fun start(): SpanBuilder = apply {
            this.startTimeNanos = System.currentTimeMillis() * MILLIS_TO_NANOS
        }

        public fun end(): Span {
            this.endTimeNanos = System.currentTimeMillis() * MILLIS_TO_NANOS
            val span = Span(
                spanName,
                traceId,
                spanId ?: generateSpanIdHexString(),
                kind,
                parentSpanId,
                attributes,
                startTimeNanos,
                endTimeNanos,
            )
            sendSpan(span)
            return span
        }
    }


    @OptIn(ExperimentalStdlibApi::class)
    public companion object Companion {

        public fun generateSpanIdHexString(): String {
            val randomBytes = Random.nextBytes(SPAN_ID_SIZE)
            return randomBytes.toHexString()
        }

        private const val MILLIS_TO_NANOS = 1_000_000

        internal const val SPAN_ID_SIZE = 8
    }
}
