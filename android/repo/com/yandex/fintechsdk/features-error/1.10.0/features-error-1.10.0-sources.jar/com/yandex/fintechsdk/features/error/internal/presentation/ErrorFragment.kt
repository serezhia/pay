package com.yandex.fintechsdk.features.error.internal.presentation

import android.os.Bundle
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.yandex.fintechsdk.core.architecture.api.component.injectFeatureComponentStore
import com.yandex.fintechsdk.core.architecture.api.fragment.BaseFragment
import com.yandex.fintechsdk.core.architecture.api.fragment.viewBinding
import com.yandex.fintechsdk.core.architecture.api.viewmodel.injectViewModel
import com.yandex.fintechsdk.core.ui.impl.R
import com.yandex.fintechsdk.core.ui.impl.databinding.FinsdkErrorViewDefaultBinding
import com.yandex.fintechsdk.features.error.internal.di.ErrorComponentStore

internal class ErrorFragment : BaseFragment<Unit, Unit>(R.layout.finsdk_error_view_default) {

    override val viewModel: ErrorViewModel by injectViewModel { componentStore.component.viewModel }

    private val componentStore: ErrorComponentStore by injectFeatureComponentStore(::ErrorComponentStore)

    private val binding: FinsdkErrorViewDefaultBinding by viewBinding(
        viewBindingProducer = FinsdkErrorViewDefaultBinding::bind,
    )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initViews()

        if (!componentStore.component.layoutOptions.ignoreInsets) {
            applyWindowInsets()
        }
    }

    private fun initViews() {
        initTryAgainButton()
        initCloseButton()
    }

    private fun initTryAgainButton() {
        binding.finsdkTryAgainButton.setOnClickListener {
            viewModel.onTryAgainClicked()
        }
    }

    private fun initCloseButton() {
        binding.finsdkCloseButton.setOnClickListener {
            viewModel.onCloseClicked()
        }
    }

    private fun applyWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, windowInsets ->
            val insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars())

            val paddingBottomInPx = (BOTTOM_PADDING_DP * view.context.resources.displayMetrics.density).toInt()
            view.setPadding(
                view.paddingLeft,
                view.paddingTop,
                view.paddingRight,
                paddingBottomInPx + insets.bottom,
            )

            windowInsets
        }
    }

    companion object {
        private const val BOTTOM_PADDING_DP = 12
    }
}
