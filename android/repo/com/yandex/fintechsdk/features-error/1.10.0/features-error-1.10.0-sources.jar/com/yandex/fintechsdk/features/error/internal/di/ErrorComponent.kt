package com.yandex.fintechsdk.features.error.internal.di

import com.yandex.fintechsdk.core.architecture.api.component.FintechComponent
import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import com.yandex.fintechsdk.features.error.api.dependencies.ErrorDependencies
import com.yandex.fintechsdk.features.error.api.dependencies.layout.ErrorLayoutOptions
import com.yandex.fintechsdk.features.error.internal.presentation.ErrorViewModel
import dagger.Component

@FeatureScope
@Component(
    dependencies = [ErrorDependencies::class],
)
internal interface ErrorComponent : FintechComponent {

    val viewModel: ErrorViewModel
    val layoutOptions: ErrorLayoutOptions

    @Component.Factory
    interface Factory {
        fun create(dependencies: ErrorDependencies): ErrorComponent
    }
}
