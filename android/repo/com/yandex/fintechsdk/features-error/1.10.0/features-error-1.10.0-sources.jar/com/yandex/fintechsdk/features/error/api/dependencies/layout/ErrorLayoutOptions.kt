package com.yandex.fintechsdk.features.error.api.dependencies.layout

public interface ErrorLayoutOptions {
    public val ignoreInsets: Boolean
}
