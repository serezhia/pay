package com.yandex.fintechsdk.features.error.api.di;

import com.yandex.fintechsdk.core.architecture.api.feature.graph.FeatureGraphProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ErrorModule_ProvideFeatureGraphProviderFactory implements Factory<FeatureGraphProvider> {
  private final ErrorModule module;

  private ErrorModule_ProvideFeatureGraphProviderFactory(ErrorModule module) {
    this.module = module;
  }

  @Override
  public FeatureGraphProvider get() {
    return provideFeatureGraphProvider(module);
  }

  public static ErrorModule_ProvideFeatureGraphProviderFactory create(ErrorModule module) {
    return new ErrorModule_ProvideFeatureGraphProviderFactory(module);
  }

  public static FeatureGraphProvider provideFeatureGraphProvider(ErrorModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideFeatureGraphProvider());
  }
}
