package com.yandex.fintechsdk.features.error.api.di

import com.yandex.fintechsdk.core.architecture.api.feature.graph.FeatureGraphProvider
import com.yandex.fintechsdk.features.error.internal.navigation.ErrorFeatureGraphProvider
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoSet

@Module
public class ErrorModule {

    @Provides
    @IntoSet
    public fun provideFeatureGraphProvider(): FeatureGraphProvider {
        return ErrorFeatureGraphProvider()
    }
}
