package com.yandex.fintechsdk.features.error.api.dependencies

import com.yandex.fintechsdk.core.architecture.api.feature.dependencies.FeatureDependencies
import com.yandex.fintechsdk.features.error.api.dependencies.navigation.ErrorNavigator

public interface ErrorDependencies : FeatureDependencies {
    public val errorNavigator: ErrorNavigator
}
