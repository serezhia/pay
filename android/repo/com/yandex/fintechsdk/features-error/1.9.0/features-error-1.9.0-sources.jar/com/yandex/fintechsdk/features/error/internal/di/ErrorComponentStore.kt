package com.yandex.fintechsdk.features.error.internal.di

import androidx.lifecycle.ViewModel
import com.yandex.fintechsdk.core.architecture.api.component.FintechComponentStore
import com.yandex.fintechsdk.features.error.api.dependencies.ErrorDependencies

internal class ErrorComponentStore(
    dependencies: ErrorDependencies,
) : ViewModel(), FintechComponentStore {
    override val component: ErrorComponent = DaggerErrorComponent.factory().create(dependencies)
}
