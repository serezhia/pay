package com.yandex.fintechsdk.features.error.api.dependencies.navigation

public interface ErrorNavigator {

    public fun back()

    public fun toNextScreen()
}
