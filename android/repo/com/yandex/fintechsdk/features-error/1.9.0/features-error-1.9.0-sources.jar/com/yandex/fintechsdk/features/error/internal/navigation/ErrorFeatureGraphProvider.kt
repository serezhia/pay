package com.yandex.fintechsdk.features.error.internal.navigation

import androidx.navigation.NavController
import androidx.navigation.NavGraph
import com.yandex.fintechsdk.core.architecture.api.feature.graph.FeatureGraphProvider
import com.yandex.fintechsdk.features.error.R

internal class ErrorFeatureGraphProvider : FeatureGraphProvider {

    override fun provideFeatureGraph(navController: NavController): NavGraph {
        return navController.navInflater.inflate(R.navigation.finsdk_error_graph)
    }
}
