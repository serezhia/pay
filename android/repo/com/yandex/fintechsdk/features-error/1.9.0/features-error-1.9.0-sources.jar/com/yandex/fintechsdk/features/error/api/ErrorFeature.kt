package com.yandex.fintechsdk.features.error.api

public object ErrorFeature {
    public const val GRAPH_ROUTE: String = "error"
}
