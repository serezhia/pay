package com.yandex.fintechsdk.features.error.internal.presentation

import com.yandex.fintechsdk.core.architecture.api.viewmodel.BaseViewModel
import com.yandex.fintechsdk.features.error.api.dependencies.navigation.ErrorNavigator
import javax.inject.Inject

internal class ErrorViewModel @Inject constructor(
    private val errorNavigator: ErrorNavigator,
) : BaseViewModel<Unit, Unit>(
    initialState = Unit,
) {

    override fun onBackPressed() {
        errorNavigator.back()
    }

    fun onTryAgainClicked() {
        errorNavigator.toNextScreen()
    }

    fun onCloseClicked() {
        errorNavigator.back()
    }
}
