package com.yandex.fintechsdk.features.error.internal.di;

import com.yandex.fintechsdk.features.error.api.dependencies.ErrorDependencies;
import com.yandex.fintechsdk.features.error.internal.presentation.ErrorViewModel;
import dagger.internal.DaggerGenerated;
import dagger.internal.Preconditions;
import javax.annotation.processing.Generated;

@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DaggerErrorComponent {
  private DaggerErrorComponent() {
  }

  public static ErrorComponent.Factory factory() {
    return new Factory();
  }

  private static final class Factory implements ErrorComponent.Factory {
    @Override
    public ErrorComponent create(ErrorDependencies dependencies) {
      Preconditions.checkNotNull(dependencies);
      return new ErrorComponentImpl(dependencies);
    }
  }

  private static final class ErrorComponentImpl implements ErrorComponent {
    private final ErrorDependencies errorDependencies;

    private final ErrorComponentImpl errorComponentImpl = this;

    ErrorComponentImpl(ErrorDependencies errorDependenciesParam) {
      this.errorDependencies = errorDependenciesParam;

    }

    @Override
    public ErrorViewModel getViewModel() {
      return new ErrorViewModel(Preconditions.checkNotNullFromComponent(errorDependencies.getErrorNavigator()));
    }
  }
}
