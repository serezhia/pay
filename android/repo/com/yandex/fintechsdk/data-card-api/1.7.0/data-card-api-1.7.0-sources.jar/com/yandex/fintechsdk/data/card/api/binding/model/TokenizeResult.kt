package com.yandex.fintechsdk.data.card.api.binding.model

public data class TokenizeResult(
    val requestId: String,
    val pmd: String,
    val psd: String?,
)
