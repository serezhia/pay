package com.yandex.fintechsdk.data.card.api.binding.model

public data class TokenizeContext(
    public val uid: String,
    public val loginId: String,
    public val op: String,
    public val opId: String,
)
