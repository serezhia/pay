package com.yandex.fintechsdk.data.card.api.binding

import com.yandex.fintechsdk.entities.card.BinInfo
import com.yandex.fintechsdk.data.card.api.binding.model.CardBindingCurrency
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeCardData
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeMethod
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeResult
import kotlinx.serialization.json.JsonObject

public interface CardBindingRepository {

    public suspend fun initVerification(currency: CardBindingCurrency): Result<JsonObject>

    public suspend fun tokenize(baseUrl: String, method: TokenizeMethod, data: TokenizeCardData, context: JsonObject): Result<TokenizeResult>

    public suspend fun getBinInfo(baseUrl: String, prefix: String): Result<BinInfo>
}
