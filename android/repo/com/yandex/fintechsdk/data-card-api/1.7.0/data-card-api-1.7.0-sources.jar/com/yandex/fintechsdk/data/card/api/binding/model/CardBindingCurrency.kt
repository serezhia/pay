package com.yandex.fintechsdk.data.card.api.binding.model

public enum class CardBindingCurrency {
    RUB,
}
