package com.yandex.fintechsdk.data.card.api.binding.model

public data class TokenizeCardData(
    val pan: String,
    val expirationYear: String,
    val expirationMonth: String,
    val secretCode: String?,
    val holderName: String?,
)
