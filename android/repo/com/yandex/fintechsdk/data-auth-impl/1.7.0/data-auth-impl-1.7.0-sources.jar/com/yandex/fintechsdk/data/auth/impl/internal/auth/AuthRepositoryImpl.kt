package com.yandex.fintechsdk.data.auth.impl.internal.auth

import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.auth.api.AuthState
import com.yandex.fintechsdk.data.auth.impl.internal.storage.SecureTokenStorage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@FlowScope
internal class AuthRepositoryImpl @Inject constructor(
    private val secureTokenStorage: SecureTokenStorage,
) : AuthRepository {

    private val _authState: MutableStateFlow<AuthState> = MutableStateFlow(loadInitialState())
    override val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _uidState: MutableStateFlow<Long?> = MutableStateFlow(
        (_authState.value as? AuthState.Authorized)?.credentials?.uid
    )
    override val uidState: StateFlow<Long?> = _uidState.asStateFlow()

    override fun setAuthState(authState: AuthState) {
        _authState.value = authState

        when (authState) {
            is AuthState.Authorized -> {
                _uidState.value = authState.credentials.uid
                secureTokenStorage.saveCredentials(
                    token = authState.credentials.token,
                    uid = authState.credentials.uid,
                )
            }
            else -> _uidState.value = null
        }
    }

    override fun clearCredentials() {
        secureTokenStorage.clear()
        _authState.value = AuthState.Unauthorized
        _uidState.value = null
    }

    private fun loadInitialState(): AuthState {
        val credentials = secureTokenStorage.getCredentials() ?: return AuthState.Initial
        return AuthState.Authorized(credentials = credentials)
    }
}
