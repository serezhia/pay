/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.yandex.fintechsdk.data.auth.impl;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.yandex.fintechsdk.data.auth.impl";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_NAME = "1.10.0";
}
