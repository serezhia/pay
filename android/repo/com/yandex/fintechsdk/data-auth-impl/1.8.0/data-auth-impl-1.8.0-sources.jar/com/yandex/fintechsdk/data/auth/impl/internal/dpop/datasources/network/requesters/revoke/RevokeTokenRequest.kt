package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.revoke

import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod

internal class RevokeTokenRequest(
    private val token: String,
) : Request(configure = { isAuthNeeded = false }) {

    override val method: RestMethod = RestMethod.POST
    override val requestName: String = "authenticator_tokens_revoke"
    override val requestPath: String = REQUEST_PATH

    override fun headers(): Map<String, String> {
        return mapOf(Header.Authorization.key to "$OAUTH_PREFIX$token")
    }

    companion object {
        const val REQUEST_PATH = "/api/v1/authenticator/tokens/revoke"
        private const val OAUTH_PREFIX = "OAuth "
    }
}

