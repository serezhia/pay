package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.request

internal class GenerateAuthSessionParams(
    val dpop: String,
    val merchantId: String,
)

