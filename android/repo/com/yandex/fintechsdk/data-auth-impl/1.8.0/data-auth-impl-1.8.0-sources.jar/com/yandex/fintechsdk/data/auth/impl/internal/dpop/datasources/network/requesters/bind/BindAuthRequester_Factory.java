package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind;

import com.yandex.fintechsdk.core.network.api.network.PayNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BindAuthRequester_Factory implements Factory<BindAuthRequester> {
  private final Provider<PayNetworkApi> apiProvider;

  private BindAuthRequester_Factory(Provider<PayNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public BindAuthRequester get() {
    return newInstance(apiProvider.get());
  }

  public static BindAuthRequester_Factory create(Provider<PayNetworkApi> apiProvider) {
    return new BindAuthRequester_Factory(apiProvider);
  }

  public static BindAuthRequester newInstance(PayNetworkApi api) {
    return new BindAuthRequester(api);
  }
}
