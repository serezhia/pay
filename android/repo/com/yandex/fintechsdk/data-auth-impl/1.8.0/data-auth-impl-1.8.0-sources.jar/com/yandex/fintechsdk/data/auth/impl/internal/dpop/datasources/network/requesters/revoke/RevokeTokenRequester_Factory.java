package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.revoke;

import com.yandex.fintechsdk.core.network.api.network.PayNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RevokeTokenRequester_Factory implements Factory<RevokeTokenRequester> {
  private final Provider<PayNetworkApi> apiProvider;

  private RevokeTokenRequester_Factory(Provider<PayNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public RevokeTokenRequester get() {
    return newInstance(apiProvider.get());
  }

  public static RevokeTokenRequester_Factory create(Provider<PayNetworkApi> apiProvider) {
    return new RevokeTokenRequester_Factory(apiProvider);
  }

  public static RevokeTokenRequester newInstance(PayNetworkApi api) {
    return new RevokeTokenRequester(api);
  }
}
