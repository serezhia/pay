package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network

import com.yandex.fintechsdk.core.security.api.dpop.Jwk
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind.BindAuthRequester
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.GenerateAuthSessionRequester
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.request.GenerateAuthSessionParams
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.revoke.RevokeTokenRequester
import javax.inject.Inject

internal class DpopNetworkDataSource @Inject constructor(
    private val bindAuthRequester: BindAuthRequester,
    private val generateAuthSessionRequester: GenerateAuthSessionRequester,
    private val revokeTokenRequester: RevokeTokenRequester,
) {

    suspend fun bindAuth(jwk: Jwk): Result<Unit> {
        return bindAuthRequester.execute(params = jwk)
    }

    suspend fun revokeToken(token: String): Result<Unit> {
        return revokeTokenRequester.execute(params = token)
    }

    suspend fun generateSession(dpop: String, merchantId: String): Result<String> {
        return generateAuthSessionRequester.execute(
            params = GenerateAuthSessionParams(
                dpop = dpop,
                merchantId = merchantId,
            ),
        )
    }
}
