package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.request

import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

internal class GenerateAuthSessionRequest(
    private val dpop: String,
    private val merchantId: String,
) : Request() {

    override val method: RestMethod = METHOD
    override val requestName: String = "authenticator_sessions_generate"
    override val requestPath: String = REQUEST_PATH

    override fun headers(): Map<String, String> {
        return mapOf(Header.Dpop.key to dpop)
    }

    override fun body(): JsonObject = buildJsonObject {
        put(JSON_KEY_MERCHANT_ID, merchantId)
    }

    companion object {
        val METHOD: RestMethod = RestMethod.POST
        const val REQUEST_PATH: String = "/api/v1/authenticator/sessions/generate"
        private const val JSON_KEY_MERCHANT_ID: String = "merchant_id"
    }
}
