package com.yandex.fintechsdk.data.auth.impl.api.di

import android.content.Context
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.auth.api.dpop.DpopRepository
import com.yandex.fintechsdk.data.auth.impl.internal.auth.AuthRepositoryImpl
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.DpopRepositoryImpl
import com.yandex.fintechsdk.data.auth.impl.internal.storage.SecureTokenStorage
import dagger.Binds
import dagger.Module
import dagger.Provides

@Module
public abstract class DataAuthModule {

    @FlowScope
    @Binds
    internal abstract fun bindAuthRepository(impl: AuthRepositoryImpl): AuthRepository

    @FlowScope
    @Binds
    internal abstract fun bindDpopRepository(impl: DpopRepositoryImpl): DpopRepository

    public companion object {
        @FlowScope
        @Provides
        internal fun provideSecureTokenStorage(
            @ApplicationContext context: Context,
        ): SecureTokenStorage {
            return SecureTokenStorage(context = context)
        }
    }
}
