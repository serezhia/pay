package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class GenerateAuthSessionResponse(
    @SerialName("session_token")
    val sessionToken: String,

    @SerialName("expires_at")
    val expiresAt: Long,
)
