package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.memory

import javax.inject.Inject

internal class DpopMemoryDataSource @Inject constructor() {

    private var authSession: String? = null

    fun getAuthSession(): String? {
        return synchronized(this) {
            authSession
        }
    }

    fun setAuthSession(authSession: String?) {
        synchronized(this) {
            this.authSession = authSession
        }
    }

    fun clearAuthSession() {
        synchronized(this) {
            authSession = null
        }
    }
}
