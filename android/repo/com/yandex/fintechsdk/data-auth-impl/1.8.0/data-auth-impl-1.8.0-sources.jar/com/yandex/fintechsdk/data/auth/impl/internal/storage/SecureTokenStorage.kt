package com.yandex.fintechsdk.data.auth.impl.internal.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.yandex.fintechsdk.entities.auth.AccountCredentials

internal class SecureTokenStorage(
    context: Context,
) {

    private val prefs: SharedPreferences? = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (e: Exception) {
        // Ignore - graceful degradation
        null
    }

    fun saveCredentials(
        token: String,
        uid: Long,
    ) {
        try {
            prefs?.edit()?.apply {
                putString(KEY_TOKEN, token)
                putLong(KEY_UID, uid)
                apply()
            }
        } catch (e: Exception) {
            // Ignore - graceful degradation
        }
    }

    fun getCredentials(): AccountCredentials? {
        return try {
            val token = prefs?.getString(KEY_TOKEN, null) ?: return null
            val uid = prefs.getLong(KEY_UID, Long.MIN_VALUE)
            if (uid == Long.MIN_VALUE) return null
            AccountCredentials(
                token = token,
                uid = uid,
            )
        } catch (e: Exception) {
            null
        }
    }

    fun clear() {
        try {
            prefs?.edit()?.clear()?.apply()
        } catch (e: Exception) {
            // Ignore - graceful degradation
        }
    }

    private companion object {
        private const val PREFS_NAME = "fintechsdk.auth"
        private const val KEY_TOKEN = "oauth_token"
        private const val KEY_UID = "uid"
    }
}

