package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.revoke

import com.yandex.fintechsdk.core.network.api.network.PayNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import javax.inject.Inject

internal class RevokeTokenRequester @Inject constructor(
    private val api: PayNetworkApi,
) : Requester<String, RevokeTokenRequest, Unit, Unit>() {

    override fun createRequest(params: String): RevokeTokenRequest {
        return RevokeTokenRequest(token = params)
    }

    override suspend fun executeRequest(request: RevokeTokenRequest): Result<Unit> {
        return api.sendRequest(request = request)
    }

    override fun transformResponse(response: Unit): Unit = response
}

