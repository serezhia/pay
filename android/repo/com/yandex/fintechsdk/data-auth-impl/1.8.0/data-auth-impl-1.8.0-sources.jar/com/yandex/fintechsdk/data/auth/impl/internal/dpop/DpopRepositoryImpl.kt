package com.yandex.fintechsdk.data.auth.impl.internal.dpop

import androidx.fragment.app.FragmentActivity
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.core.security.api.dpop.DpopManager
import com.yandex.fintechsdk.data.auth.api.dpop.DpopRepository
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.memory.DpopMemoryDataSource
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.DpopNetworkDataSource
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.request.GenerateAuthSessionRequest
import javax.inject.Inject

@FlowScope
internal class DpopRepositoryImpl @Inject constructor(
    private val dpopManager: DpopManager,
    private val memoryDataSource: DpopMemoryDataSource,
    private val networkDataSource: DpopNetworkDataSource,
) : DpopRepository {

    override fun getCachedAuthSession(): String? {
        return memoryDataSource.getAuthSession()
    }

    override fun clearCachedAuthSession() {
        memoryDataSource.clearAuthSession()
    }

    override suspend fun bindAuth(): Result<Unit> {
        val jwk = dpopManager.getDpopJwk().getOrNull()

        jwk ?: return Result.failure(exception = IllegalStateException("Could not get jwk"))

        return networkDataSource.bindAuth(jwk = jwk)
    }

    override suspend fun revokeToken(token: String): Result<Unit> {
        return networkDataSource.revokeToken(token = token)
    }

    override suspend fun generateAuthSession(
        activity: FragmentActivity,
        authToken: String,
        merchantId: String,
    ): Result<String> {
        val dpopHeader = dpopManager.createDpopHeader(
            activity = activity,
            authToken = authToken,
            restMethod = GenerateAuthSessionRequest.METHOD.name,
            path = GenerateAuthSessionRequest.REQUEST_PATH,
        ).getOrNull()

        dpopHeader ?: return Result.failure(exception = IllegalStateException("Could not create dpop header"))

        return networkDataSource.generateSession(
            dpop = dpopHeader,
            merchantId = merchantId,
        ).onSuccess { authSession ->
            memoryDataSource.setAuthSession(authSession = authSession)
        }
    }
}
