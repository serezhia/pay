package com.yandex.fintechsdk.data.auth.impl.api.di;

import android.content.Context;
import com.yandex.fintechsdk.data.auth.impl.internal.storage.SecureTokenStorage;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DataAuthModule_Companion_ProvideSecureTokenStorage$impl_releaseFactory implements Factory<SecureTokenStorage> {
  private final Provider<Context> contextProvider;

  private DataAuthModule_Companion_ProvideSecureTokenStorage$impl_releaseFactory(
      Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public SecureTokenStorage get() {
    return provideSecureTokenStorage$impl_release(contextProvider.get());
  }

  public static DataAuthModule_Companion_ProvideSecureTokenStorage$impl_releaseFactory create(
      Provider<Context> contextProvider) {
    return new DataAuthModule_Companion_ProvideSecureTokenStorage$impl_releaseFactory(contextProvider);
  }

  public static SecureTokenStorage provideSecureTokenStorage$impl_release(Context context) {
    return Preconditions.checkNotNullFromProvides(DataAuthModule.Companion.provideSecureTokenStorage$impl_release(context));
  }
}
