package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate

import com.yandex.fintechsdk.core.network.api.network.PayNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.request.GenerateAuthSessionParams
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.request.GenerateAuthSessionRequest
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.response.GenerateAuthSessionResponse
import javax.inject.Inject

internal class GenerateAuthSessionRequester @Inject constructor(
    private val api: PayNetworkApi,
) : Requester<GenerateAuthSessionParams, GenerateAuthSessionRequest, GenerateAuthSessionResponse, String>() {

    override fun createRequest(params: GenerateAuthSessionParams): GenerateAuthSessionRequest {
        return GenerateAuthSessionRequest(
            dpop = params.dpop,
            merchantId = params.merchantId,
        )
    }

    override suspend fun executeRequest(request: GenerateAuthSessionRequest): Result<GenerateAuthSessionResponse> {
        return api.sendRequest(request = request)
    }

    override fun transformResponse(response: GenerateAuthSessionResponse): String {
        return response.sessionToken
    }
}
