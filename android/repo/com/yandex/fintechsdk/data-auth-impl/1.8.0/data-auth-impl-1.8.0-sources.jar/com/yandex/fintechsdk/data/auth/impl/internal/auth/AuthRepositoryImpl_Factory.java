package com.yandex.fintechsdk.data.auth.impl.internal.auth;

import com.yandex.fintechsdk.data.auth.api.AuthOptionsProvider;
import com.yandex.fintechsdk.data.auth.impl.internal.storage.SecureTokenStorage;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class AuthRepositoryImpl_Factory implements Factory<AuthRepositoryImpl> {
  private final Provider<AuthOptionsProvider> authOptionsProvider;

  private final Provider<SecureTokenStorage> secureTokenStorageProvider;

  private AuthRepositoryImpl_Factory(Provider<AuthOptionsProvider> authOptionsProvider,
      Provider<SecureTokenStorage> secureTokenStorageProvider) {
    this.authOptionsProvider = authOptionsProvider;
    this.secureTokenStorageProvider = secureTokenStorageProvider;
  }

  @Override
  public AuthRepositoryImpl get() {
    return newInstance(authOptionsProvider.get(), secureTokenStorageProvider.get());
  }

  public static AuthRepositoryImpl_Factory create(Provider<AuthOptionsProvider> authOptionsProvider,
      Provider<SecureTokenStorage> secureTokenStorageProvider) {
    return new AuthRepositoryImpl_Factory(authOptionsProvider, secureTokenStorageProvider);
  }

  public static AuthRepositoryImpl newInstance(AuthOptionsProvider authOptionsProvider,
      SecureTokenStorage secureTokenStorage) {
    return new AuthRepositoryImpl(authOptionsProvider, secureTokenStorage);
  }
}
