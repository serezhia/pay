package com.yandex.fintechsdk.data.auth.impl.internal.dpop;

import com.yandex.fintechsdk.core.security.api.dpop.DpopManager;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.memory.DpopMemoryDataSource;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.DpopNetworkDataSource;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DpopRepositoryImpl_Factory implements Factory<DpopRepositoryImpl> {
  private final Provider<DpopManager> dpopManagerProvider;

  private final Provider<DpopMemoryDataSource> memoryDataSourceProvider;

  private final Provider<DpopNetworkDataSource> networkDataSourceProvider;

  private DpopRepositoryImpl_Factory(Provider<DpopManager> dpopManagerProvider,
      Provider<DpopMemoryDataSource> memoryDataSourceProvider,
      Provider<DpopNetworkDataSource> networkDataSourceProvider) {
    this.dpopManagerProvider = dpopManagerProvider;
    this.memoryDataSourceProvider = memoryDataSourceProvider;
    this.networkDataSourceProvider = networkDataSourceProvider;
  }

  @Override
  public DpopRepositoryImpl get() {
    return newInstance(dpopManagerProvider.get(), memoryDataSourceProvider.get(), networkDataSourceProvider.get());
  }

  public static DpopRepositoryImpl_Factory create(Provider<DpopManager> dpopManagerProvider,
      Provider<DpopMemoryDataSource> memoryDataSourceProvider,
      Provider<DpopNetworkDataSource> networkDataSourceProvider) {
    return new DpopRepositoryImpl_Factory(dpopManagerProvider, memoryDataSourceProvider, networkDataSourceProvider);
  }

  public static DpopRepositoryImpl newInstance(DpopManager dpopManager,
      DpopMemoryDataSource memoryDataSource, DpopNetworkDataSource networkDataSource) {
    return new DpopRepositoryImpl(dpopManager, memoryDataSource, networkDataSource);
  }
}
