package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind

import com.yandex.fintechsdk.core.network.api.network.PayNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.core.security.api.dpop.Jwk
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind.request.BindAuthRequest
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind.request.BindAuthRequestDto
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind.request.PublicKeyDto
import javax.inject.Inject

internal class BindAuthRequester @Inject constructor(
    private val api: PayNetworkApi,
) : Requester<Jwk, BindAuthRequest, Unit, Unit>() {

    override fun createRequest(params: Jwk): BindAuthRequest {
        return BindAuthRequest(
            requestDto = BindAuthRequestDto(
                publicKey = PublicKeyDto(
                    crv = params.crv,
                    kty = params.kty,
                    x = params.x,
                    y = params.y,
                )
            )
        )
    }

    override suspend fun executeRequest(request: BindAuthRequest): Result<Unit> {
        return api.sendRequest(request = request)
    }

    override fun transformResponse(response: Unit): Unit = response
}
