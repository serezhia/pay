package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.memory;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DpopMemoryDataSource_Factory implements Factory<DpopMemoryDataSource> {
  @Override
  public DpopMemoryDataSource get() {
    return newInstance();
  }

  public static DpopMemoryDataSource_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DpopMemoryDataSource newInstance() {
    return new DpopMemoryDataSource();
  }

  private static final class InstanceHolder {
    static final DpopMemoryDataSource_Factory INSTANCE = new DpopMemoryDataSource_Factory();
  }
}
