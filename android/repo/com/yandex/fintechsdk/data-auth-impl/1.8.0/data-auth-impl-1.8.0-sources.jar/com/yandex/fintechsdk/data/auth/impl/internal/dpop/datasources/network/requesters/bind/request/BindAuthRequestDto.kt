package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind.request

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class BindAuthRequestDto(
    @SerialName("public_key")
    val publicKey: PublicKeyDto,
)

@Serializable
internal class PublicKeyDto(
    @SerialName("crv")
    val crv: String,

    @SerialName("kty")
    val kty: String,

    @SerialName("x")
    val x: String,

    @SerialName("y")
    val y: String,
)
