package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network;

import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind.BindAuthRequester;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.GenerateAuthSessionRequester;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.revoke.RevokeTokenRequester;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DpopNetworkDataSource_Factory implements Factory<DpopNetworkDataSource> {
  private final Provider<BindAuthRequester> bindAuthRequesterProvider;

  private final Provider<GenerateAuthSessionRequester> generateAuthSessionRequesterProvider;

  private final Provider<RevokeTokenRequester> revokeTokenRequesterProvider;

  private DpopNetworkDataSource_Factory(Provider<BindAuthRequester> bindAuthRequesterProvider,
      Provider<GenerateAuthSessionRequester> generateAuthSessionRequesterProvider,
      Provider<RevokeTokenRequester> revokeTokenRequesterProvider) {
    this.bindAuthRequesterProvider = bindAuthRequesterProvider;
    this.generateAuthSessionRequesterProvider = generateAuthSessionRequesterProvider;
    this.revokeTokenRequesterProvider = revokeTokenRequesterProvider;
  }

  @Override
  public DpopNetworkDataSource get() {
    return newInstance(bindAuthRequesterProvider.get(), generateAuthSessionRequesterProvider.get(), revokeTokenRequesterProvider.get());
  }

  public static DpopNetworkDataSource_Factory create(
      Provider<BindAuthRequester> bindAuthRequesterProvider,
      Provider<GenerateAuthSessionRequester> generateAuthSessionRequesterProvider,
      Provider<RevokeTokenRequester> revokeTokenRequesterProvider) {
    return new DpopNetworkDataSource_Factory(bindAuthRequesterProvider, generateAuthSessionRequesterProvider, revokeTokenRequesterProvider);
  }

  public static DpopNetworkDataSource newInstance(BindAuthRequester bindAuthRequester,
      GenerateAuthSessionRequester generateAuthSessionRequester,
      RevokeTokenRequester revokeTokenRequester) {
    return new DpopNetworkDataSource(bindAuthRequester, generateAuthSessionRequester, revokeTokenRequester);
  }
}
