package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate;

import com.yandex.fintechsdk.core.network.api.network.PayNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GenerateAuthSessionRequester_Factory implements Factory<GenerateAuthSessionRequester> {
  private final Provider<PayNetworkApi> apiProvider;

  private GenerateAuthSessionRequester_Factory(Provider<PayNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public GenerateAuthSessionRequester get() {
    return newInstance(apiProvider.get());
  }

  public static GenerateAuthSessionRequester_Factory create(Provider<PayNetworkApi> apiProvider) {
    return new GenerateAuthSessionRequester_Factory(apiProvider);
  }

  public static GenerateAuthSessionRequester newInstance(PayNetworkApi api) {
    return new GenerateAuthSessionRequester(api);
  }
}
