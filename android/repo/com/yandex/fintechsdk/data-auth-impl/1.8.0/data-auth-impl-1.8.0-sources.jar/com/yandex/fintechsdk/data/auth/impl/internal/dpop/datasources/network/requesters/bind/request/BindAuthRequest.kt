package com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind.request

import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.encodeToJsonElement
import kotlinx.serialization.json.jsonObject

internal class BindAuthRequest(
    private val requestDto: BindAuthRequestDto,
) : Request() {

    override val method: RestMethod = RestMethod.POST
    override val requestName: String = "authenticator_bind"
    override val requestPath: String = "/api/v1/authenticator/bind"

    override fun body(): JsonObject {
        return Json.encodeToJsonElement(value = requestDto).jsonObject
    }
}
