package com.yandex.fintechsdk.core.analytics.api.identifiers

public interface IdentifiersProvider {

    public fun getGaid(): String?

    public fun getAppMetricaDeviceId(): String?

    public fun getUuid(): String?
}
