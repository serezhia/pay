package com.yandex.fintechsdk.core.analytics.api.event

public open class Event(
    public val name: String,
    public val params: Map<String, String> = emptyMap(),
)
