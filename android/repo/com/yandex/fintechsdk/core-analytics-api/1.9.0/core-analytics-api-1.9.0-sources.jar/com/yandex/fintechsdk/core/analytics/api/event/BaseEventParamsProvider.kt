package com.yandex.fintechsdk.core.analytics.api.event

public interface BaseEventParamsProvider {
    public fun getParams(): Map<String, String>
}
