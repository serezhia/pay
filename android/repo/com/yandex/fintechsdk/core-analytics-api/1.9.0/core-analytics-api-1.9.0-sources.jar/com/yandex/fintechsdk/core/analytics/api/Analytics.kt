package com.yandex.fintechsdk.core.analytics.api

import com.yandex.fintechsdk.core.analytics.api.event.Event

public interface Analytics {

    public fun reportProductEvent(event: Event)

    public fun reportRuntimeError(
        key: String,
        exception: Throwable,
    )

    public fun reportRuntimeError(event: Event)
}
