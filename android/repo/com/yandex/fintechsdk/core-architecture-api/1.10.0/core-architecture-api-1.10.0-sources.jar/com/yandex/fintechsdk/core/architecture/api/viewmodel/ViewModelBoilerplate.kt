package com.yandex.fintechsdk.core.architecture.api.viewmodel

import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel

public inline fun <reified T : ViewModel> Fragment.injectViewModel(
    noinline viewModelCreator: () -> T,
): Lazy<T> {
    return viewModels(
        factoryProducer = {
            ViewModelProviderFactory(viewModelCreator)
        }
    )
}

public inline fun <reified T : ViewModel> ComponentActivity.injectViewModel(
    noinline viewModelCreator: () -> T,
): Lazy<T> {
    return viewModels {
        ViewModelProviderFactory { viewModelCreator() }
    }
}
