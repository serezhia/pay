package com.yandex.fintechsdk.core.architecture.api.mvi

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

public interface Store<STATE : Any, SIDE_EFFECT : Any> {

    public val stateFlow: StateFlow<STATE>

    public val sideEffectFlow: Flow<SIDE_EFFECT>

    public fun intent(intent: suspend StoreContext<STATE, SIDE_EFFECT>.() -> Unit)
}
