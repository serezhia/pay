package com.yandex.fintechsdk.core.architecture.api.mvi

public data class StateContext<STATE : Any>(public val state: STATE)
