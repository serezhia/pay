package com.yandex.fintechsdk.core.architecture.api.component

public interface FintechComponentStore {
    public val component: FintechComponent
}
