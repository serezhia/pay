package com.yandex.fintechsdk.core.architecture.api.component

import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import com.yandex.fintechsdk.core.architecture.api.feature.dependencies.FeatureDependencies
import com.yandex.fintechsdk.core.architecture.api.feature.dependencies.FeatureDependenciesResolver
import com.yandex.fintechsdk.core.architecture.api.viewmodel.ViewModelProviderFactory

public inline fun <reified T : ViewModel, reified D : FeatureDependencies> Fragment.injectFeatureComponentStore(
    noinline viewModelCreator: (dependencies: D) -> T,
): Lazy<T> = viewModels<T> {
    val dependenciesResolver = findDependenciesResolver()
    val dependencies = dependenciesResolver.resolveDependencies<D>()

    ViewModelProviderFactory { viewModelCreator(dependencies) }
}

/**
 * Finds a [FeatureDependenciesResolver] by first searching the parent fragment chain,
 * then falling back to the activity.
 */
public fun Fragment.findDependenciesResolver(): FeatureDependenciesResolver {
    var parent = parentFragment
    while (parent != null) {
        if (parent is FeatureDependenciesResolver) {
            return parent
        }
        parent = parent.parentFragment
    }

    return requireActivity() as FeatureDependenciesResolver
}
