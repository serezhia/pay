package com.yandex.fintechsdk.core.architecture.api.mvi

public data class StoreContext<STATE : Any, SIDE_EFFECT : Any>(
    public val reduce: suspend ((STATE) -> STATE) -> Unit,
    public val postSideEffect: suspend (SIDE_EFFECT) -> Unit,
)
