package com.yandex.fintechsdk.core.architecture.api.viewmodel

import androidx.lifecycle.ViewModel
import com.yandex.fintechsdk.core.architecture.api.mvi.Store
import com.yandex.fintechsdk.core.architecture.api.mvi.StoreHost
import com.yandex.fintechsdk.core.architecture.api.mvi.store

public abstract class BaseViewModel<STATE : Any, SIDE_EFFECT : Any>(
    initialState: STATE,
) : ViewModel(), StoreHost<STATE, SIDE_EFFECT> {

    override val store: Store<STATE, SIDE_EFFECT> = store(initialState)

    public abstract fun onBackPressed()
}
