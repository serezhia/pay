package com.yandex.fintechsdk.core.architecture.api.mvi

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

public fun <STATE : Any, SIDE_EFFECT : Any> ViewModel.store(initialState: STATE): Store<STATE, SIDE_EFFECT> {
    return store(initialState = initialState, coroutineScope = viewModelScope)
}

public fun <STATE : Any, SIDE_EFFECT : Any> store(
    initialState: STATE,
    coroutineScope: CoroutineScope,
): Store<STATE, SIDE_EFFECT> {
    return FintechStore(initialState = initialState, parentScope = coroutineScope)
}

public fun <STATE : Any, SIDE_EFFECT : Any> StoreHost<STATE, SIDE_EFFECT>.intent(intent: suspend IntentContext<STATE, SIDE_EFFECT>.() -> Unit) {
    store.intent {
        IntentContext(this).intent()
    }
}

public suspend fun <STATE : Any, SIDE_EFFECT : Any> IntentContext<STATE, SIDE_EFFECT>.sideEffect(sideEffect: SIDE_EFFECT) {
    storeContext.postSideEffect(sideEffect)
}

public suspend fun <STATE : Any, SIDE_EFFECT : Any> IntentContext<STATE, SIDE_EFFECT>.reduce(reducer: StateContext<STATE>.() -> STATE) {
    storeContext.reduce { state -> StateContext(state).reducer() }
}

public fun <STATE : Any, SIDE_EFFECT : Any> StoreHost<STATE, SIDE_EFFECT>.observe(
    lifecycleOwner: LifecycleOwner,
    lifecycleState: Lifecycle.State = Lifecycle.State.STARTED,
    state: ((state: STATE) -> Unit)? = null,
    sideEffect: ((sideEffect: SIDE_EFFECT) -> Unit)? = null
) {
    with(lifecycleOwner) {
        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(lifecycleState) {
                state?.let { launch { store.stateFlow.collect { state(it) } } }
                sideEffect?.let { launch { store.sideEffectFlow.collect { sideEffect(it) } } }
            }
        }
    }
}
