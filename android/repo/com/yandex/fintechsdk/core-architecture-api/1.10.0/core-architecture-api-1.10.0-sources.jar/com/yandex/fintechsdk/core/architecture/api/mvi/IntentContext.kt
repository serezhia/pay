package com.yandex.fintechsdk.core.architecture.api.mvi

public data class IntentContext<STATE : Any, SIDE_EFFECT : Any>(public val storeContext: StoreContext<STATE, SIDE_EFFECT>)
