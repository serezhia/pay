package com.yandex.fintechsdk.core.architecture.api.fragment

import android.content.Context
import android.content.res.Configuration
import android.content.res.Resources
import android.os.Bundle
import android.view.View
import androidx.activity.addCallback
import androidx.annotation.CallSuper
import androidx.annotation.ColorRes
import androidx.annotation.LayoutRes
import androidx.core.view.OnApplyWindowInsetsListener
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import com.yandex.fintechsdk.core.architecture.api.activity.BottomSheetModeProvider
import com.yandex.fintechsdk.core.architecture.api.mvi.observe
import com.yandex.fintechsdk.core.architecture.api.viewmodel.BaseViewModel
import com.yandex.fintechsdk.resources.api.ResColor

public abstract class BaseFragment<STATE : Any, SIDE_EFFECT : Any> : Fragment, OnApplyWindowInsetsListener {

    protected abstract val viewModel: BaseViewModel<STATE, SIDE_EFFECT>

    @ColorRes
    protected open val statusBarColor: Int = ResColor.finsdk_surface_elevated_0

    public constructor() : super()
    public constructor(@LayoutRes contentLayoutId: Int) : super(contentLayoutId)

    protected open fun render(state: STATE): Unit = Unit
    protected open fun sideEffect(sideEffect: SIDE_EFFECT): Unit = Unit

    override fun onApplyWindowInsets(v: View, insets: WindowInsetsCompat): WindowInsetsCompat {
        insets.getInsets(WindowInsetsCompat.Type.systemBars()).apply {
            v.updatePadding(
                left = left,
                top = top,
                right = right,
                bottom = bottom,
            )
        }

        return WindowInsetsCompat.CONSUMED
    }

    @CallSuper
    override fun onAttach(context: Context) {
        super.onAttach(context)
        requireActivity().onBackPressedDispatcher.addCallback(this) { viewModel.onBackPressed() }
    }

    @CallSuper
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (!isBottomSheetMode()) {
            // Regular mode: apply insets by adding padding to the view
            ViewCompat.setOnApplyWindowInsetsListener(view, this)
        }
        // Bottom sheet mode: don't set listener here - insets are handled by Activity/InsetsSetupHelper
        // Setting a listener here would interfere with custom insets setup in PaymentKitActivity

        // when we have dark mode we need light text that not equals dark mode
        val isDarkMode = requireContext().resources.isDarkMode()
        setupStatusBar(statusBarColor, !isDarkMode)

        viewModel.observe(viewLifecycleOwner, state = ::render, sideEffect = ::sideEffect)
    }

    /**
     * Setup system android status bar
     * [statusBarColor] is a color of status bar
     * [isDarkText] is a dark or light text, clocks, icons and statuses in status bar
     * Use (dark text with light colors) and (light text with dark mode) for more contrast in status bar
     * Call this method only when your fragment was attached to activity and has activity and context
     */
    protected open fun setupStatusBar(@ColorRes statusBarColor: Int, isDarkText: Boolean) {
        requireActivity().window.statusBarColor = requireContext().getColor(statusBarColor)
        val insetController = WindowCompat.getInsetsController(requireActivity().window, requireActivity().window.decorView)
        insetController.isAppearanceLightStatusBars = isDarkText
    }

    protected open fun isBottomSheetMode(): Boolean {
        val activity = activity
        if (activity is BottomSheetModeProvider) {
            return activity.isBottomSheetMode()
        }

        return false
    }

    private fun Resources.isDarkMode(): Boolean = getNightModeFlags() == Configuration.UI_MODE_NIGHT_YES

    private fun Resources.getNightModeFlags(): Int = configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
}
