package com.yandex.fintechsdk.core.architecture.api.mvi

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus

public class FintechStore<STATE : Any, SIDE_EFFECT : Any>(
    initialState: STATE,
    parentScope: CoroutineScope,
) : Store<STATE, SIDE_EFFECT> {

    private val scope = parentScope + Dispatchers.Default
    private val internalStateFlow = MutableStateFlow(initialState)
    private val sideEffectChannel = Channel<SIDE_EFFECT>()
    private val dispatchChannel = Channel<suspend StoreContext<STATE, SIDE_EFFECT>.() -> Unit>(Channel.UNLIMITED)

    private val context: StoreContext<STATE, SIDE_EFFECT> = StoreContext(
        reduce = { reducer -> internalStateFlow.update { state -> reducer(state) } },
        postSideEffect = { sideEffect -> sideEffectChannel.send(sideEffect) },
    )

    init {
        scope.launch {
            for (intent in dispatchChannel) {
                scope.launch { intent.invoke(context) }
            }
        }
    }

    override val stateFlow: StateFlow<STATE> = internalStateFlow.asStateFlow()

    override val sideEffectFlow: Flow<SIDE_EFFECT> = sideEffectChannel.receiveAsFlow()

    override fun intent(intent: suspend StoreContext<STATE, SIDE_EFFECT>.() -> Unit) {
        if (dispatchChannel.trySend(intent).isFailure) {
            scope.launch {
                dispatchChannel.send(intent)
            }
        }
    }
}
