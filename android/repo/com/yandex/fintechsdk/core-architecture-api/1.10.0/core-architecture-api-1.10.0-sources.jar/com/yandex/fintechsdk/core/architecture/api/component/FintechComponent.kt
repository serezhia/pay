package com.yandex.fintechsdk.core.architecture.api.component

public interface FintechComponent
