package com.yandex.fintechsdk.core.architecture.api.activity

/**
 * Interface for activities that can provide information about bottom sheet mode.
 * Activity should implement this interface and get the value from component dependencies.
 */
public interface BottomSheetModeProvider {
    /**
     * Returns true if the activity is in bottom sheet mode, false otherwise.
     */
    public fun isBottomSheetMode(): Boolean
}

