package com.yandex.fintechsdk.core.architecture.api.feature.dependencies

public interface FeatureDependencies
