package com.yandex.fintechsdk.core.architecture.api.feature.dependencies

public interface FeatureDependenciesResolver {
    public fun <T : FeatureDependencies> resolveDependencies(): T
}
