package com.yandex.fintechsdk.core.architecture.api.feature.graph

import androidx.navigation.NavController
import androidx.navigation.NavGraph

public interface FeatureGraphProvider {

    public fun provideFeatureGraph(navController: NavController): NavGraph
}
