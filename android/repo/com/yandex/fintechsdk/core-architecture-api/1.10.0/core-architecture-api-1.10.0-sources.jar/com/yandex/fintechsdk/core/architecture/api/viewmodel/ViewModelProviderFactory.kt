package com.yandex.fintechsdk.core.architecture.api.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

public class ViewModelProviderFactory<VM : ViewModel>(
    private val viewModelProvider: () -> VM,
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return viewModelProvider.invoke() as T
    }
}
