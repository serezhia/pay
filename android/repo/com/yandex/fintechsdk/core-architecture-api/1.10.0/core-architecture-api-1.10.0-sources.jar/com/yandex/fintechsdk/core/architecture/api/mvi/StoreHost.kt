package com.yandex.fintechsdk.core.architecture.api.mvi

public interface StoreHost<STATE : Any, SIDE_EFFECT : Any> {
    public val store: Store<STATE, SIDE_EFFECT>
}
