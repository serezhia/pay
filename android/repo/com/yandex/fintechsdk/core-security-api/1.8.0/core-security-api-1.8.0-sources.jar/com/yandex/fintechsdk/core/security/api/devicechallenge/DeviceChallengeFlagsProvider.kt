package com.yandex.fintechsdk.core.security.api.devicechallenge

/**
 * Provides flags for device challenge.
 */
public interface DeviceChallengeFlagsProvider {
    public fun isBiometryEnabled(): Boolean = false
    public fun isBiometryWithPasswordEnabled(): Boolean = false
}
