package com.yandex.fintechsdk.core.security.api.biometric

public interface AuthenticationAvailabilityChecker {
    /**
     * Checks if device has any authentication method available
     * (biometric OR device credential like PIN/pattern/password)
     */
    public fun checkAuthenticationAvailability(): AuthenticationStatus
}

