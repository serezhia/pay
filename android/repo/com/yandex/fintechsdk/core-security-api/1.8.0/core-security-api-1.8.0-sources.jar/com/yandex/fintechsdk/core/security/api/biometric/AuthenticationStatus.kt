package com.yandex.fintechsdk.core.security.api.biometric

public sealed class AuthenticationStatus {
    public object Available : AuthenticationStatus()
    public object NoHardware : AuthenticationStatus()
    public object NotEnrolled : AuthenticationStatus()
    public object Unavailable : AuthenticationStatus()
}

