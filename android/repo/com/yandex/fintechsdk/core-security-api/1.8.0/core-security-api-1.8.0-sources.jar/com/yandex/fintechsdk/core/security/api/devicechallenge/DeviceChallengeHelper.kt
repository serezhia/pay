package com.yandex.fintechsdk.core.security.api.devicechallenge

import androidx.fragment.app.FragmentActivity

/**
 * Helper class for device challenge.
 *
 * Provides public key (generates private-public key pair if doesn't exist).
 *
 * Creates data for signing based on purchase token and payment method id and signs it
 * with private key. Signing operation requires user authentication.
 */
public interface DeviceChallengeHelper {
    public fun getPublicKeyBase64(): String?

    public fun getSignature(
        activity: FragmentActivity,
        deviceChallengePostDelay: Int,
        deviceChallengeStartDelay: Int,
        paymentMethodId: String,
        purchaseToken: String,
        completion: (data: String?, signature: String?) -> Unit,
    )
}
