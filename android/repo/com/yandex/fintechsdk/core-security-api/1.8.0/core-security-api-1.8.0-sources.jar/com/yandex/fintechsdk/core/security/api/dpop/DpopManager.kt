package com.yandex.fintechsdk.core.security.api.dpop

import androidx.fragment.app.FragmentActivity

/**
 * Simplifies the implementation and management of DPoP (Delegated Proof of Possession).
 *
 * DPoP enhances security by allowing clients to prove possession of a private key without transmitting sensitive data in plain form.
 * Instead of sending tokens directly, the client sends a JWT (JSON Web Token) signed with its private key. The server can then verify
 * this signature using the corresponding public key, ensuring the authenticity and integrity of the request.
 */
public interface DpopManager {

    public fun getDpopJwk(): Result<Jwk>

    public suspend fun createDpopHeader(
        activity: FragmentActivity,
        authToken: String,
        restMethod: String,
        path: String,
    ): Result<String>
}
