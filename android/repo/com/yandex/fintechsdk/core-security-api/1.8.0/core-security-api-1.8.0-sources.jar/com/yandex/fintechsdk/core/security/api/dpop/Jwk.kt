package com.yandex.fintechsdk.core.security.api.dpop

/**
 * The Jwk class encapsulates a JSON Web Key (JWK) required for the DPoP (Delegated Proof of Possession) algorithm,
 * providing a structured representation of key parameters such as curve (crv), key type (kty), and coordinate values (x, y).
 */
public class Jwk(
    public val crv: String,
    public val kty: String,
    public val x: String,
    public val y: String,
)
