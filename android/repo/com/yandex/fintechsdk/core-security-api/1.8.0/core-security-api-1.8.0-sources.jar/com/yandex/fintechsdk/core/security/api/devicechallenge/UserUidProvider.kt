package com.yandex.fintechsdk.core.security.api.devicechallenge

/**
 * Provides user UID.
 */
public interface UserUidProvider {
    public fun getUserUid(): String? = null
}
