package com.yandex.fintechsdk.resources.api

import com.yandex.fintechsdk.resources.R

public typealias ResAnim = R.anim
public typealias ResAnimator = R.animator
public typealias ResColor = R.color
public typealias ResDimen = R.dimen
public typealias ResDrawable = R.drawable
public typealias ResStrings = R.string
