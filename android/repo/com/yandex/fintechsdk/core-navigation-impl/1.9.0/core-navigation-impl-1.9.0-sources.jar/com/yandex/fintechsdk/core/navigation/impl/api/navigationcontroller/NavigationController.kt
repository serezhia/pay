package com.yandex.fintechsdk.core.navigation.impl.api.navigationcontroller

import androidx.annotation.MainThread
import androidx.navigation.NavController
import androidx.navigation.NavOptions

public class NavigationController(
    private val navController: NavController,
    private val onEmptyBackStack: () -> Unit,
) {

    @MainThread
    public fun back() {
        if (!navController.popBackStack()) {
            onEmptyBackStack()
        }
    }

    @MainThread
    public fun toScreen(route: String, args: Map<String, String>, navOptions: NavOptions?) {
        navController.navigate(
            route = buildRoute(baseRoute = route, args = args),
            navOptions = navOptions,
        )
    }

    private fun buildRoute(baseRoute: String, args: Map<String, String>): String {
        if (args.isEmpty()) return baseRoute

        val builder = StringBuilder(baseRoute)

        args.entries.forEachIndexed { index, (key, value) ->
            builder.append(
                if (index == 0) {
                    ROUTE_SEPARATOR
                } else {
                    ARG_SEPARATOR
                }
            )

            builder.append("$key=$value")
        }

        return builder.toString()
    }

    private companion object {
        const val ROUTE_SEPARATOR = '?'
        const val ARG_SEPARATOR = '&'
    }
}
