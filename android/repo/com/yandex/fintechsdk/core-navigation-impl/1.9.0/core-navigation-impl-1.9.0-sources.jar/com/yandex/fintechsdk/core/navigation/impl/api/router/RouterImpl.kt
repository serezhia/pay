package com.yandex.fintechsdk.core.navigation.impl.api.router

import androidx.navigation.NavOptions
import com.yandex.fintechsdk.core.navigation.api.FintechNavOptions
import com.yandex.fintechsdk.core.navigation.api.Router
import com.yandex.fintechsdk.core.navigation.impl.api.navigationcontroller.NavigationController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

public class RouterImpl : Router {

    private var navigationController: NavigationController? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mutex = Mutex()

    override fun back() {
        executeWithLock {
            navigationController?.back()
        }
    }

    override fun toScreen(route: String, args: Map<String, String>, navOptions: FintechNavOptions?) {
        executeWithLock {
            navigationController?.toScreen(route = route, args = args, navOptions = convertNavOptions(navOptions))
        }
    }

    public fun setNavigationController(navigationController: NavigationController?) {
        this.navigationController = navigationController
    }

    private fun executeWithLock(block: () -> Unit) {
        scope.launch {
            mutex.withLock {
                block()
            }
        }
    }

    private fun convertNavOptions(navOptions: FintechNavOptions?): NavOptions? {
        return navOptions?.let {
            val builder = NavOptions.Builder()
                .setLaunchSingleTop(navOptions.singleTop)
                .setRestoreState(navOptions.restoreState)
                .setPopUpTo(
                    route = navOptions.popUpToRoute,
                    inclusive = navOptions.popUpToInclusive,
                    saveState = navOptions.popUpToSaveState,
                )

            navOptions.enterAnim?.let { enterAnim ->
                builder.setEnterAnim(enterAnim)
            }

            navOptions.exitAnim?.let { exitAnim ->
                builder.setExitAnim(exitAnim)
            }

            navOptions.popEnterAnim?.let { popEnterAnim ->
                builder.setPopEnterAnim(popEnterAnim)
            }

            navOptions.popExitAnim?.let { popExitAnim ->
                builder.setPopExitAnim(popExitAnim)
            }

            builder.build()
        }
    }
}
