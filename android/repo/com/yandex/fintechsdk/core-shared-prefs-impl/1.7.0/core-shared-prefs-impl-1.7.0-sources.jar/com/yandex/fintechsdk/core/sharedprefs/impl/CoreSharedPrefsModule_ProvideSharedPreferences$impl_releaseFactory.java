package com.yandex.fintechsdk.core.sharedprefs.impl;

import android.content.Context;
import android.content.SharedPreferences;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CoreSharedPrefsModule_ProvideSharedPreferences$impl_releaseFactory implements Factory<SharedPreferences> {
  private final Provider<Context> contextProvider;

  private CoreSharedPrefsModule_ProvideSharedPreferences$impl_releaseFactory(
      Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public SharedPreferences get() {
    return provideSharedPreferences$impl_release(contextProvider.get());
  }

  public static CoreSharedPrefsModule_ProvideSharedPreferences$impl_releaseFactory create(
      Provider<Context> contextProvider) {
    return new CoreSharedPrefsModule_ProvideSharedPreferences$impl_releaseFactory(contextProvider);
  }

  public static SharedPreferences provideSharedPreferences$impl_release(Context context) {
    return Preconditions.checkNotNullFromProvides(CoreSharedPrefsModule.INSTANCE.provideSharedPreferences$impl_release(context));
  }
}
