package com.yandex.fintechsdk.core.sharedprefs.impl

import android.content.Context
import android.content.SharedPreferences
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import dagger.Module
import dagger.Provides

@Module
public object CoreSharedPrefsModule {

    private const val PREFERENCES_NAME = "finsdk_shared_prefs"

    @Provides
    internal fun provideSharedPreferences(@ApplicationContext context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
    }
}
