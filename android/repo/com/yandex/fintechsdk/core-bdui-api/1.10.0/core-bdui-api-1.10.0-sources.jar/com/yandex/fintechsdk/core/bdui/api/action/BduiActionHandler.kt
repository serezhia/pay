package com.yandex.fintechsdk.core.bdui.api.action

public interface BduiActionHandler {

    public fun handle(action: BduiAction, context: BduiHandlingContext)
}
