package com.yandex.fintechsdk.core.bdui.api.customview.factory

import com.yandex.fintechsdk.core.bdui.api.customview.BduiVariableController
import com.yandex.fintechsdk.core.bdui.api.customview.configuration.CustomViewConfiguration

public interface CustomViewFactoryDelegateCreator {
    public fun create(
        variableController: BduiVariableController,
        configurations: Map<String, CustomViewConfiguration>,
    ): CustomViewFactoryDelegate
}
