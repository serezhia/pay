package com.yandex.fintechsdk.core.bdui.api.network

public interface BduiExtraHeadersProvider {

    public fun getHeaders(): Map<String, String>
}
