package com.yandex.fintechsdk.core.bdui.api.spinner

public data class IsSpinnerPreviewEnabled(public val value: Boolean)
