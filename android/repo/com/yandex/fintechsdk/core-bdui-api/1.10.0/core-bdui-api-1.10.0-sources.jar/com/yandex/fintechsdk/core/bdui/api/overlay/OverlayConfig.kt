package com.yandex.fintechsdk.core.bdui.api.overlay

import com.yandex.fintechsdk.entities.ui.BottomSheetMode

/**
 * Configuration for overlay display in bottom sheet mode.
 *
 * @param bottomSheetMode Display mode for bottom sheet (DISABLED/REGULAR/FULLSCREEN)
 * @param overlayTopMarginDp Top margin for overlay in dp
 */
public class OverlayConfig(
    public val bottomSheetMode: BottomSheetMode,
    public val overlayTopMarginDp: Float,
)
