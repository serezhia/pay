package com.yandex.fintechsdk.core.bdui.api.error

import android.view.ViewGroup

/**
 * Configuration for customizing the error view.
 * Flow can provide this configuration without depending on flex types.
 * The XML layout is passed externally through this configuration, rather than stored in the flex implementation.
*/
public interface ErrorViewFactory {
    public fun createErrorViewBinding(container: ViewGroup): FlexErrorViewBinding?
}
