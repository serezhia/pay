package com.yandex.fintechsdk.core.bdui.api.route

import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery

public interface BduiRouteHandler {

    /**
     * @param tag The tag identifying the overlay to hide
     * @param withAnimation Whether to animate the hiding transition
     * @param customProps Additional properties
     * @return Boolean Indicates whether the overlay was successfully hidden
     */
    public fun hideOverlay(tag: String, withAnimation: Boolean, customProps: Map<String, Any>): Boolean

    /**
     * Pops all screens from the navigation stack except the root screen
     * @param animated Whether to animate the pop transition
     */
    public fun popToRoot(animated: Boolean)

    /**
     * Performs a backward navigation between BDUI screens
     * @param animated Whether to animate the pop transition
     * @param customProps Additional properties
     * @return Boolean Indicates whether the backward navigation was successfully performed
     */
    public fun backward(animated: Boolean, customProps: Map<String, Any>): Boolean

    /**
     * @return Number of entries currently in the back stack
     */
    public fun getBackStackEntryCount(): Int

    /**
     * @return Current displayed BDUI fragment's document query
     */
    public fun getCurrentFragmentQuery(): BduiDocumentQuery?
}
