package com.yandex.fintechsdk.core.bdui.api.network

public interface BduiExtraQueriesProvider {

    public fun getQueries(): Map<String, String>
}
