package com.yandex.fintechsdk.core.bdui.api.customview.configuration

/**
 * Interface for marking configuration data for view
 */
public interface CustomViewConfiguration
