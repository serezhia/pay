package com.yandex.fintechsdk.core.bdui.api.action

public class BduiHandlingContext(
    public val actionDispatcher: NestedActionDispatcher,
)
