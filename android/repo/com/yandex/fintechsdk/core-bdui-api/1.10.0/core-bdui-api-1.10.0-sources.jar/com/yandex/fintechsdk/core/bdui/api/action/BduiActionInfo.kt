package com.yandex.fintechsdk.core.bdui.api.action

import kotlinx.serialization.KSerializer

public data class BduiActionInfo<out T : BduiAction>(
    public val type: String,
    public val handler: BduiActionHandler,
    public val serializer: KSerializer<out T>,
)
