package com.yandex.fintechsdk.core.bdui.api.query

public data class BduiDocumentQuery(
    val path: String,
    val params: Map<String, List<String>> = emptyMap(),
    val body: Map<String, Any>? = null,
)
