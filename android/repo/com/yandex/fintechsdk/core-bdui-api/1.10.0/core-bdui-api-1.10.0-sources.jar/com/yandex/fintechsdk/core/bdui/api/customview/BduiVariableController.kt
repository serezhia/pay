package com.yandex.fintechsdk.core.bdui.api.customview

public interface BduiVariableController {

    public fun setVariable(name: String, value: String)

    public fun setVariable(name: String, value: Boolean)

    public fun setVariableListener(variableName: String, listenerKey: String, listener: (Any) -> Unit)

    public fun removeVariableListener(variableName: String, listenerKey: String)
}
