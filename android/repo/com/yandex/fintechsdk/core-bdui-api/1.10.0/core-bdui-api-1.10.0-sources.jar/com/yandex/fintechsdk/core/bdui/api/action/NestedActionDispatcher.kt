package com.yandex.fintechsdk.core.bdui.api.action

public interface NestedActionDispatcher {
    public fun dispatch(action: NestedAction)
}
