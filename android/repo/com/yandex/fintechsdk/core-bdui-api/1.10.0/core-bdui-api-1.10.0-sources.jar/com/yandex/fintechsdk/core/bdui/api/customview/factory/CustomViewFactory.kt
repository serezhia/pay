package com.yandex.fintechsdk.core.bdui.api.customview.factory

import android.content.Context
import android.view.View
import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomActionHandler
import com.yandex.fintechsdk.core.bdui.api.customview.expression.BduiExpressionResolver
import org.json.JSONObject

/**
 * Interface for custom view factory. Required in [CustomViewFactoryDelegate]
 */
public interface CustomViewFactory<T : View> {

    public val type: String

    public fun createView(context: Context, params: JSONObject?): T

    public fun bindView(
        actionHandler: DivCustomActionHandler,
        view: T,
        expressionResolver: BduiExpressionResolver? = null,
    )
}
