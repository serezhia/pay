package com.yandex.fintechsdk.core.bdui.api.customview.action

/**
 * Sends [DivCustomAction] to the framework's action handler, which then invokes the corresponding BduiAction and delegates execution to BduiActionHandler
 */
public interface DivCustomActionHandler {
    public fun handleAction(action: DivCustomAction): Boolean
}
