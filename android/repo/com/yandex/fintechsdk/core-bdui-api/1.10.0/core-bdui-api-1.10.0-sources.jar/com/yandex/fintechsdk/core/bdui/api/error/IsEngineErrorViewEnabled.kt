package com.yandex.fintechsdk.core.bdui.api.error

public data class IsEngineErrorViewEnabled(public val value: Boolean)
