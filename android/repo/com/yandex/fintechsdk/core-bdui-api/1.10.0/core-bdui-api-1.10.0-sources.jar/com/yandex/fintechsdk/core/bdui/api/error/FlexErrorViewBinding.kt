package com.yandex.fintechsdk.core.bdui.api.error

import android.view.View
import android.view.ViewGroup

/**
 * Interface for ViewBinding, viewing errors
 * Flow can implement this interface for viewing errors.
*/
public interface FlexErrorViewBinding {
    public val root: ViewGroup
    public val closeButton: View?
    public val retryButton: View?
}
