package com.yandex.fintechsdk.core.bdui.api.customview.factory

import android.content.Context
import android.view.View
import kotlinx.serialization.KSerializer
import kotlinx.serialization.json.Json
import org.json.JSONObject

/**
 * Base factory for BDUI custom View. Implements [JSONObject] -> view params serializer.
 */
public abstract class BaseCustomViewFactory<T : View, P : Any>(
    private val paramsSerializer: KSerializer<P>,
) : CustomViewFactory<T> {

    private val serializerJson = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    public override fun createView(context: Context, params: JSONObject?): T {
        val decodedParams = params?.let { json ->
            serializerJson.decodeFromString(
                deserializer = paramsSerializer,
                string = json.toString(),
            )
        }

        return createViewWithParams(
            context = context,
            params = decodedParams,
        )
    }

    protected abstract fun createViewWithParams(context: Context, params: P?): T
}
