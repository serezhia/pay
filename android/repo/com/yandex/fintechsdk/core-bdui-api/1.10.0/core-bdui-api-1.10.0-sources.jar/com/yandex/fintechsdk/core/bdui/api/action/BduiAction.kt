package com.yandex.fintechsdk.core.bdui.api.action

public interface BduiAction

/**
 * Use it only to mark actions that are nested in another actions' data
 */
public interface NestedAction : BduiAction
