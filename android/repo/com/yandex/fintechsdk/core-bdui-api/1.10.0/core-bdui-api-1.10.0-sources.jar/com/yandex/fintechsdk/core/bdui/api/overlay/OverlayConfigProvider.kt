package com.yandex.fintechsdk.core.bdui.api.overlay

/**
 * Provider for getting actual overlay configuration.
 */
public interface OverlayConfigProvider {
    public fun get(): OverlayConfig
}
