package com.yandex.fintechsdk.core.bdui.api.customview.expression

import android.net.Uri

/**
 * Interface for expression resolver that abstracts DivKit's ExpressionResolver
 * This allows core-bdui-api to work with expressions without direct dependency on DivKit
 */
public interface BduiExpressionResolver {

    public fun resolveString(expression: String): String?

    public fun resolveColor(expression: String): Int?

    public fun resolveUrl(expression: String): Uri?
}
