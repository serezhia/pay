package com.yandex.fintechsdk.core.bdui.api.customview.factory

import android.content.Context
import android.view.View
import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomActionHandler
import com.yandex.fintechsdk.core.bdui.api.customview.expression.BduiExpressionResolver
import org.json.JSONObject

/**
 * Operates with [CustomViewFactory]. Selects the desired by view type and proxies the method into it.
 */
public class CustomViewFactoryDelegate(
    public val factories: Map<String, CustomViewFactory<*>>,
) {

    @Suppress("UNCHECKED_CAST")
    public fun <T : View> createViewFor(
        type: String,
        context: Context,
        params: JSONObject? = null,
    ): T = getFactoryForType<T>(type).createView(
        context = context,
        params = params,
    )

    @Suppress("UNCHECKED_CAST")
    public fun <T : View> bindViewFor(
        actionHandler: DivCustomActionHandler,
        type: String,
        view: T,
        expressionResolver: BduiExpressionResolver? = null,
    ) {
        val factory = getFactoryForType<T>(type)
        factory.bindView(
            view = view,
            actionHandler = actionHandler,
            expressionResolver = expressionResolver,
        )
    }

    public fun isTypeSupported(type: String): Boolean = factories.containsKey(type)

    @Suppress("UNCHECKED_CAST")
    private fun <T : View> getFactoryForType(type: String): CustomViewFactory<T> {
        return factories[type] as? CustomViewFactory<T>
            ?: throw IllegalStateException("Cannot find creator for custom type $type")
    }
}
