package com.yandex.fintechsdk.core.bdui.api.eventhandler

import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery

public interface BduiErrorHandler {

    public fun handle(
        query: BduiDocumentQuery,
        throwable: Throwable,
        responseCode: Int?,
    )
}
