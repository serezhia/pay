package com.yandex.fintechsdk.core.bdui.api.customview.action

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Represents an action to use with [DivCustomActionHandler].
 * It is used to invoke the corresponding [BduiAction]
 */
@Serializable
public class DivCustomAction(
    @SerialName("log_id")
    public val logId: String,

    @SerialName("url")
    public val actionUrl: String,
)
