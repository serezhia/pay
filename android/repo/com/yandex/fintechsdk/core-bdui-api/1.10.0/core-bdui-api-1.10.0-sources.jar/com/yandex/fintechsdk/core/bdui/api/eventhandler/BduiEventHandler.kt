package com.yandex.fintechsdk.core.bdui.api.eventhandler

import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery

public interface BduiEventHandler {

    public fun onDocumentLoadingStarted(query: BduiDocumentQuery)

    public fun onDocumentLoadingFailed(query: BduiDocumentQuery)

    public fun onDocumentLoadingCancelled(query: BduiDocumentQuery)

    public fun onDocumentLoadingFinished(query: BduiDocumentQuery)
}
