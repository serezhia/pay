package com.yandex.fintechsdk.core.bdui.api.state

/**
 * Interface for managing BDUI state.
 *
 * Provides methods to retrieve values from the state and update the state with new data.
 */
public interface BduiStateManager {

    public fun getValue(path: List<String>): Any?

    public fun update(payload: Map<String, Map<String, Any>>)
}
