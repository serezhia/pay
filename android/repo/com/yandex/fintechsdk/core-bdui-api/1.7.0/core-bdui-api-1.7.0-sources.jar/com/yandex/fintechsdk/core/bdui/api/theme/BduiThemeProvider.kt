package com.yandex.fintechsdk.core.bdui.api.theme

import com.yandex.fintechsdk.entities.theme.Theme

public interface BduiThemeProvider {

    public fun getTheme(): Theme
}
