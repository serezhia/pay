package com.yandex.fintechsdk.core.telemetry.impl.extensions

import com.google.protobuf.ByteString

internal fun ByteString.toHexString(): String =
    this.toByteArray().joinToString("") { "%02x".format(it) }
