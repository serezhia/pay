package com.yandex.fintechsdk.core.telemetry.impl.sender

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody

internal class SpanHttpSender(
    private val endpoint: String,
    private val errorSending: suspend (ByteArray) -> Unit,
) {
    private val client = OkHttpClient()
    suspend fun sendHttpRequest(bytes: ByteArray) {
        try {
            val body: RequestBody = bytes.toRequestBody("application/x-protobuf".toMediaType())
            val request: Request = Request.Builder()
                .url(endpoint)
                .post(body)
                .build()
            client.newCall(request).execute()
        } catch (e: Exception) {
            errorSending(bytes)
        }
    }
}
