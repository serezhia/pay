package com.yandex.fintechsdk.core.telemetry.impl.extensions

import com.google.protobuf.ByteString
import com.yandex.fintechsdk.core.telemetry.api.Span
import com.yandex.fintechsdk.core.telemetry.api.SpanKind
import io.opentelemetry.proto2.common.v1.AnyValue
import io.opentelemetry.proto2.common.v1.KeyValue
import io.opentelemetry.proto2.trace.v1.Span as OTSpan

internal fun Span.getOTSpan(): OTSpan {
    val builder = OTSpan.newBuilder()
        .setTraceId(traceId.toByteString())
        .setSpanId(spanId.toByteString())
        .setName(spanName)
        .setKind(kind.toOTSpanKind())
        .setStartTimeUnixNano(startTimeNanos)
        .setEndTimeUnixNano(endTimeNanos)
        .also { builder ->
            parentSpanId?.let { builder.setParentSpanId(it.toByteString()) }
        }

    val kvb = KeyValue.newBuilder()
    attributes.forEach {
        kvb.setKey(it.key).setValue(
            AnyValue.newBuilder()
                .setStringValue(it.value)
        )
        builder.addAttributes(kvb.build())
    }

    return builder.build()
}

private fun SpanKind.toOTSpanKind(): OTSpan.SpanKind =
    when (this) {
        SpanKind.SPAN_KIND_INTERNAL -> OTSpan.SpanKind.SPAN_KIND_INTERNAL
        SpanKind.SPAN_KIND_SERVER -> OTSpan.SpanKind.SPAN_KIND_SERVER
        SpanKind.SPAN_KIND_CLIENT -> OTSpan.SpanKind.SPAN_KIND_CLIENT
        SpanKind.SPAN_KIND_PRODUCER -> OTSpan.SpanKind.SPAN_KIND_PRODUCER
        SpanKind.SPAN_KIND_CONSUMER -> OTSpan.SpanKind.SPAN_KIND_CONSUMER
        SpanKind.SPAN_KIND_UNSPECIFIED -> OTSpan.SpanKind.SPAN_KIND_UNSPECIFIED
        SpanKind.UNRECOGNIZED -> OTSpan.SpanKind.SPAN_KIND_UNSPECIFIED
    }


@Suppress("MagicNumber") // TODO: define numbers as well named constant
private fun String.toByteString(): ByteString {
    if (this.isEmpty()) return ByteString.EMPTY
    val len = this.length
    require(len % 2 == 0) { "Hex string must have an even number of characters" }
    val data = ByteArray(len / 2)
    var i = 0
    while (i < len) {
        try {
            data[i / 2] = ((Character.digit(this[i], 16) shl 4) +
                Character.digit(this[i + 1], 16)).toByte()
        } catch (e: Exception) {
            throw IllegalArgumentException("Invalid hex string: $this", e)
        }
        i += 2
    }
    return ByteString.copyFrom(data)
}
