package com.yandex.fintechsdk.core.telemetry.impl.queue

import com.yandex.fintechsdk.core.telemetry.api.Span
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

internal class SpanBatchQueue(
    private val coroutineScope: CoroutineScope,
    private val timeSend: Long,
    private val batchSize: Int,
    private val send: suspend (List<Span>) -> Unit,
) {
    private val queue = mutableListOf<Span>()
    private var inputChannel: Channel<Span>? = null
    private var lastPutTime = System.currentTimeMillis()
    private var job: Job? = null
    private val queueMutex = Mutex()
    private var sendingStarted = false
    private var isDestroyed = false

    fun startSending() {
        sendingStarted = true
    }

    fun destroy() {
        job?.cancel()
        job = null
        isDestroyed = true
    }

    fun start() {
        if (job == null) {
            inputChannel = Channel(Channel.UNLIMITED)
            job =
                coroutineScope.launch(Dispatchers.IO) {
                    try {
                        while (isActive) {
                            val span = withTimeoutOrNull(timeSend) {
                                inputChannel?.receiveCatching()?.getOrNull()
                            }
                            if (span != null) {
                                addInQueue(span)
                                lastPutTime = System.currentTimeMillis()
                            }
                            if (queueIsNotEmpty() && sendingStarted) {
                                val timeSinceLastPut = System.currentTimeMillis() - lastPutTime
                                if (timeSinceLastPut >= timeSend || queue.size >= batchSize) {
                                    sendBatch()
                                }
                            }
                        }
                    } finally {
                        withContext(NonCancellable) {
                            inputChannel?.tryReceive()?.getOrNull()?.let {
                                addInQueue(it)
                            }
                            if (queueIsNotEmpty() && sendingStarted) {
                                sendBatch()
                            }
                        }
                    }
                }
        }
    }

    private suspend fun addInQueue(span: Span) {
        queueMutex.withLock {
            queue.add(span)
        }
    }

    private suspend fun queueIsNotEmpty() = queueMutex.withLock {
        queue.isNotEmpty()
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    fun addSpan(value: Span) {
        if (isDestroyed) return
        inputChannel?.trySend(value)
    }

    fun forceSend() {
        coroutineScope.launch(Dispatchers.IO) {
            queueMutex.withLock {
                if (queue.isEmpty()) return@withLock
                send(queue.toList())
                queue.clear()
            }
        }
    }

    private suspend fun sendBatch() {
        queueMutex.withLock {
            send(queue.toList())
            queue.clear()
        }
    }
}
