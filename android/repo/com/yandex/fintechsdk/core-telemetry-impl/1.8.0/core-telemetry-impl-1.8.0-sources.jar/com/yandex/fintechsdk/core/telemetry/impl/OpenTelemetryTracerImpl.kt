package com.yandex.fintechsdk.core.telemetry.impl

import android.Manifest
import android.content.Context
import androidx.annotation.RequiresPermission
import com.yandex.fintechsdk.core.telemetry.api.OpenTelemetryTracer
import com.yandex.fintechsdk.core.telemetry.api.Span
import com.yandex.fintechsdk.core.telemetry.api.Span.Companion.generateSpanIdHexString
import com.yandex.fintechsdk.core.telemetry.impl.utils.generateTraceId
import com.yandex.fintechsdk.core.telemetry.impl.queue.SpanBatchQueue
import com.yandex.fintechsdk.core.telemetry.impl.queue.UnsentSpanQueue
import com.yandex.fintechsdk.core.telemetry.impl.sender.SpanDataSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

public class OpenTelemetryTracerImpl private constructor(
    context: Context,
    scopeName: String,
    resources: Map<String, String>,
    endpoint: String,
    coroutineScope: CoroutineScope,
    timeSend: Long,
    batchSize: Int,
    private val traceId: String,
    private val rootSpanId: String,
    private val rootSpanName: String,
) : OpenTelemetryTracer {

    private val dataSource by lazy {
        SpanDataSource(
            resources = resources,
            endpoint = endpoint,
            scopeName = scopeName,
            errorSending = ::errorSending,
        )
    }
    private val queue = SpanBatchQueue(
        coroutineScope = coroutineScope,
        timeSend = timeSend,
        batchSize = batchSize,
        send = dataSource::sendQueue,
    )
    private val unsentQueue = UnsentSpanQueue(
        context = context,
        coroutineScope = coroutineScope,
        send = ::sendUnsentSpan,
    )

    public override fun spanBuilder(spanName: String): Span.SpanBuilder {
        return Span
            .SpanBuilder(
                spanName = spanName,
                traceId = traceId,
                sendSpan = ::addSpanToQueue,
            )
            .setParentId(rootSpanId)
    }

    public override fun startTrace() {
        Span
            .SpanBuilder(
                spanName = rootSpanName,
                traceId = traceId,
                sendSpan = ::addSpanToQueue,
            )
            .start()
            .setSpanId(rootSpanId)
            .end()
        queue.startSending()
    }

    public override fun stopTrace() {
        unsentQueue.stop()
        queue.stop()
    }

    public override fun destroy() {
        queue.destroy()
        unsentQueue.destroy()
    }

    @RequiresPermission(Manifest.permission.ACCESS_NETWORK_STATE)
    private fun addSpanToQueue(span: Span) {
        startQueue()
        queue.addSpan(span)
    }

    @RequiresPermission(Manifest.permission.ACCESS_NETWORK_STATE)
    private fun startQueue() {
        unsentQueue.start()
        queue.start()
    }

    private suspend fun sendUnsentSpan(unsentBatch: List<ByteArray>) {
        unsentBatch.forEach {
            dataSource.sendBytes(it)
        }
    }

    private suspend fun errorSending(batch: ByteArray) {
        unsentQueue.offer(batch)
    }

    public class Builder(
        private val context: Context,
        private val scopeName: String,
        private val endpoint: String,
    ) {
        private var timeSend = DEFAULT_TIME_SEND
        private var batchSize = DEFAULT_BATCH_SIZE
        private var scope = CoroutineScope(Dispatchers.IO)
        private var resources = mutableMapOf<String, String>()
        private var traceId = generateTraceId()
        private var parentSpanId = generateSpanIdHexString()
        private var rootSpanName = DEFAULT_ROOT_SPAN_NAME

        public fun setResources(attributes: Map<String, String>): Builder {
            this.resources.putAll(attributes)
            return this
        }

        public fun setBatchSize(batchSize: Int): Builder {
            this.batchSize = batchSize
            return this
        }

        public fun setTimeSend(timeSend: Long): Builder {
            this.timeSend = timeSend
            return this
        }

        public fun setCoroutineScope(scope: CoroutineScope): Builder {
            this.scope = scope
            return this
        }

        public fun setTraceId(traceId: String): Builder {
            this.traceId = traceId
            return this
        }

        public fun setParentSpanId(parentSpanId: String): Builder {
            this.parentSpanId = parentSpanId
            return this
        }

        public fun setRootSpanName(name: String): Builder {
            this.rootSpanName = name
            return this
        }

        public fun build(): OpenTelemetryTracerImpl {
            return OpenTelemetryTracerImpl(
                context = context,
                scopeName = scopeName,
                resources = resources,
                endpoint = endpoint,
                coroutineScope = scope,
                timeSend = timeSend,
                batchSize = batchSize,
                traceId = traceId,
                rootSpanId = parentSpanId,
                rootSpanName = rootSpanName,
            )
        }

        private companion object {

            const val DEFAULT_ROOT_SPAN_NAME = "New session"
            const val DEFAULT_TIME_SEND = 5000L
            const val DEFAULT_BATCH_SIZE = 30
        }
    }
}
