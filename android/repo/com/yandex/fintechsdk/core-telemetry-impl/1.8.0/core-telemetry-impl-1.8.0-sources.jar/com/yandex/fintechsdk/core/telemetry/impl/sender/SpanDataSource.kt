package com.yandex.fintechsdk.core.telemetry.impl.sender

import com.yandex.fintechsdk.core.telemetry.api.Span
import com.yandex.fintechsdk.core.telemetry.impl.extensions.getOTSpan
import io.opentelemetry.proto2.common.v1.AnyValue
import io.opentelemetry.proto2.common.v1.InstrumentationScope
import io.opentelemetry.proto2.common.v1.KeyValue
import io.opentelemetry.proto2.resource.v1.Resource
import io.opentelemetry.proto2.trace.v1.ResourceSpans
import io.opentelemetry.proto2.trace.v1.ScopeSpans
import io.opentelemetry.proto2.trace.v1.TracesData

internal class SpanDataSource(
    resources: Map<String, String>,
    endpoint: String,
    scopeName: String,
    errorSending: suspend (ByteArray) -> Unit,
) {
    private val spanHttpSender = SpanHttpSender(endpoint, errorSending)
    private val instrumentationScope = InstrumentationScope.newBuilder().setName(scopeName).build()
    private val resource by lazy {
        val resourceBuilder = Resource.newBuilder()
        val kvb = KeyValue.newBuilder()
        resources.forEach {
            kvb.setKey(it.key).setValue(
                AnyValue.newBuilder()
                    .setStringValue(it.value)
            )
            resourceBuilder.addAttributes(kvb.build())
        }
        resourceBuilder.build()
    }

    internal suspend fun sendBytes(bytes: ByteArray) {
        spanHttpSender.sendHttpRequest(bytes)
    }

    internal suspend fun sendQueue(span: List<Span>) {
        val scopeSpans: ScopeSpans = ScopeSpans.newBuilder()
            .addAllSpans(span.map { it.getOTSpan() })
            .setScope(instrumentationScope)
            .build()

        val resourceSpans = ResourceSpans.newBuilder()
            .addScopeSpans(scopeSpans)
            .setResource(resource)
            .build()

        val tracesData: TracesData = TracesData.newBuilder()
            .addResourceSpans(resourceSpans)
            .build()
        val bytes = tracesData.toByteArray()
        spanHttpSender.sendHttpRequest(bytes)
    }
}
