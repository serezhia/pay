package com.yandex.fintechsdk.core.telemetry.impl.queue

import android.Manifest
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.annotation.RequiresPermission
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.LinkedList
import java.util.Queue

internal class UnsentSpanQueue(
    context: Context,
    private val coroutineScope: CoroutineScope,
    private val send: suspend (List<ByteArray>) -> Unit,
) {
    private var isRegisterCallback = false
    private val queue: Queue<ByteArray> = LinkedList()
    private val queueMutex = Mutex()

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            coroutineScope.launch(Dispatchers.IO) {
                sendBatches()
            }
        }

        override fun onLost(network: Network) = Unit
    }

    private suspend fun sendBatches() {
        queueMutex.withLock {
            if (queue.isEmpty()) return
            send(queue.toList())
            queue.clear()
        }
    }

    fun forceSend() {
        coroutineScope.launch(Dispatchers.IO) {
            sendBatches()
        }
    }

    suspend fun offer(bytes: ByteArray) {
        queueMutex.withLock {
            queue.offer(bytes)
        }
    }

    @RequiresPermission(Manifest.permission.ACCESS_NETWORK_STATE)
    fun start() {
        if (!isRegisterCallback) {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            connectivityManager.registerNetworkCallback(request, networkCallback)
            isRegisterCallback = true
        }
    }

    fun stop() {
        if (isRegisterCallback) {
            try {
                connectivityManager.unregisterNetworkCallback(networkCallback)
                isRegisterCallback = false
            } catch (_: Exception) {}
        }
    }

    fun destroy() {
        stop()
        queue.clear()
    }
}
