package com.yandex.fintechsdk.core.telemetry.impl.utils

import kotlin.random.Random

@OptIn(ExperimentalStdlibApi::class)
internal fun generateTraceId(): String {
    return Random.nextBytes(TRACE_ID_SIZE).toHexString()
}
internal const val TRACE_ID_SIZE = 16
