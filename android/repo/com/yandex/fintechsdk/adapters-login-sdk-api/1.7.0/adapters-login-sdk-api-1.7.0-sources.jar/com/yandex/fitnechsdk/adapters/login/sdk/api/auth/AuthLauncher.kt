package com.yandex.fitnechsdk.adapters.login.sdk.api.auth

public interface AuthLauncher {

    public fun launchAuth()
}
