package com.yandex.fitnechsdk.adapters.login.sdk.api

import android.content.Context
import androidx.activity.result.ActivityResultCaller
import com.yandex.fitnechsdk.adapters.login.sdk.api.auth.AuthLauncher

public interface LoginAdapter {

    public fun createAuthLauncher(
        activityResultCaller: ActivityResultCaller,
        context: Context,
        onGetToken: (token: String?) -> Unit,
    ): AuthLauncher
}
