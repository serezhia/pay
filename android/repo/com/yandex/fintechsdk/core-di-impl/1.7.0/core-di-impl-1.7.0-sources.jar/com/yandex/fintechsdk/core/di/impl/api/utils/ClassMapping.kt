package com.yandex.fintechsdk.core.di.impl.api.utils

import kotlin.reflect.KClass

public fun <K : Any, V> Map<Class<out K>, V>.mapKeysToKClasses(): Map<KClass<out K>, V> {
    return mapKeys { (`class`, _) -> `class`.kotlin }
}
