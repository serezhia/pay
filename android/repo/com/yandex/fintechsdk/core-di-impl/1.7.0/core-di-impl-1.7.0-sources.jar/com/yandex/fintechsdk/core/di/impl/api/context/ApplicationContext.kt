package com.yandex.fintechsdk.core.di.impl.api.context

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.RUNTIME)
public annotation class ApplicationContext
