package com.yandex.fintechsdk.core.di.impl.api.scopes

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.RUNTIME)
public annotation class FeatureScope
