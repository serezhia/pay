package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class GetActiveOrdersResponseDto(
    @SerialName("orders") val orders: List<OrderDto>,
)

