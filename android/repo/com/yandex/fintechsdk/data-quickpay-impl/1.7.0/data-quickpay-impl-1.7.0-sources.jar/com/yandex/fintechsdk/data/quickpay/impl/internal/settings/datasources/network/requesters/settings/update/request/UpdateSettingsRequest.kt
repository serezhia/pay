package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.request

import com.yandex.fintechsdk.data.quickpay.impl.internal.models.request.RequestWrapper
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

internal class UpdateSettingsRequest(
    private val enabled: Boolean?,
    private val selectedMethod: String?,
) : RequestWrapper(
    configure = { isAuthNeeded = false },
) {

    override val requestName: String = REQUEST_NAME
    override val requestPath: String = REQUEST_PATH

    override fun innerBody(): JsonObject = buildJsonObject {
        enabled?.let { put(JSON_KEY_QUICKPAY_ENABLED, it) }
        selectedMethod?.let { put(JSON_KEY_SELECTED_PAYMENT_METHOD, it) }
    }

    private companion object {
        private const val JSON_KEY_QUICKPAY_ENABLED = "quickpayment_enabled"
        private const val JSON_KEY_SELECTED_PAYMENT_METHOD = "selected_payment_method"
        private const val REQUEST_NAME = "update_quickpay_settings"
        private const val REQUEST_PATH = "pay/v1/quickpay/settings"
    }
}
