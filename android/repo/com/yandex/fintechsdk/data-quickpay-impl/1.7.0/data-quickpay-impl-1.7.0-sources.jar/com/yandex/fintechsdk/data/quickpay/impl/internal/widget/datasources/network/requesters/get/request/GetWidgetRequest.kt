package com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.get.request

import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import java.util.Locale

internal class GetWidgetRequest(
    private val divKitVersion: String,
) : Request(
    configure = { isAuthNeeded = false },
) {

    override val method: RestMethod = RestMethod.POST
    override val requestName: String = REQUEST_NAME
    override val requestPath: String = REQUEST_PATH

    override fun headers(): Map<String, String> = mapOf(
        Header.AcceptLanguage.key to Locale.getDefault().language,
        Header.DivkitVersion.key to divKitVersion,
    )

    private companion object {
        private const val REQUEST_NAME = "get_payment_methods_widget"
        private const val REQUEST_PATH = "pay/v1/public/widgets/quickpay/payment-methods"
    }
}
