package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update;

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UpdateSettingsRequester_Factory implements Factory<UpdateSettingsRequester> {
  private final Provider<FrontbackNetworkApi> apiProvider;

  private UpdateSettingsRequester_Factory(Provider<FrontbackNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public UpdateSettingsRequester get() {
    return newInstance(apiProvider.get());
  }

  public static UpdateSettingsRequester_Factory create(Provider<FrontbackNetworkApi> apiProvider) {
    return new UpdateSettingsRequester_Factory(apiProvider);
  }

  public static UpdateSettingsRequester newInstance(FrontbackNetworkApi api) {
    return new UpdateSettingsRequester(api);
  }
}
