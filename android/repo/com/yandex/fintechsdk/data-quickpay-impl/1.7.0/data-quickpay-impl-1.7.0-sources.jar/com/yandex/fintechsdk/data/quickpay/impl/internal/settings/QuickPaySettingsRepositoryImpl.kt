package com.yandex.fintechsdk.data.quickpay.impl.internal.settings

import com.yandex.fintechsdk.data.quickpay.api.settings.QuickPaySettings
import com.yandex.fintechsdk.data.quickpay.api.settings.QuickPaySettingsRepository
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.local.QuickPayEnabledStateStorage
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.QuickPaySettingsNetworkDataSource
import javax.inject.Inject

internal class QuickPaySettingsRepositoryImpl @Inject constructor(
    private val enabledStateStorage: QuickPayEnabledStateStorage,
    private val settingsNetworkDataSource: QuickPaySettingsNetworkDataSource,
) : QuickPaySettingsRepository {

    override suspend fun getSettingsFromBackend(): Result<QuickPaySettings> =
        settingsNetworkDataSource.getSettings()

    override suspend fun updateSettingsOnBackend(
        isEnabled: Boolean?,
        selectedMethod: String?,
    ): Result<QuickPaySettings> = settingsNetworkDataSource.updateSettings(
        isEnabled = isEnabled,
        selectedMethod = selectedMethod,
    )

    override fun getLocalEnabledState(): Boolean? =
        enabledStateStorage.getIsEnabled()

    override fun saveLocalEnabledState(isEnabled: Boolean) {
        enabledStateStorage.saveIsEnabled(isEnabled = isEnabled)
    }

    override fun clearLocalEnabledState() {
        enabledStateStorage.clear()
    }
}
