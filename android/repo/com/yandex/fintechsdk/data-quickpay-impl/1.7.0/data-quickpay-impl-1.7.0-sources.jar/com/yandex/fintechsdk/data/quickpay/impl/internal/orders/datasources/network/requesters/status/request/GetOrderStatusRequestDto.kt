package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.request

internal data class GetOrderStatusRequestDto(
    val transactionId: String,
    val paymentUrl: String,
)

