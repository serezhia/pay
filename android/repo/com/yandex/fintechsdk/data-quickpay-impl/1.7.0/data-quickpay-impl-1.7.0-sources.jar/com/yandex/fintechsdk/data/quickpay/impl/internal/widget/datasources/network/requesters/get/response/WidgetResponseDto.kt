package com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.get.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import org.json.JSONObject

/**
 * Widget response DTO that extracts the "card" content from the response.
 * DivKit expects the card object with "log_id" and "states" fields.
 */
@Serializable
internal data class WidgetResponseDto(
    @SerialName("card") private val card: JsonObject,
) {
    val json: JSONObject get() = JSONObject(card.toString())
}

