package com.yandex.fintechsdk.data.quickpay.impl.api.di

import android.content.SharedPreferences
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.data.quickpay.api.orders.OrdersRepository
import com.yandex.fintechsdk.data.quickpay.api.settings.QuickPaySettingsRepository
import com.yandex.fintechsdk.data.quickpay.api.widget.QuickPayWidgetRepository
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.OrdersRepositoryImpl
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.QuickPaySettingsRepositoryImpl
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.local.QuickPayEnabledStateStorage
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.QuickPayWidgetRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.Provides

@Module
public abstract class DataQuickPayModule {

    @FlowScope
    @Binds
    internal abstract fun bindOrdersRepository(
        impl: OrdersRepositoryImpl,
    ): OrdersRepository

    @FlowScope
    @Binds
    internal abstract fun bindQuickPaySettingsRepository(
        impl: QuickPaySettingsRepositoryImpl,
    ): QuickPaySettingsRepository

    @Binds
    @FlowScope
    internal abstract fun bindPaymentMethodsWidgetRepository(
        impl: QuickPayWidgetRepositoryImpl,
    ): QuickPayWidgetRepository

    internal companion object {
        @Provides
        @FlowScope
        internal fun provideQuickPayEnabledStateStorage(
            sharedPreferences: SharedPreferences,
        ): QuickPayEnabledStateStorage {
            return QuickPayEnabledStateStorage(sharedPreferences = sharedPreferences)
        }
    }
}
