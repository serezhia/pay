package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get;

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GetSettingsRequester_Factory implements Factory<GetSettingsRequester> {
  private final Provider<FrontbackNetworkApi> apiProvider;

  private GetSettingsRequester_Factory(Provider<FrontbackNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public GetSettingsRequester get() {
    return newInstance(apiProvider.get());
  }

  public static GetSettingsRequester_Factory create(Provider<FrontbackNetworkApi> apiProvider) {
    return new GetSettingsRequester_Factory(apiProvider);
  }

  public static GetSettingsRequester newInstance(FrontbackNetworkApi api) {
    return new GetSettingsRequester(api);
  }
}
