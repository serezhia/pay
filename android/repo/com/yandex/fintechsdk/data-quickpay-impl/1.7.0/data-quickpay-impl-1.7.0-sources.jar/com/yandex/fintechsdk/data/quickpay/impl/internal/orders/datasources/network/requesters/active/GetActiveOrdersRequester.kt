package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.quickpay.api.orders.model.Order
import com.yandex.fintechsdk.data.quickpay.api.orders.model.OrderStatus
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.request.GetActiveOrdersRequest
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.response.GetActiveOrdersResponseDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.response.OrderDto
import javax.inject.Inject

internal class GetActiveOrdersRequester @Inject constructor(
    private val api: FrontbackNetworkApi,
) : Requester<Unit, GetActiveOrdersRequest, GetActiveOrdersResponseDto, List<Order>>() {

    override fun createRequest(params: Unit): GetActiveOrdersRequest =
        GetActiveOrdersRequest()

    override suspend fun executeRequest(request: GetActiveOrdersRequest): Result<GetActiveOrdersResponseDto> =
        api.sendRequest(request = request)

    override fun transformResponse(response: GetActiveOrdersResponseDto): List<Order> =
        response.orders.map { it.toOrder() }

    private fun OrderDto.toOrder(): Order = Order(
        url = url,
        transactionId = transactionId,
        status = OrderStatus.fromRawValue(status),
    )
}
