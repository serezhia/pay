package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.request.UpdateSettingsRequest
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.request.UpdateSettingsRequestDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.response.MerchantSettingsDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.response.UpdateSettingsResponseDto
import javax.inject.Inject

internal class UpdateSettingsRequester @Inject constructor(
    private val api: FrontbackNetworkApi,
) : Requester<UpdateSettingsRequestDto, UpdateSettingsRequest, UpdateSettingsResponseDto, MerchantSettingsDto>() {

    override fun createRequest(params: UpdateSettingsRequestDto): UpdateSettingsRequest = UpdateSettingsRequest(
        enabled = params.enabled,
        selectedMethod = params.selectedMethod,
    )

    override suspend fun executeRequest(request: UpdateSettingsRequest): Result<UpdateSettingsResponseDto> {
        return api.sendRequest(request = request)
    }

    override fun transformResponse(response: UpdateSettingsResponseDto): MerchantSettingsDto {
        return response.merchantSettings
    }
}
