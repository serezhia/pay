package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network

import com.yandex.fintechsdk.data.quickpay.api.orders.model.Order
import com.yandex.fintechsdk.data.quickpay.api.orders.model.OrderStatus
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.GetActiveOrdersRequester
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.all.GetAllOrdersRequester
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.GetOrderStatusRequester
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.request.GetOrderStatusRequestDto
import javax.inject.Inject

internal class OrdersNetworkDataSource @Inject constructor(
    private val getActiveOrdersRequester: GetActiveOrdersRequester,
    private val getAllOrdersRequester: GetAllOrdersRequester,
    private val getOrderStatusRequester: GetOrderStatusRequester,
) {

    suspend fun getActiveOrders(): Result<List<Order>> {
        return getActiveOrdersRequester.execute(params = Unit)
    }

    suspend fun getAllOrders(): Result<List<Order>> {
        return getAllOrdersRequester.execute(params = Unit)
    }

    suspend fun getOrderStatus(
        transactionId: String,
        paymentUrl: String,
    ): Result<Order> {
        return getOrderStatusRequester.execute(
            params = GetOrderStatusRequestDto(
                transactionId = transactionId,
                paymentUrl = paymentUrl,
            ),
        ).map { orderStatus ->
            Order(
                url = paymentUrl,
                transactionId = orderStatus.transactionId,
                status = OrderStatus.fromRawValue(orderStatus.status),
            )
        }
    }
}

