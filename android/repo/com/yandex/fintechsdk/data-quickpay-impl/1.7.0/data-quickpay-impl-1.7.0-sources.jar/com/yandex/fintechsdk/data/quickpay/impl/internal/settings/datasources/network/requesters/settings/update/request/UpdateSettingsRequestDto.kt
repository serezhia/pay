package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.request

internal data class UpdateSettingsRequestDto(
    val enabled: Boolean?,
    val selectedMethod: String?,
)
