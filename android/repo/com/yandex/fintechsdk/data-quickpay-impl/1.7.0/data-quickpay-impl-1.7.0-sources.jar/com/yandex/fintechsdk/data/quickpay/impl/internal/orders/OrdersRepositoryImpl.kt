package com.yandex.fintechsdk.data.quickpay.impl.internal.orders

import com.yandex.fintechsdk.data.quickpay.api.orders.OrdersRepository
import com.yandex.fintechsdk.data.quickpay.api.orders.model.Order
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.OrdersNetworkDataSource
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject

internal class OrdersRepositoryImpl @Inject constructor(
    private val networkDataSource: OrdersNetworkDataSource,
) : OrdersRepository {

    private val _orderStatusFlow = MutableSharedFlow<Order>()
    override val orderStatusFlow: Flow<Order> = _orderStatusFlow.asSharedFlow()

    /**
     * Polls until non-empty response, timeout or exception.
     * @return List of orders or empty list if timeout exceeded.
     * @throws Exception on network errors. Typically ends with 401 when BST token expires.
     */
    override suspend fun pollActiveOrders(): List<Order> {
        val startTime = System.currentTimeMillis()
        while (System.currentTimeMillis() - startTime < POLLING_TIMEOUT_MS) {
            val orders = networkDataSource.getActiveOrders().getOrThrow()

            if (orders.isNotEmpty()) {
                return orders
            }

            delay(ACTIVE_ORDERS_POLLING_INTERVAL_MS)
        }
        return emptyList()
    }

    /**
     * Polls order status, emitting updates to [orderStatusFlow].
     * @throws Exception on network errors. Typically ends with 401 when BST token expires.
     */
    override suspend fun pollOrderStatus(
        transactionId: String,
        paymentUrl: String,
    ) {
        val startTime = System.currentTimeMillis()
        while (System.currentTimeMillis() - startTime < POLLING_TIMEOUT_MS) {
            val order = networkDataSource.getOrderStatus(
                transactionId = transactionId,
                paymentUrl = paymentUrl,
            ).getOrThrow()

            _orderStatusFlow.emit(order)

            delay(ORDER_STATUS_POLLING_INTERVAL_MS)
        }
    }

    /**
     * Gets all orders (single request, no polling).
     * @throws Exception on network errors. Typically ends with 401 when BST token expires.
     */
    override suspend fun getAllOrders(): List<Order> {
        return networkDataSource.getAllOrders().getOrThrow()
    }

    private companion object {
        private const val ACTIVE_ORDERS_POLLING_INTERVAL_MS = 2000L
        private const val ORDER_STATUS_POLLING_INTERVAL_MS = 1000L
        private const val POLLING_TIMEOUT_MS = 60 * 60 * 1000L // 1 hour
    }
}
