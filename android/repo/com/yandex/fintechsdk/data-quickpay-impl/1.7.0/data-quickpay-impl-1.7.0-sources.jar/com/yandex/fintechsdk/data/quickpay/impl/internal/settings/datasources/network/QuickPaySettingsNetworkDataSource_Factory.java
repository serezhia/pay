package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network;

import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.GetSettingsRequester;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.UpdateSettingsRequester;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class QuickPaySettingsNetworkDataSource_Factory implements Factory<QuickPaySettingsNetworkDataSource> {
  private final Provider<GetSettingsRequester> getSettingsRequesterProvider;

  private final Provider<UpdateSettingsRequester> updateSettingsRequesterProvider;

  private QuickPaySettingsNetworkDataSource_Factory(
      Provider<GetSettingsRequester> getSettingsRequesterProvider,
      Provider<UpdateSettingsRequester> updateSettingsRequesterProvider) {
    this.getSettingsRequesterProvider = getSettingsRequesterProvider;
    this.updateSettingsRequesterProvider = updateSettingsRequesterProvider;
  }

  @Override
  public QuickPaySettingsNetworkDataSource get() {
    return newInstance(getSettingsRequesterProvider.get(), updateSettingsRequesterProvider.get());
  }

  public static QuickPaySettingsNetworkDataSource_Factory create(
      Provider<GetSettingsRequester> getSettingsRequesterProvider,
      Provider<UpdateSettingsRequester> updateSettingsRequesterProvider) {
    return new QuickPaySettingsNetworkDataSource_Factory(getSettingsRequesterProvider, updateSettingsRequesterProvider);
  }

  public static QuickPaySettingsNetworkDataSource newInstance(
      GetSettingsRequester getSettingsRequester, UpdateSettingsRequester updateSettingsRequester) {
    return new QuickPaySettingsNetworkDataSource(getSettingsRequester, updateSettingsRequester);
  }
}
