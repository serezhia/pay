package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.all

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.quickpay.api.orders.model.Order
import com.yandex.fintechsdk.data.quickpay.api.orders.model.OrderStatus
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.response.GetActiveOrdersResponseDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.response.OrderDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.all.request.GetAllOrdersRequest
import javax.inject.Inject

internal class GetAllOrdersRequester @Inject constructor(
    private val api: FrontbackNetworkApi,
) : Requester<Unit, GetAllOrdersRequest, GetActiveOrdersResponseDto, List<Order>>() {

    override fun createRequest(params: Unit): GetAllOrdersRequest = GetAllOrdersRequest()

    override suspend fun executeRequest(request: GetAllOrdersRequest): Result<GetActiveOrdersResponseDto> =
        api.sendRequest(request = request)

    override fun transformResponse(response: GetActiveOrdersResponseDto): List<Order> =
        response.orders.map { it.toOrder() }

    private fun OrderDto.toOrder(): Order = Order(
        url = url,
        transactionId = transactionId,
        status = OrderStatus.fromRawValue(status),
    )
}

