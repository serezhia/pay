package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.request.GetOrderStatusRequest
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.request.GetOrderStatusRequestDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.response.GetOrderStatusResponseDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.response.OrderStatusDto
import javax.inject.Inject

internal class GetOrderStatusRequester @Inject constructor(
    private val api: FrontbackNetworkApi,
) : Requester<GetOrderStatusRequestDto, GetOrderStatusRequest, GetOrderStatusResponseDto, OrderStatusDto>() {

    override fun createRequest(params: GetOrderStatusRequestDto): GetOrderStatusRequest =
        GetOrderStatusRequest(
            transactionId = params.transactionId,
            paymentUrl = params.paymentUrl,
        )

    override suspend fun executeRequest(request: GetOrderStatusRequest): Result<GetOrderStatusResponseDto> =
        api.sendRequest(request = request)

    override fun transformResponse(response: GetOrderStatusResponseDto): OrderStatusDto =
        response.order
}
