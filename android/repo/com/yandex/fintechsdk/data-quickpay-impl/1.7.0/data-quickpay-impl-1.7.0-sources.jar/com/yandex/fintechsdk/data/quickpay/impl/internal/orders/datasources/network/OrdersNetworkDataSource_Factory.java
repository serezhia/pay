package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network;

import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.GetActiveOrdersRequester;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.all.GetAllOrdersRequester;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.GetOrderStatusRequester;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class OrdersNetworkDataSource_Factory implements Factory<OrdersNetworkDataSource> {
  private final Provider<GetActiveOrdersRequester> getActiveOrdersRequesterProvider;

  private final Provider<GetAllOrdersRequester> getAllOrdersRequesterProvider;

  private final Provider<GetOrderStatusRequester> getOrderStatusRequesterProvider;

  private OrdersNetworkDataSource_Factory(
      Provider<GetActiveOrdersRequester> getActiveOrdersRequesterProvider,
      Provider<GetAllOrdersRequester> getAllOrdersRequesterProvider,
      Provider<GetOrderStatusRequester> getOrderStatusRequesterProvider) {
    this.getActiveOrdersRequesterProvider = getActiveOrdersRequesterProvider;
    this.getAllOrdersRequesterProvider = getAllOrdersRequesterProvider;
    this.getOrderStatusRequesterProvider = getOrderStatusRequesterProvider;
  }

  @Override
  public OrdersNetworkDataSource get() {
    return newInstance(getActiveOrdersRequesterProvider.get(), getAllOrdersRequesterProvider.get(), getOrderStatusRequesterProvider.get());
  }

  public static OrdersNetworkDataSource_Factory create(
      Provider<GetActiveOrdersRequester> getActiveOrdersRequesterProvider,
      Provider<GetAllOrdersRequester> getAllOrdersRequesterProvider,
      Provider<GetOrderStatusRequester> getOrderStatusRequesterProvider) {
    return new OrdersNetworkDataSource_Factory(getActiveOrdersRequesterProvider, getAllOrdersRequesterProvider, getOrderStatusRequesterProvider);
  }

  public static OrdersNetworkDataSource newInstance(
      GetActiveOrdersRequester getActiveOrdersRequester,
      GetAllOrdersRequester getAllOrdersRequester,
      GetOrderStatusRequester getOrderStatusRequester) {
    return new OrdersNetworkDataSource(getActiveOrdersRequester, getAllOrdersRequester, getOrderStatusRequester);
  }
}
