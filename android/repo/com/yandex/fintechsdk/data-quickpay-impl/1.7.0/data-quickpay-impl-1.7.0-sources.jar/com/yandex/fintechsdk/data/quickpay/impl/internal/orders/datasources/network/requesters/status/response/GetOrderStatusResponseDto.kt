package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class GetOrderStatusResponseDto(
    @SerialName("order") val order: OrderStatusDto,
)

@Serializable
internal data class OrderStatusDto(
    @SerialName("transaction_id") val transactionId: String,
    @SerialName("status") val status: String,
)

