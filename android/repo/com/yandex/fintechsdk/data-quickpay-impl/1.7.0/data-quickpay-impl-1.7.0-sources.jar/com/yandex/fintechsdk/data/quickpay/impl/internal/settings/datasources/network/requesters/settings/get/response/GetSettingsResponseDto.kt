package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class GetSettingsResponseDto(
    @SerialName("merchant_settings") val merchantSettings: MerchantSettingsDto,
)

@Serializable
internal data class MerchantSettingsDto(
    @SerialName("enabled") val enabled: Boolean,
    @SerialName("selected_payment_method") val selectedPaymentMethod: String? = null,
)
