package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.request.GetSettingsRequest
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.request.GetSettingsRequestDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.response.GetSettingsResponseDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.response.MerchantSettingsDto
import javax.inject.Inject

internal class GetSettingsRequester @Inject constructor(
    private val api: FrontbackNetworkApi,
) : Requester<GetSettingsRequestDto, GetSettingsRequest, GetSettingsResponseDto, MerchantSettingsDto>() {

    override fun createRequest(params: GetSettingsRequestDto): GetSettingsRequest {
        return GetSettingsRequest()
    }

    override suspend fun executeRequest(request: GetSettingsRequest): Result<GetSettingsResponseDto> {
        return api.sendRequest(request = request)
    }

    override fun transformResponse(response: GetSettingsResponseDto): MerchantSettingsDto {
        return response.merchantSettings
    }
}
