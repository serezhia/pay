package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class OrderDto(
    @SerialName("url") val url: String,
    @SerialName("transaction_id") val transactionId: String,
    @SerialName("status") val status: String,
)

