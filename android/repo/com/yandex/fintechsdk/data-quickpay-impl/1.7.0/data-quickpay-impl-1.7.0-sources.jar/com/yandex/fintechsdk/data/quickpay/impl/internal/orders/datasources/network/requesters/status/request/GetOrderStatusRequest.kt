package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.request

import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod

internal class GetOrderStatusRequest(
    private val transactionId: String,
    private val paymentUrl: String,
) : Request(
    configure = { isAuthNeeded = false },
) {

    override val method: RestMethod = RestMethod.GET
    override val requestName: String = REQUEST_NAME
    override val requestPath: String = "$REQUEST_PATH_PREFIX/$transactionId"

    override fun queries(): Map<String, String> = mapOf(
        QUERY_PAYMENT_URL to paymentUrl,
    )

    private companion object {
        private const val REQUEST_NAME = "get_order_status"
        private const val REQUEST_PATH_PREFIX = "pay/v1/quickpay/order"
        private const val QUERY_PAYMENT_URL = "payment_url"
    }
}

