package com.yandex.fintechsdk.data.quickpay.impl.internal.settings;

import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.local.QuickPayEnabledStateStorage;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.QuickPaySettingsNetworkDataSource;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class QuickPaySettingsRepositoryImpl_Factory implements Factory<QuickPaySettingsRepositoryImpl> {
  private final Provider<QuickPayEnabledStateStorage> enabledStateStorageProvider;

  private final Provider<QuickPaySettingsNetworkDataSource> settingsNetworkDataSourceProvider;

  private QuickPaySettingsRepositoryImpl_Factory(
      Provider<QuickPayEnabledStateStorage> enabledStateStorageProvider,
      Provider<QuickPaySettingsNetworkDataSource> settingsNetworkDataSourceProvider) {
    this.enabledStateStorageProvider = enabledStateStorageProvider;
    this.settingsNetworkDataSourceProvider = settingsNetworkDataSourceProvider;
  }

  @Override
  public QuickPaySettingsRepositoryImpl get() {
    return newInstance(enabledStateStorageProvider.get(), settingsNetworkDataSourceProvider.get());
  }

  public static QuickPaySettingsRepositoryImpl_Factory create(
      Provider<QuickPayEnabledStateStorage> enabledStateStorageProvider,
      Provider<QuickPaySettingsNetworkDataSource> settingsNetworkDataSourceProvider) {
    return new QuickPaySettingsRepositoryImpl_Factory(enabledStateStorageProvider, settingsNetworkDataSourceProvider);
  }

  public static QuickPaySettingsRepositoryImpl newInstance(
      QuickPayEnabledStateStorage enabledStateStorage,
      QuickPaySettingsNetworkDataSource settingsNetworkDataSource) {
    return new QuickPaySettingsRepositoryImpl(enabledStateStorage, settingsNetworkDataSource);
  }
}
