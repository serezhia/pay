package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class UpdateSettingsResponseDto(
    @SerialName("merchant_settings") val merchantSettings: MerchantSettingsDto,
)

@Serializable
internal data class MerchantSettingsDto(
    @SerialName("enabled") val enabled: Boolean,
    @SerialName("selected_payment_method") val selectedPaymentMethod: String? = null,
)
