package com.yandex.fintechsdk.data.quickpay.impl.internal.orders;

import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.OrdersNetworkDataSource;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class OrdersRepositoryImpl_Factory implements Factory<OrdersRepositoryImpl> {
  private final Provider<OrdersNetworkDataSource> networkDataSourceProvider;

  private OrdersRepositoryImpl_Factory(
      Provider<OrdersNetworkDataSource> networkDataSourceProvider) {
    this.networkDataSourceProvider = networkDataSourceProvider;
  }

  @Override
  public OrdersRepositoryImpl get() {
    return newInstance(networkDataSourceProvider.get());
  }

  public static OrdersRepositoryImpl_Factory create(
      Provider<OrdersNetworkDataSource> networkDataSourceProvider) {
    return new OrdersRepositoryImpl_Factory(networkDataSourceProvider);
  }

  public static OrdersRepositoryImpl newInstance(OrdersNetworkDataSource networkDataSource) {
    return new OrdersRepositoryImpl(networkDataSource);
  }
}
