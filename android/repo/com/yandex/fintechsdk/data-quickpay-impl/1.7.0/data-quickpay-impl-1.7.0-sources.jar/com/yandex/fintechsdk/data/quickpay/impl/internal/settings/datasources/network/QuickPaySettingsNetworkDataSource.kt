package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network

import com.yandex.fintechsdk.data.quickpay.api.settings.QuickPaySettings
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.GetSettingsRequester
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.request.GetSettingsRequestDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.UpdateSettingsRequester
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.request.UpdateSettingsRequestDto
import javax.inject.Inject

/**
 * Network data source for QuickPay settings
 */
internal class QuickPaySettingsNetworkDataSource @Inject constructor(
    private val getSettingsRequester: GetSettingsRequester,
    private val updateSettingsRequester: UpdateSettingsRequester,
) {

    suspend fun getSettings(): Result<QuickPaySettings> {
        return getSettingsRequester.execute(
            params = GetSettingsRequestDto,
        ).map { merchantSettings ->
            QuickPaySettings(
                isEnabled = merchantSettings.enabled,
                selectedMethod = merchantSettings.selectedPaymentMethod,
            )
        }
    }

    suspend fun updateSettings(
        isEnabled: Boolean?,
        selectedMethod: String?,
    ): Result<QuickPaySettings> {
        return updateSettingsRequester.execute(
            params = UpdateSettingsRequestDto(
                enabled = isEnabled,
                selectedMethod = selectedMethod,
            ),
        ).map { merchantSettings ->
            QuickPaySettings(
                isEnabled = merchantSettings.enabled,
                selectedMethod = merchantSettings.selectedPaymentMethod,
            )
        }
    }
}
