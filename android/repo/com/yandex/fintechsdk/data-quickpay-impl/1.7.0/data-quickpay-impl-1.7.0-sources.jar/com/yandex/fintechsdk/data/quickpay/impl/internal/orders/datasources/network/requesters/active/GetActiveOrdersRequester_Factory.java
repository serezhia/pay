package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active;

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GetActiveOrdersRequester_Factory implements Factory<GetActiveOrdersRequester> {
  private final Provider<FrontbackNetworkApi> apiProvider;

  private GetActiveOrdersRequester_Factory(Provider<FrontbackNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public GetActiveOrdersRequester get() {
    return newInstance(apiProvider.get());
  }

  public static GetActiveOrdersRequester_Factory create(Provider<FrontbackNetworkApi> apiProvider) {
    return new GetActiveOrdersRequester_Factory(apiProvider);
  }

  public static GetActiveOrdersRequester newInstance(FrontbackNetworkApi api) {
    return new GetActiveOrdersRequester(api);
  }
}
