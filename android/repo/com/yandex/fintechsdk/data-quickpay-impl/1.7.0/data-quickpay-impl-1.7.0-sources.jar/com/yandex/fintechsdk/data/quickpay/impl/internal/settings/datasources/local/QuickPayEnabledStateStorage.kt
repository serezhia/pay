package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.local

import android.content.SharedPreferences

internal class QuickPayEnabledStateStorage(
    private val sharedPreferences: SharedPreferences,
) {

    fun getIsEnabled(): Boolean? {
        if (!sharedPreferences.contains(KEY_IS_ENABLED)) {
            return null
        }
        return sharedPreferences.getBoolean(
            /* key = */ KEY_IS_ENABLED,
            /* defValue = */ false,
        )
    }

    fun saveIsEnabled(isEnabled: Boolean) {
        sharedPreferences.edit()
            .putBoolean(
                /* key = */ KEY_IS_ENABLED,
                /* value = */ isEnabled,
            )
            .apply()
    }

    fun clear() {
        sharedPreferences.edit()
            .remove(KEY_IS_ENABLED)
            .apply()
    }

    private companion object {
        private const val KEY_IS_ENABLED = "quickpay_enabled_state"
    }
}

