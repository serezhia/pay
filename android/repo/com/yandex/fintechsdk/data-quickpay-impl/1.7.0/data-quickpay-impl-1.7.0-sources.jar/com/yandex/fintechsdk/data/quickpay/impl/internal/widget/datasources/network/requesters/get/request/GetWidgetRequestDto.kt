package com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.get.request

internal data class GetWidgetRequestDto(
    val divKitVersion: String,
)
