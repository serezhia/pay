package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.request

import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod

internal class GetActiveOrdersRequest : Request(
    configure = { isAuthNeeded = false },
) {

    override val method: RestMethod = RestMethod.GET
    override val requestName: String = REQUEST_NAME
    override val requestPath: String = REQUEST_PATH

    override fun queries(): Map<String, String> = mapOf(
        QUERY_ONLY_ACTIVE to QUERY_ONLY_ACTIVE_VALUE,
    )

    private companion object {
        private const val REQUEST_NAME = "get_active_orders"
        private const val REQUEST_PATH = "pay/v1/quickpay/orders"
        private const val QUERY_ONLY_ACTIVE = "active"
        private const val QUERY_ONLY_ACTIVE_VALUE = "true"
    }
}

