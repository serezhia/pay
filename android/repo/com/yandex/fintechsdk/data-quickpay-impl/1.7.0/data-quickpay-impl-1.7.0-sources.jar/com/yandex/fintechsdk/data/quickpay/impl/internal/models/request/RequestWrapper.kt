package com.yandex.fintechsdk.data.quickpay.impl.internal.models.request


import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

internal abstract class RequestWrapper(
    configure: Request.Configuration.() -> Unit = {},
) : Request(configure) {

    override val method: RestMethod = RestMethod.POST

    protected abstract fun innerBody(): JsonObject

    override fun body(): JsonObject = buildJsonObject {
        put(JSON_KEY_REQUEST, innerBody())
    }

    private companion object {
        private const val JSON_KEY_REQUEST = "request"
    }
}
