package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.request

import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod

internal class GetSettingsRequest : Request(
    configure = { isAuthNeeded = false },
) {

    override val method: RestMethod = RestMethod.GET
    override val requestName: String = REQUEST_NAME
    override val requestPath: String = REQUEST_PATH

    private companion object {
        private const val REQUEST_NAME = "get_quickpay_settings"
        private const val REQUEST_PATH = "pay/v1/quickpay/settings"
    }
}
