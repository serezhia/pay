package com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.all;

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GetAllOrdersRequester_Factory implements Factory<GetAllOrdersRequester> {
  private final Provider<FrontbackNetworkApi> apiProvider;

  private GetAllOrdersRequester_Factory(Provider<FrontbackNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public GetAllOrdersRequester get() {
    return newInstance(apiProvider.get());
  }

  public static GetAllOrdersRequester_Factory create(Provider<FrontbackNetworkApi> apiProvider) {
    return new GetAllOrdersRequester_Factory(apiProvider);
  }

  public static GetAllOrdersRequester newInstance(FrontbackNetworkApi api) {
    return new GetAllOrdersRequester(api);
  }
}
