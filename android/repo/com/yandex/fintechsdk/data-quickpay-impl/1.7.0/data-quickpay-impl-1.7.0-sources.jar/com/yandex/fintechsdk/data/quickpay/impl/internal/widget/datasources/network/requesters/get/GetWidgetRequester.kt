package com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.get

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.get.request.GetWidgetRequest
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.get.request.GetWidgetRequestDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.get.response.WidgetResponseDto
import org.json.JSONObject
import javax.inject.Inject

internal class GetWidgetRequester @Inject constructor(
    private val api: FrontbackNetworkApi,
) : Requester<GetWidgetRequestDto, GetWidgetRequest, WidgetResponseDto, JSONObject>() {

    override fun createRequest(params: GetWidgetRequestDto): GetWidgetRequest =
        GetWidgetRequest(divKitVersion = params.divKitVersion)

    override suspend fun executeRequest(request: GetWidgetRequest): Result<WidgetResponseDto> =
        api.sendRequest(request = request)

    override fun transformResponse(response: WidgetResponseDto): JSONObject =
        response.json
}
