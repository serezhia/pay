package com.yandex.fintechsdk.data.quickpay.impl.api.di;

import android.content.SharedPreferences;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.local.QuickPayEnabledStateStorage;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DataQuickPayModule_Companion_ProvideQuickPayEnabledStateStorage$impl_releaseFactory implements Factory<QuickPayEnabledStateStorage> {
  private final Provider<SharedPreferences> sharedPreferencesProvider;

  private DataQuickPayModule_Companion_ProvideQuickPayEnabledStateStorage$impl_releaseFactory(
      Provider<SharedPreferences> sharedPreferencesProvider) {
    this.sharedPreferencesProvider = sharedPreferencesProvider;
  }

  @Override
  public QuickPayEnabledStateStorage get() {
    return provideQuickPayEnabledStateStorage$impl_release(sharedPreferencesProvider.get());
  }

  public static DataQuickPayModule_Companion_ProvideQuickPayEnabledStateStorage$impl_releaseFactory create(
      Provider<SharedPreferences> sharedPreferencesProvider) {
    return new DataQuickPayModule_Companion_ProvideQuickPayEnabledStateStorage$impl_releaseFactory(sharedPreferencesProvider);
  }

  public static QuickPayEnabledStateStorage provideQuickPayEnabledStateStorage$impl_release(
      SharedPreferences sharedPreferences) {
    return Preconditions.checkNotNullFromProvides(DataQuickPayModule.Companion.provideQuickPayEnabledStateStorage$impl_release(sharedPreferences));
  }
}
