package com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.request

internal object GetSettingsRequestDto
