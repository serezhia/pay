package com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.get;

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GetWidgetRequester_Factory implements Factory<GetWidgetRequester> {
  private final Provider<FrontbackNetworkApi> apiProvider;

  private GetWidgetRequester_Factory(Provider<FrontbackNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public GetWidgetRequester get() {
    return newInstance(apiProvider.get());
  }

  public static GetWidgetRequester_Factory create(Provider<FrontbackNetworkApi> apiProvider) {
    return new GetWidgetRequester_Factory(apiProvider);
  }

  public static GetWidgetRequester newInstance(FrontbackNetworkApi api) {
    return new GetWidgetRequester(api);
  }
}
