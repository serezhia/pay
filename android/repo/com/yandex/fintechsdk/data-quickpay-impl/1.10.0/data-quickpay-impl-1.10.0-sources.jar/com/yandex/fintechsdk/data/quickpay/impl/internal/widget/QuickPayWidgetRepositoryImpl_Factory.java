package com.yandex.fintechsdk.data.quickpay.impl.internal.widget;

import com.yandex.fintechsdk.adapters.divkit.sdk.api.version.DivKitVersionProvider;
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.widget.GetWidgetRequester;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class QuickPayWidgetRepositoryImpl_Factory implements Factory<QuickPayWidgetRepositoryImpl> {
  private final Provider<DivKitVersionProvider> divKitVersionProvider;

  private final Provider<GetWidgetRequester> widgetRequesterProvider;

  private QuickPayWidgetRepositoryImpl_Factory(
      Provider<DivKitVersionProvider> divKitVersionProvider,
      Provider<GetWidgetRequester> widgetRequesterProvider) {
    this.divKitVersionProvider = divKitVersionProvider;
    this.widgetRequesterProvider = widgetRequesterProvider;
  }

  @Override
  public QuickPayWidgetRepositoryImpl get() {
    return newInstance(divKitVersionProvider.get(), widgetRequesterProvider.get());
  }

  public static QuickPayWidgetRepositoryImpl_Factory create(
      Provider<DivKitVersionProvider> divKitVersionProvider,
      Provider<GetWidgetRequester> widgetRequesterProvider) {
    return new QuickPayWidgetRepositoryImpl_Factory(divKitVersionProvider, widgetRequesterProvider);
  }

  public static QuickPayWidgetRepositoryImpl newInstance(
      DivKitVersionProvider divKitVersionProvider, GetWidgetRequester widgetRequester) {
    return new QuickPayWidgetRepositoryImpl(divKitVersionProvider, widgetRequester);
  }
}
