package com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.badge.request

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class GetActivePaymentMethodBadgeRequestDto(
    @SerialName("div_kit_version")
    val divKitVersion: String,
)
