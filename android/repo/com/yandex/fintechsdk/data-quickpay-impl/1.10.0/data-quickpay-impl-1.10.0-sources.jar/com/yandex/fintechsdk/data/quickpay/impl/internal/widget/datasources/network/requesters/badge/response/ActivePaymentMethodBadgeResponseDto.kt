package com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.badge.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import org.json.JSONObject

@Serializable
internal class ActivePaymentMethodBadgeResponseDto(
    @SerialName("card")
    private val card: JsonObject,
) {
    val json: JSONObject get() = JSONObject(card.toString())
}
