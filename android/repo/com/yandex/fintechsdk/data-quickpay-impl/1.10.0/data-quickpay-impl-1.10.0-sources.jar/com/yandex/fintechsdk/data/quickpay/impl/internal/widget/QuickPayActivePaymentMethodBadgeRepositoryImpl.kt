package com.yandex.fintechsdk.data.quickpay.impl.internal.widget

import com.yandex.fintechsdk.adapters.divkit.sdk.api.version.DivKitVersionProvider
import com.yandex.fintechsdk.data.quickpay.api.widget.QuickPayActivePaymentMethodBadgeRepository
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.badge.GetActivePaymentMethodBadgeRequester
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.badge.request.GetActivePaymentMethodBadgeRequestDto
import org.json.JSONObject
import javax.inject.Inject

internal class QuickPayActivePaymentMethodBadgeRepositoryImpl @Inject constructor(
    private val divKitVersionProvider: DivKitVersionProvider,
    private val widgetRequester: GetActivePaymentMethodBadgeRequester,
) : QuickPayActivePaymentMethodBadgeRepository {

    override suspend fun loadWidget(): Result<JSONObject> {
        val widgetParams = GetActivePaymentMethodBadgeRequestDto(
            divKitVersion = divKitVersionProvider.getVersion(),
        )

        return widgetRequester.execute(params = widgetParams)
    }
}
