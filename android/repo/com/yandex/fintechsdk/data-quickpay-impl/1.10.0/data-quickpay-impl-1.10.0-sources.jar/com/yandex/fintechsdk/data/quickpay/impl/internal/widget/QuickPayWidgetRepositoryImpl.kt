package com.yandex.fintechsdk.data.quickpay.impl.internal.widget

import com.yandex.fintechsdk.adapters.divkit.sdk.api.version.DivKitVersionProvider
import com.yandex.fintechsdk.data.quickpay.api.widget.QuickPayWidgetRepository
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.widget.GetWidgetRequester
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.widget.request.GetWidgetRequestDto
import org.json.JSONObject
import javax.inject.Inject

internal class QuickPayWidgetRepositoryImpl @Inject constructor(
    private val divKitVersionProvider: DivKitVersionProvider,
    private val widgetRequester: GetWidgetRequester,
) : QuickPayWidgetRepository {

    override var isActivePaymentMethodVisible: Boolean = false

    override suspend fun loadWidget(): Result<JSONObject> {
        val widgetParams = GetWidgetRequestDto(
            divKitVersion = divKitVersionProvider.getVersion(),
            showActivePaymentMethod = isActivePaymentMethodVisible,
        )

        return widgetRequester.execute(params = widgetParams)
    }
}
