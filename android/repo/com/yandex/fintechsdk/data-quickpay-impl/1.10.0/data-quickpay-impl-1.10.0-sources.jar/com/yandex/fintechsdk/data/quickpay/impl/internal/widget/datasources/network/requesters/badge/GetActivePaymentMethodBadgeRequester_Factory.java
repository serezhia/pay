package com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.badge;

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GetActivePaymentMethodBadgeRequester_Factory implements Factory<GetActivePaymentMethodBadgeRequester> {
  private final Provider<FrontbackNetworkApi> apiProvider;

  private GetActivePaymentMethodBadgeRequester_Factory(Provider<FrontbackNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public GetActivePaymentMethodBadgeRequester get() {
    return newInstance(apiProvider.get());
  }

  public static GetActivePaymentMethodBadgeRequester_Factory create(
      Provider<FrontbackNetworkApi> apiProvider) {
    return new GetActivePaymentMethodBadgeRequester_Factory(apiProvider);
  }

  public static GetActivePaymentMethodBadgeRequester newInstance(FrontbackNetworkApi api) {
    return new GetActivePaymentMethodBadgeRequester(api);
  }
}
