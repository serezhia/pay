package com.yandex.fintechsdk.data.quickpay.impl.internal.widget;

import com.yandex.fintechsdk.adapters.divkit.sdk.api.version.DivKitVersionProvider;
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.badge.GetActivePaymentMethodBadgeRequester;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class QuickPayActivePaymentMethodBadgeRepositoryImpl_Factory implements Factory<QuickPayActivePaymentMethodBadgeRepositoryImpl> {
  private final Provider<DivKitVersionProvider> divKitVersionProvider;

  private final Provider<GetActivePaymentMethodBadgeRequester> widgetRequesterProvider;

  private QuickPayActivePaymentMethodBadgeRepositoryImpl_Factory(
      Provider<DivKitVersionProvider> divKitVersionProvider,
      Provider<GetActivePaymentMethodBadgeRequester> widgetRequesterProvider) {
    this.divKitVersionProvider = divKitVersionProvider;
    this.widgetRequesterProvider = widgetRequesterProvider;
  }

  @Override
  public QuickPayActivePaymentMethodBadgeRepositoryImpl get() {
    return newInstance(divKitVersionProvider.get(), widgetRequesterProvider.get());
  }

  public static QuickPayActivePaymentMethodBadgeRepositoryImpl_Factory create(
      Provider<DivKitVersionProvider> divKitVersionProvider,
      Provider<GetActivePaymentMethodBadgeRequester> widgetRequesterProvider) {
    return new QuickPayActivePaymentMethodBadgeRepositoryImpl_Factory(divKitVersionProvider, widgetRequesterProvider);
  }

  public static QuickPayActivePaymentMethodBadgeRepositoryImpl newInstance(
      DivKitVersionProvider divKitVersionProvider,
      GetActivePaymentMethodBadgeRequester widgetRequester) {
    return new QuickPayActivePaymentMethodBadgeRepositoryImpl(divKitVersionProvider, widgetRequester);
  }
}
