package com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.badge

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.badge.request.GetActivePaymentMethodBadgeRequest
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.badge.request.GetActivePaymentMethodBadgeRequestDto
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.badge.response.ActivePaymentMethodBadgeResponseDto
import org.json.JSONObject
import javax.inject.Inject

internal class GetActivePaymentMethodBadgeRequester @Inject constructor(
    private val api: FrontbackNetworkApi,
) : Requester<GetActivePaymentMethodBadgeRequestDto, GetActivePaymentMethodBadgeRequest, ActivePaymentMethodBadgeResponseDto, JSONObject>() {

    override fun createRequest(params: GetActivePaymentMethodBadgeRequestDto): GetActivePaymentMethodBadgeRequest =
        GetActivePaymentMethodBadgeRequest(
            divKitVersion = params.divKitVersion,
        )

    override suspend fun executeRequest(request: GetActivePaymentMethodBadgeRequest): Result<ActivePaymentMethodBadgeResponseDto> =
        api.sendRequest(request = request)

    override fun transformResponse(response: ActivePaymentMethodBadgeResponseDto): JSONObject =
        response.json
}
