package com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.widget.request

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class GetWidgetRequestDto(
    @SerialName("div_kit_version")
    val divKitVersion: String,

    @SerialName("show_active_payment_method")
    val showActivePaymentMethod: Boolean? = false,
)
