package com.yandex.fintechsdk.data.card.impl.internal.binding

import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository
import com.yandex.fintechsdk.data.card.api.binding.model.CardBindingCurrency
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeCardData
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeMethod
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeResult
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.memory.CardBindingMemoryDataSource
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.CardBindingNetworkDataSource
import com.yandex.fintechsdk.entities.card.BinInfo
import kotlinx.serialization.json.JsonObject
import javax.inject.Inject

internal class CardBindingRepositoryImpl @Inject constructor(
    private val memoryDataSource: CardBindingMemoryDataSource,
    private val networkDatasource: CardBindingNetworkDataSource,
) : CardBindingRepository {

    override suspend fun initVerification(currency: CardBindingCurrency): Result<JsonObject> {
        return networkDatasource.initVerification(currency = currency)
    }

    override suspend fun tokenize(baseUrl: String, method: TokenizeMethod, data: TokenizeCardData, context: JsonObject): Result<TokenizeResult> {
        return networkDatasource.tokenize(
            baseUrl = baseUrl,
            method = method,
            data = data,
            context = context,
        )
    }

    override suspend fun getBinInfo(baseUrl: String, prefix: String): Result<BinInfo> {
        memoryDataSource.getBinInfo(prefix = prefix)?.let { cached ->
            return Result.success(value = cached)
        }

        val result = networkDatasource.getBinInfo(baseUrl = baseUrl, prefix = prefix)
        result.onSuccess { binInfo ->
            memoryDataSource.setBinInfo(
                prefix = prefix,
                binInfo = binInfo,
            )
        }
        return result
    }
}
