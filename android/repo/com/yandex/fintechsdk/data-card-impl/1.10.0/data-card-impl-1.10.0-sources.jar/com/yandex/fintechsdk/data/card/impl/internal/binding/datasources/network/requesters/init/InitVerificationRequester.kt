package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.init

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.card.api.binding.model.CardBindingCurrency
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.init.request.InitVerificationRequest
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.init.request.InitVerificationRequestDto
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.init.response.InitVerificationResponseDto
import kotlinx.serialization.json.JsonObject
import javax.inject.Inject

internal class InitVerificationRequester @Inject constructor(
    private val api: FrontbackNetworkApi,
) : Requester<CardBindingCurrency, InitVerificationRequest, InitVerificationResponseDto, JsonObject>() {

    override fun createRequest(params: CardBindingCurrency): InitVerificationRequest {
        return InitVerificationRequest(
            initVerificationRequestDto = InitVerificationRequestDto(currency = params),
        )
    }

    override suspend fun executeRequest(request: InitVerificationRequest): Result<InitVerificationResponseDto> {
        return api.sendRequest(request = request)
    }

    override fun transformResponse(response: InitVerificationResponseDto): JsonObject {
        return response.tokenizationContext
    }
}
