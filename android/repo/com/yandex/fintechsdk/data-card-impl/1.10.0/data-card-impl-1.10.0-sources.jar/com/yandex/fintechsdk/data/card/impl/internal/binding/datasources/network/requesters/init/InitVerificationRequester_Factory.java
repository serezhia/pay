package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.init;

import com.yandex.fintechsdk.core.network.api.network.FrontbackNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class InitVerificationRequester_Factory implements Factory<InitVerificationRequester> {
  private final Provider<FrontbackNetworkApi> apiProvider;

  private InitVerificationRequester_Factory(Provider<FrontbackNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public InitVerificationRequester get() {
    return newInstance(apiProvider.get());
  }

  public static InitVerificationRequester_Factory create(
      Provider<FrontbackNetworkApi> apiProvider) {
    return new InitVerificationRequester_Factory(apiProvider);
  }

  public static InitVerificationRequester newInstance(FrontbackNetworkApi api) {
    return new InitVerificationRequester(api);
  }
}
