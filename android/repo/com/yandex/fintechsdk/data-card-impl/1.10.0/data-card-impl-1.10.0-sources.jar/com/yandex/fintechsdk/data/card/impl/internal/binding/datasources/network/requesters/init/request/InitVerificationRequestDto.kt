package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.init.request

import com.yandex.fintechsdk.data.card.api.binding.model.CardBindingCurrency
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class InitVerificationRequestDto(
    @SerialName("currency")
    val currency: CardBindingCurrency,
)
