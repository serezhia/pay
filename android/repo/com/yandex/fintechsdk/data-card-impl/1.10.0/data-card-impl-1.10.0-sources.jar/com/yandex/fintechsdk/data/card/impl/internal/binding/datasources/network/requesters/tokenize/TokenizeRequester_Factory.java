package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize;

import com.yandex.fintechsdk.core.network.api.network.DiehardNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class TokenizeRequester_Factory implements Factory<TokenizeRequester> {
  private final Provider<DiehardNetworkApi> apiProvider;

  private TokenizeRequester_Factory(Provider<DiehardNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public TokenizeRequester get() {
    return newInstance(apiProvider.get());
  }

  public static TokenizeRequester_Factory create(Provider<DiehardNetworkApi> apiProvider) {
    return new TokenizeRequester_Factory(apiProvider);
  }

  public static TokenizeRequester newInstance(DiehardNetworkApi api) {
    return new TokenizeRequester(api);
  }
}
