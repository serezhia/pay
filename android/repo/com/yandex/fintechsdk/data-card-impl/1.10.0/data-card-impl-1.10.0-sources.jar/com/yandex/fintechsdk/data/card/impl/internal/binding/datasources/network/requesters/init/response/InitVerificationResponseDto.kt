package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.init.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

@Serializable
internal class InitVerificationResponseDto(
    @SerialName("tokenization_context")
    val tokenizationContext: JsonObject,
)
