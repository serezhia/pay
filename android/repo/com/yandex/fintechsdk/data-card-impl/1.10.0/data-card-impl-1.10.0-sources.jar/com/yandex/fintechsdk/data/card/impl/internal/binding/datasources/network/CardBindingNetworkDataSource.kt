package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network

import com.yandex.fintechsdk.data.card.api.binding.model.CardBindingCurrency
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeCardData
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeMethod
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeResult
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.BinInfoRequester
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.request.BinInfoParams
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.init.InitVerificationRequester
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.TokenizeRequester
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.request.TokenizeParams
import com.yandex.fintechsdk.entities.card.BinInfo
import kotlinx.serialization.json.JsonObject
import javax.inject.Inject

internal class CardBindingNetworkDataSource @Inject constructor(
    private val initVerificationRequester: InitVerificationRequester,
    private val tokenizeRequester: TokenizeRequester,
    private val binInfoRequester: BinInfoRequester,
) {

    suspend fun initVerification(currency: CardBindingCurrency): Result<JsonObject> {
        return initVerificationRequester.execute(params = currency)
    }

    suspend fun tokenize(baseUrl: String, method: TokenizeMethod, data: TokenizeCardData, context: JsonObject): Result<TokenizeResult> {
        return tokenizeRequester.execute(
            params = TokenizeParams(
                baseUrl = baseUrl,
                method = method,
                data = data,
                context = context,
            )
        )
    }

    suspend fun getBinInfo(baseUrl: String, prefix: String): Result<BinInfo> {
        return binInfoRequester.execute(params = BinInfoParams(baseUrl = baseUrl, prefix = prefix))
    }
}
