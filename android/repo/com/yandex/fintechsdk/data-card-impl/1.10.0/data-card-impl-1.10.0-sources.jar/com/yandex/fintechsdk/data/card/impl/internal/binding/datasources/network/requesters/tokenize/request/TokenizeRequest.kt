package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.request

import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.encodeToJsonElement
import kotlinx.serialization.json.jsonObject

internal class TokenizeRequest(
    override val baseUrl: String,
    private val tokenizeRequestDto: TokenizeRequestDto,
) : Request() {

    override val method: RestMethod = RestMethod.POST
    override val requestName: String = "card_tokenize"
    override val requestPath: String = "/v2/tokenize"

    override fun body(): JsonObject {
        // Use Json with explicitNulls = false to exclude null fields (like cvn for cards without CVV)
        val json = Json {
            explicitNulls = false
        }
        return json.encodeToJsonElement(value = tokenizeRequestDto).jsonObject
    }
}
