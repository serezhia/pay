package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.request

import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeCardData
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeMethod
import kotlinx.serialization.json.JsonObject

internal class TokenizeParams(
    val baseUrl: String,
    val method: TokenizeMethod,
    val data: TokenizeCardData,
    val context: JsonObject,
)
