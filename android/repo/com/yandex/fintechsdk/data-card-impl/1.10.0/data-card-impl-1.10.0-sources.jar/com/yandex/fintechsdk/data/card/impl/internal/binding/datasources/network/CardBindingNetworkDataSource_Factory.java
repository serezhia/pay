package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network;

import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.BinInfoRequester;
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.init.InitVerificationRequester;
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.TokenizeRequester;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CardBindingNetworkDataSource_Factory implements Factory<CardBindingNetworkDataSource> {
  private final Provider<InitVerificationRequester> initVerificationRequesterProvider;

  private final Provider<TokenizeRequester> tokenizeRequesterProvider;

  private final Provider<BinInfoRequester> binInfoRequesterProvider;

  private CardBindingNetworkDataSource_Factory(
      Provider<InitVerificationRequester> initVerificationRequesterProvider,
      Provider<TokenizeRequester> tokenizeRequesterProvider,
      Provider<BinInfoRequester> binInfoRequesterProvider) {
    this.initVerificationRequesterProvider = initVerificationRequesterProvider;
    this.tokenizeRequesterProvider = tokenizeRequesterProvider;
    this.binInfoRequesterProvider = binInfoRequesterProvider;
  }

  @Override
  public CardBindingNetworkDataSource get() {
    return newInstance(initVerificationRequesterProvider.get(), tokenizeRequesterProvider.get(), binInfoRequesterProvider.get());
  }

  public static CardBindingNetworkDataSource_Factory create(
      Provider<InitVerificationRequester> initVerificationRequesterProvider,
      Provider<TokenizeRequester> tokenizeRequesterProvider,
      Provider<BinInfoRequester> binInfoRequesterProvider) {
    return new CardBindingNetworkDataSource_Factory(initVerificationRequesterProvider, tokenizeRequesterProvider, binInfoRequesterProvider);
  }

  public static CardBindingNetworkDataSource newInstance(
      InitVerificationRequester initVerificationRequester, TokenizeRequester tokenizeRequester,
      BinInfoRequester binInfoRequester) {
    return new CardBindingNetworkDataSource(initVerificationRequester, tokenizeRequester, binInfoRequester);
  }
}
