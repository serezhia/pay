package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.memory;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CardBindingMemoryDataSource_Factory implements Factory<CardBindingMemoryDataSource> {
  @Override
  public CardBindingMemoryDataSource get() {
    return newInstance();
  }

  public static CardBindingMemoryDataSource_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static CardBindingMemoryDataSource newInstance() {
    return new CardBindingMemoryDataSource();
  }

  private static final class InstanceHolder {
    static final CardBindingMemoryDataSource_Factory INSTANCE = new CardBindingMemoryDataSource_Factory();
  }
}
