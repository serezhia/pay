package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.request

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class BinInfoRequestDto(
    @SerialName("prefix")
    val prefix: String,
)
