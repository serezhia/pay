package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.request

internal class BinInfoParams(
    val baseUrl: String,
    val prefix: String,
)
