package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.memory

import com.yandex.fintechsdk.entities.card.BinInfo
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject

internal class CardBindingMemoryDataSource @Inject constructor() {

    private val cachedBinInfo = ConcurrentHashMap<String, BinInfo>()

    fun getBinInfo(prefix: String): BinInfo? {
        return cachedBinInfo[prefix]
    }

    fun setBinInfo(prefix: String, binInfo: BinInfo) {
        cachedBinInfo[prefix] = binInfo
    }

    fun clearBinInfo() {
        cachedBinInfo.clear()
    }
}
