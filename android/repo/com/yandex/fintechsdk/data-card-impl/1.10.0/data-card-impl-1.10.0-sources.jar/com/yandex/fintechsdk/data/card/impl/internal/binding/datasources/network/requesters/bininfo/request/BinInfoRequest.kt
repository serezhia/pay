package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.request

import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.encodeToJsonElement
import kotlinx.serialization.json.jsonObject

internal class BinInfoRequest(
    override val baseUrl: String,
    private val binInfoRequestDto: BinInfoRequestDto,
) : Request() {

    override val method: RestMethod = RestMethod.POST
    override val requestName: String = "cardmeta"
    override val requestPath: String = "/v2/cardmeta"

    override fun body(): JsonObject {
        return Json.encodeToJsonElement(value = binInfoRequestDto).jsonObject
    }
}
