package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo

import com.yandex.fintechsdk.core.network.api.network.DiehardNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.request.BinInfoParams
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.request.BinInfoRequest
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.request.BinInfoRequestDto
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.response.BinInfoResponseDto
import com.yandex.fintechsdk.entities.card.BinInfo
import javax.inject.Inject

internal class BinInfoRequester @Inject constructor(
    private val api: DiehardNetworkApi,
) : Requester<BinInfoParams, BinInfoRequest, BinInfoResponseDto, BinInfo>() {

    override fun createRequest(params: BinInfoParams): BinInfoRequest {
        return BinInfoRequest(
            baseUrl = params.baseUrl,
            binInfoRequestDto = BinInfoRequestDto(
                prefix = params.prefix,
            ),
        )
    }

    override suspend fun executeRequest(request: BinInfoRequest): Result<BinInfoResponseDto> {
        return api.sendRequest(request = request)
    }

    override fun transformResponse(response: BinInfoResponseDto): BinInfo {
        return BinInfo(
            paymentSystem = response.result.paymentSystem,
            withoutCvn = response.result.withoutCvn,
        )
    }
}
