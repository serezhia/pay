package com.yandex.fintechsdk.data.card.impl.api.di

import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository
import com.yandex.fintechsdk.data.card.impl.internal.binding.CardBindingRepositoryImpl
import dagger.Binds
import dagger.Module

@Module
public abstract class DataCardModule {

    @FlowScope
    @Binds
    internal abstract fun bindCardBindingRepository(impl: CardBindingRepositoryImpl): CardBindingRepository
}
