package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize

import com.yandex.fintechsdk.core.network.api.network.DiehardNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeMethod
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeResult
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.request.TokenizeCardDto
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.request.TokenizeMethodDto
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.request.TokenizeParams
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.request.TokenizeRequest
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.request.TokenizeRequestDto
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.response.TokenizeResponseDto
import javax.inject.Inject

internal class TokenizeRequester @Inject constructor(
    private val api: DiehardNetworkApi,
) : Requester<TokenizeParams, TokenizeRequest, TokenizeResponseDto, TokenizeResult>() {

    override fun createRequest(params: TokenizeParams): TokenizeRequest {
        return TokenizeRequest(
            baseUrl = params.baseUrl,
            tokenizeRequestDto = TokenizeRequestDto(
                method = params.method.toTokenizeMethodDto().value,
                data = TokenizeCardDto(
                    pan = formatPan(pan = params.data.pan),
                    expirationYear = formatExpirationYear(year = params.data.expirationYear),
                    expirationMonth = formatExpirationMonth(month = params.data.expirationMonth),
                    cvn = params.data.secretCode,
                ),
                context = params.context,
            ),
        )
    }

    override suspend fun executeRequest(request: TokenizeRequest): Result<TokenizeResponseDto> {
        return api.sendRequest(request = request)
    }

    override fun transformResponse(response: TokenizeResponseDto): TokenizeResult {
        return TokenizeResult(
            requestId = response.requestId,
            pmd = response.result.pmd,
            psd = response.result.psd,
        )
    }

    private fun TokenizeMethod.toTokenizeMethodDto(): TokenizeMethodDto {
        return when (this) {
            TokenizeMethod.CARD -> TokenizeMethodDto.CARD
        }
    }

    private fun formatExpirationYear(year: String): String {
        // Request will not work, if the year is in format "XX", we need to send four-digit format of the year
        if (year.length > 2) return year

        return "20${year}"
    }

    private fun formatPan(pan: String): String {
        return pan.replace(" ", "")
    }

    private fun formatExpirationMonth(month: String): String {
        return month.padStart(2, '0')
    }
}
