package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.init.request

import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.encodeToJsonElement
import kotlinx.serialization.json.jsonObject

internal class InitVerificationRequest(
    private val initVerificationRequestDto: InitVerificationRequestDto,
) : Request() {

    override val method: RestMethod = RestMethod.POST
    override val requestName: String = "card_init_verification"
    override val requestPath: String = "/v2/init_verification"

    override fun body(): JsonObject {
        return Json.encodeToJsonElement(initVerificationRequestDto).jsonObject
    }
}
