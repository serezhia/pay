package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo;

import com.yandex.fintechsdk.core.network.api.network.DiehardNetworkApi;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BinInfoRequester_Factory implements Factory<BinInfoRequester> {
  private final Provider<DiehardNetworkApi> apiProvider;

  private BinInfoRequester_Factory(Provider<DiehardNetworkApi> apiProvider) {
    this.apiProvider = apiProvider;
  }

  @Override
  public BinInfoRequester get() {
    return newInstance(apiProvider.get());
  }

  public static BinInfoRequester_Factory create(Provider<DiehardNetworkApi> apiProvider) {
    return new BinInfoRequester_Factory(apiProvider);
  }

  public static BinInfoRequester newInstance(DiehardNetworkApi api) {
    return new BinInfoRequester(api);
  }
}
