package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.request

import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

@Serializable
internal class TokenizeRequestDto(
    @SerialName(value = "method")
    val method: String,

    @SerialName(value = "data")
    val data: TokenizeCardDto,

    @SerialName(value = "context")
    val context: JsonObject,
)

@Serializable
internal class TokenizeCardDto(
    @SerialName(value = "pan")
    val pan: String,

    @SerialName(value = "expiration_year")
    val expirationYear: String,

    @SerialName(value = "expiration_month")
    val expirationMonth: String,

    @SerialName(value = "cvn")
    @EncodeDefault(mode = EncodeDefault.Mode.NEVER)
    val cvn: String?,
)

internal enum class TokenizeMethodDto(val value: String) {
    CARD(value = "card"),
}
