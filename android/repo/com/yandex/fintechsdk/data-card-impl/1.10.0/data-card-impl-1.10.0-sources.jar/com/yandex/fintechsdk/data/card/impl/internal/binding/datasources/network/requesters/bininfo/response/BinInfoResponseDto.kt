package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.bininfo.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
public data class BinInfoResponseDto(
    @SerialName("id")
    val id: String,

    @SerialName("result")
    val result: CardMetaResult,
)

@Serializable
public data class CardMetaResult(
    @SerialName("payment_system")
    val paymentSystem: String,

    @SerialName("without_cvn")
    val withoutCvn: Boolean,
)
