package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.requesters.tokenize.response

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class TokenizeResponseDto(
    @SerialName(value = "id")
    val requestId: String,

    @SerialName(value = "result")
    val result: TokenizeResult,
)

@Serializable
internal class TokenizeResult(
    @SerialName(value = "pmd")
    val pmd: String,

    @SerialName(value = "psd")
    val psd: String? = null,
)
