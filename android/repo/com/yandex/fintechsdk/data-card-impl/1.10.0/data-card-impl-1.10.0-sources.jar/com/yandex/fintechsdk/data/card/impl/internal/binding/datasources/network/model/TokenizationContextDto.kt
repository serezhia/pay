package com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class TokenizationContextDto(
    @SerialName("uid")
    val uid: String,

    @SerialName("login_id")
    val loginId: String,

    @SerialName("op")
    val op: String,

    @SerialName("op_id")
    val opId: String,
)
