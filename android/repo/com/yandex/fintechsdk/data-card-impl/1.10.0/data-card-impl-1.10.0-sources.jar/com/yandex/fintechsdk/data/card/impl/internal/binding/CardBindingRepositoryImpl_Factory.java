package com.yandex.fintechsdk.data.card.impl.internal.binding;

import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.memory.CardBindingMemoryDataSource;
import com.yandex.fintechsdk.data.card.impl.internal.binding.datasources.network.CardBindingNetworkDataSource;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CardBindingRepositoryImpl_Factory implements Factory<CardBindingRepositoryImpl> {
  private final Provider<CardBindingMemoryDataSource> memoryDataSourceProvider;

  private final Provider<CardBindingNetworkDataSource> networkDatasourceProvider;

  private CardBindingRepositoryImpl_Factory(
      Provider<CardBindingMemoryDataSource> memoryDataSourceProvider,
      Provider<CardBindingNetworkDataSource> networkDatasourceProvider) {
    this.memoryDataSourceProvider = memoryDataSourceProvider;
    this.networkDatasourceProvider = networkDatasourceProvider;
  }

  @Override
  public CardBindingRepositoryImpl get() {
    return newInstance(memoryDataSourceProvider.get(), networkDatasourceProvider.get());
  }

  public static CardBindingRepositoryImpl_Factory create(
      Provider<CardBindingMemoryDataSource> memoryDataSourceProvider,
      Provider<CardBindingNetworkDataSource> networkDatasourceProvider) {
    return new CardBindingRepositoryImpl_Factory(memoryDataSourceProvider, networkDatasourceProvider);
  }

  public static CardBindingRepositoryImpl newInstance(CardBindingMemoryDataSource memoryDataSource,
      CardBindingNetworkDataSource networkDatasource) {
    return new CardBindingRepositoryImpl(memoryDataSource, networkDatasource);
  }
}
