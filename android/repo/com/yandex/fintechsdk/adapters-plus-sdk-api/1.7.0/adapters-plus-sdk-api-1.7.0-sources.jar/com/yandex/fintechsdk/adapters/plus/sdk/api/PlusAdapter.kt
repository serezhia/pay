package com.yandex.fintechsdk.adapters.plus.sdk.api

import android.content.Context
import com.yandex.fintechsdk.adapters.plus.sdk.api.model.PlusOffersInfo
import com.yandex.fintechsdk.entities.auth.AccountCredentials
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment

public interface PlusAdapter {

    public fun init(offersInfo: PlusOffersInfo)

    public suspend fun subscribeOnPlus(
        accountCredentials: AccountCredentials,
        context: Context,
        environment: DefaultEnvironment,
    ): Boolean
}
