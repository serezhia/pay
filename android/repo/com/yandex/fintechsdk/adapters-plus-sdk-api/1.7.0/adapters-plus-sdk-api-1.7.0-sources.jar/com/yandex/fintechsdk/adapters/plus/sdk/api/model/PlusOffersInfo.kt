package com.yandex.fintechsdk.adapters.plus.sdk.api.model

public class PlusOffersInfo(
    public val clientFrom: String,
    public val clientPlace: String,
    public val offerName: String,
    public val serviceChannel: String,
    public val serviceName: String,
)
