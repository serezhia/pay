/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.yandex.fintechsdk.data.quickpay.api;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.yandex.fintechsdk.data.quickpay.api";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_NAME = "1.7.0";
}
