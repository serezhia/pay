package com.yandex.fintechsdk.data.quickpay.api.settings

public data class QuickPaySettings(
    val isEnabled: Boolean,
    val selectedMethod: String?,
)

