package com.yandex.fintechsdk.data.quickpay.api.settings

public interface QuickPaySettingsRepository {
    // === Backend Settings (требуют сети и BST) ===

    /**
     * Get settings from backend
     * Requires network and BST token
     *
     * @return Result with settings or error
     */
    public suspend fun getSettingsFromBackend(): Result<QuickPaySettings>

    /**
     * Update settings on backend
     * Requires network and BST token
     *
     * @param isEnabled Enable/disable quick pay
     * @param selectedMethod Selected payment method
     * @return Result with updated settings or error
     */
    public suspend fun updateSettingsOnBackend(
        isEnabled: Boolean?,
        selectedMethod: String?,
    ): Result<QuickPaySettings>

    /**
     * Get locally cached enabled state
     * Returns null if not cached yet
     * Does NOT require network or BST
     *
     * @return Cached enabled state or null
     */
    public fun getLocalEnabledState(): Boolean?

    /**
     * Save enabled state to local cache
     *
     * @param isEnabled Enabled state to save
     */
    public fun saveLocalEnabledState(isEnabled: Boolean)

    /**
     * Clear local enabled state cache
     */
    public fun clearLocalEnabledState()
}
