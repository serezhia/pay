package com.yandex.fintechsdk.data.quickpay.api.orders.model

public data class Order(
    val url: String,
    val transactionId: String,
    val status: OrderStatus,
)

