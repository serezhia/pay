package com.yandex.fintechsdk.data.quickpay.api

/**
 * Provider for merchant identifier
 */
public interface MerchantIdProvider {
    public fun getMerchantId(): String
}

