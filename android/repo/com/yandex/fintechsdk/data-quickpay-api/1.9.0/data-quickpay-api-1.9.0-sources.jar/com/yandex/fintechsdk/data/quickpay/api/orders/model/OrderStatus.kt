package com.yandex.fintechsdk.data.quickpay.api.orders.model

public enum class OrderStatus(public val rawValue: String) {
    NEW("new"),
    IN_PROGRESS("in_process"),
    USER_INTERACTION("user_interaction"),
    SUCCESS("success"),
    FAIL("fail"),
    ;

    public companion object {
        public fun fromRawValue(value: String): OrderStatus =
            entries.firstOrNull { it.rawValue == value.lowercase() } ?: IN_PROGRESS
    }
}

