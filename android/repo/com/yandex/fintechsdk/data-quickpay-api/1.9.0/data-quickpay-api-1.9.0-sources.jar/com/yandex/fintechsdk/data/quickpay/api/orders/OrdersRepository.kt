package com.yandex.fintechsdk.data.quickpay.api.orders

import com.yandex.fintechsdk.data.quickpay.api.orders.model.Order
import kotlinx.coroutines.flow.Flow

/**
 * Repository for payment orders
 */
public interface OrdersRepository {

    /**
     * Flow emitting order status updates.
     * Collect this flow to receive order status changes.
     */
    public val orderStatusFlow: Flow<Order>

    /**
     * Poll active orders (status != success, fail)
     *
     * @return List of active orders or empty list if timeout exceeded.
     *         Throws exception on network errors (401 for expired BST).
     */
    public suspend fun pollActiveOrders(): List<Order>

    /**
     * Start polling specific order status
     *
     * @param transactionId Transaction ID to poll
     * @param paymentUrl Payment URL of the order
     * @throws Exception on network errors (401 for expired BST) or timeout.
     */
    public suspend fun pollOrderStatus(
        transactionId: String,
        paymentUrl: String,
    )

    /**
     * Get all orders (including completed ones)
     *
     * @return List of all orders.
     * @throws Exception on network errors (401 for expired BST).
     */
    public suspend fun getAllOrders(): List<Order>
}
