package com.yandex.fintechsdk.data.quickpay.api.widget

import org.json.JSONObject

public interface QuickPayWidgetRepository {

    public var isActivePaymentMethodVisible: Boolean

    public suspend fun loadWidget(): Result<JSONObject>
}

