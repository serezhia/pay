package com.yandex.fintechsdk.core.utils.api.time

public fun Long.millisToSeconds() = this / MILLIS_IN_SECOND

private const val MILLIS_IN_SECOND = 1000L
