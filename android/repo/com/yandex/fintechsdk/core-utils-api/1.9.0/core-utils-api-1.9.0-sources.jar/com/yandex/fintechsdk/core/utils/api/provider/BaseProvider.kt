package com.yandex.fintechsdk.core.utils.api.provider

import java.lang.ref.WeakReference

public abstract class BaseProvider<T> {

    private var ref: WeakReference<T>? = null

    public fun set(value: T?) {
        synchronized(this) {
            if (value != null) {
                ref = WeakReference(value)
            } else {
                ref?.clear()
                ref = null
            }
        }
    }

    public fun get(): T? {
        return synchronized(this) { ref?.get() }
    }

    public fun getOrThrow(): T {
        // TODO: catch all the exceptions at a higher level and redirect to the error screen
        return synchronized(this) { requireNotNull(ref?.get()) }
    }
}
