package com.yandex.fintechsdk.core.utils.api.adapter

public interface AdapterFinder {
    public fun <T> find(adapterClass: Class<T>, factoryClassName: String): T?
}
