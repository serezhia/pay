package com.yandex.fintechsdk.core.utils.api.date

import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Utility functions for date and time operations
 */
public object DateUtils {

    private val ISO_8601_FORMATTER = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    /**
     * Parse ISO-8601 date string to milliseconds since epoch
     *
     * @param dateString ISO-8601 formatted date string (e.g., "2024-11-14T10:30:00.000Z")
     * @return Milliseconds since epoch (Unix timestamp)
     * @throws IllegalArgumentException if the date string is not in valid ISO-8601 format
     */
    public fun parseIso8601ToMillis(dateString: String): Long {
        return ISO_8601_FORMATTER.parse(dateString)?.time
            ?: throw IllegalArgumentException("Invalid ISO-8601 date format: $dateString")
    }

    /**
     * Format milliseconds since epoch to ISO-8601 date string
     *
     * @param millis Milliseconds since epoch (Unix timestamp)
     * @return ISO-8601 formatted date string
     */
    public fun formatMillisToIso8601(millis: Long): String {
        return ISO_8601_FORMATTER.format(millis)
    }
}

