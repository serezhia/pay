package com.yandex.fintechsdk.core.utils.api

import android.content.Context

/**
 * Converts a value in dp to pixels using the screen density from the context.
 *
 * @param context Context to get display metrics from
 * @return Value in pixels
 */
public fun Float.dpToPx(context: Context): Float {
    return this * context.resources.displayMetrics.density
}

/**
 * Converts a value in dp to pixels using the screen density from the context.
 *
 * @param context Context to get display metrics from
 * @return Value in pixels
 */
public fun Int.dpToPx(context: Context): Float {
    return this.toFloat().dpToPx(context)
}

