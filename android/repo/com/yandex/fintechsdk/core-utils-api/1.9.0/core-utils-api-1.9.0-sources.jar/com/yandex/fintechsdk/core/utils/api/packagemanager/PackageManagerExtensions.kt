package com.yandex.fintechsdk.core.utils.api.packagemanager

import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

public fun PackageManager.isAppInstalled(packageName: String): Boolean = try {
    getPackageInfoCompat(packageName = packageName)
    true
} catch (_: PackageManager.NameNotFoundException) {
    false
}

public fun PackageManager.getAppVersion(packageName: String): String? = try {
    getPackageInfoCompat(packageName = packageName).versionName
} catch (_: Throwable) {
    null
}

private fun PackageManager.getPackageInfoCompat(packageName: String, flags: Int = 0): PackageInfo {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(flags.toLong()))
    } else {
        getPackageInfo(packageName, flags)
    }
}
