package com.yandex.fintechsdk.core.utils.api.url

/**
 * URL encoding utility for encoding strings as URL parameters.
 */
public object UrlEncoder {

    private val OAUTH_SYMBOLS = listOf('-', '.', '_', '~').map { it.code.toByte() }
    private val URL_ALPHABET = (('a'..'z') + ('A'..'Z') + ('0'..'9')).map { it.code.toByte() }.toSet()

    /**
     * Encodes a string for use as a URL parameter.
     *
     * @param spaceToPlus If true, spaces are encoded as '+' instead of '%20'
     * @return URL-encoded string
     */
    public fun encode(value: String, spaceToPlus: Boolean = false): String = buildString {
        value.toByteArray().forEach { byte ->
            when {
                byte in URL_ALPHABET || byte in OAUTH_SYMBOLS -> append(byte.toInt().toChar())
                spaceToPlus && byte == ' '.code.toByte() -> append('+')
                else -> append(byte.percentEncode())
            }
        }
    }

    @Suppress("MagicNumber") // TODO: define numbers as well named constant
    private fun Byte.percentEncode(): String {
        val code = toInt() and 0xff
        val array = CharArray(3)
        array[0] = '%'
        array[1] = hexDigitToChar(code shr 4)
        array[2] = hexDigitToChar(code and 0xf)
        return array.concatToString()
    }

    @Suppress("MagicNumber") // TODO: define numbers as well named constant
    private fun hexDigitToChar(digit: Int): Char = when (digit) {
        in 0..9 -> '0' + digit
        else -> 'A' + digit - 10
    }
}

/**
 * Extension function to encode a string for use as a URL parameter.
 */
public fun String.encodeAsUrlParameter(spaceToPlus: Boolean = false): String {
    return UrlEncoder.encode(this, spaceToPlus)
}

