package com.yandex.fintechsdk.core.utils.api.session

public class SessionIdGenerator {

    public fun generate(merchantId: String? = null): String {
        val prefix = merchantId?.let { "$it." } ?: ""
        return "$prefix${generateRandomPostfix()}.${System.currentTimeMillis()}"
    }

    private fun generateRandomPostfix(): String {
        val charPool: List<Char> = ('a'..'z') + ('A'..'Z') + ('0'..'9')

        return (1..POSTFIX_SIZE)
            .map { charPool.random() }
            .joinToString(separator = "")
    }

    private companion object {
        private const val POSTFIX_SIZE = 8
    }
}

