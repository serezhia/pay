package com.yandex.fintechsdk.core.utils.api.collection

public inline fun <K, V> MutableMap<K, V>.putIfNotNull(key: K, value: V?) {
    if (value != null) {
        put(key, value)
    }
}
