package com.yandex.fintechsdk.core.utils.api.useragent

public interface UserAgentProvider {
    public fun get(): String
}
