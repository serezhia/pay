package com.yandex.fintechsdk.core.utils.api.session

public class SessionId(public val value: String)

