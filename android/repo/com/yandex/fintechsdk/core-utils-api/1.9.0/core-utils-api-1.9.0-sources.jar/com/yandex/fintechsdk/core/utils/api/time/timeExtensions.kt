package com.yandex.fintechsdk.core.utils.api.time

import android.os.SystemClock

public fun Long.millisToSeconds() = this / MILLIS_IN_SECOND

/**
 * Measures the execution time of a given block of code.
 *
 * @param block The code block to measure.
 * @return A [Pair] containing the result of the block execution and the duration in milliseconds.
 */
public inline fun <T> measureDuration(block: () -> T): Pair<T, Long> {
    val startTime = SystemClock.elapsedRealtime()
    val result = block()
    val duration = SystemClock.elapsedRealtime() - startTime
    return result to duration
}

private const val MILLIS_IN_SECOND = 1000L
