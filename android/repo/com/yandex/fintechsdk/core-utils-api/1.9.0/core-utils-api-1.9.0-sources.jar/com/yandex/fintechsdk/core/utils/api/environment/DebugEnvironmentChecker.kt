package com.yandex.fintechsdk.core.utils.api.environment

public interface DebugEnvironmentChecker {
    public fun isDebugEnvironment(): Boolean
}
