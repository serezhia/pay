package com.yandex.fintechsdk.core.ui.impl.api.shimmers

import android.os.Parcelable
import androidx.annotation.LayoutRes
import kotlinx.parcelize.Parcelize

@Parcelize
public class ShimmersLayoutIdentifiers(
    @param:LayoutRes public val backbuttonId: Int,
    @param:LayoutRes public val contentId: Int,
    @param:LayoutRes public val bottomBarId: Int?,
) : Parcelable
