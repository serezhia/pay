package com.yandex.fintechsdk.core.ui.impl.api.bottomsheet

import android.view.View
import androidx.coordinatorlayout.widget.CoordinatorLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior

internal class BottomSheetStateCallback(
    private val bottomSheetBehavior: BottomSheetBehavior<*>,
    private val dimmingBackgroundAlpha: Float,
    private val dimmingBackgroundView: View,
    private val onFinish: () -> Unit,
    private val isProgrammaticallyExpanding: () -> Boolean,
    private val setIsProgrammaticallyExpanding: (Boolean) -> Unit,
) : BottomSheetBehavior.BottomSheetCallback() {

    private var lastSlideOffset = INITIAL_SLIDE_OFFSET

    override fun onStateChanged(bottomSheet: View, newState: Int) {
        when (newState) {
            BottomSheetBehavior.STATE_HIDDEN -> {
                onFinish()
            }

            BottomSheetBehavior.STATE_EXPANDED -> {
                dimmingBackgroundView.alpha = dimmingBackgroundAlpha
                setIsProgrammaticallyExpanding(false)
                bottomSheetBehavior.isDraggable = true
            }

            BottomSheetBehavior.STATE_HALF_EXPANDED -> {
                if (!isProgrammaticallyExpanding()) {
                    bottomSheet.post {
                        handleIntermediateState(bottomSheet = bottomSheet)
                    }
                }
            }
        }
    }

    override fun onSlide(bottomSheet: View, slideOffset: Float) {
        lastSlideOffset = slideOffset
        if (!slideOffset.isNaN()) {
            val normalized = (slideOffset + SLIDE_OFFSET_NORMALIZATION_OFFSET) / SLIDE_OFFSET_NORMALIZATION_DIVISOR
            dimmingBackgroundView.alpha = normalized * dimmingBackgroundAlpha
        }
    }

    private fun handleIntermediateState(bottomSheet: View) {
        if (bottomSheet.height <= 0) return

        val currentOffset = calculateSlideOffset(bottomSheet = bottomSheet)

        if (currentOffset < 0) return

        val targetState = if (currentOffset > SWIPE_THRESHOLD) {
            BottomSheetBehavior.STATE_EXPANDED
        } else {
            BottomSheetBehavior.STATE_HIDDEN
        }

        if (bottomSheetBehavior.state != targetState) {
            bottomSheetBehavior.state = targetState
        }
    }

    private fun calculateSlideOffset(bottomSheet: View): Float {
        val parent = bottomSheet.parent as? CoordinatorLayout ?: return lastSlideOffset
        val parentHeight = parent.height
        if (parentHeight <= 0) return -1f

        val bottom = bottomSheet.bottom
        val collapsedOffset = parentHeight - bottomSheetBehavior.peekHeight
        val expandedOffset = bottomSheetBehavior.expandedOffset

        if (collapsedOffset <= expandedOffset) return 0f

        val offset = (collapsedOffset - bottom).toFloat() / (collapsedOffset - expandedOffset)
        return offset.coerceIn(0f, 1f)
    }

    private companion object {
        const val SWIPE_THRESHOLD = 0.5f
        const val INITIAL_SLIDE_OFFSET = 1f
        const val SLIDE_OFFSET_NORMALIZATION_OFFSET = 1f
        const val SLIDE_OFFSET_NORMALIZATION_DIVISOR = 2f
    }
}

