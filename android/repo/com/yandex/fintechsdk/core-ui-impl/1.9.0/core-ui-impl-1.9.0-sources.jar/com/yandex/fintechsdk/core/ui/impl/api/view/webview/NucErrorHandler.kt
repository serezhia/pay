package com.yandex.fintechsdk.core.ui.impl.api.view.webview

import android.content.Context
import android.net.http.SslError
import ru.domesticroots.nuc.NucCTLogUrlProvider
import ru.domesticroots.nuc.NucCertificateProvider
import ru.domesticroots.webview.WebViewSslErrorHandler

public class NucErrorHandler(context: Context) {

    private val sslErrorHandler = WebViewSslErrorHandler.create(
        context.applicationContext,
        NucCertificateProvider(context.applicationContext),
        NucCTLogUrlProvider(),
    )

    public fun handleSslError(error: SslError, callback: Callback) {
        sslErrorHandler.handleSslError(
            error,
            object : WebViewSslErrorHandler.Callback {
                override fun onProceeded() {
                    callback.onProceed()
                }

                override fun onCanceled() {
                    callback.onCancelled()
                }
            },
        )
    }

    public interface Callback {
        public fun onProceed()
        public fun onCancelled()
    }
}
