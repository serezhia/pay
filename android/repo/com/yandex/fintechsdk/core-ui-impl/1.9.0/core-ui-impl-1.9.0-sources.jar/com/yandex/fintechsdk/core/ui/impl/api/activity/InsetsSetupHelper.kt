package com.yandex.fintechsdk.core.ui.impl.api.activity

import android.app.Activity
import android.content.Context
import android.view.View
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnAttach
import androidx.core.view.doOnDetach
import androidx.core.view.updatePadding
import androidx.fragment.app.FragmentManager
import androidx.navigation.fragment.NavHostFragment
import com.yandex.fintechsdk.core.utils.api.dpToPx

public class InsetsSetupHelper(
    private val config: InsetsConfig,
    private val containerView: View,
    private val navHostView: View,
    private val rootView: View,
) {
    private val containerInitialBottomPadding = containerView.paddingBottom

    /**
     * Set of views that have already been configured with insets.
     * Views are automatically removed via doOnDetach callback.
     */
    private val configuredViews = mutableSetOf<View>()

    /**
     * Runtime override for fullscreen mode. When true, disables custom top margin.
     */
    private var isFullscreenBottomSheetOverride: Boolean = false

    public fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { _, insets ->
            applyContainerPadding(insets = insets)
            insets
        }
    }

    public fun setupNavHostFragmentInsets(fragmentManager: FragmentManager) {
        (fragmentManager.findFragmentById(navHostView.id) as? NavHostFragment)
            ?.view
            ?.let { applyInsetsToNavHostViewSafe(view = it) }
    }

    public fun setupFragmentLifecycleCallbacks(fragmentManager: FragmentManager) {
        fragmentManager.registerFragmentLifecycleCallbacks(
            InsetsFragmentLifecycleCallbacks(
                applyInsetsToNavHostView = { view -> applyInsetsToNavHostViewSafe(view = view) },
                isBottomSheet = config.isBottomSheet
            ),
            true,
        )
    }

    /**
     * Sets up fullscreen mode for bottom sheet insets logic.
     * Disables custom top margin and re-dispatches insets to all configured views.
     */
    public fun setupFullscreenMode() {
        if (!config.isBottomSheet) return
        if (isFullscreenBottomSheetOverride) return

        isFullscreenBottomSheetOverride = true

        val activity = rootView.context as? Activity ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        // Reapply insets to all configured views (if any)
        configuredViews.toList().forEach { view ->
            if (!view.isAttachedToWindow) return@forEach

            view.post {
                if (!view.isAttachedToWindow) return@post

                val rootInsets = ViewCompat.getRootWindowInsets(view) ?: return@post
                ViewCompat.dispatchApplyWindowInsets(
                    view,
                    createModifiedInsets(context = view.context, insets = rootInsets),
                )
            }
        }
    }

    /**
     * Adds bottom padding to container when keyboard (IME) is shown.
     * Ensures content is not hidden behind the keyboard.
     */
    private fun applyContainerPadding(insets: WindowInsetsCompat) {
        val imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime())
        val navBarInsets = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
        val insetsBottom = calculateBottomInset(imeInsets = imeInsets, navBarInsets = navBarInsets)

        // Preserve initial padding from layout + add dynamic keyboard inset
        containerView.updatePadding(
            bottom = containerInitialBottomPadding + insetsBottom
        )
    }

    /**
     * Calculates bottom inset by subtracting navigation bar height from keyboard height.
     * Returns 0 if keyboard is not shown or doesn't extend beyond navigation bar.
     */
    private fun calculateBottomInset(imeInsets: Insets, navBarInsets: Insets): Int {
        // Subtract nav bar height since keyboard overlaps it
        return if (imeInsets.bottom > navBarInsets.bottom) {
            imeInsets.bottom - navBarInsets.bottom
        } else {
            NO_MARGIN
        }
    }

    /**
     * Applies insets to view only once. Prevents duplicate configuration.
     */
    private fun applyInsetsToNavHostViewSafe(view: View) {
        // Skip if already configured (idempotent operation)
        if (configuredViews.contains(view)) return

        configuredViews.add(view)
        applyInsetsToNavHostView(view = view)
    }

    /**
     * Configures view to handle window insets with custom top margin.
     * Sets up insets listener, cleanup on detach, and applies insets when view is ready.
     */
    private fun applyInsetsToNavHostView(view: View) {
        // Set up listener for future insets changes
        ViewCompat.setOnApplyWindowInsetsListener(view) { _, insets ->
            createModifiedInsets(context = view.context, insets = insets)
        }

        // Clean up when view is removed from hierarchy
        setupDetachCleanup(view = view)
        // Apply current insets immediately
        applyInsetsWhenReady(view = view)
    }

    private fun shouldModifyInsets(): Boolean {
        if (!config.isBottomSheet) return false
        
        // Fullscreen bottom sheet -> use original system insets
        val isFullscreen = config.isFullscreenBottomSheet || isFullscreenBottomSheetOverride
        if (isFullscreen) return false
        
        // Regular bottom sheet -> modify insets with custom margin
        return true
    }

    private fun setupDetachCleanup(view: View) {
        view.doOnDetach { detachedView ->
            // Remove from tracking when view is detached to prevent memory leaks
            configuredViews.remove(detachedView)
        }
    }

    private fun applyInsetsWhenReady(view: View) {
        if (view.isAttachedToWindow) {
            // View is already attached, apply immediately
            applyInsetsImmediately(view = view)
        } else {
            // Wait for view to attach before applying insets
            view.doOnAttach { attachedView ->
                applyInsetsImmediately(view = attachedView)
            }
        }
    }

    private fun applyInsetsImmediately(view: View) {
        // Post to message queue to ensure view is laid out
        view.post {
            // Double-check attachment (view might have been detached during post)
            if (!view.isAttachedToWindow) return@post

            try {
                val rootInsets = ViewCompat.getRootWindowInsets(view)

                if (rootInsets != null) {
                    // Apply modified insets (or original in fullscreen)
                    ViewCompat.dispatchApplyWindowInsets(
                        view,
                        createModifiedInsets(context = view.context, insets = rootInsets)
                    )
                } else {
                    // Fallback: request insets if not available yet
                    ViewCompat.requestApplyInsets(view)
                }
            } catch (e: IllegalStateException) {
                // Ignored: view was detached during async operation
            }
        }
    }

    /**
     * Creates modified insets with custom top margin (for bottom sheet mode).
     *
     * In bottom sheet mode (non-fullscreen):
     *   - Replaces systemBars.top and systemGestures.top with custom margin (16dp)
     *   - This creates consistent spacing from top for content
     *
     * In fullscreen mode:
     *   - Returns original insets unchanged
     *   - Content gets real system insets (status bar height, gesture areas, etc)
     *
     * Other inset types (ime, displayCutout, etc) are always preserved.
     */
    private fun createModifiedInsets(
        context: Context,
        insets: WindowInsetsCompat,
    ): WindowInsetsCompat {
        if (!shouldModifyInsets()) {
            return insets
        }

        // Bottom sheet non-fullscreen mode - apply custom top margin
        val customTopMarginPx = config.bottomSheetTopMarginDp.dpToPx(context).toInt()

        val systemBarsInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        val systemGesturesInsets = insets.getInsets(WindowInsetsCompat.Type.systemGestures())

        return WindowInsetsCompat.Builder(insets)
            .setInsets(
                WindowInsetsCompat.Type.systemBars(),
                Insets.of(
                    systemBarsInsets.left,
                    customTopMarginPx,
                    systemBarsInsets.right,
                    systemBarsInsets.bottom,
                ),
            )
            .setInsets(
                WindowInsetsCompat.Type.systemGestures(),
                Insets.of(
                    systemGesturesInsets.left,
                    customTopMarginPx,
                    systemGesturesInsets.right,
                    systemGesturesInsets.bottom,
                ),
            )
            .build()
    }

    private companion object {
        const val NO_MARGIN = 0
    }
}
