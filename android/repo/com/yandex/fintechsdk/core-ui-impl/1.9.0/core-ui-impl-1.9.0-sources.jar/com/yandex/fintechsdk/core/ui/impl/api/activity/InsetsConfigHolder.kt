package com.yandex.fintechsdk.core.ui.impl.api.activity

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Reactive holder for InsetsConfig that allows dynamic updates.
 * Used to propagate fullscreen mode changes to all consumers (e.g., overlay controllers).
 */
public class InsetsConfigHolder(
    initialConfig: InsetsConfig,
) {
    private val _config: MutableStateFlow<InsetsConfig> = MutableStateFlow(initialConfig)
    public val config: StateFlow<InsetsConfig> = _config.asStateFlow()

    /**
     * Updates the configuration and notifies all observers.
     */
    public fun update(newConfig: InsetsConfig) {
        _config.value = newConfig
    }
}
