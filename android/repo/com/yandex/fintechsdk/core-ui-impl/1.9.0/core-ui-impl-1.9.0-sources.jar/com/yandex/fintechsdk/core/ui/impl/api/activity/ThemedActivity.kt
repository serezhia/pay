package com.yandex.fintechsdk.core.ui.impl.api.activity

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.yandex.fintechsdk.entities.theme.Theme

/**
 * Base Activity with support for forcing a specific theme (day/night).
 *
 * Override [getThemeOverride] to set a theme different from the system theme.
 * The theme will be applied automatically before the Activity is created.
 */
public abstract class ThemedActivity : AppCompatActivity() {

    /**
     * Returns the theme to be applied to the Activity.
     *
     * @return [Theme] to force a specific theme, or null to use the system theme
     */
    protected abstract fun getThemeOverride(context: Context): Theme?

    override fun attachBaseContext(newBase: Context) {
        getThemeOverride(context = newBase)?.let { theme ->
            delegate.localNightMode = if (theme == Theme.NIGHT) {
                AppCompatDelegate.MODE_NIGHT_YES
            } else {
                AppCompatDelegate.MODE_NIGHT_NO
            }
        }
        super.attachBaseContext(newBase)
    }
}
