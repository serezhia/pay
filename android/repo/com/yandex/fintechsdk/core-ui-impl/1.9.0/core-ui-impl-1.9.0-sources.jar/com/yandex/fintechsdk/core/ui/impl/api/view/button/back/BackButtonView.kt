package com.yandex.fintechsdk.core.ui.impl.api.view.button.back

import android.animation.AnimatorInflater
import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.annotation.AttrRes
import androidx.annotation.StyleRes
import com.yandex.fintechsdk.core.ui.impl.api.extensions.dpToPx
import com.yandex.fintechsdk.resources.api.ResAnimator
import com.yandex.fintechsdk.resources.api.ResDrawable
import com.yandex.fintechsdk.resources.api.ResStrings

public class BackButtonView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    @AttrRes defStyleAttr: Int = 0,
    @StyleRes defStyleRes: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr, defStyleRes) {

    private val backButtonImage = ImageView(context)

    init {
        val imagePadding = PADDING_DP.dpToPx
        val fullSize = FULL_SIZE_DP.dpToPx
        backButtonImage.layoutParams = LayoutParams(fullSize, fullSize)
        backButtonImage.setPadding(imagePadding, imagePadding, imagePadding, imagePadding)
        backButtonImage.stateListAnimator = AnimatorInflater.loadStateListAnimator(context, ResAnimator.finsdk_button_resize)
        backButtonImage.isClickable = true
        backButtonImage.isFocusable = true
        backButtonImage.setBackgroundColor(context.getColor(android.R.color.transparent))
        backButtonImage.setImageResource(ResDrawable.finsdk_ic_arrow_left)
        backButtonImage.contentDescription = context.getString(ResStrings.finsdk_back)
        addView(backButtonImage)
    }

    override fun setClickable(clickable: Boolean) {
        super.setClickable(clickable)
        backButtonImage.isClickable = clickable
    }

    override fun setFocusable(focusable: Boolean) {
        super.setFocusable(focusable)
        backButtonImage.isFocusable = focusable
    }

    override fun setOnClickListener(l: OnClickListener?) {
        super.setOnClickListener(l)
        backButtonImage.setOnClickListener(l)
    }

    private companion object {
        const val PADDING_DP = 8
        const val FULL_SIZE_DP = 40
    }
}
