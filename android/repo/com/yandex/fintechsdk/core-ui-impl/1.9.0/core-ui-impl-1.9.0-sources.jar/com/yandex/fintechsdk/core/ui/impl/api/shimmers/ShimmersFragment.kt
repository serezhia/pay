package com.yandex.fintechsdk.core.ui.impl.api.shimmers

import android.animation.ObjectAnimator
import android.graphics.Outline
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import androidx.annotation.IdRes
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.LifecycleOwner
import com.yandex.fintechsdk.core.ui.impl.R
import com.yandex.fintechsdk.core.ui.impl.api.view.button.back.BackButtonView
import com.yandex.fintechsdk.resources.api.ResAnim
import com.yandex.fintechsdk.resources.api.ResColor

public class ShimmersFragment : Fragment() {

    @Suppress("DEPRECATION")
    private val shimmersLayoutIdentifiers: ShimmersLayoutIdentifiers
        get() {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                arguments?.getParcelable(
                    SHIMMERS_FRAGMENT_LAYOUT_IDS_KEY,
                    ShimmersLayoutIdentifiers::class.java,
                )
            } else {
                arguments?.getParcelable(SHIMMERS_FRAGMENT_LAYOUT_IDS_KEY)
            } ?: DEFAULT_SHIMMERS_LAYOUT_IDS
        }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        val layoutId = shimmersLayoutIdentifiers.contentId
        return inflater.inflate(layoutId, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initBackButton()
        initBottomBar()

        if (shimmersLayoutIdentifiers.contentId == DEFAULT_SHIMMERS_LAYOUT_IDS.contentId) {
            initDefaultLoading()
        }
    }

    private fun initBottomBar() {
        val bottomBarId = shimmersLayoutIdentifiers.bottomBarId ?: return
        val bottomBar = view?.findViewById<LinearLayout>(bottomBarId) ?: return
        with(bottomBar) {
            elevation = ELEVATION
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                outlineSpotShadowColor = resources.getColor(ResColor.finsdk_border_icon, null)
                outlineAmbientShadowColor = resources.getColor(ResColor.finsdk_border_icon, null)
            }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(
                        0,
                        SHADOW_HEIGHT,
                        view.width,
                        view.height,
                        SHADOW_RADIUS
                    )
                }
            }
        }
    }

    private fun initBackButton() {
        val backButton = view?.findViewById<BackButtonView>(shimmersLayoutIdentifiers.backbuttonId) ?: return
        backButton.setOnClickListener {
            parentFragmentManager.setFragmentResult(SHIMMERS_FRAGMENT_RESULT_ID, bundleOf())
        }
    }

    private fun initDefaultLoading() {
        val loadingCircle = view?.findViewById<View>(R.id.finsdkLoadingCircle) ?: return
        ObjectAnimator.ofFloat(loadingCircle, ROTATION_NAME, ROTATION_VALUE_START, ROTATION_VALUE_END).also {
            it.repeatCount = ObjectAnimator.INFINITE
            it.duration = ROTATION_DURATION
            it.interpolator = LinearInterpolator()
            it.start()
        }
    }

    public companion object {

        public fun addShimmers(
            fragmentManager: FragmentManager,
            @IdRes containerId: Int,
            shimmersLayoutProvider: ShimmersLayoutProvider,
        ) {
            if (fragmentManager.findFragmentByTag(SHIMMERS_FRAGMENT_TAG) != null) {
                return
            }
            val shimmersLayoutIdentifiers = shimmersLayoutProvider.getLayoutIdentifiers()
            val fragment = ShimmersFragment().apply {
                arguments = Bundle().apply { putParcelable(SHIMMERS_FRAGMENT_LAYOUT_IDS_KEY, shimmersLayoutIdentifiers) }
            }
            fragmentManager.beginTransaction().apply {
                setCustomAnimations(
                    /* enter = */ ResAnim.finsdk_fade_in,
                    /* exit = */ ResAnim.finsdk_fade_out,
                )
                replace(containerId, fragment, SHIMMERS_FRAGMENT_TAG)
                commit()
            }
        }

        public fun removeShimmers(fragmentManager: FragmentManager) {
            val fragment = fragmentManager.findFragmentByTag(SHIMMERS_FRAGMENT_TAG) ?: return
            fragmentManager.beginTransaction().apply {
                remove(fragment)
                commit()
            }
        }

        public fun subscribeOnBackButton(fragmentManager: FragmentManager, lifecycleOwner: LifecycleOwner, callback: () -> Unit) {
            fragmentManager.setFragmentResultListener(SHIMMERS_FRAGMENT_RESULT_ID, lifecycleOwner) { _, _ ->
                callback.invoke()
            }
        }

        private const val SHIMMERS_FRAGMENT_TAG = "shimmers_fragment_tag"
        private const val SHIMMERS_FRAGMENT_RESULT_ID = "shimmers_fragment_result_id"
        private const val SHIMMERS_FRAGMENT_LAYOUT_IDS_KEY = "shimmers_fragment_layout_ids"
        private const val ROTATION_NAME = "rotation"

        private const val ELEVATION = 80f
        private const val SHADOW_HEIGHT = -30
        private const val SHADOW_RADIUS = 70f

        private const val ROTATION_VALUE_START = 0F
        private const val ROTATION_VALUE_END = 360F
        private const val ROTATION_DURATION = 1000L

        private val DEFAULT_SHIMMERS_LAYOUT_IDS = ShimmersLayoutIdentifiers(
            backbuttonId = R.id.finsdkBackButton,
            bottomBarId = null,
            contentId = R.layout.finsdk_fragment_shimmers_default,
        )
    }
}
