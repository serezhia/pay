package com.yandex.fintechsdk.core.ui.impl.api.bottomsheet

import android.app.Activity
import android.graphics.Color
import android.graphics.Outline
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.yandex.fintechsdk.entities.theme.Theme

/**
 * Helper class for setting up bottom sheet behavior, appearance, and callbacks.
 *
 * @param activity Activity instance
 * @param containerView The main container view that has BottomSheetBehavior attached
 * @param decorationContainerId Resource ID of the decoration container view
 * @param decorationDrawableId Resource ID of the decoration drawable
 * @param dimmingBackgroundView View used for dimming background effect
 * @param onFinish Callback to be called when bottom sheet should be finished
 * @param rootView Root view for finding decoration container
 * @param theme Current theme (DAY or NIGHT)
 * @param onStatusBarHeightChanged Optional callback for custom behavior when status bar height changes
 */
public class BottomSheetSetupHelper(
    private val activity: Activity,
    private val containerView: View,
    private val decorationContainerId: Int,
    private val decorationDrawableId: Int,
    private val dimmingBackgroundView: View,
    private val onFinish: () -> Unit,
    private val rootView: View,
    private val theme: Theme,
    /**
     * Optional callback for clients that need to react to effective status bar height changes.
     * In fullscreen mode, [0] will be emitted.
     */
    private val onStatusBarHeightChanged: ((Int) -> Unit)? = null,
) {
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<*>
    private var customBottomSheetBehavior: CustomBottomSheetBehavior<*>? = null
    private var isProgrammaticallyExpanding = true
    private val closeController = BottomSheetCloseController(defaultOnFinish = onFinish)
    private var isFullscreenMode = false

    public fun setup() {
        setupBottomSheetBehavior()
        setupLayoutObserver()
    }

    /**
     * Sets up fullscreen mode for the bottom sheet.
     *
     * Sheet becomes edge-to-edge, decor/rounded corners are removed,
     * expandedOffset becomes 0 and [CustomBottomSheetBehavior] is synced.
     */
    public fun setupFullscreenMode() {
        if (isFullscreenMode) return
        if (!::bottomSheetBehavior.isInitialized) return

        isFullscreenMode = true

        // Re-apply dimensions with fullscreen mode
        setupBottomSheetDimensions()
    }

    public fun hideWithAnimation(onHidden: () -> Unit) {
        if (!::bottomSheetBehavior.isInitialized) {
            onHidden()
            return
        }

        if (bottomSheetBehavior.state == BottomSheetBehavior.STATE_HIDDEN) {
            closeController.requestClose(onHidden = onHidden)
            closeController.onHidden()
            return
        }

        closeController.requestClose(onHidden = onHidden)
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_HIDDEN
    }

    private fun syncOffsetsAndExpand(effectiveStatusBarHeight: Int) {
        // In fullscreen mode, enable fullscreen behavior to prevent expandedOffset override in onApplyWindowInsets
        if (isFullscreenMode) {
            customBottomSheetBehavior?.setFullscreenMode()
        }

        customBottomSheetBehavior?.setStatusBarHeight(statusBarHeightPx = effectiveStatusBarHeight)
        onStatusBarHeightChanged?.invoke(effectiveStatusBarHeight)
        bottomSheetBehavior.expandedOffset = effectiveStatusBarHeight

        dimmingBackgroundView.alpha = DIMMING_BACKGROUND_ALPHA

        isProgrammaticallyExpanding = true
        if (bottomSheetBehavior.state != BottomSheetBehavior.STATE_EXPANDED) {
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
        }
        isProgrammaticallyExpanding = false
        containerView.requestLayout()
    }

    private fun setupBottomSheetBehavior() {
        val layoutParams = containerView.layoutParams as CoordinatorLayout.LayoutParams
        bottomSheetBehavior = layoutParams.behavior as BottomSheetBehavior
        customBottomSheetBehavior = bottomSheetBehavior as? CustomBottomSheetBehavior<*>

        bottomSheetBehavior.apply {
            isFitToContents = false
            skipCollapsed = true
            isDraggable = true
            isHideable = true
            peekHeight = PEEK_HEIGHT
            state = BottomSheetBehavior.STATE_HIDDEN
        }
    }

    private fun setupLayoutObserver() {
        containerView.viewTreeObserver.addOnGlobalLayoutListener(
            object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    containerView.viewTreeObserver.removeOnGlobalLayoutListener(this)

                    setupRoundedCorners()
                    setupDecorationHandle()
                    setupBottomSheetCallbacks()
                    setupBottomSheetDimensions()
                }
            }
        )
    }

    private fun setupBottomSheetCallbacks() {
        val callback = BottomSheetStateCallback(
            bottomSheetBehavior = bottomSheetBehavior,
            dimmingBackgroundAlpha = DIMMING_BACKGROUND_ALPHA,
            dimmingBackgroundView = dimmingBackgroundView,
            onFinish = { closeController.onHidden() },
            isProgrammaticallyExpanding = { isProgrammaticallyExpanding },
            setIsProgrammaticallyExpanding = { isProgrammaticallyExpanding = it },
        )
        bottomSheetBehavior.addBottomSheetCallback(callback)
    }

    private fun setupBottomSheetDimensions() {
        containerView.post {
            val effectiveStatusBarHeight = calculateEffectiveStatusBarHeight()
            val windowHeight = getWindowHeight()

            applyContainerLayoutParams(
                effectiveStatusBarHeight = effectiveStatusBarHeight,
                windowHeight = windowHeight,
            )
            syncOffsetsAndExpand(effectiveStatusBarHeight = effectiveStatusBarHeight)
            applyDecorAndOutline()
        }
    }

    private fun calculateEffectiveStatusBarHeight(): Int {
        return if (isFullscreenMode) 0 else getStatusBarHeight()
    }

    private fun getWindowHeight(): Int {
        return if (activity.window.decorView.height > 0) {
            activity.window.decorView.height
        } else {
            activity.windowManager.currentWindowMetrics.bounds.height()
        }
    }

    private fun applyContainerLayoutParams(effectiveStatusBarHeight: Int, windowHeight: Int) {
        val displayMetrics = activity.resources.displayMetrics
        val layoutParams = containerView.layoutParams as CoordinatorLayout.LayoutParams
        layoutParams.width = displayMetrics.widthPixels
        layoutParams.height = windowHeight - effectiveStatusBarHeight
        layoutParams.topMargin = 0
        layoutParams.bottomMargin = 0
        containerView.layoutParams = layoutParams
    }

    private fun applyDecorAndOutline() {
        if (isFullscreenMode) {
            clearRoundedCornersOutline()
            val decorationContainer = rootView.findViewById<FrameLayout>(decorationContainerId)
            decorationContainer?.visibility = View.GONE
        } else {
            val cornerRadius = CORNER_RADIUS_DP * activity.resources.displayMetrics.density
            setupRoundedCornersOutline(cornerRadius = cornerRadius)
        }
    }

    private fun setupRoundedCorners() {
        val backgroundColor = if (theme == Theme.DAY) Color.WHITE else Color.BLACK
        containerView.setBackgroundColor(backgroundColor)
        if (isFullscreenMode) {
            clearRoundedCornersOutline()
            return
        }

        val cornerRadius = CORNER_RADIUS_DP * activity.resources.displayMetrics.density
        setupRoundedCornersOutline(cornerRadius = cornerRadius)
    }

    private fun setupRoundedCornersOutline(cornerRadius: Float) {
        containerView.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                if (view.width > 0 && view.height > 0) {
                    outline.setRoundRect(0, 0, view.width, view.height, cornerRadius)
                }
            }
        }
        containerView.clipToOutline = true
    }

    private fun clearRoundedCornersOutline() {
        containerView.outlineProvider = null
        containerView.clipToOutline = false
    }

    private fun setupDecorationHandle() {
        val decorationContainer = rootView.findViewById<FrameLayout>(decorationContainerId) ?: return
        if (isFullscreenMode) {
            decorationContainer.removeAllViews()
            decorationContainer.visibility = View.GONE
            return
        }
        val density = activity.resources.displayMetrics.density
        val topMarginPx = (DECORATION_HANDLE_TOP_MARGIN_DP * density).toInt()
        val widthPx = (DECORATION_HANDLE_WIDTH_DP * density).toInt()
        val heightPx = (DECORATION_HANDLE_HEIGHT_DP * density).toInt()

        (decorationContainer.layoutParams as? FrameLayout.LayoutParams)?.topMargin = topMarginPx

        val decorationView = View(activity).apply {
            layoutParams = FrameLayout.LayoutParams(widthPx, heightPx, Gravity.CENTER_HORIZONTAL)
            setBackgroundResource(decorationDrawableId)
        }

        decorationContainer.removeAllViews()
        decorationContainer.addView(decorationView)
        decorationContainer.visibility = View.VISIBLE
    }

    private fun getStatusBarHeight(): Int {
        return ViewCompat.getRootWindowInsets(activity.window.decorView)
            ?.getInsets(WindowInsetsCompat.Type.statusBars())?.top ?: 0
    }

    private companion object {
        const val DIMMING_BACKGROUND_ALPHA = 0.5f
        const val CORNER_RADIUS_DP = 24f
        const val DECORATION_HANDLE_TOP_MARGIN_DP = 8
        const val DECORATION_HANDLE_WIDTH_DP = 40
        const val DECORATION_HANDLE_HEIGHT_DP = 4
        const val PEEK_HEIGHT = 0
    }
}
