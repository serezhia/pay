package com.yandex.fintechsdk.core.ui.impl.api.shimmers

/**
 * Interface for providing custom splash screen UI.
 * Implement this interface to customize the splash screen appearance.
 * If not provided, the default shimmer loading UI will be used.
 */
public interface ShimmersLayoutProvider {
    public fun getLayoutIdentifiers(): ShimmersLayoutIdentifiers
}
