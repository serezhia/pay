package com.yandex.fintechsdk.core.ui.impl.api.bottomsheet

internal class BottomSheetCloseController(
    private val defaultOnFinish: () -> Unit,
) {
    private var pendingOnFinish: (() -> Unit)? = null

    fun requestClose(onHidden: () -> Unit) {
        pendingOnFinish = onHidden
    }

    fun onHidden() {
        val callback = pendingOnFinish ?: defaultOnFinish
        pendingOnFinish = null
        callback()
    }
}

