package com.yandex.fintechsdk.core.ui.impl.api.extensions

import android.content.res.Resources
import android.util.TypedValue

public val Number.dpToPx: Int
    get() = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        this.toFloat(),
        Resources.getSystem().displayMetrics
    ).toInt()
