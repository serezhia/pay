package com.yandex.fintechsdk.core.ui.impl.api.activity

import com.yandex.fintechsdk.entities.ui.BottomSheetMode

/**
 * Configuration for window insets setup.
 * Groups related parameters to avoid conflicts in DI graph.
 *
 * @param bottomSheetMode Display mode for bottom sheet
 * @param bottomSheetTopMarginDp Top margin for bottom sheet mode in dp (default: 16f)
 */
public class InsetsConfig(
    public val bottomSheetMode: BottomSheetMode = BottomSheetMode.DISABLED,
    public val bottomSheetTopMarginDp: Float = DEFAULT_BOTTOM_SHEET_TOP_MARGIN_DP,
) {
    /** Whether the activity is in bottom sheet mode (regular or fullscreen) */
    public val isBottomSheet: Boolean get() = bottomSheetMode != BottomSheetMode.DISABLED

    /** Whether the bottom sheet is in fullscreen mode (no custom top margin) */
    public val isFullscreenBottomSheet: Boolean get() = bottomSheetMode == BottomSheetMode.FULLSCREEN

    public companion object {
        /**
         * Default top margin for bottom sheet mode in dp.
         */
        public const val DEFAULT_BOTTOM_SHEET_TOP_MARGIN_DP: Float = 16f
    }
}

