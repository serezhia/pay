package com.yandex.fintechsdk.core.ui.impl.api.view.webview

public data class WebViewCookie(
    val url: String,
    val value: String,
)
