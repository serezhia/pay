package com.yandex.fintechsdk.core.ui.impl.api.error

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.yandex.fintechsdk.core.bdui.api.error.ErrorViewFactory
import com.yandex.fintechsdk.core.bdui.api.error.FlexErrorViewBinding
import com.yandex.fintechsdk.core.ui.impl.R

public class DefaultErrorViewFactoryImpl : ErrorViewFactory {
    override fun createErrorViewBinding(container: ViewGroup): FlexErrorViewBinding? {
        val view = LayoutInflater.from(container.context)
            .inflate(R.layout.finsdk_error_view_default, container, false)

        return object : FlexErrorViewBinding {
            override val root: ViewGroup = view as ViewGroup
            override val closeButton: View? = view.findViewById(R.id.finsdkCloseButton)
            override val retryButton: View? = view.findViewById(R.id.finsdkTryAgainButton)
        }
    }
}
