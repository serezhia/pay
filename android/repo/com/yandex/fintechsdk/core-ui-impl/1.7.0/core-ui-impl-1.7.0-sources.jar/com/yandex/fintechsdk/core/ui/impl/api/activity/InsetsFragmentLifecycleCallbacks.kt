package com.yandex.fintechsdk.core.ui.impl.api.activity

import android.os.Bundle
import android.view.View
import androidx.core.view.ViewCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.navigation.fragment.NavHostFragment

/**
 * Fragment lifecycle callbacks for handling window insets in fragments.
 */
public class InsetsFragmentLifecycleCallbacks(
    private val isBottomSheet: Boolean,
    private val applyInsetsToNavHostView: (View) -> Unit,
) : FragmentManager.FragmentLifecycleCallbacks() {

    override fun onFragmentViewCreated(
        fm: FragmentManager,
        fragment: Fragment,
        v: View,
        savedInstanceState: Bundle?,
    ) {
        super.onFragmentViewCreated(fm, fragment, v, savedInstanceState)

        v.post {
            if (isBottomSheet && fragment is NavHostFragment) {
                fragment.view?.let { view -> applyInsetsToNavHostView(view) }
            } else {
                ViewCompat.requestApplyInsets(v)
            }
        }
    }
}

