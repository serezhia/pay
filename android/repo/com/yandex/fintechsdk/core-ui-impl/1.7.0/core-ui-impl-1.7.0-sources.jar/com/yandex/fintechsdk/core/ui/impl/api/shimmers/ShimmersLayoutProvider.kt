package com.yandex.fintechsdk.core.ui.impl.api.shimmers

import androidx.annotation.LayoutRes

/**
 * Interface for providing custom splash screen UI.
 * Implement this interface to customize the splash screen appearance.
 * If not provided, the default shimmer loading UI will be used.
 */
public interface ShimmersLayoutProvider {
    @LayoutRes public fun getBackbuttonId(): Int
    @LayoutRes public fun getContentId(): Int
    @LayoutRes public fun getBottomBarId(): Int?
}
