package com.yandex.fintechsdk.core.ui.impl.api.activity

/**
 * Configuration for window insets setup.
 * Groups related parameters to avoid conflicts in DI graph.
 *
 * @param isBottomSheet Whether the activity is in bottom sheet mode
 * @param bottomSheetTopMarginDp Top margin for bottom sheet mode in dp (default: 16f)
 */
public data class InsetsConfig(
    val isBottomSheet: Boolean,
    val bottomSheetTopMarginDp: Float = DEFAULT_BOTTOM_SHEET_TOP_MARGIN_DP,
) {
    public companion object {
        /**
         * Default top margin for bottom sheet mode in dp.
         */
        public const val DEFAULT_BOTTOM_SHEET_TOP_MARGIN_DP: Float = 16f
    }
}

