package com.yandex.fintechsdk.core.ui.impl.api.activity

import android.graphics.Color
import android.view.View
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.fragment.app.FragmentManager
import androidx.navigation.fragment.NavHostFragment
import com.yandex.fintechsdk.core.utils.api.dpToPx

/**
 * Helper class for setting up window insets in activities.
 * Provides reusable logic for handling insets in both regular and bottom sheet modes.
 */
public class InsetsSetupHelper(
    private val config: InsetsConfig,
    private val containerView: View,
    private val navHostView: View,
    private val rootView: View,
) {

    /**
     * Sets up window insets for the root view, handling IME and navigation bar insets.
     */
    public fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { _, insets ->
            val imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime())
            val navBarInsets = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
            val insetsBottom = if (imeInsets.bottom > navBarInsets.bottom) {
                imeInsets.bottom - navBarInsets.bottom
            } else {
                NO_MARGIN
            }

            containerView.updatePadding(bottom = insetsBottom)
            insets
        }
    }

    /**
     * Sets up insets for the NavHostFragment view.
     */
    public fun setupNavHostFragmentInsets(fragmentManager: FragmentManager) {
        val navHostFragment = fragmentManager.findFragmentById(navHostView.id) as? NavHostFragment
            ?: return

        navHostFragment.view?.let { view -> applyInsetsToNavHostView(view) }
            ?: navHostView.post {
                (fragmentManager.findFragmentById(navHostView.id) as? NavHostFragment)
                    ?.view?.let { view -> applyInsetsToNavHostView(view) }
            }
    }

    /**
     * Registers fragment lifecycle callbacks to handle insets for fragments.
     */
    public fun setupFragmentLifecycleCallbacks(fragmentManager: FragmentManager) {
        fragmentManager.registerFragmentLifecycleCallbacks(
            InsetsFragmentLifecycleCallbacks(
                isBottomSheet = config.isBottomSheet,
                applyInsetsToNavHostView = ::applyInsetsToNavHostView,
            ),
            true,
        )
    }

    private fun applyInsetsToNavHostView(view: View) {
        view.setBackgroundColor(Color.TRANSPARENT)

        val topMarginPx = if (config.isBottomSheet) {
            config.bottomSheetTopMarginDp.dpToPx(view.context).toInt()
        } else {
            NO_MARGIN
        }

        ViewCompat.setOnApplyWindowInsetsListener(view) { _, insets ->
            createModifiedInsets(insets, topMarginPx)
        }

        // Explicitly reapply insets after setting listener
        // This is critical for activity recreation scenarios
        view.post {
            ViewCompat.getRootWindowInsets(view)?.let { rootInsets ->
                ViewCompat.dispatchApplyWindowInsets(view, createModifiedInsets(rootInsets, topMarginPx))
            } ?: ViewCompat.requestApplyInsets(view)
        }
    }

    private fun createModifiedInsets(insets: WindowInsetsCompat, topMarginPx: Int): WindowInsetsCompat {
        val systemBarsInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        val systemGesturesInsets = insets.getInsets(WindowInsetsCompat.Type.systemGestures())
        val bottomPx = systemBarsInsets.bottom

        return WindowInsetsCompat.Builder()
            .setInsets(
                WindowInsetsCompat.Type.systemBars(),
                Insets.of(
                    systemBarsInsets.left,
                    topMarginPx,
                    systemBarsInsets.right,
                    bottomPx,
                ),
            )
            .setInsets(
                WindowInsetsCompat.Type.systemGestures(),
                Insets.of(
                    systemGesturesInsets.left,
                    topMarginPx,
                    systemGesturesInsets.right,
                    bottomPx,
                ),
            )
            .setInsets(
                WindowInsetsCompat.Type.ime(),
                insets.getInsets(WindowInsetsCompat.Type.ime()),
            )
            .setInsets(
                WindowInsetsCompat.Type.displayCutout(),
                insets.getInsets(WindowInsetsCompat.Type.displayCutout()),
            )
            .build()
    }

    private companion object {
        /**
         * No margin value (0 - no margin).
         */
        const val NO_MARGIN = 0
    }
}

