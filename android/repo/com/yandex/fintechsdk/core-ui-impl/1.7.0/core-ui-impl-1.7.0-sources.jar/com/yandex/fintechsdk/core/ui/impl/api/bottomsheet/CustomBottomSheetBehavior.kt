package com.yandex.fintechsdk.core.ui.impl.api.bottomsheet

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.NestedScrollView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.yandex.fintechsdk.core.ui.impl.api.extensions.dpToPx

public class CustomBottomSheetBehavior<V : View> : BottomSheetBehavior<V> {
    private var dragZoneHeightPx: Float = 0f
    private var statusBarHeightPx: Int = 0
    private var touchState: TouchState = TouchState.Idle

    public constructor() : super()

    public constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        dragZoneHeightPx = 60f.dpToPx.toFloat()
    }

    public fun setDragZoneHeightDp(heightDp: Float) {
        dragZoneHeightPx = heightDp.dpToPx.toFloat()
    }

    public fun setStatusBarHeight(heightPx: Int) {
        statusBarHeightPx = heightPx
    }

    override fun onInterceptTouchEvent(
        parent: CoordinatorLayout,
        child: V,
        event: MotionEvent,
    ): Boolean {
        if (child.height <= 0) return false

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                handleActionDown(child, event)
            }

            MotionEvent.ACTION_MOVE -> {
                if (!touchState.isInDragZone) return false
                if (shouldAllowScrollableViewScroll(event)) return false
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touchState = TouchState.Idle
            }
        }

        return if (touchState.isInDragZone) {
            super.onInterceptTouchEvent(parent, child, event)
        } else {
            false
        }
    }

    override fun onTouchEvent(
        parent: CoordinatorLayout,
        child: V,
        event: MotionEvent,
    ): Boolean {
        if (!touchState.isInDragZone || touchState.viewUnderTouch.isScrollable()) {
            return false
        }
        return super.onTouchEvent(parent, child, event)
    }

    private fun handleActionDown(child: V, event: MotionEvent) {
        val dragZoneRange = statusBarHeightPx.toFloat()..(statusBarHeightPx + dragZoneHeightPx)
        val isInDragZone = event.y in dragZoneRange && event.y <= child.height

        touchState = TouchState(
            isInDragZone = isInDragZone,
            initialY = event.y,
            viewUnderTouch = if (isInDragZone) findViewUnderTouch(child, event.x, event.y) else null,
        )
    }

    private fun shouldAllowScrollableViewScroll(event: MotionEvent): Boolean {
        val view = touchState.viewUnderTouch ?: return false
        if (!view.isScrollable()) return false

        val deltaY = event.y - touchState.initialY
        val isSwipeDown = deltaY > 0

        return !isSwipeDown || view.canScrollVertically(-1)
    }

    private fun findViewUnderTouch(
        view: View,
        x: Float,
        y: Float,
    ): View? {
        if (!view.containsPoint(x, y)) return null

        if (view is ViewGroup) {
            for (i in view.childCount - 1 downTo 0) {
                val child = view.getChildAt(i)
                if (child.visibility != View.VISIBLE) continue

                val foundView = findViewUnderTouch(
                    child,
                    x - child.left,
                    y - child.top,
                )
                if (foundView != null) return foundView
            }
        }
        return view
    }

    override fun onApplyWindowInsets(
        parent: CoordinatorLayout,
        child: V,
        insets: WindowInsetsCompat,
    ): WindowInsetsCompat {
        val newStatusBarHeight = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top

        if (statusBarHeightPx != newStatusBarHeight) {
            statusBarHeightPx = newStatusBarHeight
            expandedOffset = newStatusBarHeight

            if (state == STATE_EXPANDED) {
                child.post { state = STATE_EXPANDED }
            }
        }

        return insets
    }

    private fun View?.isScrollable(): Boolean {
        return this is RecyclerView || this is NestedScrollView || this is android.widget.ScrollView
    }

    private fun View.containsPoint(x: Float, y: Float): Boolean {
        return x in 0f..width.toFloat() && y in 0f..height.toFloat()
    }

    private data class TouchState(
        val isInDragZone: Boolean = false,
        val initialY: Float = 0f,
        val viewUnderTouch: View? = null,
    ) {
        companion object {
            @SuppressLint("StaticFieldLeak")
            val Idle = TouchState()
        }
    }
}

