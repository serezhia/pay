package com.yandex.fintechsdk.core.ui.impl.api.shimmers

import android.graphics.Outline
import android.os.Bundle
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.LinearLayout
import androidx.annotation.IdRes
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.LifecycleOwner
import com.yandex.fintechsdk.core.ui.impl.api.view.button.back.BackButtonView
import com.yandex.fintechsdk.resources.api.ResAnim
import com.yandex.fintechsdk.resources.api.ResColor

public class ShimmersFragment(
    private val shimmersLayoutProvider: ShimmersLayoutProvider,
) : Fragment(
    shimmersLayoutProvider.getContentId()
) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        initBackButton()
        initBottomBar()
    }

    private fun initBottomBar() {
        val bottomBarId = shimmersLayoutProvider.getBottomBarId()
        if (bottomBarId == null) {
            return
        }
        val bottomBar = view?.findViewById<LinearLayout>(bottomBarId) ?: return
        with(bottomBar) {
            elevation = ELEVATION
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                outlineSpotShadowColor = resources.getColor(ResColor.finsdk_border_icon, null)
                outlineAmbientShadowColor = resources.getColor(ResColor.finsdk_border_icon, null)
            }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(
                        0,
                        SHADOW_HEIGHT,
                        view.width,
                        view.height,
                        SHADOW_RADIUS
                    )
                }
            }
        }
    }

    private fun initBackButton() {
        val backButton = view?.findViewById<BackButtonView>(shimmersLayoutProvider.getBackbuttonId()) ?: return
        backButton.setOnClickListener {
            parentFragmentManager.setFragmentResult(SHIMMERS_FRAGMENT_RESULT_ID, bundleOf())
        }
    }

    public companion object {

        public fun addShimmers(
            fragmentManager: FragmentManager,
            @IdRes containerId: Int,
            shimmersLayoutProvider: ShimmersLayoutProvider,
        ) {
            if (fragmentManager.findFragmentByTag(SHIMMERS_FRAGMENT_TAG) != null) {
                return
            }
            val fragment = ShimmersFragment(
                shimmersLayoutProvider = shimmersLayoutProvider,
            )
            fragmentManager.beginTransaction().apply {
                setCustomAnimations(
                    /* enter = */ ResAnim.finsdk_fade_in,
                    /* exit = */ ResAnim.finsdk_fade_out,
                )
                replace(containerId, fragment, SHIMMERS_FRAGMENT_TAG)
                commit()
            }
        }

        public fun removeShimmers(fragmentManager: FragmentManager) {
            val fragment = fragmentManager.findFragmentByTag(SHIMMERS_FRAGMENT_TAG) ?: return
            fragmentManager.beginTransaction().apply {
                remove(fragment)
                commit()
            }
        }

        public fun subscribeOnBackButton(fragmentManager: FragmentManager, lifecycleOwner: LifecycleOwner, callback: () -> Unit) {
            fragmentManager.setFragmentResultListener(SHIMMERS_FRAGMENT_RESULT_ID, lifecycleOwner) { _, _ ->
                callback.invoke()
            }
        }

        private const val SHIMMERS_FRAGMENT_TAG = "shimmers_fragment_tag"
        private const val SHIMMERS_FRAGMENT_RESULT_ID = "shimmers_fragment_result_id"

        private const val ELEVATION = 80f
        private const val SHADOW_HEIGHT = -30
        private const val SHADOW_RADIUS = 70f
    }
}
