package com.yandex.fintechsdk.core.divkit.api.action

/**
 * Delegate for handling custom DivKit actions
 */
public abstract class DivActionsDelegate {

    /**
     * Opens a new flex flow with the given parameters
     *
     * @param endpoint The endpoint path for the bottom sheet content
     * @param query Query parameters
     * @param headers HTTP headers
     */
    public abstract fun openFlexScreen(
        endpoint: String,
        query: Map<String, String>,
        headers: Map<String, String>,
    )

    /**
     * Triggers authorization flow
     */
    public open fun authorize() {}

    /**
     * Called when a remote action is triggered from DivKit
     *
     * @param path The endpoint path of the remote action
     */
    public open fun onRemoteAction(path: String) {}
}

