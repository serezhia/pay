package com.yandex.fintechsdk.core.divkit.api.action

/**
 * Executor for DivKit actions.
 * Allows executing actions by URL string directly through DivKit.
 */
public interface DivActionExecutor {

    /**
     * Execute a DivKit callback action.
     *
     * @param action The callback action to execute
     * @return true if action was handled, false otherwise
     */
    public fun executeAction(action: DivCallbackAction): Boolean
}

