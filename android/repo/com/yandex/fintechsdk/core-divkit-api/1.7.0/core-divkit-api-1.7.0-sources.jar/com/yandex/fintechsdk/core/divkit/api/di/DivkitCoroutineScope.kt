package com.yandex.fintechsdk.core.divkit.api.di

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.RUNTIME)
public annotation class DivkitCoroutineScope

