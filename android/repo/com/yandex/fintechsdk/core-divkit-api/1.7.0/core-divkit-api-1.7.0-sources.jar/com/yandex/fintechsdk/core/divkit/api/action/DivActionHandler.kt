package com.yandex.fintechsdk.core.divkit.api.action

/**
 * Handler for custom DivKit actions
 */
public interface DivActionHandler {
    /**
     * Action type identifier
     */
    public val actionType: String

    /**
     * Handle the action
     *
     * @param divAction Action data with payload
     * @param actionExecutor Executor for executing nested DivKit actions
     */
    public fun handle(divAction: DivAction, actionExecutor: DivActionExecutor)
}

