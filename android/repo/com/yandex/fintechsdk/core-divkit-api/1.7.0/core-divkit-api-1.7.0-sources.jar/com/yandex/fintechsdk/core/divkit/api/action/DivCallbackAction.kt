package com.yandex.fintechsdk.core.divkit.api.action

/**
 * Represents a callback action with URL and optional payload.
 * Used for on_success/on_fail callbacks in remote actions and list actions.
 */
public data class DivCallbackAction(
    val logId: String,
    val url: String,
    val payload: Map<String, Any?>? = null,
) {

    public companion object {

        /**
         * Extract a callback action from a payload map by key.
         *
         * @param payload The parent payload map
         * @param key The key to look up in the payload
         * @return CallbackAction if found and valid, null otherwise
         */
        public fun fromPayload(payload: Map<String, Any?>, key: String): DivCallbackAction? {
            @Suppress("UNCHECKED_CAST")
            val actionMap = payload[key] as? Map<String, Any?> ?: return null
            return fromMap(actionMap = actionMap)
        }

        /**
         * Extract a callback action from a map.
         * Values are expected to be wrapped in {"value": ...} objects.
         *
         * @param actionMap The action map containing log_id, url, and optional payload
         * @return CallbackAction if valid, null otherwise
         */
        public fun fromMap(actionMap: Map<String, Any?>): DivCallbackAction? {
            val url = getNestedValue<String>(actionMap, KEY_URL) ?: return null
            val logId = getNestedValue<String>(actionMap, KEY_LOG_ID) ?: ""

            @Suppress("UNCHECKED_CAST")
            val actionPayload = getNestedValue<Map<String, Any?>>(actionMap, KEY_PAYLOAD)

            return DivCallbackAction(logId = logId, url = url, payload = actionPayload)
        }

        /**
         * Extract nested value from a wrapper object.
         * Supports two formats:
         * - {"key": {"value": "..."}} (on_success/on_fail callbacks)
         * - {"key": {"key": "..."}} (list_action items)
         */
        @Suppress("UNCHECKED_CAST")
        private inline fun <reified T> getNestedValue(map: Map<String, Any?>, key: String): T? {
            val valueDict = map[key] as? Map<String, Any?> ?: return null
            return (valueDict[KEY_VALUE] ?: valueDict[key]) as? T
        }

        /**
         * Extract a list of callback actions from a payload map by key.
         *
         * @param payload The parent payload map
         * @param key The key to look up in the payload
         * @return List of CallbackActions if found, null otherwise
         */
        public fun listFromPayload(payload: Map<String, Any?>, key: String): List<DivCallbackAction>? {
            @Suppress("UNCHECKED_CAST")
            val actionsList = payload[key] as? List<Map<String, Any?>> ?: return null
            return actionsList.mapNotNull { actionMap -> fromMap(actionMap = actionMap) }
        }

        private const val KEY_LOG_ID = "log_id"
        private const val KEY_PAYLOAD = "payload"
        private const val KEY_URL = "url"
        private const val KEY_VALUE = "value"
    }
}

