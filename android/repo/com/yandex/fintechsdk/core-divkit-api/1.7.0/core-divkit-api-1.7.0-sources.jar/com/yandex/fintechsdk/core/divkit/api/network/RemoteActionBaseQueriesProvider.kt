package com.yandex.fintechsdk.core.divkit.api.network

public interface RemoteActionBaseQueriesProvider {

    public fun getBaseQueries(): Map<String, String>
}

