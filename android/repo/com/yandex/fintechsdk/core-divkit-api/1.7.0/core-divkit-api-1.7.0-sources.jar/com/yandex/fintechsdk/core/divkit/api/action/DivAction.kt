package com.yandex.fintechsdk.core.divkit.api.action

/**
 * Represents a DivKit action with payload
 */
public data class DivAction(
    val payload: Map<String, Any?>,
    val type: String,
)

