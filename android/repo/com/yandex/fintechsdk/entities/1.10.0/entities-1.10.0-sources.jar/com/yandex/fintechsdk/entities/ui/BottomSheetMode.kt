package com.yandex.fintechsdk.entities.ui

/**
 * Bottom sheet display mode.
 */
public enum class BottomSheetMode {
    /** Not a bottom sheet (regular fullscreen activity) */
    DISABLED,

    /** Bottom sheet with custom top margin and decoration */
    REGULAR,

    /** Bottom sheet in fullscreen (edge-to-edge, no custom top margin) */
    FULLSCREEN
}
