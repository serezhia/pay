package com.yandex.fintechsdk.entities.environment

public enum class DefaultEnvironment {
    TESTING,
    PRODUCTION,
}
