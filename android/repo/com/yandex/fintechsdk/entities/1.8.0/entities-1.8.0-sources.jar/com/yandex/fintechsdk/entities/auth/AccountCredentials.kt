package com.yandex.fintechsdk.entities.auth

public class AccountCredentials(
    public val uid: Long,
    public val token: String,
)
