package com.yandex.fintechsdk.entities.config.payment.applink

public class ApplinkPaymentConfig(
    public val isBugAvailable: Boolean,
    public val isWebviewForced: Boolean,
)
