package com.yandex.fintechsdk.entities.card

public class PayCard(
    public val trustId: String,
)
