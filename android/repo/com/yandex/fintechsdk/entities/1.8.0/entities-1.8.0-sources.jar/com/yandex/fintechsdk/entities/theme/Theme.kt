package com.yandex.fintechsdk.entities.theme

public enum class Theme(public val key: String) {
    DAY("DAY"),
    NIGHT("NIGHT"),
}
