package com.yandex.fintechsdk.entities.card

public class BinInfo(
    public val paymentSystem: String,
    public val withoutCvn: Boolean,
)
