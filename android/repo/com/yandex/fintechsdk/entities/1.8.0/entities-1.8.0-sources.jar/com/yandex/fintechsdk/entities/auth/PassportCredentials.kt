package com.yandex.fintechsdk.entities.auth

public data class PassportCredentials(
    val clientId: String,
    val secretId: String,
)
