package com.yandex.fintechsdk.entities.environment

public enum class PayEnvironment {
    TESTING,
    SANDBOX,
    PRODUCTION,
}
