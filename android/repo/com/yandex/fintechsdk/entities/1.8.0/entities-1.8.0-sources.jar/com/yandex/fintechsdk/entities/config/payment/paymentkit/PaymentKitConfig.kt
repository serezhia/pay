package com.yandex.fintechsdk.entities.config.payment.paymentkit

/**
 * Represents configuration for a Payment flow.
 *
 * @property expBoxes Experimental group id's used for analytics.
 * @property flags A map of flag keys to their string-encoded values. These values can represent
 *                 various types such as string, boolean, integer, double, List<T>, Map<Key, Value>,
 *                 or custom serializable classes.
 * @property status The status of the configuration.
 */
public data class PaymentKitConfig(
    val expBoxes: String,
    val flags: Map<String, String>,
    val status: String,
)
