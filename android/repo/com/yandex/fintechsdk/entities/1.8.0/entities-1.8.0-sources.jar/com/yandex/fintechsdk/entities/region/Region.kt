package com.yandex.fintechsdk.entities.region

public enum class Region(public val key: String) {
    RU("ru"),
    UZ("uz"),
}
