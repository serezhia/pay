package com.yandex.fintechsdk.entities.order

public class OrderMetaInfo(
    public val longUrl: String,
    public val merchantId: String,
    public val orderToken: String,
)
