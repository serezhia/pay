package com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers.metrica;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class MetricaDeviceIdProvider_Factory implements Factory<MetricaDeviceIdProvider> {
  private final Provider<Context> contextProvider;

  private MetricaDeviceIdProvider_Factory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public MetricaDeviceIdProvider get() {
    return newInstance(contextProvider.get());
  }

  public static MetricaDeviceIdProvider_Factory create(Provider<Context> contextProvider) {
    return new MetricaDeviceIdProvider_Factory(contextProvider);
  }

  public static MetricaDeviceIdProvider newInstance(Context context) {
    return new MetricaDeviceIdProvider(context);
  }
}
