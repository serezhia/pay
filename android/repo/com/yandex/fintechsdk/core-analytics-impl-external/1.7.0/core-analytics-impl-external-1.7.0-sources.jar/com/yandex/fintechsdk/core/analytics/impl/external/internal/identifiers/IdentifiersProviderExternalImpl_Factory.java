package com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers;

import com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers.metrica.MetricaDeviceIdProvider;
import com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers.metrica.MetricaUuidProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class IdentifiersProviderExternalImpl_Factory implements Factory<IdentifiersProviderExternalImpl> {
  private final Provider<MetricaDeviceIdProvider> metricaDeviceIdProvider;

  private final Provider<MetricaUuidProvider> metricaUuidProvider;

  private IdentifiersProviderExternalImpl_Factory(
      Provider<MetricaDeviceIdProvider> metricaDeviceIdProvider,
      Provider<MetricaUuidProvider> metricaUuidProvider) {
    this.metricaDeviceIdProvider = metricaDeviceIdProvider;
    this.metricaUuidProvider = metricaUuidProvider;
  }

  @Override
  public IdentifiersProviderExternalImpl get() {
    return newInstance(metricaDeviceIdProvider.get(), metricaUuidProvider.get());
  }

  public static IdentifiersProviderExternalImpl_Factory create(
      Provider<MetricaDeviceIdProvider> metricaDeviceIdProvider,
      Provider<MetricaUuidProvider> metricaUuidProvider) {
    return new IdentifiersProviderExternalImpl_Factory(metricaDeviceIdProvider, metricaUuidProvider);
  }

  public static IdentifiersProviderExternalImpl newInstance(
      MetricaDeviceIdProvider metricaDeviceIdProvider, MetricaUuidProvider metricaUuidProvider) {
    return new IdentifiersProviderExternalImpl(metricaDeviceIdProvider, metricaUuidProvider);
  }
}
