package com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers.metrica;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class MetricaUuidProvider_Factory implements Factory<MetricaUuidProvider> {
  private final Provider<Context> contextProvider;

  private MetricaUuidProvider_Factory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public MetricaUuidProvider get() {
    return newInstance(contextProvider.get());
  }

  public static MetricaUuidProvider_Factory create(Provider<Context> contextProvider) {
    return new MetricaUuidProvider_Factory(contextProvider);
  }

  public static MetricaUuidProvider newInstance(Context context) {
    return new MetricaUuidProvider(context);
  }
}
