package com.yandex.fintechsdk.core.analytics.impl.external.api.appmetrica

public interface AppMetricaApiKeyProvider {
    public fun getApiKey(): String
}

