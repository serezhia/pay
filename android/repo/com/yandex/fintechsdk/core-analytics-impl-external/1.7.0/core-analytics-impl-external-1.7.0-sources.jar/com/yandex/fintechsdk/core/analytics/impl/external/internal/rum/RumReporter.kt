package com.yandex.fintechsdk.core.analytics.impl.external.internal.rum

import com.yandex.fintechsdk.core.analytics.api.event.Event
import com.yandex.fintechsdk.core.analytics.impl.external.BuildConfig
import com.yandex.fintechsdk.core.analytics.impl.external.api.rum.RumConfiguration
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal class RumReporter(
    private val rumConfiguration: RumConfiguration,
) {

    private val client = OkHttpClient.Builder().build()
    private val bodyBuilder = RumBodyBuilder()

    suspend fun sendEvent(event: Event, params: Map<String, String>) {
        runCatching {
            send(bodyBuilder.buildBody(eventName = event.name, params = params, table = RUM_TABLE, configuration = rumConfiguration))

            if (!BuildConfig.DEBUG) {
                send(bodyBuilder.buildBody(eventName = event.name, params = params, table = TRUST_TABLE, configuration = rumConfiguration))
            }
        }
    }

    private suspend fun send(body: String) {
        suspendCancellableCoroutine { continuation ->
            val request = Request.Builder()
                .url(CLICKHOUSE_BASE_URL)
                .addHeader(HEADER_CONTENT_TYPE, MEDIA_TYPE_PLAIN)
                .addHeader(HEADER_CONNECTION, CONNECTION_VALUE)
                .post(body.toRequestBody(MEDIA_TYPE_PLAIN.toMediaType()))
                .build()
            val call = client.newCall(request)
            call.enqueue(
                object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        continuation.resumeWithException(e)
                    }

                    override fun onResponse(call: Call, response: Response) {
                        continuation.resume(response)
                    }
                }
            )
            continuation.invokeOnCancellation {
                try {
                    call.cancel()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private companion object {
        const val MEDIA_TYPE_PLAIN = "text/plain; charset=utf-8"
        const val CONNECTION_VALUE = "keep-alive"
        const val HEADER_CONTENT_TYPE = "Content-Type"
        const val HEADER_CONNECTION = "Connection"
        const val CLICKHOUSE_BASE_URL = "https://pay.yandex.ru/cl/click"
        const val TRUST_TABLE = "trust_front"
        const val RUM_TABLE = "rum_events"
    }
}

