package com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers.metrica

import android.content.Context
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import io.appmetrica.analytics.AppMetrica
import javax.inject.Inject

internal class MetricaUuidProvider @Inject constructor(
    @ApplicationContext context: Context,
) {
    private val uuid = AppMetrica.getUuid(context)

    fun getMetricaUuid(): String? {
        return uuid
    }
}

