package com.yandex.fintechsdk.core.analytics.impl.external.api.rum

/**
 * RUM configuration data class.
 * RUM is not available in external builds, but the interface is kept for API compatibility.
 */
public class RumConfiguration(
    public val path: String,
    public val project: String,
    public val page: String,
    public val service: String,
    public val rumId: String,
)

