package com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers

import com.yandex.fintechsdk.core.analytics.api.identifiers.IdentifiersProvider
import com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers.metrica.MetricaDeviceIdProvider
import com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers.metrica.MetricaUuidProvider
import javax.inject.Inject

internal class IdentifiersProviderExternalImpl @Inject constructor(
    private val metricaDeviceIdProvider: MetricaDeviceIdProvider,
    private val metricaUuidProvider: MetricaUuidProvider,
) : IdentifiersProvider {

    override fun getAppMetricaDeviceId(): String? {
        return metricaDeviceIdProvider.getMetricaDeviceId()
    }

    override fun getGaid(): String? {
        // GAID is not available in external builds
        return null
    }

    override fun getUuid(): String? {
        return metricaUuidProvider.getMetricaUuid()
    }
}

