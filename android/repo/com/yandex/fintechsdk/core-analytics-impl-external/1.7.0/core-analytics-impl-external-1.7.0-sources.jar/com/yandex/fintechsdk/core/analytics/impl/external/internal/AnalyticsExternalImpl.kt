package com.yandex.fintechsdk.core.analytics.impl.external.internal

import android.content.Context
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.analytics.api.event.BaseEventParamsProvider
import com.yandex.fintechsdk.core.analytics.api.event.Event
import com.yandex.fintechsdk.core.analytics.impl.external.api.appmetrica.AppMetricaApiKeyProvider
import com.yandex.fintechsdk.core.analytics.impl.external.api.rum.RumConfigurationProvider
import com.yandex.fintechsdk.core.analytics.impl.external.internal.mapping.toErrorMessage
import com.yandex.fintechsdk.core.analytics.impl.external.internal.rum.RumReporter
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import io.appmetrica.analytics.AppMetrica
import io.appmetrica.analytics.IReporter
import io.appmetrica.analytics.ReporterConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

internal class AnalyticsExternalImpl @Inject constructor(
    private val appMetricaApiKeyProvider: AppMetricaApiKeyProvider,
    private val baseEventParamsProvider: BaseEventParamsProvider,
    @ApplicationContext private val context: Context,
    rumConfigurationProvider: RumConfigurationProvider,
) : Analytics {

    private val appMetricaReporter: IReporter = buildReporter()
    private val rumReporter = rumConfigurationProvider.getConfiguration()?.let { RumReporter(it) }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun reportProductEvent(event: Event) {
        runCatching {
            val mergedParams = buildMap {
                putAll(baseEventParamsProvider.getParams())
                putAll(event.params)
            }

            appMetricaReporter.reportEvent(
                event.name,
                mergedParams,
            )

            scope.launch {
                rumReporter?.sendEvent(event, mergedParams)
            }
        }
    }

    override fun reportRuntimeError(key: String, exception: Throwable) {
        runCatching {
            val errorInfo = exception.toErrorMessage(
                key = key,
                baseParams = baseEventParamsProvider.getParams(),
            )
            appMetricaReporter.reportError(
                errorInfo.title,
                errorInfo.message,
                errorInfo.throwable,
            )
        }
    }

    override fun reportRuntimeError(event: Event) {
        runCatching {
            val errorInfo = event.toErrorMessage(
                baseParams = baseEventParamsProvider.getParams(),
            )
            appMetricaReporter.reportError(
                errorInfo.title,
                errorInfo.message,
            )
        }
    }

    private fun buildReporter(): IReporter {
        val apiKey = appMetricaApiKeyProvider.getApiKey()

        val config = ReporterConfig.newConfigBuilder(apiKey)
            .build()

        AppMetrica.activateReporter(context, config)

        return AppMetrica.getReporter(context, apiKey)
    }
}
