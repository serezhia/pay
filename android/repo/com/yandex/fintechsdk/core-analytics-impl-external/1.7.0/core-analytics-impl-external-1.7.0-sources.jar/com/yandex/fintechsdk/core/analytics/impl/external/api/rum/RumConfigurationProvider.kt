package com.yandex.fintechsdk.core.analytics.impl.external.api.rum

/**
 * Stub interface for RUM configuration provider.
 * RUM is not available in external builds.
 */
public interface RumConfigurationProvider {
    public fun getConfiguration(): RumConfiguration?
}

