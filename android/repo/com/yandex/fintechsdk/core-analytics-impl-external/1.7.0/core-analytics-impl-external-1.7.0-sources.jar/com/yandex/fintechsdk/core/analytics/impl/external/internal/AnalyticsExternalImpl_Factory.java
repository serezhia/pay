package com.yandex.fintechsdk.core.analytics.impl.external.internal;

import android.content.Context;
import com.yandex.fintechsdk.core.analytics.api.event.BaseEventParamsProvider;
import com.yandex.fintechsdk.core.analytics.impl.external.api.appmetrica.AppMetricaApiKeyProvider;
import com.yandex.fintechsdk.core.analytics.impl.external.api.rum.RumConfigurationProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class AnalyticsExternalImpl_Factory implements Factory<AnalyticsExternalImpl> {
  private final Provider<AppMetricaApiKeyProvider> appMetricaApiKeyProvider;

  private final Provider<BaseEventParamsProvider> baseEventParamsProvider;

  private final Provider<Context> contextProvider;

  private final Provider<RumConfigurationProvider> rumConfigurationProvider;

  private AnalyticsExternalImpl_Factory(Provider<AppMetricaApiKeyProvider> appMetricaApiKeyProvider,
      Provider<BaseEventParamsProvider> baseEventParamsProvider, Provider<Context> contextProvider,
      Provider<RumConfigurationProvider> rumConfigurationProvider) {
    this.appMetricaApiKeyProvider = appMetricaApiKeyProvider;
    this.baseEventParamsProvider = baseEventParamsProvider;
    this.contextProvider = contextProvider;
    this.rumConfigurationProvider = rumConfigurationProvider;
  }

  @Override
  public AnalyticsExternalImpl get() {
    return newInstance(appMetricaApiKeyProvider.get(), baseEventParamsProvider.get(), contextProvider.get(), rumConfigurationProvider.get());
  }

  public static AnalyticsExternalImpl_Factory create(
      Provider<AppMetricaApiKeyProvider> appMetricaApiKeyProvider,
      Provider<BaseEventParamsProvider> baseEventParamsProvider, Provider<Context> contextProvider,
      Provider<RumConfigurationProvider> rumConfigurationProvider) {
    return new AnalyticsExternalImpl_Factory(appMetricaApiKeyProvider, baseEventParamsProvider, contextProvider, rumConfigurationProvider);
  }

  public static AnalyticsExternalImpl newInstance(AppMetricaApiKeyProvider appMetricaApiKeyProvider,
      BaseEventParamsProvider baseEventParamsProvider, Context context,
      RumConfigurationProvider rumConfigurationProvider) {
    return new AnalyticsExternalImpl(appMetricaApiKeyProvider, baseEventParamsProvider, context, rumConfigurationProvider);
  }
}
