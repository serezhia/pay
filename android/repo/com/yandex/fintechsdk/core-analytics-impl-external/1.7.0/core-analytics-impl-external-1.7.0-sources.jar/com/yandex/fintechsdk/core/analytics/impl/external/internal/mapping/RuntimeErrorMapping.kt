package com.yandex.fintechsdk.core.analytics.impl.external.internal.mapping

import com.yandex.fintechsdk.core.analytics.api.event.Event
import org.json.JSONObject

internal fun Throwable.toErrorMessage(
    key: String,
    baseParams: Map<String, String>,
): ErrorInfo {
    val errorTitle = "[Exception] - $key"
    return ErrorInfo(
        title = errorTitle,
        message = JSONObject(baseParams).toString(),
        throwable = this,
    )
}

internal fun Event.toErrorMessage(
    baseParams: Map<String, String>,
): ErrorInfo {
    val errorTitle = "[Technical Error] - $name"

    val mergedParams = buildMap {
        putAll(baseParams)
        putAll(params)
    }

    return ErrorInfo(
        title = errorTitle,
        message = JSONObject(mergedParams).toString(),
        throwable = null,
    )
}

internal data class ErrorInfo(
    val title: String,
    val message: String,
    val throwable: Throwable?,
)

