package com.yandex.fintechsdk.core.analytics.impl.external.api.di

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.analytics.api.identifiers.IdentifiersProvider
import com.yandex.fintechsdk.core.analytics.impl.external.internal.AnalyticsExternalImpl
import com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers.IdentifiersProviderExternalImpl
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import dagger.Binds
import dagger.Module

@Module
public abstract class AnalyticsExternalModule {

    @FlowScope
    @Binds
    internal abstract fun bindAnalytics(impl: AnalyticsExternalImpl): Analytics

    @FlowScope
    @Binds
    internal abstract fun bindIdentifiersProvider(impl: IdentifiersProviderExternalImpl): IdentifiersProvider
}

