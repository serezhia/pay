package com.yandex.fintechsdk.core.analytics.impl.external.internal.identifiers.metrica

import android.content.Context
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import io.appmetrica.analytics.AppMetrica
import javax.inject.Inject

internal class MetricaDeviceIdProvider @Inject constructor(
    @ApplicationContext context: Context,
) {
    private val deviceId = AppMetrica.getDeviceId(context)

    fun getMetricaDeviceId(): String? {
        return deviceId
    }
}

