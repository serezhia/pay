package com.yandex.fintechsdk.core.analytics.impl.external.internal.rum

import com.yandex.fintechsdk.core.analytics.impl.external.BuildConfig
import com.yandex.fintechsdk.core.analytics.impl.external.api.rum.RumConfiguration
import com.yandex.fintechsdk.core.utils.api.url.encodeAsUrlParameter
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

internal class RumBodyBuilder {

    fun buildBody(eventName: String, params: Map<String, Any>, table: String, configuration: RumConfiguration): String {
        return buildString {
            append("/table=$table")
            append("/path=${configuration.path}")
            append("/vars=${buildVars(eventName, params, configuration)}")
            append(EVENT_END)
        }
    }

    private fun buildVars(eventName: String, params: Map<String, Any>, configuration: RumConfiguration): String {
        return buildString {
            append("rum_id=${configuration.rumId}")
            append(",-version=${BuildConfig.VERSION_NAME}")
            append(",-env=${getEnvironmentString()}")
            append(",-project=${configuration.project}")
            append(",-page=${configuration.page}")
            append(",-service=${configuration.service}")
            append(",-ts=${System.currentTimeMillis()}")
            append(",-name=$eventName")
            append(",-additional=${buildAdditional(params)}")
        }
    }

    private fun buildAdditional(params: Map<String, Any>): String {
        return params.mapValues { entry -> entry.value.toString() }.toJsonString().encodeAsUrlParameter()
    }

    /**
     * Serializes map into raw JSON. Used for some arguments in `vars` section
     */
    private fun Map<String, String>.toJsonString() = Json.encodeToString(this)

    private fun getEnvironmentString(): String {
        return when (BuildConfig.DEBUG) {
            true -> "development"
            false -> "production"
        }
    }

    private companion object {
        const val EVENT_END = "/*"
    }
}
