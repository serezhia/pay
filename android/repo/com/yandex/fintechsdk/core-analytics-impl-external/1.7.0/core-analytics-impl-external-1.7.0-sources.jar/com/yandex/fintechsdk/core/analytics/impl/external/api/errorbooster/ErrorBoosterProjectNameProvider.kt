package com.yandex.fintechsdk.core.analytics.impl.external.api.errorbooster

/**
 * Stub interface for Error Booster project name provider.
 * Error Booster is not available in external builds.
 */
public interface ErrorBoosterProjectNameProvider {
    public fun get(): String
}

