package com.yandex.fintechsdk.adapters.bank.sdk.api

import android.content.Context
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import com.yandex.fintechsdk.adapters.bank.sdk.api.auth.BankAuthProvider
import com.yandex.fintechsdk.entities.card.PayCard
import java.math.BigDecimal
import java.util.Locale

public interface BankAdapter {

    public fun init(
        context: Context,
        isTestEnvironment: Boolean,
        isNightMode: Boolean,
        authProvider: BankAuthProvider,
        userAgent: String,
        locale: Locale?,
    )

    public suspend fun openPayCard(fragmentActivity: FragmentActivity, container: ViewGroup)

    public suspend fun topUpPayCard(
        topUpSum: BigDecimal?,
        fragmentActivity: FragmentActivity,
        container: ViewGroup,
    )

    public suspend fun getPayCardInfo(): PayCard?
}
