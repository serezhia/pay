package com.yandex.fintechsdk.adapters.bank.sdk.api.auth

import kotlinx.coroutines.flow.StateFlow

public interface BankAuthProvider {
    public fun getUidFlow(): StateFlow<Long?>
}
