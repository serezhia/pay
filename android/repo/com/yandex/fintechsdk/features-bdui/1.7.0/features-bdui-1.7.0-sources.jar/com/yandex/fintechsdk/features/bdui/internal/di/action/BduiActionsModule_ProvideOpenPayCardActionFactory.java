package com.yandex.fintechsdk.features.bdui.internal.di.action;

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction;
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionInfo;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.open.OpenPayCardActionHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiActionsModule_ProvideOpenPayCardActionFactory implements Factory<BduiActionInfo<BduiAction>> {
  private final BduiActionsModule module;

  private final Provider<OpenPayCardActionHandler> handlerProvider;

  private BduiActionsModule_ProvideOpenPayCardActionFactory(BduiActionsModule module,
      Provider<OpenPayCardActionHandler> handlerProvider) {
    this.module = module;
    this.handlerProvider = handlerProvider;
  }

  @Override
  public BduiActionInfo<BduiAction> get() {
    return provideOpenPayCardAction(module, handlerProvider.get());
  }

  public static BduiActionsModule_ProvideOpenPayCardActionFactory create(BduiActionsModule module,
      Provider<OpenPayCardActionHandler> handlerProvider) {
    return new BduiActionsModule_ProvideOpenPayCardActionFactory(module, handlerProvider);
  }

  public static BduiActionInfo<BduiAction> provideOpenPayCardAction(BduiActionsModule instance,
      OpenPayCardActionHandler handler) {
    return Preconditions.checkNotNullFromProvides(instance.provideOpenPayCardAction(handler));
  }
}
