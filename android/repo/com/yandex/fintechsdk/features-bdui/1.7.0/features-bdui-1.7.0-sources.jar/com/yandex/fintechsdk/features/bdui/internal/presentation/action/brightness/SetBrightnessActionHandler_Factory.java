package com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness;

import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class SetBrightnessActionHandler_Factory implements Factory<SetBrightnessActionHandler> {
  private final Provider<FragmentActivityProvider> activityProvider;

  private final Provider<ScreenBrightnessStateHolder> brightnessStateHolderProvider;

  private SetBrightnessActionHandler_Factory(Provider<FragmentActivityProvider> activityProvider,
      Provider<ScreenBrightnessStateHolder> brightnessStateHolderProvider) {
    this.activityProvider = activityProvider;
    this.brightnessStateHolderProvider = brightnessStateHolderProvider;
  }

  @Override
  public SetBrightnessActionHandler get() {
    return newInstance(activityProvider.get(), brightnessStateHolderProvider.get());
  }

  public static SetBrightnessActionHandler_Factory create(
      Provider<FragmentActivityProvider> activityProvider,
      Provider<ScreenBrightnessStateHolder> brightnessStateHolderProvider) {
    return new SetBrightnessActionHandler_Factory(activityProvider, brightnessStateHolderProvider);
  }

  public static SetBrightnessActionHandler newInstance(FragmentActivityProvider activityProvider,
      ScreenBrightnessStateHolder brightnessStateHolder) {
    return new SetBrightnessActionHandler(activityProvider, brightnessStateHolder);
  }
}
