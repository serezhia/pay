package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

internal data class CardRelatedData<T>(
    val param: T,
    val cardNetworkPattern: CardNetworkPattern,
)
