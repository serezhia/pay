package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetworkPattern

internal class CardNumberFormatter(
    private val cardNetworkChecker: CardNetworkWithPatternChecker = CardNetworkWithPatternChecker(),
) {

    fun format(input: String): String? {
        val filteredInput = input.filter(Char::isDigit)
        val pattern = cardNetworkChecker.lookup(filteredInput).pattern
        return applyFormatting(filteredInput, pattern)
    }

    private fun applyFormatting(inputValue: String, pattern: CardNetworkPattern): String? =
        pattern
            .takeIf { it.validLengths.any { validLength -> validLength >= inputValue.length } }
            ?.let { applySpacers(inputValue, it.spaceIndexes) }

    private fun applySpacers(str: String, spaceIndexes: List<Int>): String {
        if (spaceIndexes.isEmpty()) return str
        return buildString {
            var spaceNumber = 0
            val spaceLimit = spaceIndexes.size
            for ((index, char) in str.withIndex()) {
                if (spaceNumber < spaceLimit && index == spaceIndexes[spaceNumber]) {
                    append(' ')
                    spaceNumber++
                }
                append(char)
            }
        }
    }
}
