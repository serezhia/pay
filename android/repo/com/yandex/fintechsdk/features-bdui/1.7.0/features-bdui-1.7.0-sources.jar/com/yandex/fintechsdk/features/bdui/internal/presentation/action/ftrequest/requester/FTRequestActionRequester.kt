package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.requester

import com.yandex.fintechsdk.core.network.api.network.DefaultNetworkApi
import com.yandex.fintechsdk.core.network.api.network.sendRequest
import com.yandex.fintechsdk.core.network.api.request.Requester
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.FTRequestAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.DtoHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.parseBodyAsMap
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.stringRepresentation
import kotlinx.serialization.json.JsonObject
import java.net.URLEncoder
import javax.inject.Inject

internal class FTRequestActionRequester @Inject constructor(
    private val api: DefaultNetworkApi,
    private val dtoHandler: DtoHandler,
) : Requester<FTRequestAction, FTRequestActionRequest, JsonObject, Map<String, Any>>() {

    override fun createRequest(params: FTRequestAction): FTRequestActionRequest {
        val queryItems: Map<String, String>? = params.queryItems?.mapNotNull { (key, node) ->
            val value = node?.let(dtoHandler::extractSingleValue)?.getOrThrow()
            value.stringRepresentation?.let { key to URLEncoder.encode(/* s = */ it, /* enc = */ "UTF-8") }
        }?.toMap()

        val headers: Map<String, String>? = params.headers?.mapNotNull { (key, node) ->
            val value = dtoHandler.extractSingleValue(node).getOrThrow()
            value.stringRepresentation?.let { key to it }
        }?.toMap()

        val bodyMap: Map<String, Any>? = dtoHandler.buildDto(dtoMap = params.requestMap).getOrThrow()

        return FTRequestActionRequest(
            method = params.method,
            baseUrl = params.baseUrl,
            requestPath = params.path,
            body = bodyMap,
            headers = headers,
            queries = queryItems,
        )
    }

    override suspend fun executeRequest(request: FTRequestActionRequest): Result<JsonObject> {
        return api.sendRequest(request = request)
    }

    override fun transformResponse(response: JsonObject): Map<String, Any> {
        return response.parseBodyAsMap()
    }
}
