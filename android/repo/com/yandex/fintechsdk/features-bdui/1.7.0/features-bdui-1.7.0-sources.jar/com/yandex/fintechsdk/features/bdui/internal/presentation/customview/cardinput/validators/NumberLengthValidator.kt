package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.validators

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNumber
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardRelatedData

internal class NumberLengthValidator : Validator<CardRelatedData<CardNumber>> {

    override fun validate(verifiable: CardRelatedData<CardNumber>): Boolean {
        val number = verifiable.param.value.replace(" ", "")
        val pattern = verifiable.cardNetworkPattern

        return pattern
            .validLengths
            .contains(number.length)
    }
}
