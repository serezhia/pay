package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.serializers

import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.DtoNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.SingleValueNode
import kotlinx.serialization.KSerializer
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.descriptors.buildClassSerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonDecoder
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

internal object SingleValueNodeSerializer : KSerializer<SingleValueNode> {
    override val descriptor: SerialDescriptor = buildClassSerialDescriptor(serialName = "SingleValueTransportNode")

    override fun serialize(encoder: Encoder, value: SingleValueNode) {
        encoder.encodeSerializableValue(serializer = SingleValueNode.serializer(), value = value)
    }

    override fun deserialize(decoder: Decoder): SingleValueNode {
        val jsonDecoder = decoder as? JsonDecoder ?: throw IllegalStateException("Expected JsonDecoder")
        val element = jsonDecoder.decodeJsonElement()
        return deserializeFromJsonElement(decoder = jsonDecoder, element = element)
    }

    private fun deserializeFromJsonElement(element: JsonElement, decoder: JsonDecoder): SingleValueNode {
        return when (element) {
            is JsonObject -> when (element.containsKey(DtoNodeSerializer.FT_NODE_TYPE_KEY)) {
                true -> ValueTransferNodeSerializer.deserializeFromJsonElement(element = element, decoder = decoder)
                false -> DtoNode.Value(value = element)
            }

            is JsonArray, is JsonNull, is JsonPrimitive -> DtoNode.Value(value = element)
        }
    }
}
