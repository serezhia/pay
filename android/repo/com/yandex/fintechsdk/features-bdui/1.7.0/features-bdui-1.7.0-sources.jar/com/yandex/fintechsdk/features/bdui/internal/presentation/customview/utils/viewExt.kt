package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils

import android.transition.ChangeBounds
import android.transition.Transition
import android.transition.TransitionManager
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.core.view.isVisible

internal fun View.setLockedAndUnclickable(isLocked: Boolean) {
    this.setLocked(isLocked)
    // setting isClickable to "true" triggers accessibility feedback "Double tap to activate"
    // we don't want it for some views such as text views
    this.isClickable = false
}

internal fun View.show() {
    isVisible = true
}

internal fun View.hide() {
    isVisible = false
}

private const val NORMAL_ALPHA = 1f
private const val DISABLED_ALPHA = 0.4f

internal fun View.setLocked(isLocked: Boolean) {
    isClickable = !isLocked
    isEnabled = !isLocked
    if (this !is EditText) {
        alpha = if (isLocked) DISABLED_ALPHA else NORMAL_ALPHA
    }
}

internal fun ViewGroup.runLayoutChangesAnimation(duration: Long? = null) {
    val transition: Transition = ChangeBounds()
    duration?.let {
        transition.duration = duration
    }
    TransitionManager.beginDelayedTransition(this, transition)
}
