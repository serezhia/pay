package com.yandex.fintechsdk.features.bdui.internal.presentation.action.delayed.cancellable

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.NestedAction
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class CancellableDelayedAction(
    @SerialName("params")
    val params: CancellableDelayedActionParams,
) : BduiAction

@Serializable
internal class CancellableDelayedActionParams(
    @SerialName("mills")
    val millis: Long,

    @SerialName("cancelTag")
    val cancelTag: String,

    @SerialName("action")
    val action: @Contextual NestedAction,
)
