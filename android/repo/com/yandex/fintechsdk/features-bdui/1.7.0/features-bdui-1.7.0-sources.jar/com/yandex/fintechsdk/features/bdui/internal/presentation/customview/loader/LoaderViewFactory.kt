package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.loader

import android.content.Context
import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomActionHandler
import com.yandex.fintechsdk.core.bdui.api.customview.expression.BduiExpressionResolver
import com.yandex.fintechsdk.core.bdui.api.customview.factory.BaseCustomViewFactory
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.loader.model.LoaderViewCustomProps
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.model.CustomViewKeys

internal class LoaderViewFactory : BaseCustomViewFactory<LoaderView, LoaderViewCustomProps>(
    paramsSerializer = LoaderViewCustomProps.serializer(),
) {

    override val type: String = CustomViewKeys.LOADER_VIEW_KEY

    override fun createViewWithParams(
        context: Context,
        params: LoaderViewCustomProps?,
    ): LoaderView = LoaderView(
        context = context,
        params = params,
    )

    override fun bindView(
        actionHandler: DivCustomActionHandler,
        view: LoaderView,
        expressionResolver: BduiExpressionResolver?,
    ) {
        view.applyExpressionResolver(expressionResolver)
    }
}
