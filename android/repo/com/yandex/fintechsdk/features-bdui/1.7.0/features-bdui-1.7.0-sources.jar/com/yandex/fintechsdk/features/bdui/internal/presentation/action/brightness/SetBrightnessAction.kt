package com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class SetBrightnessAction(
    @SerialName("value")
    val value: Float? = null,
) : BduiAction

