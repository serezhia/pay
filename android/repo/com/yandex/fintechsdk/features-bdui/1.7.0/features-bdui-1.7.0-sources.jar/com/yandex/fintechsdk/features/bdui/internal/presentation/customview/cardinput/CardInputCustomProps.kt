package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput

import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

@Serializable
internal class CardInputCustomProps(
    @SerialName(value = "tokenizationData")
    val tokenizationData: CardInputTokenizationData,

    @SerialName(value = "enableDynamicBinInfo")
    val enableDynamicBinInfo: Boolean? = false,

    @SerialName(value = "theme")
    val theme: String? = null,

    @SerialName(value = "dynamicBinInfoProps")
    val dynamicBinInfoProps: DynamicBinInfoProps? = null,

    @SerialName(value = "placeholderColorExpression")
    val placeholderColorExpression: String? = null,

    @SerialName(value = "textColorExpression")
    val textColorExpression: String? = null,

    @SerialName(value = "topLabelColorExpression")
    val topLabelColorExpression: String? = null,

    @SerialName(value = "errorTextColorExpression")
    val errorTextColorExpression: String? = null,
)

@Serializable
internal class CardInputTokenizationData(
    @SerialName(value = "pmdVariableName")
    val pmdVariableName: String,

    @SerialName(value = "psdVariableName")
    val psdVariableName: String,

    @SerialName(value = "tokenizationContext")
    val tokenizationContext: JsonObject,

    @SerialName(value = "tokenizeSuccessAction")
    val tokenizeSuccessAction: DivCustomAction,

    @SerialName(value = "tokenizeFailureAction")
    val tokenizeFailureAction: DivCustomAction,

    @SerialName(value = "diehardBaseUrl")
    val diehardBaseUrl: String,
)

@Serializable
internal class DynamicBinInfoProps(
    @SerialName(value = "nextActionLockDelayInMillis")
    val nextActionLockDelayInMillis: Long,

    @SerialName(value = "cardNetworkDetails")
    val cardNetworkDetails: Map<String, CardNetworkData>,
)

@Serializable
internal class CardNetworkData(
    @SerialName(value = "iconUrl")
    val iconUrl: CardNetworkIconUrl,

    @SerialName(value = "stringCode")
    val stringCode: String,

    @SerialName(value = "intervals")
    val intervals: List<CardNetworkNumberIntervalData>? = null,

    @SerialName(value = "securityCodeLabel")
    val securityCodeLabel: String? = null,

    @SerialName(value = "securityCodeLength")
    val securityCodeLength: Int,

    @SerialName(value = "validLengths")
    val validLengths: List<Int>,

    @SerialName(value = "spaceIndexes")
    val spaceIndexes: List<Int>,
)

@Serializable
internal class CardNetworkIconUrl(
    @SerialName(value = "day")
    val day: String,

    @SerialName(value = "night")
    val night: String,
)

@Serializable
internal class CardNetworkNumberIntervalData(
    @SerialName(value = "start")
    val start: String,

    @SerialName(value = "end")
    val end: String? = null,
)
