package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model

import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class WebViewCustomProps(
    @SerialName("allowNewTabType")
    val allowNewTabType: AllowNewTabType? = null,

    @SerialName("url")
    val url: String,

    @SerialName("authRequired")
    val authRequired: Boolean = false,

    @SerialName("onErrorAction")
    val onErrorAction: DivCustomAction? = null,

    @SerialName("onLoadComplete")
    val onLoadCompleteList: List<LoadCompleteAction>? = null,

    @SerialName("onPostMessage")
    val onPostMessage: List<PostMessageAction>? = null,
)

@Serializable
internal enum class AllowNewTabType {
    BROWSER,
    INPLACE,
    SYSTEM_TAB,
}

@Serializable
internal data class LoadCompleteAction(
    @SerialName("url")
    val url: String,

    @SerialName("match")
    val match: UrlMatch,

    @SerialName("action")
    val action: DivCustomAction,
)

@Serializable
internal enum class UrlMatch {
    CONTAINING,
    EXACT,
}
