package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.barcode

import com.google.zxing.BarcodeFormat

internal enum class SupportedBarcodeFormat(
    val key: String,
    val zxingFormat: BarcodeFormat,
) {
    AZTEC(key = "aztec", zxingFormat = BarcodeFormat.AZTEC),
    CODE128(key = "code128", zxingFormat = BarcodeFormat.CODE_128),
    EAN8(key = "ean8", zxingFormat = BarcodeFormat.EAN_8),
    EAN13(key = "ean13", zxingFormat = BarcodeFormat.EAN_13),
    PDF417(key = "pdf417", zxingFormat = BarcodeFormat.PDF_417),
    QR(key = "qr", zxingFormat = BarcodeFormat.QR_CODE),
    ;

    companion object {
        fun fromKey(key: String): SupportedBarcodeFormat? {
            return entries.find { entry -> entry.key == key.lowercase() }
        }
    }
}
