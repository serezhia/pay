package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters

import androidx.annotation.StringRes
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.CardNetworkData
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetwork
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNumber
import com.yandex.fintechsdk.resources.R.string

internal data class SecurityCodeLabel(
    @StringRes val fallbackRes: Int,
    val customLabel: String?,
)

internal class SecurityCodeTypeStringFacade(
    private val cardNetworkChecker: CardNetworkWithPatternChecker = CardNetworkWithPatternChecker(),
    cardNetworks: Map<String, CardNetworkData>? = null,
) {

    private val networksByKey: Map<String, CardNetworkData>? = cardNetworks?.mapKeys { it.key.lowercase() }

    fun getSecurityCodeLabel(cardNumber: CardNumber): SecurityCodeLabel {
        val cardNetwork = cardNetworkChecker.lookup(numStr = cardNumber.value).cardNetwork
        return getSecurityCodeLabel(value = cardNetwork)
    }

    fun getSecurityCodeLabel(value: CardNetwork): SecurityCodeLabel {
        val fallback = when (value) {
            CardNetwork.MIR -> string.finsdk_cvp
            CardNetwork.MASTERCARD -> string.finsdk_cvc
            CardNetwork.UNIONPAY -> string.finsdk_cvn
            CardNetwork.VISA -> string.finsdk_cvv
            else -> string.finsdk_cvv
        }
        val key = value.stringCode.lowercase()
        val customLabel = networksByKey?.get(key = key)?.securityCodeLabel
        return SecurityCodeLabel(
            fallbackRes = fallback,
            customLabel = customLabel,
        )
    }
}
