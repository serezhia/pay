package com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import javax.inject.Inject

/**
 * OpenDeeplinkAction handler - executes deeplink opening and handles callbacks
 *
 * @param deeplinkExecutor Deeplink executor - class for working with Android Intent System
 */
internal class OpenDeeplinkActionHandler @Inject constructor(
    private val deeplinkExecutor: DeeplinkExecutor,
) : BduiActionHandler {

    /**
     * Handles action - checks type and executes OpenDeeplinkAction
     *
     * @param action Action to handle
     * @return true if action was handled by this handler
     */
    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is OpenDeeplinkAction) return

        handleOpenDeeplink(action = action, context = context)
    }

    /**
     * Executes specific OpenDeeplinkAction logic
     */
    private fun handleOpenDeeplink(action: OpenDeeplinkAction, context: BduiHandlingContext) {
        val result = deeplinkExecutor.execute(
            deeplink = action.deeplink,
            universalLinksOnly = action.universalLinksOnly,
        )

        when (result) {
            DeeplinkResult.SUCCESS -> {
                action.onSuccess?.let { onSuccess -> context.actionDispatcher.dispatch(action = onSuccess) }
            }

            DeeplinkResult.FAILURE,
            DeeplinkResult.NO_APP_FOUND -> {
                action.onFail?.let { onFail -> context.actionDispatcher.dispatch(action = onFail) }
            }
        }
    }
}
