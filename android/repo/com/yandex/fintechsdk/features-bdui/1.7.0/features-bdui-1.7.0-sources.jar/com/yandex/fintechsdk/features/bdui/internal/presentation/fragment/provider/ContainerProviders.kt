package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider

import android.view.ViewGroup
import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import com.yandex.fintechsdk.core.utils.api.provider.BaseProvider
import javax.inject.Inject

@FeatureScope
internal class ContainerWithInsetsProvider @Inject constructor() : BaseProvider<ViewGroup>()

@FeatureScope
internal class ContainerWithoutInsetsProvider @Inject constructor() : BaseProvider<ViewGroup>()
