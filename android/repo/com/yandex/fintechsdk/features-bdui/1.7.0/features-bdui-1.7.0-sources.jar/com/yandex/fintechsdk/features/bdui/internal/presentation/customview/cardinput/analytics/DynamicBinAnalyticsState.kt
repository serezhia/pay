package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics

internal class DynamicBinAnalyticsState {
    private var firstRequestTimeMs: Long? = null

    fun onTrackedRequestStarted(startTimeMs: Long) {
        if (firstRequestTimeMs == null) {
            firstRequestTimeMs = startTimeMs
        }
    }

    fun timeSinceFirstRequest(): Long? {
        val startTime = firstRequestTimeMs ?: return null
        return System.currentTimeMillis() - startTime
    }

    fun reset() {
        firstRequestTimeMs = null
    }
}
