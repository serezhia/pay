package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.textwatchers

import android.text.Editable
import android.text.TextWatcher
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNumberFormatter
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.interfaces.CardNumberChangedListener

internal class CardNumberTextWatcher(
    private val listener: CardNumberChangedListener,
    private val cardNumberFormatter: CardNumberFormatter = CardNumberFormatter(),
) : TextWatcher {

    private var prevText: String = ""

    override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) = Unit

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit

    override fun afterTextChanged(editable: Editable) {
        val newContent = cardNumberFormatter.format(editable.toString())
        when {
            newContent == null -> {
                editable.filters = emptyArray()
                editable.replace(0, editable.length, prevText)
                listener.onCardNumberChanged(prevText)
            }
            newContent != prevText -> {
                prevText = newContent
                editable.filters = emptyArray()
                editable.replace(0, editable.length, newContent)
                listener.onCardNumberChanged(newContent)
            }
        }
    }
}
