package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes

import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.serializers.SingleValueNodeSerializer
import kotlinx.serialization.Serializable

/**
 * Represents a node that holds only one value.
 * This interface is serializable using [SingleValueNodeSerializer].
 */
@Serializable(SingleValueNodeSerializer::class)
internal sealed interface SingleValueNode
