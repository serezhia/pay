package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils

import com.yandex.fintechsdk.core.bdui.api.state.BduiStateManager
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.ErrorBodyLoggingRule
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.FTRequestAction
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.double
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.long
import kotlinx.serialization.json.longOrNull
import kotlin.collections.map
import kotlin.collections.mapValues

/**
 * Updates a variable within the state managed by [BduiStateManager] at the specified path with the given value.
 *
 * This function creates a base map, stores the provided value at the specified path within this map,
 * and then attempts to cast and update the state manager with the new value.
 *
 * @param path A list of strings representing the path to the variable that needs to be updated.
 * @param value The new value to be set at the specified path.
 */
internal fun BduiStateManager.updateVariable(path: List<String>, value: Any) {
    val base = mutableMapOf<String, Any>().apply {
        storeValueRecursive(path = path, value = value)
    }
    @Suppress("UNCHECKED_CAST")
    (base as? Map<String, Map<String, Any>>)?.let(::update)
}

/**
 * Stores a value in a nested map structure based on a given path.
 *
 * This function recursively traverses or creates nested maps to store the provided value
 * at the location specified by the path. If the path is empty, the function returns immediately.
 * If the path has only one element, the value is stored directly at that key. Otherwise,
 * the function navigates deeper into the nested structure, creating new maps as needed.
 *
 * @param path A list of strings representing the nested keys to reach the target location.
 * @param value The value to be stored at the location specified by the path.
 */
internal fun MutableMap<String, Any>.storeValueRecursive(path: List<String>, value: Any) {
    if (path.isEmpty()) return
    if (path.size == 1) {
        this[path[0]] = value
        return
    }

    val firstKey = path[0]
    val remainingPath = path.subList(1, path.size)

    if (this[firstKey] == null || this[firstKey] !is MutableMap<*, *>) {
        this[firstKey] = mutableMapOf<String, Any>()
    }

    @Suppress("UNCHECKED_CAST")
    (this[firstKey] as? MutableMap<String, Any>)?.storeValueRecursive(remainingPath, value)
}

internal fun JsonElement.toAny(): Any? {
    return when (this) {
        is JsonNull -> null
        is JsonPrimitive -> when {
            isString -> content
            booleanOrNull != null -> boolean
            longOrNull != null -> long
            doubleOrNull != null -> double
            else -> content
        }

        is JsonArray -> map { it.toAny() }
        is JsonObject -> mapValues { it.value.toAny() }
    }
}

internal val FTRequestAction.joinedUrl: String get() = "${baseUrl.trimEnd('/')}/${path.trimStart('/')}"

internal fun FTRequestAction.errorBodyLogMessage(code: Int, body: JsonObject?): String {
    return buildString {
        append("Failed with code $code")
        when (errorBodyLoggingRule?.type) {
            null, ErrorBodyLoggingRule.Type.Skip -> return@buildString
            ErrorBodyLoggingRule.Type.Full -> append(", body: ${body?.toString()}")
            ErrorBodyLoggingRule.Type.Partial -> errorBodyLoggingRule.length?.let {
                append(", body snippet: ${body?.toString()?.take(it)}")
            }
        }
    }
}

internal fun JsonObject.parseBodyAsMap(): Map<String, Any> {
    return this.mapNotNull { (key, value) ->
        value.toAny()?.let { key to it }
    }.toMap()
}

internal val Any?.stringRepresentation: String?
    get() = when (this) {
        is String -> this
        is Number -> this.toString()
        is Boolean -> this.toString()
        else -> null
    }

@Suppress("CyclomaticComplexMethod")
internal fun Any?.toJsonElement(): JsonElement {
    return when (this) {
        null -> JsonNull
        is JsonElement -> this
        is String -> JsonPrimitive(this)
        is Number -> JsonPrimitive(this)
        is Boolean -> JsonPrimitive(this)
        is Char -> JsonPrimitive(this.toString())
        is Map<*, *> -> buildJsonObject {
            for ((k, v) in this@toJsonElement) {
                require(k is String) { "Key must be String but get: $k" }
                put(k, v.toJsonElement())
            }
        }

        is Iterable<*> -> buildJsonArray { for (e in this@toJsonElement) add(e.toJsonElement()) }
        is Array<*> -> buildJsonArray { for (e in this@toJsonElement) add(e.toJsonElement()) }
        is IntArray -> buildJsonArray { for (e in this@toJsonElement) add(JsonPrimitive(e)) }
        is LongArray -> buildJsonArray { for (e in this@toJsonElement) add(JsonPrimitive(e)) }
        is DoubleArray -> buildJsonArray { for (e in this@toJsonElement) add(JsonPrimitive(e)) }
        is FloatArray -> buildJsonArray { for (e in this@toJsonElement) add(JsonPrimitive(e)) }
        is BooleanArray -> buildJsonArray { for (e in this@toJsonElement) add(JsonPrimitive(e)) }
        is ShortArray -> buildJsonArray { for (e in this@toJsonElement) add(JsonPrimitive(e.toInt())) }
        is CharArray -> buildJsonArray { for (e in this@toJsonElement) add(JsonPrimitive(e.toString())) }
        is ByteArray -> buildJsonArray { for (e in this@toJsonElement) add(JsonPrimitive(e.toInt())) }
        else -> throw IllegalArgumentException("Unsupported type: ${this::class}")
    }
}
