package com.yandex.fintechsdk.features.bdui.internal.presentation.customview

import com.yandex.fintechsdk.core.bdui.api.customview.BduiVariableController
import com.yandex.fintechsdk.core.bdui.api.customview.configuration.CustomViewConfiguration
import com.yandex.fintechsdk.core.bdui.api.customview.factory.CustomViewFactory
import com.yandex.fintechsdk.core.bdui.api.customview.factory.CustomViewFactoryDelegate
import com.yandex.fintechsdk.core.bdui.api.customview.factory.CustomViewFactoryDelegateCreator
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.barcode.BarcodeViewFactory
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.CardInputViewConfiguration
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.CardInputViewFactory
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.loader.LoaderViewFactory
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.model.CustomViewKeys
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.CustomWebViewFactory
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.WebViewConfiguration
import javax.inject.Inject

internal class CustomViewFactoryDelegateCreatorImpl @Inject constructor() : CustomViewFactoryDelegateCreator {

    override fun create(
        variableController: BduiVariableController,
        configurations: Map<String, CustomViewConfiguration>,
    ): CustomViewFactoryDelegate {
        val factories = mutableMapOf<String, CustomViewFactory<*>>()

        factories.addBarcodeViewFactory()
        factories.addCardInputViewFactory(configurations = configurations, variableController = variableController)
        factories.addCustomWebViewFactory(configurations = configurations, variableController = variableController)
        factories.addLoaderViewFactory()

        return CustomViewFactoryDelegate(factories = factories)
    }

    private fun MutableMap<String, CustomViewFactory<*>>.addCustomWebViewFactory(
        configurations: Map<String, CustomViewConfiguration>,
        variableController: BduiVariableController,
    ) {
        (configurations[WebViewConfiguration.KEY] as? WebViewConfiguration)?.let { config ->
            put(
                CustomViewKeys.WEB_VIEW_KEY,
                CustomWebViewFactory(
                    bduiVariableController = variableController,
                    webViewConfiguration = config,
                ),
            )
        }
    }

    private fun MutableMap<String, CustomViewFactory<*>>.addCardInputViewFactory(
        configurations: Map<String, CustomViewConfiguration>,
        variableController: BduiVariableController,
    ) {
        (configurations[CardInputViewConfiguration.KEY] as? CardInputViewConfiguration)?.let { config ->
            put(
                CustomViewKeys.CARD_INPUT_VIEW_KEY,
                CardInputViewFactory(
                    variableController = variableController,
                    cardInputViewConfiguration = config,
                ),
            )
        }
    }

    private fun MutableMap<String, CustomViewFactory<*>>.addLoaderViewFactory() {
        put(
            CustomViewKeys.LOADER_VIEW_KEY,
            LoaderViewFactory(),
        )
    }

    private fun MutableMap<String, CustomViewFactory<*>>.addBarcodeViewFactory() {
        put(
            CustomViewKeys.BARCODE_VIEW_KEY,
            BarcodeViewFactory(),
        )
    }
}
