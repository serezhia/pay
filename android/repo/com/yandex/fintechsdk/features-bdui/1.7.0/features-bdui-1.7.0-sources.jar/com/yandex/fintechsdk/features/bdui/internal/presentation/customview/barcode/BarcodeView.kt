package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.barcode

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import androidx.appcompat.widget.AppCompatImageView
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix

internal class BarcodeView(
    context: Context,
    private val props: BarcodeCustomProps?,
) : AppCompatImageView(context) {

    init {
        scaleType = ScaleType.FIT_CENTER
        adjustViewBounds = true
    }

    fun bind() {
        props?.let { generateBarcode(props = it) }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) {
            props?.let { generateBarcode(props = it) }
        }
    }

    private fun generateBarcode(props: BarcodeCustomProps) {
        val barcodeFormat = SupportedBarcodeFormat.fromKey(props.format) ?: return
        val width = if (width > 0) width else DEFAULT_WIDTH
        val height = if (height > 0) height else DEFAULT_HEIGHT

        try {
            val hints = mutableMapOf<EncodeHintType, Any>()
            hints[EncodeHintType.MARGIN] = 0

            val bitMatrix = MultiFormatWriter().encode(
                /* contents = */ props.value,
                /* format = */ barcodeFormat.zxingFormat,
                /* width = */ width,
                /* height = */ height,
                /* hints = */ hints,
            )

            val bitmap = createBitmap(bitMatrix = bitMatrix)
            setImageBitmap(bitmap)
        } catch (e: Exception) {
            // Failed to generate barcode
        }
    }

    private fun createBitmap(bitMatrix: BitMatrix): Bitmap {
        val width = bitMatrix.width
        val height = bitMatrix.height
        val pixels = IntArray(width * height)

        for (y in 0 until height) {
            for (x in 0 until width) {
                pixels[y * width + x] = if (bitMatrix[x, y]) Color.BLACK else Color.WHITE
            }
        }

        return Bitmap.createBitmap(
            /* width = */ width,
            /* height = */ height,
            /* config = */ Bitmap.Config.ARGB_8888,
        ).apply {
            setPixels(
                /* pixels = */ pixels,
                /* offset = */ 0,
                /* stride = */ width,
                /* x = */ 0,
                /* y = */ 0,
                /* width = */ width,
                /* height = */ height,
            )
        }
    }

    private companion object {
        const val DEFAULT_WIDTH = 200
        const val DEFAULT_HEIGHT = 200
    }
}
