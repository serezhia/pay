package com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness

import android.app.Activity
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider
import javax.inject.Inject

internal class SetBrightnessActionHandler @Inject constructor(
    private val activityProvider: FragmentActivityProvider,
    private val brightnessStateHolder: ScreenBrightnessStateHolder,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is SetBrightnessAction) return

        val activity = activityProvider.get() ?: return

        if (action.value != null) {
            setBrightness(activity = activity, brightness = action.value)
        } else {
            restoreBrightness(activity = activity)
        }
    }

    private fun setBrightness(activity: Activity, brightness: Float) {
        val window = activity.window ?: return
        val layoutParams = window.attributes

        brightnessStateHolder.saveBrightness(brightness = layoutParams.screenBrightness)

        layoutParams.screenBrightness = brightness.coerceIn(minimumValue = 0f, maximumValue = 1f)
        window.attributes = layoutParams
    }

    private fun restoreBrightness(activity: Activity) {
        val previousBrightness = brightnessStateHolder.restoreBrightness() ?: return
        val window = activity.window ?: return
        val layoutParams = window.attributes

        layoutParams.screenBrightness = previousBrightness
        window.attributes = layoutParams

        brightnessStateHolder.clear()
    }
}

