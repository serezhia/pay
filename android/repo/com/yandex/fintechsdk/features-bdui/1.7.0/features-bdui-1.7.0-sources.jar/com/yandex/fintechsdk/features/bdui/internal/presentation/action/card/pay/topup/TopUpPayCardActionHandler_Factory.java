package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.topup;

import com.yandex.fintechsdk.adapters.bank.sdk.api.BankAdapter;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithInsetsProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class TopUpPayCardActionHandler_Factory implements Factory<TopUpPayCardActionHandler> {
  private final Provider<BankAdapter> bankAdapterProvider;

  private final Provider<ContainerWithInsetsProvider> containerProvider;

  private final Provider<FragmentActivityProvider> fragmentActivityProvider;

  private final Provider<ViewModelScopeProvider> scopeProvider;

  private TopUpPayCardActionHandler_Factory(Provider<BankAdapter> bankAdapterProvider,
      Provider<ContainerWithInsetsProvider> containerProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<ViewModelScopeProvider> scopeProvider) {
    this.bankAdapterProvider = bankAdapterProvider;
    this.containerProvider = containerProvider;
    this.fragmentActivityProvider = fragmentActivityProvider;
    this.scopeProvider = scopeProvider;
  }

  @Override
  public TopUpPayCardActionHandler get() {
    return newInstance(bankAdapterProvider.get(), containerProvider.get(), fragmentActivityProvider.get(), scopeProvider.get());
  }

  public static TopUpPayCardActionHandler_Factory create(Provider<BankAdapter> bankAdapterProvider,
      Provider<ContainerWithInsetsProvider> containerProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<ViewModelScopeProvider> scopeProvider) {
    return new TopUpPayCardActionHandler_Factory(bankAdapterProvider, containerProvider, fragmentActivityProvider, scopeProvider);
  }

  public static TopUpPayCardActionHandler newInstance(@Nullable BankAdapter bankAdapter,
      ContainerWithInsetsProvider containerProvider,
      FragmentActivityProvider fragmentActivityProvider, ViewModelScopeProvider scopeProvider) {
    return new TopUpPayCardActionHandler(bankAdapter, containerProvider, fragmentActivityProvider, scopeProvider);
  }
}
