package com.yandex.fintechsdk.features.bdui.internal.presentation.action.plus;

import com.yandex.fintechsdk.adapters.plus.sdk.api.PlusAdapter;
import com.yandex.fintechsdk.data.auth.api.AuthRepository;
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class OpenPlusActionHandler_Factory implements Factory<OpenPlusActionHandler> {
  private final Provider<AuthRepository> authRepositoryProvider;

  private final Provider<ContextProvider> contextProvider;

  private final Provider<DefaultEnvironment> environmentProvider;

  private final Provider<PlusAdapter> plusAdapterProvider;

  private final Provider<ViewModelScopeProvider> scopeProvider;

  private OpenPlusActionHandler_Factory(Provider<AuthRepository> authRepositoryProvider,
      Provider<ContextProvider> contextProvider, Provider<DefaultEnvironment> environmentProvider,
      Provider<PlusAdapter> plusAdapterProvider, Provider<ViewModelScopeProvider> scopeProvider) {
    this.authRepositoryProvider = authRepositoryProvider;
    this.contextProvider = contextProvider;
    this.environmentProvider = environmentProvider;
    this.plusAdapterProvider = plusAdapterProvider;
    this.scopeProvider = scopeProvider;
  }

  @Override
  public OpenPlusActionHandler get() {
    return newInstance(authRepositoryProvider.get(), contextProvider.get(), environmentProvider.get(), plusAdapterProvider.get(), scopeProvider.get());
  }

  public static OpenPlusActionHandler_Factory create(
      Provider<AuthRepository> authRepositoryProvider, Provider<ContextProvider> contextProvider,
      Provider<DefaultEnvironment> environmentProvider, Provider<PlusAdapter> plusAdapterProvider,
      Provider<ViewModelScopeProvider> scopeProvider) {
    return new OpenPlusActionHandler_Factory(authRepositoryProvider, contextProvider, environmentProvider, plusAdapterProvider, scopeProvider);
  }

  public static OpenPlusActionHandler newInstance(AuthRepository authRepository,
      ContextProvider contextProvider, DefaultEnvironment environment,
      @Nullable PlusAdapter plusAdapter, ViewModelScopeProvider scopeProvider) {
    return new OpenPlusActionHandler(authRepository, contextProvider, environment, plusAdapter, scopeProvider);
  }
}
