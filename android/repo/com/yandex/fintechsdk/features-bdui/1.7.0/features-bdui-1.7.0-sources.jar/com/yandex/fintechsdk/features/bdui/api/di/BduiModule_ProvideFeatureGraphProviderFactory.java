package com.yandex.fintechsdk.features.bdui.api.di;

import com.yandex.fintechsdk.core.architecture.api.feature.graph.FeatureGraphProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiModule_ProvideFeatureGraphProviderFactory implements Factory<FeatureGraphProvider> {
  private final BduiModule module;

  private BduiModule_ProvideFeatureGraphProviderFactory(BduiModule module) {
    this.module = module;
  }

  @Override
  public FeatureGraphProvider get() {
    return provideFeatureGraphProvider(module);
  }

  public static BduiModule_ProvideFeatureGraphProviderFactory create(BduiModule module) {
    return new BduiModule_ProvideFeatureGraphProviderFactory(module);
  }

  public static FeatureGraphProvider provideFeatureGraphProvider(BduiModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideFeatureGraphProvider());
  }
}
