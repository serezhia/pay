package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model

import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class SendToBackendConfig(
    @SerialName("stateName")
    val stateName: String,

    @SerialName("stateKey")
    val stateKey: String,
)

@Serializable
internal data class PostMessageParameterMapping(
    @SerialName("path")
    val path: String,

    @SerialName("variableName")
    val variableName: String,

    @SerialName("sendToBackend")
    val sendToBackend: SendToBackendConfig? = null,
)

@Serializable
internal data class PostMessageAction(
    @SerialName("messageName")
    val messageName: String,

    @SerialName("action")
    val action: DivCustomAction,

    @SerialName("parametersMapping")
    val parametersMapping: List<PostMessageParameterMapping>? = null,
)
