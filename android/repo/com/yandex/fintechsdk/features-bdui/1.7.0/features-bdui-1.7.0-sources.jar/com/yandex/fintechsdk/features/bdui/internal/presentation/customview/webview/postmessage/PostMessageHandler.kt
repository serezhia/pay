package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.postmessage

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.bdui.api.customview.BduiVariableController
import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.PostMessageAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.PostMessageData
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

internal class PostMessageHandler(
    private val actionHandler: DivCustomActionHandler,
    private val bduiVariableController: BduiVariableController,
    private val flexAdapter: FlexAdapter?,
) {
    private val registeredHandlers = mutableMapOf<String, PostMessageAction>()
    private val json = Json { ignoreUnknownKeys = true }

    fun setHandlers(postMessageActions: List<PostMessageAction>) {
        registeredHandlers.clear()
        postMessageActions.forEach { postMessageAction ->
            registeredHandlers[postMessageAction.messageName] = postMessageAction
        }
    }

    fun unregisterHandlers() {
        registeredHandlers.clear()
    }

    fun handlePostMessage(data: String) {
        try {
            val message = json.decodeFromString<PostMessageData>(data)
            val postMessageAction = registeredHandlers[message.type] ?: return

            val dataSource = message.payload ?: message.data?.jsonObject

            postMessageAction.parametersMapping?.forEach { mapping ->
                val value = extractValueByPath(jsonObject = dataSource, path = mapping.path)
                if (value != null) {
                    bduiVariableController.setVariable(name = mapping.variableName, value = value)

                    mapping.sendToBackend?.let { backendConfig ->
                        sendToBackend(
                            stateName = backendConfig.stateName,
                            stateKey = backendConfig.stateKey,
                            value = value,
                        )
                    }
                }
            }

            actionHandler.handleAction(action = postMessageAction.action)
        } catch (_: Exception) {
            // Ignore malformed messages
        }
    }

    /**
     * Extract value from JsonObject using simplified path notation
     * Examples: "userId", "user.name", "items[0].title"
     */
    private fun extractValueByPath(jsonObject: JsonObject?, path: String): String? {
        if (jsonObject == null) return null

        return try {
            val parts = path.split('.', '[', ']').filter { it.isNotEmpty() }
            var current: JsonElement = jsonObject

            for (part in parts) {
                current = when {
                    part.toIntOrNull() != null -> {
                        val index = part.toInt()
                        current.jsonArray.getOrNull(index) ?: return null
                    }
                    else -> {
                        current.jsonObject[part] ?: return null
                    }
                }
            }

            current.jsonPrimitive.contentOrNull
        } catch (_: Exception) {
            null
        }
    }

    private fun sendToBackend(stateName: String, stateKey: String, value: Any) {
        flexAdapter?.updateStateValue(
            stateName = stateName,
            valueName = stateKey,
            newValue = value,
        )
    }
}
