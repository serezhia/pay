package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.newtab

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

internal class NewWindowInterceptorWebViewFactory {

    /**
     * Creates a temporary WebView instance used only to intercept "new window" navigations.
     *
     * Why we need this:
     * - When a page uses window.open() / target="_blank", WebView calls WebChromeClient.onCreateWindow().
     * - The only supported way to capture the requested URL is to provide a child WebView
     *   via WebViewTransport and observe its navigation callbacks.
     * - We do NOT want to actually render a second WebView UI.
     *
     * How it works:
     * - The created WebView is never attached to a view hierarchy.
     * - It intercepts any attempted navigation (shouldOverrideUrlLoading / onPageStarted),
     *   forwards the URL to the provided handleUrl callback, then destroys itself on the main thread.
     *
     * Safety:
     * - Multiple windows and automatic JS popups are disabled to prevent popup loops.
     * - Destroy operations are posted to the main looper because WebView teardown must happen on UI thread.
     */
    @SuppressLint("SetJavaScriptEnabled")
    fun create(parentContext: Context, handleUrl: (String) -> Unit): WebView {
        return WebView(parentContext).apply {
            with(settings) {
                // Some sites require JS/DOM storage even to compute redirect URLs.
                // We enable them here to reliably capture the final URL.
                javaScriptEnabled = true
                domStorageEnabled = true

                // This WebView is an interceptor, not a real multi-window container.
                setSupportMultipleWindows(false)

                // Prevent JS from spawning additional windows automatically.
                javaScriptCanOpenWindowsAutomatically = false
            }

            webViewClient = object : WebViewClient() {

                /**
                 * API 21+ navigation callback.
                 * We always override because we don't want this WebView to actually load anything.
                 */
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    handleUrlAndDestroy(request?.url?.toString(), handleUrl)
                    return true
                }

                /**
                 * Legacy navigation callback.
                 * Kept for compatibility with older WebView implementations.
                 */
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    handleUrlAndDestroy(url, handleUrl)
                    return true
                }

                /**
                 * Some WebView versions trigger onPageStarted before shouldOverrideUrlLoading.
                 * We handle it too to ensure we always capture the URL.
                 */
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    handleUrlAndDestroy(url, handleUrl)
                }
            }
        }
    }

    private fun WebView.handleUrlAndDestroy(url: String?, handleUrl: (String) -> Unit) {
        val safeUrl = url.orEmpty()
        handleUrl(safeUrl)

        // WebView must be destroyed on the main/UI thread.
        Handler(Looper.getMainLooper()).post {
            runCatching { stopLoading() }
            runCatching { removeAllViews() }
            runCatching { destroy() }
        }
    }
}
