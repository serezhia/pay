package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model

import com.yandex.finsdtechsdk.adapters.passport.sdk.api.PassportAdapter
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.bdui.api.customview.configuration.CustomViewConfiguration
import com.yandex.fintechsdk.core.ui.impl.api.view.webview.WebViewCookie
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment
import com.yandex.fintechsdk.entities.region.Region
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.javascript.FintechJavascriptInterface

internal class WebViewConfiguration(
    val authRepository: AuthRepository,
    val environment: DefaultEnvironment,
    val flexAdapter: FlexAdapter?,
    val region: Region,
    val passportAdapter: PassportAdapter?,
    val cookies: List<WebViewCookie>?,
    val httpHeaders: Map<String, String>?,
    val javascriptInterfaces: List<FintechJavascriptInterface>?,
    val userAgentProvider: ((String) -> String?)?,
) : CustomViewConfiguration {
    companion object {
        const val KEY: String = "WebViewConfiguration"
    }
}
