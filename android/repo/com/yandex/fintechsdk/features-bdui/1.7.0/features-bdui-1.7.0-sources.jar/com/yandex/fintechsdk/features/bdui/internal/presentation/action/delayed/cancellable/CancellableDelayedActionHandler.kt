package com.yandex.fintechsdk.features.bdui.internal.presentation.action.delayed.cancellable

import androidx.lifecycle.withResumed
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@FeatureScope
internal class CancellableDelayedActionHandler @Inject constructor(
    private val activityProvider: FragmentActivityProvider,
    private val scopeProvider: ViewModelScopeProvider,
) : BduiActionHandler {

    private val jobsMap = mutableMapOf<String, Job>()

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is CancellableDelayedAction) return

        val activity = activityProvider.get() ?: return
        val scope = scopeProvider.get() ?: return
        val actionsDispatcher = context.actionDispatcher

        synchronized(this) {
            val currentJob = jobsMap[action.params.cancelTag]

            currentJob?.cancel()

            jobsMap[action.params.cancelTag] = scope.launch {
                delay(action.params.millis)
                activity.lifecycle.withResumed {
                    actionsDispatcher.dispatch(action = action.params.action)
                }
            }
        }
    }
}
