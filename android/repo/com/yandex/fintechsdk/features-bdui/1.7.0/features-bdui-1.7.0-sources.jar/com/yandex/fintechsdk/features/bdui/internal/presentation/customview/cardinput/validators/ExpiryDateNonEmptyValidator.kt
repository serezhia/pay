package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.validators

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.ExpiryDate

internal class ExpiryDateNonEmptyValidator : Validator<ExpiryDate> {

    override fun validate(verifiable: ExpiryDate): Boolean = verifiable is ExpiryDate.NonEmpty
}
