package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

internal data class ExpiryDateField(
    val rawExpiryDate: String,
    val expiryDate: ExpiryDate,
    val showValidationStatus: Boolean,
    val validationStatus: ValidationStatus,
)
