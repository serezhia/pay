package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters

import android.graphics.Canvas
import android.graphics.Paint
import android.text.Editable
import android.text.Spanned
import android.text.style.ReplacementSpan

internal class ExpirationDateFormatter {

    fun formatContent(editable: Editable, changeWasAddition: Boolean) {
        if (changeWasAddition && editable.length == 1 && Character.getNumericValue(editable[0]) > 1) {
            prependLeadingZero(editable)
        }

        val paddingSpans = editable.getSpans(0, editable.length, SlashSpan::class.java)
        paddingSpans.forEach(editable::removeSpan)
        addDateSlash(editable)
    }

    private fun prependLeadingZero(editable: Editable) {
        val firstChar = editable[0]
        editable.replace(0, 1, "0").append(firstChar)
    }

    private fun addDateSlash(editable: Editable) {
        val index = MONTH_LENGTH
        val length = editable.length
        if (index <= length) {
            editable.setSpan(
                SlashSpan(),
                index - 1,
                index,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
    }

    private class SlashSpan : ReplacementSpan() {
        private val sb = StringBuilder()

        override fun getSize(
            paint: Paint,
            text: CharSequence,
            start: Int,
            end: Int,
            fm: Paint.FontMetricsInt?
        ): Int {
            val padding = paint.measureText(PADDING, 0, 1)
            val separator = paint.measureText(SEPARATOR, 0, 1)
            val textSize = paint.measureText(text, start, end)
            return (padding + separator + padding + textSize).toInt()
        }

        override fun draw(
            canvas: Canvas,
            text: CharSequence,
            start: Int,
            end: Int,
            x: Float,
            top: Int,
            y: Int,
            bottom: Int,
            paint: Paint
        ) {
            sb.setLength(0)
            sb.append(text.subSequence(start, end)).append(PADDING + SEPARATOR + PADDING)
            canvas.drawText(sb, 0, sb.length, x, y.toFloat(), paint)
        }

        private companion object {
            const val SEPARATOR: String = "/"
            const val PADDING: String = " "
        }
    }

    private companion object {
        const val MONTH_LENGTH: Int = 2
    }
}
