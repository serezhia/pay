package com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class OpenBrowserAction(
    @SerialName("url")
    val url: String,
) : BduiAction
