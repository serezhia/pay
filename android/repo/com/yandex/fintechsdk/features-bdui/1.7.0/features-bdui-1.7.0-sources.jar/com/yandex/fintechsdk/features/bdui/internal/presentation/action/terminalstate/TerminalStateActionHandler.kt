package com.yandex.fintechsdk.features.bdui.internal.presentation.action.terminalstate

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate
import javax.inject.Inject

internal class TerminalStateActionHandler @Inject constructor(
    private val actionsDelegate: BduiActionsDelegate,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is TerminalStateAction) return

        actionsDelegate.onTerminalState(
            result = action.result,
            description = action.description,
            reasonCode = action.reasonCode,
        )
    }
}

