package com.yandex.fintechsdk.features.bdui.internal.di.action;

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction;
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionInfo;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.FTRequestActionHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiActionsModule_ProvideFTRequestActionFactory implements Factory<BduiActionInfo<BduiAction>> {
  private final BduiActionsModule module;

  private final Provider<FTRequestActionHandler> handlerProvider;

  private BduiActionsModule_ProvideFTRequestActionFactory(BduiActionsModule module,
      Provider<FTRequestActionHandler> handlerProvider) {
    this.module = module;
    this.handlerProvider = handlerProvider;
  }

  @Override
  public BduiActionInfo<BduiAction> get() {
    return provideFTRequestAction(module, handlerProvider.get());
  }

  public static BduiActionsModule_ProvideFTRequestActionFactory create(BduiActionsModule module,
      Provider<FTRequestActionHandler> handlerProvider) {
    return new BduiActionsModule_ProvideFTRequestActionFactory(module, handlerProvider);
  }

  public static BduiActionInfo<BduiAction> provideFTRequestAction(BduiActionsModule instance,
      FTRequestActionHandler handler) {
    return Preconditions.checkNotNullFromProvides(instance.provideFTRequestAction(handler));
  }
}
