package com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action

public interface DevicePubkeyProvider {
    public fun getPublicKey(): String? = null
}
