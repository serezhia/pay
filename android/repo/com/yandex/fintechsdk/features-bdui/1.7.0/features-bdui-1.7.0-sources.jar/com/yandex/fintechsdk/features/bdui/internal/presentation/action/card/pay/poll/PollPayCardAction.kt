package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.poll

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.NestedAction
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class PollPayCardAction(
    @SerialName("retryCount")
    val retryCount: Int,

    @SerialName("intervalSec")
    val intervalSec: Double,

    @SerialName("trustIdStateName")
    val trustIdStateName: String,

    @SerialName("trustIdStateKey")
    val trustIdStateKey: String,

    @SerialName("onFinish")
    val onFinish: @Contextual NestedAction? = null,

    @SerialName("onStart")
    val onStart: @Contextual NestedAction? = null,

    @SerialName("onError")
    val onError: @Contextual NestedAction? = null,
) : BduiAction
