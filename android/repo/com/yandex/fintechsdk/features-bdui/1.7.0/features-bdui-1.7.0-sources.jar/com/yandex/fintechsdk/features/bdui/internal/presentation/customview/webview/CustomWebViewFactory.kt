package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview

import android.content.Context
import com.yandex.fintechsdk.core.bdui.api.customview.BduiVariableController
import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomActionHandler
import com.yandex.fintechsdk.core.bdui.api.customview.expression.BduiExpressionResolver
import com.yandex.fintechsdk.core.bdui.api.customview.factory.BaseCustomViewFactory
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.WebViewConfiguration
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.model.CustomViewKeys
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.WebViewCustomProps

internal class CustomWebViewFactory(
    private val webViewConfiguration: WebViewConfiguration,
    private val bduiVariableController: BduiVariableController,
) : BaseCustomViewFactory<CustomWebView, WebViewCustomProps>(
    paramsSerializer = WebViewCustomProps.serializer(),
) {

    override val type: String = CustomViewKeys.WEB_VIEW_KEY

    override fun createViewWithParams(
        context: Context,
        params: WebViewCustomProps?,
    ): CustomWebView = CustomWebView(
        bduiVariableController = bduiVariableController,
        context = context,
        params = params,
        config = webViewConfiguration,
    )

    override fun bindView(
        actionHandler: DivCustomActionHandler,
        view: CustomWebView,
        expressionResolver: BduiExpressionResolver?,
    ) {
        view.bind(actionHandler = actionHandler)
    }
}
