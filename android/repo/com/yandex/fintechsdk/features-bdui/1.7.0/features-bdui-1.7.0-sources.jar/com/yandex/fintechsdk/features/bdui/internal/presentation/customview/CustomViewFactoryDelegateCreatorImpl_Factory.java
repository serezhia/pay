package com.yandex.fintechsdk.features.bdui.internal.presentation.customview;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CustomViewFactoryDelegateCreatorImpl_Factory implements Factory<CustomViewFactoryDelegateCreatorImpl> {
  @Override
  public CustomViewFactoryDelegateCreatorImpl get() {
    return newInstance();
  }

  public static CustomViewFactoryDelegateCreatorImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static CustomViewFactoryDelegateCreatorImpl newInstance() {
    return new CustomViewFactoryDelegateCreatorImpl();
  }

  private static final class InstanceHolder {
    static final CustomViewFactoryDelegateCreatorImpl_Factory INSTANCE = new CustomViewFactoryDelegateCreatorImpl_Factory();
  }
}
