package com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge;

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DevicePubkeyProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceChallengePubkeyActionHandler_Factory implements Factory<DeviceChallengePubkeyActionHandler> {
  private final Provider<Analytics> analyticsProvider;

  private final Provider<DevicePubkeyProvider> devicePubkeyProvider;

  private final Provider<FlexAdapter> flexAdapterProvider;

  private DeviceChallengePubkeyActionHandler_Factory(Provider<Analytics> analyticsProvider,
      Provider<DevicePubkeyProvider> devicePubkeyProvider,
      Provider<FlexAdapter> flexAdapterProvider) {
    this.analyticsProvider = analyticsProvider;
    this.devicePubkeyProvider = devicePubkeyProvider;
    this.flexAdapterProvider = flexAdapterProvider;
  }

  @Override
  public DeviceChallengePubkeyActionHandler get() {
    return newInstance(analyticsProvider.get(), devicePubkeyProvider.get(), flexAdapterProvider.get());
  }

  public static DeviceChallengePubkeyActionHandler_Factory create(
      Provider<Analytics> analyticsProvider, Provider<DevicePubkeyProvider> devicePubkeyProvider,
      Provider<FlexAdapter> flexAdapterProvider) {
    return new DeviceChallengePubkeyActionHandler_Factory(analyticsProvider, devicePubkeyProvider, flexAdapterProvider);
  }

  public static DeviceChallengePubkeyActionHandler newInstance(Analytics analytics,
      DevicePubkeyProvider devicePubkeyProvider, @Nullable FlexAdapter flexAdapter) {
    return new DeviceChallengePubkeyActionHandler(analytics, devicePubkeyProvider, flexAdapter);
  }
}
