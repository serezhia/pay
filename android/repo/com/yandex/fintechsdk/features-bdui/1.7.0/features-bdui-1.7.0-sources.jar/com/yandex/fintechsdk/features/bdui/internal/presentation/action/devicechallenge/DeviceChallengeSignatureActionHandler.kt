package com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DeviceChallengeSignatureProvider
import com.yandex.fintechsdk.features.bdui.internal.analytics.BiometrySupplyDeviceChallengeResult
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.updateVariable
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider
import javax.inject.Inject

internal class DeviceChallengeSignatureActionHandler @Inject constructor(
    private val analytics: Analytics,
    private val flexAdapter: FlexAdapter?,
    private val fragmentActivityProvider: FragmentActivityProvider,
    private val deviceChallengeSignatureProvider: DeviceChallengeSignatureProvider,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is DeviceChallengeSignatureAction) return

        val activity = fragmentActivityProvider.get()
        if (activity == null) {
            updateUserSuccess(action = action, isSuccess = false)
            onComplete(action = action, context = context)
            return
        }

        deviceChallengeSignatureProvider.getSignature(
            activity = activity,
            deviceChallengePostDelay = action.deviceChallengePostDelay,
            deviceChallengeStartDelay = action.deviceChallengeStartDelay,
            paymentMethodId = action.paymentMethodId,
            purchaseToken = action.purchaseToken,
        ) { data, signature ->
            analytics.reportProductEvent(
                event = BiometrySupplyDeviceChallengeResult.create(
                    data = data ?: "",
                    signature = signature ?: "",
                    userSuccess = signature != null,
                ),
            )

            if (signature == null || data == null) {
                updateUserSuccess(action = action, isSuccess = false)
                onComplete(action = action, context = context)
                return@getSignature
            }

            val signatureVarPath = action.signatureVarPath
            if (!signatureVarPath.isNullOrEmpty()) {
                flexAdapter?.stateManager?.updateVariable(
                    path = signatureVarPath,
                    value = signature,
                )
            }

            val dataVarPath = action.dataVarPath
            if (!dataVarPath.isNullOrEmpty()) {
                flexAdapter?.stateManager?.updateVariable(
                    path = dataVarPath,
                    value = data,
                )
            }

            updateUserSuccess(action = action, isSuccess = !signature.isEmpty())
            onComplete(action = action, context = context)
        }
    }

    private fun onComplete(action: DeviceChallengeSignatureAction, context: BduiHandlingContext) {
        action.onCompleteAction?.let {
                onCompleteAction -> context.actionDispatcher.dispatch(action = onCompleteAction)
        }
    }

    private fun updateUserSuccess(action: DeviceChallengeSignatureAction, isSuccess: Boolean) {
        val userSuccessVarPath = action.userSuccessVarPath
        if (!userSuccessVarPath.isNullOrEmpty()) {
            flexAdapter?.stateManager?.updateVariable(
                path = userSuccessVarPath,
                value = isSuccess,
            )
        }
    }
}
