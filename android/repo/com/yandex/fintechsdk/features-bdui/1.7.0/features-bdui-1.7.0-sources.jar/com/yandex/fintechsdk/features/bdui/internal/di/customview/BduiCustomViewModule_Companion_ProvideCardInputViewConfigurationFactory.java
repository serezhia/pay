package com.yandex.fintechsdk.features.bdui.internal.di.customview;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.bdui.api.customview.configuration.CustomViewConfiguration;
import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiCustomViewModule_Companion_ProvideCardInputViewConfigurationFactory implements Factory<CustomViewConfiguration> {
  private final Provider<Analytics> analyticsProvider;

  private final Provider<CardBindingRepository> cardBindingRepositoryProvider;

  private BduiCustomViewModule_Companion_ProvideCardInputViewConfigurationFactory(
      Provider<Analytics> analyticsProvider,
      Provider<CardBindingRepository> cardBindingRepositoryProvider) {
    this.analyticsProvider = analyticsProvider;
    this.cardBindingRepositoryProvider = cardBindingRepositoryProvider;
  }

  @Override
  public CustomViewConfiguration get() {
    return provideCardInputViewConfiguration(analyticsProvider.get(), cardBindingRepositoryProvider.get());
  }

  public static BduiCustomViewModule_Companion_ProvideCardInputViewConfigurationFactory create(
      Provider<Analytics> analyticsProvider,
      Provider<CardBindingRepository> cardBindingRepositoryProvider) {
    return new BduiCustomViewModule_Companion_ProvideCardInputViewConfigurationFactory(analyticsProvider, cardBindingRepositoryProvider);
  }

  public static CustomViewConfiguration provideCardInputViewConfiguration(Analytics analytics,
      CardBindingRepository cardBindingRepository) {
    return Preconditions.checkNotNullFromProvides(BduiCustomViewModule.Companion.provideCardInputViewConfiguration(analytics, cardBindingRepository));
  }
}
