package com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class OpenBrowserActionHandler_Factory implements Factory<OpenBrowserActionHandler> {
  private final Provider<ChromeTabLaunchActionsStore> chromeTabLaunchActionsStoreProvider;

  private OpenBrowserActionHandler_Factory(
      Provider<ChromeTabLaunchActionsStore> chromeTabLaunchActionsStoreProvider) {
    this.chromeTabLaunchActionsStoreProvider = chromeTabLaunchActionsStoreProvider;
  }

  @Override
  public OpenBrowserActionHandler get() {
    return newInstance(chromeTabLaunchActionsStoreProvider.get());
  }

  public static OpenBrowserActionHandler_Factory create(
      Provider<ChromeTabLaunchActionsStore> chromeTabLaunchActionsStoreProvider) {
    return new OpenBrowserActionHandler_Factory(chromeTabLaunchActionsStoreProvider);
  }

  public static OpenBrowserActionHandler newInstance(
      ChromeTabLaunchActionsStore chromeTabLaunchActionsStore) {
    return new OpenBrowserActionHandler(chromeTabLaunchActionsStore);
  }
}
