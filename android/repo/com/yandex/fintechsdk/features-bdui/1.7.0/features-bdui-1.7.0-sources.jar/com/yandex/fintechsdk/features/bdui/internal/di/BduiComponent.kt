package com.yandex.fintechsdk.features.bdui.internal.di

import com.yandex.fintechsdk.core.architecture.api.component.FintechComponent
import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import com.yandex.fintechsdk.core.ui.impl.api.shimmers.ShimmersLayoutProvider
import com.yandex.fintechsdk.features.bdui.api.dependencies.BduiDependencies
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule
import com.yandex.fintechsdk.features.bdui.internal.di.customview.BduiCustomViewModule
import com.yandex.fintechsdk.features.bdui.internal.di.error.BduiErrorHandlerModule
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.BduiViewModel
import dagger.Component

@FeatureScope
@Component(
    dependencies = [BduiDependencies::class],
    modules = [
        BduiActionsModule::class,
        BduiCustomViewModule::class,
        BduiErrorHandlerModule::class,
    ],
)
internal interface BduiComponent : FintechComponent {

    val viewModel: BduiViewModel
    val shimmersLayoutProvider: ShimmersLayoutProvider

    @Component.Factory
    interface Factory {
        fun create(dependencies: BduiDependencies): BduiComponent
    }
}
