package com.yandex.fintechsdk.features.bdui.internal.presentation.action.plus

import com.yandex.fintechsdk.adapters.plus.sdk.api.PlusAdapter
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.auth.api.AuthState
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider
import kotlinx.coroutines.launch
import javax.inject.Inject

internal class OpenPlusActionHandler @Inject constructor(
    private val authRepository: AuthRepository,
    private val contextProvider: ContextProvider,
    private val environment: DefaultEnvironment,
    private val plusAdapter: PlusAdapter?,
    private val scopeProvider: ViewModelScopeProvider,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is OpenPlusAction) return

        val androidContext = contextProvider.get() ?: return
        val scope = scopeProvider.get() ?: return

        val authState = authRepository.authState.value

        if (authState !is AuthState.Authorized) return

        scope.launch {
            val isSubscribed = plusAdapter?.subscribeOnPlus(
                accountCredentials = authState.credentials,
                context = androidContext,
                environment = environment,
            )

            if (isSubscribed == true) {
                action.onPlusOpened?.let { onPlusOpened -> context.actionDispatcher.dispatch(action = onPlusOpened) }
            } else {
                action.onCancelled?.let { onPlusCancelled -> context.actionDispatcher.dispatch(action = onPlusCancelled) }
            }
        }
    }
}
