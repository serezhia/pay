package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.loader.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class LoaderViewCustomProps(
    @SerialName("uniqueId")
    val uniqueId: String,

    @SerialName("lineWidth")
    val lineWidth: Double,

    @SerialName("strokeEnd")
    val strokeEnd: Double,

    @SerialName("duration")
    val duration: Double,

    @SerialName("strokeColorExpression")
    val strokeColorExpression: String,
)
