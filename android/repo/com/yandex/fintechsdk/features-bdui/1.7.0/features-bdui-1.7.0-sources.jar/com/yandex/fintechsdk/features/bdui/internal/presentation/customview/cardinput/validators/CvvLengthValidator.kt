package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.validators

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardRelatedData
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.Cvv

internal class CvvLengthValidator : Validator<CardRelatedData<Cvv>> {

    override fun validate(verifiable: CardRelatedData<Cvv>): Boolean {
        val cvv = verifiable.param
        val pattern = verifiable.cardNetworkPattern
        return pattern.cvvLength == cvv.value.length
    }
}
