package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils

import android.app.Activity
import android.view.View
import android.view.inputmethod.InputMethodManager

internal object Keyboard {

    internal fun hide(view: View) {
        inputMethodManager(view).hideSoftInputFromWindow(view.windowToken, 0)
    }

    internal fun show(view: View) {
        view.post {
            inputMethodManager(view).showSoftInput(view, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun inputMethodManager(view: View): InputMethodManager =
        view.context.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
}
