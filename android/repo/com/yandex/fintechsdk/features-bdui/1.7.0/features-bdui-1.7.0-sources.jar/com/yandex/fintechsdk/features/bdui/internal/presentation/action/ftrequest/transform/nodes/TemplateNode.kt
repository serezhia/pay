package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Defines patterns and templates for replacing substrings in strings.
 *
 * @property pattern The substring pattern to be replaced (e.g., "{oauth_token}").
 * @property template The full template string containing the pattern (e.g., "OAuth {oauth_token}").
 */
internal sealed class TemplateNode : ValueTransferNode() {
    abstract val pattern: String
    abstract val template: String

    @Serializable
    data class Oauth(
        @SerialName("pattern")
        override val pattern: String,

        @SerialName("template")
        override val template: String,
    ) : TemplateNode()

    @Serializable
    data class GenUuid(
        @SerialName("pattern")
        override val pattern: String,

        @SerialName("template")
        override val template: String,
    ) : TemplateNode()
}
