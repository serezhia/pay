package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ContainerWithInsetsProvider_Factory implements Factory<ContainerWithInsetsProvider> {
  @Override
  public ContainerWithInsetsProvider get() {
    return newInstance();
  }

  public static ContainerWithInsetsProvider_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ContainerWithInsetsProvider newInstance() {
    return new ContainerWithInsetsProvider();
  }

  private static final class InstanceHolder {
    static final ContainerWithInsetsProvider_Factory INSTANCE = new ContainerWithInsetsProvider_Factory();
  }
}
