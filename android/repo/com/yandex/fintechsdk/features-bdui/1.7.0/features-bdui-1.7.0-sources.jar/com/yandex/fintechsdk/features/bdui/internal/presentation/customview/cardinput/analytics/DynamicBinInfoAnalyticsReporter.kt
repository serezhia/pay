package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.entities.card.BinInfo
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardInputState
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetwork
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.dynamicbininfo.BinRequestContext
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.dynamicbininfo.DynamicBinInfoManager
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNetworkWithPatternChecker

internal class DynamicBinInfoAnalyticsReporter(
    private val analytics: Analytics,
    private val cardNetworkChecker: CardNetworkWithPatternChecker,
    private val analyticsState: DynamicBinAnalyticsState,
    private val isDynamicBinEnabled: Boolean,
) {
    fun reportDynamicDataApplied(binInfo: BinInfo, context: BinRequestContext, currentState: CardInputState) {
        if (!isDynamicBinEnabled) return

        val binWrapper = DynamicBinEventWrapper(prefix = context.prefix)
        val staticNetwork = cardNetworkChecker.lookup(numStr = context.cardNumber).cardNetwork
        val staticPaymentSystem = staticNetwork.takeIf { it != CardNetwork.UNKNOWN }?.stringCode
        val systemsMatch = staticPaymentSystem?.equals(other = binInfo.paymentSystem)
        val cardNumberLength = context.cardNumber.length
        val iconSource = when {
            currentState.networkIconUrl != null -> DynamicBinInfoAnalyticsDataSource.DIEHARD
            currentState.networkImageRes != 0 -> DynamicBinInfoAnalyticsDataSource.LOCAL
            else -> null
        }

        analytics.reportDynamicBinEvent(
            event = DynamicBinInfoEvent.DataApplied(
                binWrapper = binWrapper,
                cardNumberLength = cardNumberLength,
                dataSource = DynamicBinInfoAnalyticsDataSource.DIEHARD,
                iconSource = iconSource,
                paymentSystem = binInfo.paymentSystem,
                startTime = context.startTime,
                staticPaymentSystem = staticPaymentSystem,
                systemsMatch = systemsMatch,
            ),
            isFeatureEnabled = true,
        )
    }

    fun reportStaticDataApplied(cardNetwork: CardNetwork, cardNumberLength: Int) {
        if (!isDynamicBinEnabled) return
        analytics.reportDynamicBinEvent(
            event = DynamicBinInfoEvent.StaticDataApplied(
                cardNumberLength = cardNumberLength,
                paymentSystem = cardNetwork.stringCode,
                reason = DynamicBinInfoAnalyticsStaticDataReason.FEATURE_DISABLED,
            ),
            isFeatureEnabled = true,
        )
    }

    fun reportDataStateOnSubmit(
        state: CardInputState,
        currentBinInfo: BinInfo?,
        binInfoManager: DynamicBinInfoManager,
    ) {
        if (!isDynamicBinEnabled) return
        val digitsOnly = state.cardNumberField.cardNumber.value.replace(oldValue = " ", newValue = "")
        val cardNumberLength = digitsOnly.length
        val staticNetwork = cardNetworkChecker.lookup(numStr = digitsOnly).cardNetwork
        val staticPaymentSystem = staticNetwork.takeIf { it != CardNetwork.UNKNOWN }?.stringCode
        val hasDynamicData = currentBinInfo != null
        val hasPendingRequests = binInfoManager.hasPendingRequests()
        val paymentSystem = currentBinInfo?.paymentSystem ?: staticPaymentSystem
        val systemsMatch = if (currentBinInfo != null && staticPaymentSystem != null) {
            currentBinInfo.paymentSystem.equals(other = staticPaymentSystem, ignoreCase = true)
        } else null
        val iconSource = when {
            state.networkIconUrl != null -> DynamicBinInfoAnalyticsDataSource.DIEHARD
            state.networkImageRes != 0 -> DynamicBinInfoAnalyticsDataSource.LOCAL
            else -> null
        }
        val dataSource = when {
            hasDynamicData -> DynamicBinInfoAnalyticsDataSource.DIEHARD
            isDynamicBinEnabled && hasPendingRequests -> DynamicBinInfoAnalyticsDataSource.CACHED
            else -> DynamicBinInfoAnalyticsDataSource.LOCAL
        }

        analytics.reportDynamicBinEvent(
            event = DynamicBinInfoEvent.DataStateOnSubmit(
                cardNumberLength = cardNumberLength,
                dataSource = dataSource,
                failedPrefixes = binInfoManager.getFailedPrefixes(),
                hasDynamicData = hasDynamicData,
                hasPendingRequests = hasPendingRequests,
                iconSource = iconSource,
                paymentSystem = paymentSystem,
                pendingPrefixes = binInfoManager.getPendingPrefixes(),
                staticPaymentSystem = staticPaymentSystem,
                successfulPrefixes = binInfoManager.getSuccessfulPrefixes(),
                systemsMatch = systemsMatch,
                timeSinceFirstRequestMs = analyticsState.timeSinceFirstRequest(),
                trigger = DynamicBinInfoAnalyticsTrigger.SUBMIT,
            ),
            isFeatureEnabled = true,
        )
    }
}
