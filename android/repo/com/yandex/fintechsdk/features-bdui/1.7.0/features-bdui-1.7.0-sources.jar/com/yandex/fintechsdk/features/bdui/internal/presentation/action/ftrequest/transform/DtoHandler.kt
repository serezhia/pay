package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.network.api.auth.AuthTokenProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.exception.JasonPathNotFoundException
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.DtoNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.SingleValueNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.TemplateNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.ValueTransferNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.VariableNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.DtoNodeProcessor
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.PatchHolder
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.toAny
import com.yandex.fintechsdk.core.bdui.api.state.BduiStateManager
import java.util.UUID
import javax.inject.Inject

/**
 * Handles the transformation and processing of DTO nodes.
 *
 * This class is responsible for building DTOs from maps of [DtoNode] objects,
 * extracting values from various node types, and applying patches to the state
 * managed by [BduiStateManager]. It uses a [ValueExtractor] to recursively extract
 * values from complex node structures and delegates node processing to [DtoNodeProcessor].
 *
 * @property authTokenProvider Provides authentication tokens for template replacement.
 * @property dtoNodeProcessor Processes individual DTO nodes and applies changes to the state.
 * @property flexAdapter The [FlexAdapter] for accessing [BduiStateManager] and updating the state.
 */
internal class DtoHandler @Inject constructor(
    private val authTokenProvider: AuthTokenProvider,
    private val dtoNodeProcessor: DtoNodeProcessor,
    private val flexAdapter: FlexAdapter?,
) {

    private val valueExtractor = ValueExtractor()

    /**
     * Builds a map of DTO values from a map of DTO nodes.
     *
     * @param dtoMap A map where keys are strings and values are DtoNode objects.
     * @return A map where keys are strings and values are the extracted values from the DtoNode objects.
     */
    fun buildDto(dtoMap: Map<String, DtoNode>): Result<Map<String, Any>> = runCatching {
        val resultMap = buildMap {
            dtoMap.forEach { key, node ->
                valueExtractor.extractValueFromDtoNode(node = node)?.let { set(key = key, value = it) }
            }
        }
        return Result.success(value = resultMap)
    }

    /**
     * Extracts a single value from a [SingleValueNode].
     *
     * @param node The [SingleValueNode] from which to extract the value.
     * @return The extracted value, or null if the node is [DtoNode.Empty].
     */
    fun extractSingleValue(node: SingleValueNode): Result<Any?> = runCatching {
        val resultValue = when (node) {
            DtoNode.Empty -> null
            is DtoNode.Value -> node.value.toAny()
            is ValueTransferNode -> valueExtractor.extractValueFromValueTransportNode(node)
        }
        return Result.success(value = resultValue)
    }

    /**
     * Handles the processing of a DTO (Data Transfer Object) by iterating through its nodes,
     * processing each node with a corresponding value, and applying the resulting patches to the state manager.
     *
     * @param dto A map representing the DTO, where keys are node names and values are the corresponding data.
     * @param dtoMap A map of node names to [DtoNode] objects that define how each node should be processed.
     */
    fun handle(dto: Map<String, Any>, dtoMap: Map<String, DtoNode>): Result<Unit> = runCatching {
        val patchHolder = PatchHolder()
        dtoMap.forEach { name, node ->
            dtoNodeProcessor.process(
                node = node,
                nodeValue = dto[name],
                patchHolder = patchHolder,
                path = name,
            )
        }

        val stateManager = flexAdapter?.stateManager ?: return Result.success(Unit)
        patchHolder.getPayload()?.let(stateManager::update)
    }

    private inner class ValueExtractor {

        /**
         * Extracts values from a [DtoNode], handling different node types including arrays, maps, and value nodes.
         * For [ValueTransferNode] instances, it delegates to [extractValueFromValueTransportNode] method.
         *
         * @param node The DtoNode from which to extract the value
         * @return The extracted value which can be a list, map, primitive value, or null
         */
        fun extractValueFromDtoNode(node: DtoNode): Any? {
            return when (node) {
                is DtoNode.Array -> node.value.map(::extractValueFromDtoNode)
                is DtoNode.Map -> buildDto(node.value).getOrThrow()
                is DtoNode.Value -> node.value.toAny()
                is ValueTransferNode -> extractValueFromValueTransportNode(node = node)
                DtoNode.Empty -> null
            }
        }

        /**
         * Extracts values from [ValueTransferNode] instances, handling template nodes and variable nodes.
         * For TemplateNode instances, it generates values based on the template type (UUID or OAuth token).
         * For VariableNode instances, it retrieves values from the state manager using the provided path.
         *
         * @param node The ValueTransferNode from which to extract the value
         * @return The extracted value which can be a string or null
         * @throws JasonPathNotFoundException if a variable node path cannot be found in the state manager
         */
        fun extractValueFromValueTransportNode(node: ValueTransferNode): Any? {
            return when (node) {
                is TemplateNode -> node.replaceValue()
                is VariableNode -> flexAdapter?.stateManager?.getValue(path = node.path)
                    ?: throw JasonPathNotFoundException(path = node.path.joinToString("."))
            }
        }

        /**
         * Replaces template placeholders with actual values based on the template node type.
         * Handles GenUuid templates by generating a random UUID and Oauth templates by retrieving an auth token.
         *
         * @return The template string with replaced values, or null if the replacement value is null
         */
        private fun TemplateNode.replaceValue(): String? {
            val value = when (this) {
                is TemplateNode.GenUuid -> UUID.randomUUID().toString()
                is TemplateNode.Oauth -> authTokenProvider.getToken()
            } ?: return null

            return template.replace(oldValue = pattern, newValue = value)
        }
    }
}
