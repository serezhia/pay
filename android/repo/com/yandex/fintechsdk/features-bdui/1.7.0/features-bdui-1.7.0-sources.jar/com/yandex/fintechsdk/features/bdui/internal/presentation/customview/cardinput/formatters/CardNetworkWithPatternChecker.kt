package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetwork
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetworkNumberInterval
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetworkWithPattern

internal class CardNetworkWithPatternChecker(
    private val cardNetworkPatternDictionary: CardNetworkPatternDictionary = CardNetworkPatternDictionary(),
) {

    private val unknownCardNetworkWithPattern
        get() = CardNetworkWithPattern(cardNetwork = CardNetwork.UNKNOWN, cardNetworkPatternDictionary.unknownPattern)

    fun lookup(numStr: String): CardNetworkWithPattern {
        val cleanNumber = numStr.replace(" ", "")
        if (cleanNumber.isEmpty() || cleanNumber.toLongOrNull() == null) return unknownCardNetworkWithPattern

        val networkWithPattern = CardNetwork.entries
            .map { cardNetwork -> CardNetworkWithPattern(cardNetwork, cardNetworkPatternDictionary.getPatternFor(cardNetwork)) }
            .singleOrNull { networkWithPattern ->
                networkWithPattern.pattern
                    .intervals
                    .any { interval: CardNetworkNumberInterval -> isNumberInInterval(cleanNumber, interval) }
            }

        return networkWithPattern ?: unknownCardNetworkWithPattern
    }

    private fun isNumberInInterval(number: String, interval: CardNetworkNumberInterval): Boolean {
        val intervalStart = interval.start
        val intervalEnd = interval.end ?: interval.start
        val intervalStartNumberLength: Int = minOf(number.length, intervalStart.length)
        val intervalEndNumberLength: Int = minOf(number.length, intervalEnd.length)
        var originalNumberPartToCompare: Long = number.substring(0, intervalStartNumberLength).toLong()
        var intervalNumberPartToCompare: Long = intervalStart.substring(0, intervalStartNumberLength).toLong()
        if (originalNumberPartToCompare < intervalNumberPartToCompare) {
            return false
        }
        originalNumberPartToCompare = number.substring(0, intervalEndNumberLength).toLong()
        intervalNumberPartToCompare = intervalEnd.substring(0, intervalEndNumberLength).toLong()
        return originalNumberPartToCompare <= intervalNumberPartToCompare
    }
}
