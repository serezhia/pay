package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ContextProvider_Factory implements Factory<ContextProvider> {
  @Override
  public ContextProvider get() {
    return newInstance();
  }

  public static ContextProvider_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ContextProvider newInstance() {
    return new ContextProvider();
  }

  private static final class InstanceHolder {
    static final ContextProvider_Factory INSTANCE = new ContextProvider_Factory();
  }
}
