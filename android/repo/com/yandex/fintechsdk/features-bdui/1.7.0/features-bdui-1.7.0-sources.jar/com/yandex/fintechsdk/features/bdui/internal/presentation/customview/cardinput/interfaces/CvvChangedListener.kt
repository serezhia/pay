package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.interfaces

internal interface CvvChangedListener {

    fun onCvvChanged(value: String)
}
