package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetwork
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetworkNumberInterval
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetworkPattern
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNetworkPatternDictionary

internal object CardNetworkPatternDictionaryFactory {

    fun create(
        cardNetworks: Map<String, CardNetworkData>?,
        enableDynamicBinInfo: Boolean,
    ): CardNetworkPatternDictionary {
        if (!enableDynamicBinInfo || cardNetworks.isNullOrEmpty()) {
            return CardNetworkPatternDictionary()
        }

        val overrides = cardNetworks.mapNotNull { (rawKey, data) ->
            val cardNetwork = CardNetwork.entries.first { it.stringCode == rawKey.uppercase() }
            cardNetwork to CardNetworkPattern(
                intervals = data.intervals?.map {
                    CardNetworkNumberInterval(
                        start = it.start,
                        end = it.end,
                    )
                } ?: listOf(),
                validLengths = data.validLengths,
                cvvLength = data.securityCodeLength,
                spaceIndexes = data.spaceIndexes,
            )
        }.toMap()

        return CardNetworkPatternDictionary(overrides = overrides)
    }
}
