package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.javascript

internal interface FintechJavascriptInterface {
    val interfaceName: String
}
