package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.views

import android.content.Context
import android.text.InputFilter
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.annotation.AttrRes
import androidx.annotation.StringRes
import androidx.annotation.StyleRes
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import com.yandex.fintechsdk.features.bdui.databinding.FinsdkViewSecretCodeInputBinding
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.Keyboard
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.setLocked
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.setLockedAndUnclickable
import com.yandex.fintechsdk.resources.R.color
import com.yandex.fintechsdk.resources.R.string

internal class SecretCodeInputView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    @AttrRes defStyleAttr: Int = 0,
    @StyleRes defStyleRes: Int = 0,
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {

    val binding: FinsdkViewSecretCodeInputBinding = FinsdkViewSecretCodeInputBinding.inflate(LayoutInflater.from(context), this)

    private var textFieldValue: String
        get() = binding.finsdkCvvInputText.text.toString()
        set(value) {
            binding.finsdkCvvInputText.setText(value)
        }

    var onError: ((String?) -> Unit)? = null

    init {
        orientation = VERTICAL
        gravity = Gravity.START or Gravity.CENTER_VERTICAL

        with(binding) {
            finsdkCvvInputTextHint.isVisible = finsdkCvvInputText.text.isEmpty()
            finsdkCvvInputText.doAfterTextChanged { text ->
                finsdkCvvInputTextHint.isVisible = text.isNullOrEmpty()
            }
        }
    }

    fun setSecurityCodeType(@StringRes codeType: Int, customLabel: String?) {
        binding.finsdkCvvInputLabel.text = customLabel ?: resources.getString(codeType)
    }

    fun setLocked(isLocked: Boolean) {
        with(binding) {
            finsdkCvvInputLabel.setLockedAndUnclickable(isLocked)
            finsdkCvvInputText.setLocked(isLocked)
        }
    }

    fun gainFocus() {
        with(binding.finsdkCvvInputText) {
            requestFocus()
            Keyboard.show(this)
        }
    }

    fun updateLengthFilter() {
        binding.finsdkCvvInputText.filters = arrayOf(InputFilter.LengthFilter(MAX_CHAR_COUNT))
    }

    fun showError(): Boolean {
        hideError()
        return textFieldValue.isNotBlank().also {
            binding.finsdkCvvInputLabel.setTextColor(
                ResourcesCompat.getColor(
                    resources,
                    color.finsdk_text_negative,
                    context.theme
                )
            )
            onError?.invoke(resources.getString(string.finsdk_wrong_cvv))
        }
    }

    fun hideError() {
        binding.finsdkCvvInputLabel.setTextColor(
            ResourcesCompat.getColor(
                resources,
                color.finsdk_text_secondary,
                context.theme
            )
        )
        onError?.invoke(null)
    }

    internal fun setTextIfNew(text: String) {
        if (binding.finsdkCvvInputText.text.toString() != text) {
            binding.finsdkCvvInputText.setText(text)
        }
    }

    private companion object {
        private const val MAX_CHAR_COUNT = 4
    }
}
