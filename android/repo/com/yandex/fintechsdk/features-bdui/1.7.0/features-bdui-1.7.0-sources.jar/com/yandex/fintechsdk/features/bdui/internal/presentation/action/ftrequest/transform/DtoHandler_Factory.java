package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform;

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.core.network.api.auth.AuthTokenProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.DtoNodeProcessor;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DtoHandler_Factory implements Factory<DtoHandler> {
  private final Provider<AuthTokenProvider> authTokenProvider;

  private final Provider<DtoNodeProcessor> dtoNodeProcessorProvider;

  private final Provider<FlexAdapter> flexAdapterProvider;

  private DtoHandler_Factory(Provider<AuthTokenProvider> authTokenProvider,
      Provider<DtoNodeProcessor> dtoNodeProcessorProvider,
      Provider<FlexAdapter> flexAdapterProvider) {
    this.authTokenProvider = authTokenProvider;
    this.dtoNodeProcessorProvider = dtoNodeProcessorProvider;
    this.flexAdapterProvider = flexAdapterProvider;
  }

  @Override
  public DtoHandler get() {
    return newInstance(authTokenProvider.get(), dtoNodeProcessorProvider.get(), flexAdapterProvider.get());
  }

  public static DtoHandler_Factory create(Provider<AuthTokenProvider> authTokenProvider,
      Provider<DtoNodeProcessor> dtoNodeProcessorProvider,
      Provider<FlexAdapter> flexAdapterProvider) {
    return new DtoHandler_Factory(authTokenProvider, dtoNodeProcessorProvider, flexAdapterProvider);
  }

  public static DtoHandler newInstance(AuthTokenProvider authTokenProvider,
      DtoNodeProcessor dtoNodeProcessor, @Nullable FlexAdapter flexAdapter) {
    return new DtoHandler(authTokenProvider, dtoNodeProcessor, flexAdapter);
  }
}
