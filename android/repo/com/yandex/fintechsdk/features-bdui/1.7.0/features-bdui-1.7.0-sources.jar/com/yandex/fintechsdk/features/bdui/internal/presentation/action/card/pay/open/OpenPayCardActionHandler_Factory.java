package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.open;

import com.yandex.fintechsdk.adapters.bank.sdk.api.BankAdapter;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithInsetsProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class OpenPayCardActionHandler_Factory implements Factory<OpenPayCardActionHandler> {
  private final Provider<BankAdapter> bankAdapterProvider;

  private final Provider<ContainerWithInsetsProvider> containerProvider;

  private final Provider<FragmentActivityProvider> fragmentActivityProvider;

  private final Provider<ViewModelScopeProvider> viewModelScopeProvider;

  private OpenPayCardActionHandler_Factory(Provider<BankAdapter> bankAdapterProvider,
      Provider<ContainerWithInsetsProvider> containerProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<ViewModelScopeProvider> viewModelScopeProvider) {
    this.bankAdapterProvider = bankAdapterProvider;
    this.containerProvider = containerProvider;
    this.fragmentActivityProvider = fragmentActivityProvider;
    this.viewModelScopeProvider = viewModelScopeProvider;
  }

  @Override
  public OpenPayCardActionHandler get() {
    return newInstance(bankAdapterProvider.get(), containerProvider.get(), fragmentActivityProvider.get(), viewModelScopeProvider.get());
  }

  public static OpenPayCardActionHandler_Factory create(Provider<BankAdapter> bankAdapterProvider,
      Provider<ContainerWithInsetsProvider> containerProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<ViewModelScopeProvider> viewModelScopeProvider) {
    return new OpenPayCardActionHandler_Factory(bankAdapterProvider, containerProvider, fragmentActivityProvider, viewModelScopeProvider);
  }

  public static OpenPayCardActionHandler newInstance(@Nullable BankAdapter bankAdapter,
      ContainerWithInsetsProvider containerProvider,
      FragmentActivityProvider fragmentActivityProvider,
      ViewModelScopeProvider viewModelScopeProvider) {
    return new OpenPayCardActionHandler(bankAdapter, containerProvider, fragmentActivityProvider, viewModelScopeProvider);
  }
}
