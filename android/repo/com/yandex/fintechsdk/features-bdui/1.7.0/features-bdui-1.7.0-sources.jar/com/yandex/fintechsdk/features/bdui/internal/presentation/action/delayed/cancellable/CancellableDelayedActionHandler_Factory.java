package com.yandex.fintechsdk.features.bdui.internal.presentation.action.delayed.cancellable;

import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CancellableDelayedActionHandler_Factory implements Factory<CancellableDelayedActionHandler> {
  private final Provider<FragmentActivityProvider> activityProvider;

  private final Provider<ViewModelScopeProvider> scopeProvider;

  private CancellableDelayedActionHandler_Factory(
      Provider<FragmentActivityProvider> activityProvider,
      Provider<ViewModelScopeProvider> scopeProvider) {
    this.activityProvider = activityProvider;
    this.scopeProvider = scopeProvider;
  }

  @Override
  public CancellableDelayedActionHandler get() {
    return newInstance(activityProvider.get(), scopeProvider.get());
  }

  public static CancellableDelayedActionHandler_Factory create(
      Provider<FragmentActivityProvider> activityProvider,
      Provider<ViewModelScopeProvider> scopeProvider) {
    return new CancellableDelayedActionHandler_Factory(activityProvider, scopeProvider);
  }

  public static CancellableDelayedActionHandler newInstance(
      FragmentActivityProvider activityProvider, ViewModelScopeProvider scopeProvider) {
    return new CancellableDelayedActionHandler(activityProvider, scopeProvider);
  }
}
