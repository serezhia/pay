package com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge;

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DeviceChallengeSignatureProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceChallengeSignatureActionHandler_Factory implements Factory<DeviceChallengeSignatureActionHandler> {
  private final Provider<Analytics> analyticsProvider;

  private final Provider<FlexAdapter> flexAdapterProvider;

  private final Provider<FragmentActivityProvider> fragmentActivityProvider;

  private final Provider<DeviceChallengeSignatureProvider> deviceChallengeSignatureProvider;

  private DeviceChallengeSignatureActionHandler_Factory(Provider<Analytics> analyticsProvider,
      Provider<FlexAdapter> flexAdapterProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<DeviceChallengeSignatureProvider> deviceChallengeSignatureProvider) {
    this.analyticsProvider = analyticsProvider;
    this.flexAdapterProvider = flexAdapterProvider;
    this.fragmentActivityProvider = fragmentActivityProvider;
    this.deviceChallengeSignatureProvider = deviceChallengeSignatureProvider;
  }

  @Override
  public DeviceChallengeSignatureActionHandler get() {
    return newInstance(analyticsProvider.get(), flexAdapterProvider.get(), fragmentActivityProvider.get(), deviceChallengeSignatureProvider.get());
  }

  public static DeviceChallengeSignatureActionHandler_Factory create(
      Provider<Analytics> analyticsProvider, Provider<FlexAdapter> flexAdapterProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<DeviceChallengeSignatureProvider> deviceChallengeSignatureProvider) {
    return new DeviceChallengeSignatureActionHandler_Factory(analyticsProvider, flexAdapterProvider, fragmentActivityProvider, deviceChallengeSignatureProvider);
  }

  public static DeviceChallengeSignatureActionHandler newInstance(Analytics analytics,
      @Nullable FlexAdapter flexAdapter, FragmentActivityProvider fragmentActivityProvider,
      DeviceChallengeSignatureProvider deviceChallengeSignatureProvider) {
    return new DeviceChallengeSignatureActionHandler(analytics, flexAdapter, fragmentActivityProvider, deviceChallengeSignatureProvider);
  }
}
