package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.requester;

import com.yandex.fintechsdk.core.network.api.network.DefaultNetworkApi;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.DtoHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FTRequestActionRequester_Factory implements Factory<FTRequestActionRequester> {
  private final Provider<DefaultNetworkApi> apiProvider;

  private final Provider<DtoHandler> dtoHandlerProvider;

  private FTRequestActionRequester_Factory(Provider<DefaultNetworkApi> apiProvider,
      Provider<DtoHandler> dtoHandlerProvider) {
    this.apiProvider = apiProvider;
    this.dtoHandlerProvider = dtoHandlerProvider;
  }

  @Override
  public FTRequestActionRequester get() {
    return newInstance(apiProvider.get(), dtoHandlerProvider.get());
  }

  public static FTRequestActionRequester_Factory create(Provider<DefaultNetworkApi> apiProvider,
      Provider<DtoHandler> dtoHandlerProvider) {
    return new FTRequestActionRequester_Factory(apiProvider, dtoHandlerProvider);
  }

  public static FTRequestActionRequester newInstance(DefaultNetworkApi api, DtoHandler dtoHandler) {
    return new FTRequestActionRequester(api, dtoHandler);
  }
}
