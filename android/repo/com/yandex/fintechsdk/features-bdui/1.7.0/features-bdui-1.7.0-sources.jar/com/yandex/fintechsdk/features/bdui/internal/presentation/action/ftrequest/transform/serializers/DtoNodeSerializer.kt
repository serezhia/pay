package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.serializers

import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.DtoNode
import kotlinx.serialization.KSerializer
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.descriptors.buildClassSerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonDecoder
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

internal object DtoNodeSerializer : KSerializer<DtoNode> {
    override val descriptor: SerialDescriptor = buildClassSerialDescriptor(serialName = "DtoNode")

    override fun serialize(encoder: Encoder, value: DtoNode) {
        encoder.encodeSerializableValue(serializer = DtoNode.serializer(), value)
    }

    override fun deserialize(decoder: Decoder): DtoNode {
        val jsonDecoder = decoder as? JsonDecoder ?: throw IllegalStateException("Expected JsonDecoder")
        val element = jsonDecoder.decodeJsonElement()
        return deserializeFromJsonElement(element = element, decoder = jsonDecoder)
    }

    private fun deserializeFromJsonElement(element: JsonElement, decoder: JsonDecoder): DtoNode {
        fun fillMap(map: MutableMap<String, DtoNode>) = (element as? JsonObject)?.forEach { key, value ->
            map[key] = deserializeFromJsonElement(element = value, decoder = decoder)
        }

        return when (element) {
            is JsonObject -> when (element.containsKey(FT_NODE_TYPE_KEY)) {
                true -> ValueTransferNodeSerializer.deserializeFromJsonElement(element = element, decoder = decoder)
                false -> buildMap(::fillMap).let(DtoNode::Map)
            }

            is JsonArray -> element
                .map { deserializeFromJsonElement(element = it, decoder = decoder) }
                .let(DtoNode::Array)

            is JsonNull -> DtoNode.Empty
            is JsonPrimitive -> DtoNode.Value(value = element)
        }
    }

    const val FT_NODE_TYPE_KEY = "ft_node_type"
}
