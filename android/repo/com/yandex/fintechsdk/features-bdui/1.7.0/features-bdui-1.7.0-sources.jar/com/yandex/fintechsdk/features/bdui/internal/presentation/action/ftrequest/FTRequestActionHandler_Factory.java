package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest;

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.requester.FTRequestActionRequester;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.DtoHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FTRequestActionHandler_Factory implements Factory<FTRequestActionHandler> {
  private final Provider<Analytics> analyticsProvider;

  private final Provider<DtoHandler> dtoHandlerProvider;

  private final Provider<FlexAdapter> flexAdapterProvider;

  private final Provider<FTRequestActionRequester> requesterProvider;

  private final Provider<ViewModelScopeProvider> viewModelScopeProvider;

  private FTRequestActionHandler_Factory(Provider<Analytics> analyticsProvider,
      Provider<DtoHandler> dtoHandlerProvider, Provider<FlexAdapter> flexAdapterProvider,
      Provider<FTRequestActionRequester> requesterProvider,
      Provider<ViewModelScopeProvider> viewModelScopeProvider) {
    this.analyticsProvider = analyticsProvider;
    this.dtoHandlerProvider = dtoHandlerProvider;
    this.flexAdapterProvider = flexAdapterProvider;
    this.requesterProvider = requesterProvider;
    this.viewModelScopeProvider = viewModelScopeProvider;
  }

  @Override
  public FTRequestActionHandler get() {
    return newInstance(analyticsProvider.get(), dtoHandlerProvider.get(), flexAdapterProvider.get(), requesterProvider.get(), viewModelScopeProvider.get());
  }

  public static FTRequestActionHandler_Factory create(Provider<Analytics> analyticsProvider,
      Provider<DtoHandler> dtoHandlerProvider, Provider<FlexAdapter> flexAdapterProvider,
      Provider<FTRequestActionRequester> requesterProvider,
      Provider<ViewModelScopeProvider> viewModelScopeProvider) {
    return new FTRequestActionHandler_Factory(analyticsProvider, dtoHandlerProvider, flexAdapterProvider, requesterProvider, viewModelScopeProvider);
  }

  public static FTRequestActionHandler newInstance(Analytics analytics, DtoHandler dtoHandler,
      @Nullable FlexAdapter flexAdapter, FTRequestActionRequester requester,
      ViewModelScopeProvider viewModelScopeProvider) {
    return new FTRequestActionHandler(analytics, dtoHandler, flexAdapter, requester, viewModelScopeProvider);
  }
}
