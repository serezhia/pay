package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.topup

import com.yandex.fintechsdk.adapters.bank.sdk.api.BankAdapter
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithInsetsProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider
import kotlinx.coroutines.launch
import javax.inject.Inject

internal class TopUpPayCardActionHandler @Inject constructor(
    private val bankAdapter: BankAdapter?,
    private val containerProvider: ContainerWithInsetsProvider,
    private val fragmentActivityProvider: FragmentActivityProvider,
    private val scopeProvider: ViewModelScopeProvider,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is TopUpPayCardAction) return

        val activity = fragmentActivityProvider.get() ?: return
        val container = containerProvider.get() ?: return
        val bankAdapter = bankAdapter ?: return
        val scope = scopeProvider.get() ?: return

        scope.launch {
            bankAdapter.topUpPayCard(
                topUpSum = action.amount?.toBigDecimal(),
                fragmentActivity = activity,
                container = container,
            )

            action.onFinish?.let { onFinish -> context.actionDispatcher.dispatch(action = onFinish) }
        }
    }
}
