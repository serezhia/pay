package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.analytics.api.event.Event
import com.yandex.fintechsdk.core.utils.api.collection.putIfNotNull

internal sealed interface DynamicBinInfoEvent {
    val requiresFeatureEnabled: Boolean
        get() = true

    class Init(
        enabledDynamicBinInfo: Boolean,
        cardNetworksCount: Int?,
        nextActionTimeoutMs: Long?,
    ) : Event(
        name = DynamicBinInfoEventName.INIT_EVENT.valueWithPrefix,
        params = buildMap {
            put(key = KEY_ENABLED, value = enabledDynamicBinInfo.toString())
            putIfNotNull(
                key = KEY_TOVARISH_NETWORKS_COUNT,
                value = cardNetworksCount?.toString(),
            )
            putIfNotNull(
                key = KEY_NEXT_ACTION_TIMEOUT_MS,
                value = nextActionTimeoutMs?.toString(),
            )
        },
    ), DynamicBinInfoEvent {
        override val requiresFeatureEnabled: Boolean = false
    }

    class RequestStarted(
        binWrapper: DynamicBinEventWrapper,
        cardNumberLength: Int,
        requestId: String,
    ) : Event(
        name = DynamicBinInfoEventName.REQUEST_STARTED.valueWithPrefix,
        params = mapOf(
            KEY_PREFIX to binWrapper.maskedPrefix,
            KEY_PREFIX_LENGTH to binWrapper.originalPrefixLength.toString(),
            KEY_CARD_NUMBER_LENGTH to cardNumberLength.toString(),
            KEY_REQUEST_ID to requestId,
        ),
    ), DynamicBinInfoEvent

    class RequestSuccess(
        binWrapper: DynamicBinEventWrapper,
        iconUrl: String?,
        networkFoundInTovarish: Boolean,
        paymentSystem: String,
        requestId: String,
        startTime: Long,
        staticPaymentSystem: String?,
        systemsMatch: Boolean?,
        withoutCvn: Boolean,
    ) : Event(
        name = DynamicBinInfoEventName.REQUEST_SUCCESS.valueWithPrefix,
        params = buildMap {
            put(key = KEY_PREFIX, value = binWrapper.maskedPrefix)
            put(key = KEY_PREFIX_LENGTH, value = binWrapper.originalPrefixLength.toString())
            put(key = KEY_PAYMENT_SYSTEM, value = paymentSystem)
            put(key = KEY_WITHOUT_CVN, value = withoutCvn.toString())
            put(key = KEY_HAS_ICON_URL, value = (iconUrl != null).toString())
            put(key = KEY_REQUEST_ID, value = requestId)
            put(key = KEY_NETWORK_FOUND_IN_TOVARISH, value = networkFoundInTovarish.toString())
            val duration = System.currentTimeMillis() - startTime
            put(key = KEY_REQUEST_DURATION_MS, value = duration.toString())
            putIfNotNull(
                key = KEY_ICON_URL,
                value = iconUrl,
            )
            putIfNotNull(
                key = KEY_STATIC_PAYMENT_SYSTEM,
                value = staticPaymentSystem,
            )
            putIfNotNull(
                key = KEY_SYSTEMS_MATCH,
                value = systemsMatch?.toString(),
            )
        },
    ), DynamicBinInfoEvent

    class RequestFailed(
        binWrapper: DynamicBinEventWrapper,
        errorMessage: String,
        errorType: DynamicBinInfoAnalyticsErrorType,
        requestId: String,
        startTime: Long,
        staticPaymentSystem: String?,
        willFallback: Boolean,
    ) : Event(
        name = DynamicBinInfoEventName.REQUEST_FAILED.valueWithPrefix,
        params = buildMap {
            put(key = KEY_PREFIX, value = binWrapper.maskedPrefix)
            put(key = KEY_PREFIX_LENGTH, value = binWrapper.originalPrefixLength.toString())
            put(key = KEY_ERROR_TYPE, value = errorType.value)
            put(key = KEY_ERROR_MESSAGE, value = errorMessage)
            put(key = KEY_WILL_FALLBACK, value = willFallback.toString())
            put(key = KEY_REQUEST_ID, value = requestId)
            val duration = System.currentTimeMillis() - startTime
            put(key = KEY_REQUEST_DURATION_MS, value = duration.toString())
            putIfNotNull(
                key = KEY_STATIC_PAYMENT_SYSTEM,
                value = staticPaymentSystem,
            )
        },
    ), DynamicBinInfoEvent

    class IconLoadStarted(
        binWrapper: DynamicBinEventWrapper,
        iconUrl: String,
        isCached: Boolean,
    ) : Event(
        name = DynamicBinInfoEventName.ICON_LOAD_STARTED.valueWithPrefix,
        params = mapOf(
            KEY_PREFIX to binWrapper.maskedPrefix,
            KEY_ICON_URL to iconUrl,
            KEY_IS_CACHED to isCached.toString(),
        ),
    ), DynamicBinInfoEvent

    class IconLoadSuccess(
        binWrapper: DynamicBinEventWrapper,
        iconUrl: String,
        imageSizeBytes: Int?,
        startTime: Long,
        wasCached: Boolean,
    ) : Event(
        name = DynamicBinInfoEventName.ICON_LOAD_SUCCESS.valueWithPrefix,
        params = buildMap {
            put(key = KEY_PREFIX, value = binWrapper.maskedPrefix)
            put(key = KEY_ICON_URL, value = iconUrl)
            put(key = KEY_WAS_CACHED, value = wasCached.toString())
            val duration = System.currentTimeMillis() - startTime
            put(key = KEY_LOAD_DURATION_MS, value = duration.toString())
            putIfNotNull(
                key = KEY_IMAGE_SIZE_BYTES,
                value = imageSizeBytes?.toString(),
            )
        },
    ), DynamicBinInfoEvent

    class IconLoadFailed(
        binWrapper: DynamicBinEventWrapper,
        errorMessage: String,
        errorType: DynamicBinInfoAnalyticsErrorType,
        iconUrl: String,
        startTime: Long,
        willFallback: Boolean,
    ) : Event(
        name = DynamicBinInfoEventName.ICON_LOAD_FAILED.valueWithPrefix,
        params = buildMap {
            put(key = KEY_PREFIX, value = binWrapper.maskedPrefix)
            put(key = KEY_ICON_URL, value = iconUrl)
            put(key = KEY_ERROR_TYPE, value = errorType.value)
            put(key = KEY_ERROR_MESSAGE, value = errorMessage)
            put(key = KEY_WILL_FALLBACK, value = willFallback.toString())
            val duration = System.currentTimeMillis() - startTime
            put(key = KEY_LOAD_DURATION_MS, value = duration.toString())
        },
    ), DynamicBinInfoEvent

    class DataApplied(
        binWrapper: DynamicBinEventWrapper,
        cardNumberLength: Int,
        dataSource: DynamicBinInfoAnalyticsDataSource,
        iconSource: DynamicBinInfoAnalyticsDataSource?,
        paymentSystem: String,
        startTime: Long,
        staticPaymentSystem: String?,
        systemsMatch: Boolean?,
    ) : Event(
        name = DynamicBinInfoEventName.DATA_APPLIED.valueWithPrefix,
        params = buildMap {
            put(key = KEY_PREFIX, value = binWrapper.maskedPrefix)
            put(key = KEY_PAYMENT_SYSTEM, value = paymentSystem)
            put(key = KEY_DATA_SOURCE, value = dataSource.value)
            put(key = KEY_HAS_ICON, value = (iconSource != null).toString())
            put(key = KEY_CARD_NUMBER_LENGTH, value = cardNumberLength.toString())
            val duration = System.currentTimeMillis() - startTime
            put(key = KEY_TIME_SINCE_REQUEST_START_MS, value = duration.toString())
            putIfNotNull(
                key = KEY_ICON_SOURCE,
                value = iconSource?.toString(),
            )
            putIfNotNull(
                key = KEY_STATIC_PAYMENT_SYSTEM,
                value = staticPaymentSystem,
            )
            putIfNotNull(
                key = KEY_SYSTEMS_MATCH,
                value = systemsMatch?.toString(),
            )
        },
    ), DynamicBinInfoEvent

    class FallbackToStatic(
        cardNumberLength: Int,
        failedPrefixes: List<DynamicBinEventWrapper>,
        failedRequestsCount: Int,
        iconSource: DynamicBinInfoAnalyticsDataSource,
        staticPaymentSystem: String?,
        timeSinceFirstRequestMs: Long?,
        totalRequestsCount: Int,
    ) : Event(
        name = DynamicBinInfoEventName.FALLBACK_TO_STATIC.valueWithPrefix,
        params = buildMap {
            put(key = KEY_CARD_NUMBER_LENGTH, value = cardNumberLength.toString())
            put(
                key = KEY_FAILED_PREFIXES,
                value = failedPrefixes.joinToString(separator = ",") { it.maskedPrefix },
            )
            put(key = KEY_TOTAL_REQUESTS_COUNT, value = totalRequestsCount.toString())
            put(key = KEY_FAILED_REQUESTS_COUNT, value = failedRequestsCount.toString())
            put(key = KEY_ICON_SOURCE, value = iconSource.value)
            putIfNotNull(
                key = KEY_STATIC_PAYMENT_SYSTEM,
                value = staticPaymentSystem,
            )
            putIfNotNull(
                key = KEY_TIME_SINCE_FIRST_REQUEST_MS,
                value = timeSinceFirstRequestMs?.toString(),
            )
        },
    ), DynamicBinInfoEvent

    class DataStateOnSubmit(
        cardNumberLength: Int,
        dataSource: DynamicBinInfoAnalyticsDataSource,
        failedPrefixes: List<DynamicBinEventWrapper>,
        hasDynamicData: Boolean,
        hasPendingRequests: Boolean,
        iconSource: DynamicBinInfoAnalyticsDataSource?,
        paymentSystem: String?,
        pendingPrefixes: List<DynamicBinEventWrapper>,
        staticPaymentSystem: String?,
        successfulPrefixes: List<DynamicBinEventWrapper>,
        systemsMatch: Boolean?,
        timeSinceFirstRequestMs: Long?,
        trigger: DynamicBinInfoAnalyticsTrigger,
    ) : Event(
        name = DynamicBinInfoEventName.DATA_STATE_ON_SUBMIT.valueWithPrefix,
        params = buildMap {
            put(key = KEY_CARD_NUMBER_LENGTH, value = cardNumberLength.toString())
            put(key = KEY_DATA_SOURCE, value = dataSource.value)
            put(key = KEY_HAS_DYNAMIC_DATA, value = hasDynamicData.toString())
            put(key = KEY_HAS_PENDING_REQUESTS, value = hasPendingRequests.toString())
            put(
                key = KEY_PENDING_PREFIXES,
                value = pendingPrefixes.joinToString(separator = ",") { it.maskedPrefix },
            )
            put(
                key = KEY_SUCCESSFUL_PREFIXES,
                value = successfulPrefixes.joinToString(separator = ",") { it.maskedPrefix },
            )
            put(
                key = KEY_FAILED_PREFIXES,
                value = failedPrefixes.joinToString(separator = ",") { it.maskedPrefix },
            )
            put(key = KEY_HAS_ICON, value = (iconSource != null).toString())
            put(key = KEY_TRIGGER, value = trigger.value)
            putIfNotNull(
                key = KEY_PAYMENT_SYSTEM,
                value = paymentSystem,
            )
            putIfNotNull(
                key = KEY_ICON_SOURCE,
                value = iconSource?.value,
            )
            putIfNotNull(
                key = KEY_STATIC_PAYMENT_SYSTEM,
                value = staticPaymentSystem,
            )
            putIfNotNull(
                key = KEY_SYSTEMS_MATCH,
                value = systemsMatch?.toString(),
            )
            putIfNotNull(
                key = KEY_TIME_SINCE_FIRST_REQUEST_MS,
                value = timeSinceFirstRequestMs?.toString(),
            )
        },
    ), DynamicBinInfoEvent

    class RequestsRace(
        paymentSystem3: String?,
        paymentSystem8: String?,
        prefix3DurationMs: Int?,
        prefix3Status: String,
        prefix8DurationMs: Int?,
        prefix8Status: String,
        systemsMatch: Boolean?,
        usedPrefix: DynamicBinEventWrapper,
    ) : Event(
        name = DynamicBinInfoEventName.REQUESTS_RACE.valueWithPrefix,
        params = buildMap {
            put(key = KEY_PREFIX_3_STATUS, value = prefix3Status)
            put(key = KEY_PREFIX_8_STATUS, value = prefix8Status)
            put(key = KEY_USED_PREFIX, value = usedPrefix.maskedPrefix)
            putIfNotNull(
                key = KEY_PREFIX_3_DURATION_MS,
                value = prefix3DurationMs?.toString(),
            )
            putIfNotNull(
                key = KEY_PREFIX_8_DURATION_MS,
                value = prefix8DurationMs?.toString(),
            )
            putIfNotNull(
                key = KEY_PAYMENT_SYSTEM_3,
                value = paymentSystem3,
            )
            putIfNotNull(
                key = KEY_PAYMENT_SYSTEM_8,
                value = paymentSystem8,
            )
            putIfNotNull(
                key = KEY_SYSTEMS_MATCH,
                value = systemsMatch?.toString(),
            )
        },
    ), DynamicBinInfoEvent

    class RequestCached(
        binWrapper: DynamicBinEventWrapper,
        paymentSystem: String,
    ) : Event(
        name = DynamicBinInfoEventName.REQUEST_CACHED.valueWithPrefix,
        params = mapOf(
            KEY_PREFIX to binWrapper.maskedPrefix,
            KEY_PREFIX_LENGTH to binWrapper.originalPrefixLength.toString(),
            KEY_PAYMENT_SYSTEM to paymentSystem,
        ),
    ), DynamicBinInfoEvent

    class DataReset(
        previousPrefixes: List<DynamicBinEventWrapper>,
        cardNumberLength: Int,
        resetReason: DynamicBinInfoAnalyticsResetReason,
    ) : Event(
        name = DynamicBinInfoEventName.DATA_RESET.valueWithPrefix,
        params = mapOf(
            KEY_PREVIOUS_PREFIXES to previousPrefixes.joinToString(separator = ",") { it.maskedPrefix },
            KEY_CARD_NUMBER_LENGTH to cardNumberLength.toString(),
            KEY_RESET_REASON to resetReason.value,
        ),
    ), DynamicBinInfoEvent

    class StaticDataApplied(
        cardNumberLength: Int,
        paymentSystem: String,
        reason: DynamicBinInfoAnalyticsStaticDataReason,
    ) : Event(
        name = DynamicBinInfoEventName.STATIC_DATA_APPLIED.valueWithPrefix,
        params = mapOf(
            KEY_PAYMENT_SYSTEM to paymentSystem,
            KEY_CARD_NUMBER_LENGTH to cardNumberLength.toString(),
            KEY_REASON to reason.value,
        ),
    ), DynamicBinInfoEvent

    companion object {
        private const val KEY_CARD_NUMBER_LENGTH = "card_number_length"
        private const val KEY_DATA_SOURCE = "data_source"
        private const val KEY_ENABLED = "enabled"
        private const val KEY_ERROR_MESSAGE = "error_message"
        private const val KEY_ERROR_TYPE = "error_type"
        private const val KEY_FAILED_PREFIXES = "failed_prefixes"
        private const val KEY_FAILED_REQUESTS_COUNT = "failed_requests_count"
        private const val KEY_HAS_DYNAMIC_DATA = "has_dynamic_data"
        private const val KEY_HAS_ICON = "has_icon"
        private const val KEY_HAS_ICON_URL = "has_icon_url"
        private const val KEY_HAS_PENDING_REQUESTS = "has_pending_requests"
        private const val KEY_ICON_SOURCE = "icon_source"
        private const val KEY_ICON_URL = "icon_url"
        private const val KEY_IMAGE_SIZE_BYTES = "image_size_bytes"
        private const val KEY_IS_CACHED = "is_cached"
        private const val KEY_LOAD_DURATION_MS = "load_duration_ms"
        private const val KEY_NEXT_ACTION_TIMEOUT_MS = "next_action_timeout_ms"
        private const val KEY_NETWORK_FOUND_IN_TOVARISH = "network_found_in_tovarish"
        private const val KEY_PAYMENT_SYSTEM = "payment_system"
        private const val KEY_PAYMENT_SYSTEM_3 = "payment_system_3"
        private const val KEY_PAYMENT_SYSTEM_8 = "payment_system_8"
        private const val KEY_PENDING_PREFIXES = "pending_prefixes"
        private const val KEY_PREFIX = "prefix"
        private const val KEY_PREFIX_LENGTH = "prefix_length"
        private const val KEY_PREFIX_3_DURATION_MS = "prefix_3_duration_ms"
        private const val KEY_PREFIX_3_STATUS = "prefix_3_status"
        private const val KEY_PREFIX_8_DURATION_MS = "prefix_8_duration_ms"
        private const val KEY_PREFIX_8_STATUS = "prefix_8_status"
        private const val KEY_PREVIOUS_PREFIXES = "previous_prefixes"
        private const val KEY_REASON = "reason"
        private const val KEY_REQUEST_DURATION_MS = "request_duration_ms"
        private const val KEY_REQUEST_ID = "request_id"
        private const val KEY_RESET_REASON = "reset_reason"
        private const val KEY_STATIC_PAYMENT_SYSTEM = "static_payment_system"
        private const val KEY_SUCCESSFUL_PREFIXES = "successful_prefixes"
        private const val KEY_SYSTEMS_MATCH = "systems_match"
        private const val KEY_TIME_SINCE_FIRST_REQUEST_MS = "time_since_first_request_ms"
        private const val KEY_TIME_SINCE_REQUEST_START_MS = "time_since_request_start_ms"
        private const val KEY_TOVARISH_NETWORKS_COUNT = "tovarish_networks_count"
        private const val KEY_TOTAL_REQUESTS_COUNT = "total_requests_count"
        private const val KEY_TRIGGER = "trigger"
        private const val KEY_USED_PREFIX = "used_prefix"
        private const val KEY_WAS_CACHED = "was_cached"
        private const val KEY_WILL_FALLBACK = "will_fallback"
        private const val KEY_WITHOUT_CVN = "without_cvn"
    }
}

internal fun Analytics?.reportDynamicBinEvent(
    event: DynamicBinInfoEvent,
    isFeatureEnabled: Boolean,
) {
    if (this == null) return
    if (event.requiresFeatureEnabled && !isFeatureEnabled) return
    reportProductEvent(event as Event)
}
