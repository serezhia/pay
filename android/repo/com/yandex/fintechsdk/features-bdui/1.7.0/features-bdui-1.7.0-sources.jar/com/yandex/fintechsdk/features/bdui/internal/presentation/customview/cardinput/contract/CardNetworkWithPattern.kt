package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

internal data class CardNetworkWithPattern(
    val cardNetwork: CardNetwork,
    val pattern: CardNetworkPattern,
)
