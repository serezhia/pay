package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics

import com.yandex.fintechsdk.core.analytics.api.event.Event
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.Step

internal data class FieldFocusedEvent(
    val fieldType: String,
    val formStep: String,
) : Event(
    name = CardInputAnalyticsConstants.EventName.FIELD_FOCUSED,
    params = mapOf(
        CardInputAnalyticsConstants.ParamKey.FIELD_TYPE to fieldType,
        CardInputAnalyticsConstants.ParamKey.FORM_STEP to formStep,
    ),
)

internal data class FieldCompletedEvent(
    val fieldType: String,
    val formStep: String,
) : Event(
    name = CardInputAnalyticsConstants.EventName.FIELD_COMPLETED,
    params = mapOf(
        CardInputAnalyticsConstants.ParamKey.FIELD_TYPE to fieldType,
        CardInputAnalyticsConstants.ParamKey.FORM_STEP to formStep,
    ),
)

internal data class FieldValidationFailedEvent(
    val fieldType: String,
    val error: String,
    val trigger: String,
    val formStep: String,
) : Event(
    name = CardInputAnalyticsConstants.EventName.VALIDATION_FAILED,
    params = mapOf(
        CardInputAnalyticsConstants.ParamKey.FIELD_TYPE to fieldType,
        CardInputAnalyticsConstants.ParamKey.ERROR to error,
        CardInputAnalyticsConstants.ParamKey.TRIGGER to trigger,
        CardInputAnalyticsConstants.ParamKey.FORM_STEP to formStep,
    ),
)

internal data class FetchImageFailedEvent(
    val error: String,
    val url: String,
) : Event(
    name = CardInputAnalyticsConstants.EventName.FETCH_IMAGE_FAILED,
    params = mapOf(
        CardInputAnalyticsConstants.ParamKey.ERROR to error,
        CardInputAnalyticsConstants.ParamKey.URL to url,
    ),
)

internal object FormSubmittedEvent : Event(
    name = CardInputAnalyticsConstants.EventName.FORM_SUBMITTED,
    params = mapOf(
        CardInputAnalyticsConstants.ParamKey.FORM_STEP to CardInputAnalyticsConstants.FormStep.SUBMITTED,
    ),
)


internal object CardInputAnalyticsConstants {

    object EventName {
        const val FIELD_FOCUSED = "card_input_field_focused"
        const val FIELD_COMPLETED = "card_input_field_completed"
        const val VALIDATION_FAILED = "card_input_field_validation_failed"
        const val FORM_SUBMITTED = "card_input_form_submitted"
        const val FETCH_IMAGE_FAILED = "card_input_fetch_image_failed"
    }

    object ParamKey {
        const val FIELD_TYPE = "field_type"
        const val FORM_STEP = "form_step"
        const val ERROR = "error"
        const val TRIGGER = "trigger"
        const val URL = "url"
    }

    object FormStep {
        const val SUBMITTED = "submitted"
        const val CARD_NUMBER_INPUT = "card_number_input"
        const val DATE_INPUT = "date_input"
        const val CVV_INPUT = "cvv_input"
    }

    object FieldType {
        const val CARD_NUMBER = "card_number"
        const val EXPIRATION_DATE = "expiration_date"
        const val CVV = "cvv"
    }

    object ValidationError {
        const val INVALID_CARD_NUMBER = "Invalid card number"
        const val INVALID_EXPIRATION_DATE = "Invalid expiration date"
        const val INVALID_CVV = "Invalid CVV"
    }

    object Trigger {
        const val CHANGE = "change"
    }
}

internal fun Step.asEventParamValue(): String {
    return when (this) {
        is Step.CardBinding -> CardInputAnalyticsConstants.FormStep.SUBMITTED
        Step.CardCvv -> CardInputAnalyticsConstants.FormStep.CVV_INPUT
        Step.CardExpirationDate -> CardInputAnalyticsConstants.FormStep.DATE_INPUT
        Step.CardNumber -> CardInputAnalyticsConstants.FormStep.CARD_NUMBER_INPUT
    }
}
