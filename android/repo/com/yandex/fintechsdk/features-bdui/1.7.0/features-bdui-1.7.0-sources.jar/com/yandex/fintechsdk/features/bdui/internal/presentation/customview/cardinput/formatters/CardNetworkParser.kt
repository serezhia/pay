package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetwork

internal class CardNetworkParser {

    fun mapPaymentSystemToCardNetwork(paymentSystem: String): CardNetwork {
        return when (paymentSystem.lowercase()) {
            "visa" -> CardNetwork.VISA
            "mastercard" -> CardNetwork.MASTERCARD
            "mir" -> CardNetwork.MIR
            "amex", "american express" -> CardNetwork.AMEX
            "discover" -> CardNetwork.DISCOVER
            "jcb" -> CardNetwork.JCB
            "maestro" -> CardNetwork.MAESTRO
            "unionpay" -> CardNetwork.UNIONPAY
            "uzcard" -> CardNetwork.UZCARD
            "humocard" -> CardNetwork.HUMOCARD
            "visa electron" -> CardNetwork.VISAELECTRON
            else -> CardNetwork.UNKNOWN
        }
    }
}
