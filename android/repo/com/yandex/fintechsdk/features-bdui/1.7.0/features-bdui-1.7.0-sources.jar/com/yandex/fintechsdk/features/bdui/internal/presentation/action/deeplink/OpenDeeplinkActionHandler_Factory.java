package com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class OpenDeeplinkActionHandler_Factory implements Factory<OpenDeeplinkActionHandler> {
  private final Provider<DeeplinkExecutor> deeplinkExecutorProvider;

  private OpenDeeplinkActionHandler_Factory(Provider<DeeplinkExecutor> deeplinkExecutorProvider) {
    this.deeplinkExecutorProvider = deeplinkExecutorProvider;
  }

  @Override
  public OpenDeeplinkActionHandler get() {
    return newInstance(deeplinkExecutorProvider.get());
  }

  public static OpenDeeplinkActionHandler_Factory create(
      Provider<DeeplinkExecutor> deeplinkExecutorProvider) {
    return new OpenDeeplinkActionHandler_Factory(deeplinkExecutorProvider);
  }

  public static OpenDeeplinkActionHandler newInstance(DeeplinkExecutor deeplinkExecutor) {
    return new OpenDeeplinkActionHandler(deeplinkExecutor);
  }
}
