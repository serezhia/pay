package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.interfaces

internal interface CardNumberChangedListener {

    fun onCardNumberChanged(value: String)
}
