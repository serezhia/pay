package com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.hideoverlay;

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CustomHideOverlayActionHandler_Factory implements Factory<CustomHideOverlayActionHandler> {
  private final Provider<FlexAdapter> flexAdapterProvider;

  private CustomHideOverlayActionHandler_Factory(Provider<FlexAdapter> flexAdapterProvider) {
    this.flexAdapterProvider = flexAdapterProvider;
  }

  @Override
  public CustomHideOverlayActionHandler get() {
    return newInstance(flexAdapterProvider.get());
  }

  public static CustomHideOverlayActionHandler_Factory create(
      Provider<FlexAdapter> flexAdapterProvider) {
    return new CustomHideOverlayActionHandler_Factory(flexAdapterProvider);
  }

  public static CustomHideOverlayActionHandler newInstance(@Nullable FlexAdapter flexAdapter) {
    return new CustomHideOverlayActionHandler(flexAdapter);
  }
}
