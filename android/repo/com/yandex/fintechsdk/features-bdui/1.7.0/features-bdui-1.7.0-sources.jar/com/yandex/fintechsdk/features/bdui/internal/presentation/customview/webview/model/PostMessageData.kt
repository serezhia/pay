package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

@Serializable
internal data class PostMessageData(
    @SerialName("type")
    val type: String,
    
    @SerialName("payload")
    val payload: JsonObject? = null,
    
    @SerialName("data")
    val data: JsonElement? = null,
)
