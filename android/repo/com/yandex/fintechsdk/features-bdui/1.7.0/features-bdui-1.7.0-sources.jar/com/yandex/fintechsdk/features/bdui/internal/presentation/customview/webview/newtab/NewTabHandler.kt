package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.newtab

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.net.toUri

internal class NewTabHandler(private val context: Context, private val policy: NewTabPolicy) {

    fun handleUrl(url: String) {
        if (shouldBeSkipped(url = url)) return
        when (policy) {
            NewTabPolicy.Disabled -> Unit
            NewTabPolicy.CustomTabs -> if (!openInCustomTab(url = url)) openInBrowser(url = url)
            NewTabPolicy.ExternalBrowser -> openInBrowser(url = url)
        }
    }

    private fun openInBrowser(url: String) {
        val uri = runCatching { url.toUri() }.getOrNull() ?: return
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addCategory(Intent.CATEGORY_BROWSABLE)
            if (context !is Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    private fun openInCustomTab(url: String): Boolean {
        return runCatching {
            val customTabsIntent = CustomTabsIntent.Builder()
                .setShowTitle(true)
                .build()
                .also { if (context !is Activity) it.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            customTabsIntent.launchUrl(context, url.toUri())
            true
        }.getOrDefault(defaultValue = false)
    }

    private fun shouldBeSkipped(url: String): Boolean {
        val uri = runCatching { url.toUri() }.getOrNull() ?: return true
        val scheme = uri.scheme?.lowercase()
        return scheme != "http" && scheme != "https"
    }
}
