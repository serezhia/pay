package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

internal data class CardNetworkPattern(
    val intervals: List<CardNetworkNumberInterval>,
    val validLengths: List<Int>,
    val cvvLength: Int,
    val spaceIndexes: List<Int>,
)

internal data class CardNetworkNumberInterval(val start: String, val end: String?)
