package com.yandex.fintechsdk.features.bdui.api.dependencies

import com.yandex.fintechsdk.core.network.api.host.HostUrlProvider

public interface BduiHostUrlProvider : HostUrlProvider

