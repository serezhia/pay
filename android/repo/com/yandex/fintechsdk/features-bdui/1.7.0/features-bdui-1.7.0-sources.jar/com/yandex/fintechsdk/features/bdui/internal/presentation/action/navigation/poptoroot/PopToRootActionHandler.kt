package com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.poptoroot

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import javax.inject.Inject

internal class PopToRootActionHandler @Inject constructor(
    private val flexAdapter: FlexAdapter?,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is PopToRootAction) return

        flexAdapter?.getCurrentRouteHandler()?.popToRoot(animated = action.params.animated)
    }
}
