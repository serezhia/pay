package com.yandex.fintechsdk.features.bdui.internal.presentation.action.sendexternalevent

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class SendExternalEventAction(
    @SerialName("event")
    val event: String,

    @SerialName("params")
    val params: Map<String, String>? = null,
): BduiAction
