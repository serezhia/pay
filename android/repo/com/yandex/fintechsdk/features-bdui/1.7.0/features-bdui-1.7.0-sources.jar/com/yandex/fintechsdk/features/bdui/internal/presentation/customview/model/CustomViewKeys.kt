package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.model

internal object CustomViewKeys {
    internal const val WEB_VIEW_KEY: String = "DivCustomWebView"
    internal const val CARD_INPUT_VIEW_KEY: String = "DivCustomCardInputView"
    internal const val LOADER_VIEW_KEY: String = "DivCustomLoaderView"
    internal const val BARCODE_VIEW_KEY: String = "barcode"
}
