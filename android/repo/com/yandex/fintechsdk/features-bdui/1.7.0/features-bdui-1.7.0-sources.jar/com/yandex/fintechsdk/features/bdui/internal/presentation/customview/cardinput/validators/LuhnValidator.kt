package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.validators

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNumber

internal class LuhnValidator : Validator<CardNumber> {

    @Suppress("MagicNumber") // TODO: define numbers as well named constant
    override fun validate(verifiable: CardNumber): Boolean {
        return verifiable.value
            .replace(" ", "")
            .reversed()
            .map(Character::getNumericValue)
            .mapIndexed { index, digit ->
                when {
                    index % 2 == 0 -> digit
                    digit < 5 -> digit * 2
                    else -> digit * 2 - 9
                }
            }
            .sum() % 10 == 0
    }
}
