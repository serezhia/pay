package com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.NestedAction
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class DeviceChallengePubkeyAction(
    @SerialName("analyticsParams")
    val analyticsParams: Map<String, String>? = null,

    @SerialName("onCompleteAction")
    val onCompleteAction: @Contextual NestedAction? = null,

    @SerialName("publicKeyVarPath")
    val publicKeyVarPath: List<String>? = null,
) : BduiAction
