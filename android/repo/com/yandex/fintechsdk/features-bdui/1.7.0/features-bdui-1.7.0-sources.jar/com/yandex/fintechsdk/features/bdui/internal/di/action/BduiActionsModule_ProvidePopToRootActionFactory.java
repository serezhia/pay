package com.yandex.fintechsdk.features.bdui.internal.di.action;

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction;
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionInfo;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.poptoroot.PopToRootActionHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiActionsModule_ProvidePopToRootActionFactory implements Factory<BduiActionInfo<BduiAction>> {
  private final BduiActionsModule module;

  private final Provider<PopToRootActionHandler> handlerProvider;

  private BduiActionsModule_ProvidePopToRootActionFactory(BduiActionsModule module,
      Provider<PopToRootActionHandler> handlerProvider) {
    this.module = module;
    this.handlerProvider = handlerProvider;
  }

  @Override
  public BduiActionInfo<BduiAction> get() {
    return providePopToRootAction(module, handlerProvider.get());
  }

  public static BduiActionsModule_ProvidePopToRootActionFactory create(BduiActionsModule module,
      Provider<PopToRootActionHandler> handlerProvider) {
    return new BduiActionsModule_ProvidePopToRootActionFactory(module, handlerProvider);
  }

  public static BduiActionInfo<BduiAction> providePopToRootAction(BduiActionsModule instance,
      PopToRootActionHandler handler) {
    return Preconditions.checkNotNullFromProvides(instance.providePopToRootAction(handler));
  }
}
