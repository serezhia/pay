package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils

/**
 * A utility class for holding and managing patch payloads.
 *
 * Allows storing values at specific paths within a nested map structure,
 * which can be retrieved as a payload for patch operations.
 */
internal class PatchHolder {

    private val payload: MutableMap<String, Any> = mutableMapOf()

    fun getPayload(): Map<String, Map<String, Any>>? {
        @Suppress("UNCHECKED_CAST")
        return payload as? Map<String, Map<String, Any>>
    }

    fun storeValue(path: List<String>, value: Any) {
        payload.storeValueRecursive(path = path, value = value)
    }
}
