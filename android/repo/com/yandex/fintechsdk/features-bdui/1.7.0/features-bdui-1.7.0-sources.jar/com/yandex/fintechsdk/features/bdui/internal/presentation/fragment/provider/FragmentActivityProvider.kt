package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider

import androidx.fragment.app.FragmentActivity
import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import com.yandex.fintechsdk.core.utils.api.provider.BaseProvider
import javax.inject.Inject

@FeatureScope
internal class FragmentActivityProvider @Inject constructor() : BaseProvider<FragmentActivity>()
