package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.validators

internal interface Validator<T> {
    fun validate(verifiable: T): Boolean
}
