package com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import javax.inject.Inject

internal class OpenBrowserActionHandler @Inject constructor(
    private val chromeTabLaunchActionsStore: ChromeTabLaunchActionsStore,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is OpenBrowserAction) return

        chromeTabLaunchActionsStore.send(action.url)
    }
}
