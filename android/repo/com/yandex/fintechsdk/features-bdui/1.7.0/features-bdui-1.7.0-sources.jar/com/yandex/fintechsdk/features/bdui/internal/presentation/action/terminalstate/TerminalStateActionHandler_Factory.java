package com.yandex.fintechsdk.features.bdui.internal.presentation.action.terminalstate;

import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class TerminalStateActionHandler_Factory implements Factory<TerminalStateActionHandler> {
  private final Provider<BduiActionsDelegate> actionsDelegateProvider;

  private TerminalStateActionHandler_Factory(
      Provider<BduiActionsDelegate> actionsDelegateProvider) {
    this.actionsDelegateProvider = actionsDelegateProvider;
  }

  @Override
  public TerminalStateActionHandler get() {
    return newInstance(actionsDelegateProvider.get());
  }

  public static TerminalStateActionHandler_Factory create(
      Provider<BduiActionsDelegate> actionsDelegateProvider) {
    return new TerminalStateActionHandler_Factory(actionsDelegateProvider);
  }

  public static TerminalStateActionHandler newInstance(BduiActionsDelegate actionsDelegate) {
    return new TerminalStateActionHandler(actionsDelegate);
  }
}
