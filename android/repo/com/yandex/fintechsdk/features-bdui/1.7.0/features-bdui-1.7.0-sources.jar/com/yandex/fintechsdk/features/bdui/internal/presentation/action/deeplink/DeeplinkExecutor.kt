package com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.core.net.toUri
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider
import javax.inject.Inject

/**
 * Result of deeplink execution
 */
internal enum class DeeplinkResult {
    SUCCESS,       // Deeplink opened successfully
    FAILURE,       // Error occurred while opening
    NO_APP_FOUND,  // No application found to handle the deeplink
}

/**
 * Deeplink executor - class for working with Android Intent System
 */
internal class DeeplinkExecutor @Inject constructor(
    private val contextProvider: ContextProvider,
) {

    /**
     * Executes deeplink opening
     *
     * @param deeplink URL to open (custom scheme or https)
     * @param universalLinksOnly If true, only open universal links (https)
     * @return Result of the operation
     */
    fun execute(deeplink: String, universalLinksOnly: Boolean?): DeeplinkResult {
        return try {
            val context = contextProvider.get() ?: return DeeplinkResult.FAILURE

            val uri = deeplink.toUri()

            // URL validation
            if (uri.scheme.isNullOrEmpty()) {
                return DeeplinkResult.FAILURE
            }

            // Check universal links only mode
            if (universalLinksOnly == true && uri.scheme != HTTPS_SCHEME) {
                return DeeplinkResult.FAILURE
            }

            // Create and execute Intent
            val intent = createDeeplinkIntent(uri = uri)
            context.startActivity(intent)

            DeeplinkResult.SUCCESS

        } catch (_: ActivityNotFoundException) {
            DeeplinkResult.NO_APP_FOUND
        } catch (_: Exception) {
            DeeplinkResult.FAILURE
        }
    }

    /**
     * Creates Intent for opening deeplink
     */
    private fun createDeeplinkIntent(uri: Uri): Intent {
        return Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            if (uri.scheme != HTTPS_SCHEME) {
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
        }
    }

    companion object {
        private const val HTTPS_SCHEME = "https"
    }
}
