package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

@JvmInline
internal value class CardNumber(val value: String)
