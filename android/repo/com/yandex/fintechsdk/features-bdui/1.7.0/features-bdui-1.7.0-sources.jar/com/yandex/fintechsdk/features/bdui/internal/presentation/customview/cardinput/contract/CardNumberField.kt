package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

internal data class CardNumberField(
    val cardNumber: CardNumber,
    val showValidationStatus: Boolean,
    val validationStatus: ValidationStatus,
)

internal enum class TextState {
    REGULAR, MASKED
}
