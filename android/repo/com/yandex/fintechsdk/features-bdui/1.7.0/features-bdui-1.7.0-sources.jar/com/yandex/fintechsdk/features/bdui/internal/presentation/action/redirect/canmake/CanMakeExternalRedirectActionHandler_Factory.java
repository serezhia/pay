package com.yandex.fintechsdk.features.bdui.internal.presentation.action.redirect.canmake;

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CanMakeExternalRedirectActionHandler_Factory implements Factory<CanMakeExternalRedirectActionHandler> {
  private final Provider<ContextProvider> contextProvider;

  private final Provider<FlexAdapter> flexAdapterProvider;

  private CanMakeExternalRedirectActionHandler_Factory(Provider<ContextProvider> contextProvider,
      Provider<FlexAdapter> flexAdapterProvider) {
    this.contextProvider = contextProvider;
    this.flexAdapterProvider = flexAdapterProvider;
  }

  @Override
  public CanMakeExternalRedirectActionHandler get() {
    return newInstance(contextProvider.get(), flexAdapterProvider.get());
  }

  public static CanMakeExternalRedirectActionHandler_Factory create(
      Provider<ContextProvider> contextProvider, Provider<FlexAdapter> flexAdapterProvider) {
    return new CanMakeExternalRedirectActionHandler_Factory(contextProvider, flexAdapterProvider);
  }

  public static CanMakeExternalRedirectActionHandler newInstance(ContextProvider contextProvider,
      @Nullable FlexAdapter flexAdapter) {
    return new CanMakeExternalRedirectActionHandler(contextProvider, flexAdapter);
  }
}
