package com.yandex.fintechsdk.features.bdui.internal.di.action;

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction;
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionInfo;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.plus.OpenPlusActionHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiActionsModule_ProvideOpenPlusActionFactory implements Factory<BduiActionInfo<BduiAction>> {
  private final BduiActionsModule module;

  private final Provider<OpenPlusActionHandler> handlerProvider;

  private BduiActionsModule_ProvideOpenPlusActionFactory(BduiActionsModule module,
      Provider<OpenPlusActionHandler> handlerProvider) {
    this.module = module;
    this.handlerProvider = handlerProvider;
  }

  @Override
  public BduiActionInfo<BduiAction> get() {
    return provideOpenPlusAction(module, handlerProvider.get());
  }

  public static BduiActionsModule_ProvideOpenPlusActionFactory create(BduiActionsModule module,
      Provider<OpenPlusActionHandler> handlerProvider) {
    return new BduiActionsModule_ProvideOpenPlusActionFactory(module, handlerProvider);
  }

  public static BduiActionInfo<BduiAction> provideOpenPlusAction(BduiActionsModule instance,
      OpenPlusActionHandler handler) {
    return Preconditions.checkNotNullFromProvides(instance.provideOpenPlusAction(handler));
  }
}
