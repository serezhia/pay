package com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ChromeTabLaunchActionsStore_Factory implements Factory<ChromeTabLaunchActionsStore> {
  @Override
  public ChromeTabLaunchActionsStore get() {
    return newInstance();
  }

  public static ChromeTabLaunchActionsStore_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ChromeTabLaunchActionsStore newInstance() {
    return new ChromeTabLaunchActionsStore();
  }

  private static final class InstanceHolder {
    static final ChromeTabLaunchActionsStore_Factory INSTANCE = new ChromeTabLaunchActionsStore_Factory();
  }
}
