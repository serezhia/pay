package com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.hideoverlay

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class CustomHideOverlayAction(
    @SerialName("params")
    val params: Params,
) : BduiAction {

    @Serializable
    internal data class Params(
        @SerialName("tag")
        val tag: String,
    )
}

