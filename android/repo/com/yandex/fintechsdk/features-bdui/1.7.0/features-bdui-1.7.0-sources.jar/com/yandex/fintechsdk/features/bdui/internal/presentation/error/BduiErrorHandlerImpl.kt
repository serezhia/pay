package com.yandex.fintechsdk.features.bdui.internal.presentation.error

import com.yandex.fintechsdk.core.bdui.api.eventhandler.BduiErrorHandler
import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.BduiNavigator
import javax.inject.Inject

internal class BduiErrorHandlerImpl @Inject constructor(
    private val bduiNavigator: BduiNavigator,
) : BduiErrorHandler {

    override fun handle(query: BduiDocumentQuery, throwable: Throwable, responseCode: Int?) {
        bduiNavigator.onError(
            query = query,
            throwable = throwable,
            responseCode = responseCode,
        )
    }
}
