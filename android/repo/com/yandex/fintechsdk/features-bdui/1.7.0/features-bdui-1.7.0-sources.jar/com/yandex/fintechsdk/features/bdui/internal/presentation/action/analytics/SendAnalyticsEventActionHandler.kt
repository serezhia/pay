package com.yandex.fintechsdk.features.bdui.internal.presentation.action.analytics

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.analytics.api.event.Event
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import javax.inject.Inject

internal class SendAnalyticsEventActionHandler @Inject constructor(
    private val analytics: Analytics,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is SendAnalyticsEventAction) return

        analytics.reportProductEvent(
            event = Event(
                name = action.eventName,
                params = action.params ?: emptyMap(),
            )
        )
    }
}
