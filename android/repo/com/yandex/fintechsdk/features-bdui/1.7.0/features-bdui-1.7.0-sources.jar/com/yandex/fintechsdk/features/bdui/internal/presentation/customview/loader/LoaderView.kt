package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.loader

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.PorterDuff
import android.view.animation.LinearInterpolator
import androidx.appcompat.content.res.AppCompatResources
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.graphics.drawable.DrawableCompat
import com.yandex.fintechsdk.core.bdui.api.customview.expression.BduiExpressionResolver
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.loader.model.LoaderViewCustomProps
import com.yandex.fintechsdk.resources.api.ResDrawable

internal class LoaderView(
    context: Context,
    private val params: LoaderViewCustomProps?,
) : AppCompatImageView(context) {

    init {
        background = AppCompatResources.getDrawable(context, ResDrawable.finsdk_ic_loading_circle)
        initLoading()
    }

    fun applyExpressionResolver(expressionResolver: BduiExpressionResolver?) {
        params?.let { props ->
            expressionResolver?.let { resolver ->
                val color = resolver.resolveColor(props.strokeColorExpression)
                color?.let { setStrokeColor(it) }
            }
        }
    }

    private fun setStrokeColor(color: Int) {
        background?.let { drawable ->
            val wrappedDrawable = DrawableCompat.wrap(drawable).mutate()
            DrawableCompat.setTint(wrappedDrawable, color)
            DrawableCompat.setTintMode(wrappedDrawable, PorterDuff.Mode.SRC_IN)
            background = wrappedDrawable
        }
    }

    private fun initLoading() {
        ObjectAnimator.ofFloat(this, ROTATION_NAME, ROTATION_VALUE_START, ROTATION_VALUE_END).also {
            it.repeatCount = ObjectAnimator.INFINITE
            it.duration = ROTATION_DURATION
            it.interpolator = LinearInterpolator()
            it.start()
        }
    }

    private companion object {
        const val ROTATION_NAME = "rotation"
        const val ROTATION_VALUE_START = 0F
        const val ROTATION_VALUE_END = 360F
        const val ROTATION_DURATION = 1000L
    }
}
