package com.yandex.fintechsdk.features.bdui.internal.presentation.action.redirect.canmake

import android.content.Context
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.core.utils.api.packagemanager.isAppInstalled
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider
import javax.inject.Inject

internal class CanMakeExternalRedirectActionHandler @Inject constructor(
    private val contextProvider: ContextProvider,
    private val flexAdapter: FlexAdapter?,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is CanMakeExternalRedirectAction) return

        val context = contextProvider.get() ?: return

        val canMakeExternalRedirect = canMakeExternalRedirect(
            context = context,
            packageName = action.packageName,
        )

        flexAdapter?.updateVariable(variableName = action.boolVariableName, newValue = canMakeExternalRedirect)
    }

    private fun canMakeExternalRedirect(
        context: Context,
        packageName: String,
    ): Boolean = context.packageManager.isAppInstalled(packageName = packageName)
}
