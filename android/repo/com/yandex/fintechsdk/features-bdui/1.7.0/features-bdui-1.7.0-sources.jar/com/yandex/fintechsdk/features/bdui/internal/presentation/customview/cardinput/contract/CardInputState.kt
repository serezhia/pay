package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinEventWrapper

internal data class CardInputState(
    val cardNumberField: CardNumberField,
    val cvvField: CvvField,
    val expiryDateField: ExpiryDateField,
    @DrawableRes val networkImageRes: Int,
    val networkIconUrl: String?,
    val iconAnalytics: Analytics? = null,
    val iconBinWrapper: DynamicBinEventWrapper? = null,
    @StringRes val securityCodeStringRes: Int,
    val securityCodeLabel: String?,
    val step: Step,
    val trackedIconUrl: String? = null,
    val isCvvHidden: Boolean = false,
)

internal sealed interface Step {
    data object CardNumber : Step
    data object CardExpirationDate : Step
    data object CardCvv : Step
    data class CardBinding(val isInputsLocked: Boolean = false) : Step

    fun isLocker() = this is CardBinding && this.isInputsLocked
}
