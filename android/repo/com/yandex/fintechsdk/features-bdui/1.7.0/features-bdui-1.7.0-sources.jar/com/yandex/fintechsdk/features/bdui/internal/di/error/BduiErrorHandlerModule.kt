package com.yandex.fintechsdk.features.bdui.internal.di.error

import com.yandex.fintechsdk.core.bdui.api.eventhandler.BduiErrorHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.error.BduiErrorHandlerImpl
import dagger.Binds
import dagger.Module

@Module
internal interface BduiErrorHandlerModule {

    @Binds
    fun bindBduiErrorHandler(impl: BduiErrorHandlerImpl): BduiErrorHandler
}
