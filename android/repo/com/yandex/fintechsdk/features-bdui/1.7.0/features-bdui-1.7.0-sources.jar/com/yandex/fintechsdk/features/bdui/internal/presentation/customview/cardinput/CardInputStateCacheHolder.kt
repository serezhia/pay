package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardInputState

internal object CardInputStateCacheHolder {

    @Volatile
    private var cachedState: CardInputState? = null
    val state: CardInputState? get() = cachedState

    fun saveCache(state: CardInputState) {
        synchronized(this) {
            cachedState = state
        }
    }

    fun clearCache() {
        synchronized(this) {
            cachedState = null
        }
    }
}
