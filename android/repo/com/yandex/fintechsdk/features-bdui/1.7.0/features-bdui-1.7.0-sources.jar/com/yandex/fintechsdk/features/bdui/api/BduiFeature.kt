package com.yandex.fintechsdk.features.bdui.api

public object BduiFeature {
    public const val GRAPH_ROUTE: String = "bdui"
}
