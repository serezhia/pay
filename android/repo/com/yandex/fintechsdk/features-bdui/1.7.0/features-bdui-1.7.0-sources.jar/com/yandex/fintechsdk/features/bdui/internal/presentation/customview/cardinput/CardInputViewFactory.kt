package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput

import android.content.Context
import com.yandex.fintechsdk.core.bdui.api.customview.BduiVariableController
import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomActionHandler
import com.yandex.fintechsdk.core.bdui.api.customview.expression.BduiExpressionResolver
import com.yandex.fintechsdk.core.bdui.api.customview.factory.BaseCustomViewFactory
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.model.CustomViewKeys

internal class CardInputViewFactory(
    private val variableController: BduiVariableController,
    private val cardInputViewConfiguration: CardInputViewConfiguration,
) : BaseCustomViewFactory<CardInputMainView, CardInputCustomProps>(
    paramsSerializer = CardInputCustomProps.serializer(),
) {

    override val type: String = CustomViewKeys.CARD_INPUT_VIEW_KEY

    override fun createViewWithParams(
        context: Context,
        params: CardInputCustomProps?,
    ): CardInputMainView {
        // There's no crash - exception is handled on Flex side
        requireNotNull(params) { "CardInputCustomProps must be not null" }

        return CardInputMainView(
            context = context,
            variableController = variableController,
            cardBindingRepository = cardInputViewConfiguration.cardBindingRepository,
            params = params,
            analytics = cardInputViewConfiguration.analytics,
        )
    }

    override fun bindView(
        actionHandler: DivCustomActionHandler,
        view: CardInputMainView,
        expressionResolver: BduiExpressionResolver?,
    ) {
        view.setActionHandler(actionHandler = actionHandler)
        expressionResolver?.let { view.setExpressionResolver(it) }
    }
}
