package com.yandex.fintechsdk.features.bdui.api.di

import com.yandex.fintechsdk.core.architecture.api.feature.graph.FeatureGraphProvider
import com.yandex.fintechsdk.features.bdui.internal.navigation.BduiFeatureGraphProvider
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoSet

@Module
public class BduiModule {

    @Provides
    @IntoSet
    public fun provideFeatureGraphProvider(): FeatureGraphProvider {
        return BduiFeatureGraphProvider()
    }
}
