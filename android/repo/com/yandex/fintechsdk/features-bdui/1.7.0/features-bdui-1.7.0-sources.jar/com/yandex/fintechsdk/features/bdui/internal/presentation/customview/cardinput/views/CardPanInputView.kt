package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.views

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.annotation.AttrRes
import androidx.annotation.DrawableRes
import androidx.annotation.StyleRes
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import com.yandex.fintechsdk.features.bdui.databinding.FinsdkViewCardPanInputBinding
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinEventWrapper
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNetworkImage
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.utils.CardNetworkIconLoader
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.Keyboard
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.setLocked
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.setLockedAndUnclickable
import com.yandex.fintechsdk.features.bdui.R
import com.yandex.fintechsdk.resources.R.color
import kotlin.math.roundToInt

internal class CardPanInputView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    @AttrRes defStyleAttr: Int = 0,
    @StyleRes defStyleRes: Int = 0,
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {

    private var textFieldValue: String
        get() = binding.finsdkPanInputText.text.toString()
        set(value) {
            binding.finsdkPanInputText.setText(value)
        }

    internal val binding: FinsdkViewCardPanInputBinding = FinsdkViewCardPanInputBinding.inflate(LayoutInflater.from(context), this)

    internal var textFieldValueMasked: String
        get() = binding.finsdkPanInputTextMasked.text?.filter(Character::isDigit)?.toString()
            .orEmpty()
        set(value) {
            binding.finsdkPanInputTextMasked.setText(value)
        }

    private val paddingWithIcon: Int = resources.getDimensionPixelSize(R.dimen.finsdk_card_icon_width)
    private val paddingWithoutIcon: Int = binding.finsdkPanInputText.paddingLeft
    private val iconWidthPx: Int = resources.getDimensionPixelSize(R.dimen.finsdk_card_icon_width)
    private var paddingAnimator: ValueAnimator? = null
    private var iconAnimationState: IconAnimationState? = null
    private var lastIconState: CardNetworkImage? = null

    init {
        orientation = VERTICAL
        gravity = Gravity.START or Gravity.CENTER_VERTICAL

        with(receiver = binding) {
            finsdkPanInputTextHint.isVisible = finsdkPanInputText.text.isEmpty()
            finsdkPanInputText.doAfterTextChanged { text ->
                finsdkPanInputTextHint.isVisible = text.isNullOrEmpty()
            }
        }
        setIconWidth(width = 0)
        binding.finsdkPanCardIcon.isInvisible = true
    }

    internal fun setLocked(isLocked: Boolean) {
        with(receiver = binding) {
            finsdkPanInputLabel.setLockedAndUnclickable(isLocked = isLocked)
            finsdkPanInputText.setLocked(isLocked = isLocked)
            finsdkPanInputTextMasked.setLocked(isLocked = isLocked)
        }
    }

    internal fun gainFocus(showKeyboard: Boolean = true) {
        with(receiver = binding.finsdkPanInputText) {
            if (showKeyboard) {
                requestFocus()
                Keyboard.show(view = this)
            }
        }
    }

    internal fun updateCardTypeView(
        analytics: Analytics? = null,
        isDynamicBinEnabled: Boolean,
        binWrapper: DynamicBinEventWrapper? = null,
        @DrawableRes fallbackImage: Int,
        iconUrl: String?,
        trackedIconUrl: String? = null,
    ) {
        val hasIcon = fallbackImage != 0 || !iconUrl.isNullOrBlank()
        val newIconState = CardNetworkImage(fallbackIconRes = fallbackImage, iconUrl = iconUrl)
        val shouldAnimate = newIconState != lastIconState

        if (shouldAnimate) {
            animateIconAndPadding(hasIcon = hasIcon)
            if (hasIcon) {
                binding.finsdkPanCardIcon.isInvisible = false
            }
            lastIconState = newIconState
        }

        if (shouldAnimate) {
            CardNetworkIconLoader.load(
                context = CardNetworkIconLoader.IconLoadContext(
                    analytics = analytics,
                    binWrapper = binWrapper,
                    imageView = binding.finsdkPanCardIcon,
                    isDynamicBinEnabled = isDynamicBinEnabled,
                    trackedIconUrl = trackedIconUrl,
                ),
                request = CardNetworkIconLoader.IconRequest(
                    iconUrl = iconUrl,
                    fallbackRes = fallbackImage,
                )
            )
        }
    }

    internal fun moveCursor() {
        with(receiver = binding.finsdkPanInputText) {
            setSelection(text?.length ?: return)
        }
    }

    internal fun showError(): Boolean {
        hideError()
        return textFieldValue.isNotBlank().also {
            binding.finsdkPanInputLabel.setTextColor(
                ResourcesCompat.getColor(
                    resources,
                    color.finsdk_text_negative,
                    context.theme,
                ),
            )
        }
    }

    internal fun setCardNumberIfNew(text: String) {
        if (binding.finsdkPanInputText.text.toString().replace(oldValue = " ", newValue = "") != text) {
            binding.finsdkPanInputText.setText(text)
        }
    }

    internal fun hideError() {
        binding.finsdkPanInputLabel.setTextColor(
            ResourcesCompat.getColor(
                resources,
                color.finsdk_text_secondary,
                context.theme,
            ),
        )
    }

    private fun animateIconAndPadding(hasIcon: Boolean) {
        val animator = paddingAnimator
        val runningFraction = animator?.takeIf { it.isRunning }?.animatedFraction
        val previousState = iconAnimationState

        val startPadding = when {
            runningFraction != null && previousState != null -> previousState.interpolatePadding(fraction = runningFraction)
            else -> binding.finsdkPanInputText.paddingLeft
        }
        val startWidth = when {
            runningFraction != null && previousState != null -> previousState.interpolateWidth(fraction = runningFraction)
            else -> binding.finsdkPanCardIcon.layoutParams.width
        }

        val endPadding = if (hasIcon) paddingWithIcon else paddingWithoutIcon
        val endWidth = if (hasIcon) iconWidthPx else 0

        if (startPadding == endPadding && startWidth == endWidth) {
            binding.finsdkPanCardIcon.isInvisible = endWidth == 0
            return
        }

        iconAnimationState = IconAnimationState(
            startPadding = startPadding,
            endPadding = endPadding,
            startWidth = startWidth,
            endWidth = endWidth,
        )

        binding.finsdkPanCardIcon.isInvisible = false
        val currentAnimator = paddingAnimator ?: createIconAnimator().also { paddingAnimator = it }
        currentAnimator.start()
    }

    private fun setIconWidth(width: Int) {
        val params = binding.finsdkPanCardIcon.layoutParams
        if (params.width != width) {
            params.width = width
            binding.finsdkPanCardIcon.layoutParams = params
            binding.finsdkPanCardIcon.requestLayout()
        }
    }

    private fun setInputStartPadding(padding: Int) {
        binding.finsdkPanInputText.setPadding(
            padding,
            binding.finsdkPanInputText.paddingTop,
            binding.finsdkPanInputText.paddingRight,
            binding.finsdkPanInputText.paddingBottom,
        )
        binding.finsdkPanInputTextHint.setPadding(
            padding,
            binding.finsdkPanInputTextHint.paddingTop,
            binding.finsdkPanInputTextHint.paddingRight,
            binding.finsdkPanInputTextHint.paddingBottom,
        )
        binding.finsdkPanInputTextMasked.setPadding(
            padding,
            binding.finsdkPanInputTextMasked.paddingTop,
            binding.finsdkPanInputTextMasked.paddingRight,
            binding.finsdkPanInputTextMasked.paddingBottom,
        )
    }

    private fun createIconAnimator(): ValueAnimator {
        return ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ICON_ANIMATION_DURATION_MS
            addUpdateListener { valueAnimator ->
                val state = iconAnimationState ?: return@addUpdateListener
                val fraction = valueAnimator.animatedFraction
                val currentPadding = state.interpolatePadding(fraction = fraction)
                val currentWidth = state.interpolateWidth(fraction = fraction)
                setIconWidth(width = currentWidth)
                setInputStartPadding(padding = currentPadding)
            }
            addListener(IconAnimationListener())
        }
    }

    private data class IconAnimationState(
        val startPadding: Int,
        val endPadding: Int,
        val startWidth: Int,
        val endWidth: Int,
    ) {
        fun interpolatePadding(fraction: Float): Int {
            return (startPadding + (endPadding - startPadding) * fraction).roundToInt()
        }

        fun interpolateWidth(fraction: Float): Int {
            return (startWidth + (endWidth - startWidth) * fraction).roundToInt()
        }
    }

    private inner class IconAnimationListener : AnimatorListenerAdapter() {
        private var wasCancelled = false

        override fun onAnimationStart(animation: Animator) {
            wasCancelled = false
        }

        override fun onAnimationCancel(animation: Animator) {
            wasCancelled = true
        }

        override fun onAnimationEnd(animation: Animator) {
            if (wasCancelled) return
            val state = iconAnimationState ?: return
            setIconWidth(width = state.endWidth)
            binding.finsdkPanCardIcon.isInvisible = state.endWidth == 0
            setInputStartPadding(padding = state.endPadding)
        }
    }

    private companion object {
        private const val ICON_ANIMATION_DURATION_MS = 200L
    }
}
