package com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink;

import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeeplinkExecutor_Factory implements Factory<DeeplinkExecutor> {
  private final Provider<ContextProvider> contextProvider;

  private DeeplinkExecutor_Factory(Provider<ContextProvider> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public DeeplinkExecutor get() {
    return newInstance(contextProvider.get());
  }

  public static DeeplinkExecutor_Factory create(Provider<ContextProvider> contextProvider) {
    return new DeeplinkExecutor_Factory(contextProvider);
  }

  public static DeeplinkExecutor newInstance(ContextProvider contextProvider) {
    return new DeeplinkExecutor(contextProvider);
  }
}
