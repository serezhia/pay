package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.net.toUri
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updateLayoutParams
import androidx.core.view.updateMargins
import com.yandex.fintechsdk.core.architecture.api.component.injectFeatureComponentStore
import com.yandex.fintechsdk.core.architecture.api.fragment.BaseFragment
import com.yandex.fintechsdk.core.architecture.api.fragment.viewBinding
import com.yandex.fintechsdk.core.architecture.api.viewmodel.injectViewModel
import com.yandex.fintechsdk.core.ui.impl.api.shimmers.ShimmersFragment
import com.yandex.fintechsdk.features.bdui.R
import com.yandex.fintechsdk.features.bdui.databinding.FinsdkFragmentBduiBinding
import com.yandex.fintechsdk.features.bdui.internal.di.BduiComponentStore
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.hide
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.show

internal class BduiFragment : BaseFragment<Unit, BduiSideEffect>(R.layout.finsdk_fragment_bdui) {

    override val viewModel: BduiViewModel by injectViewModel { componentStore.component.viewModel }

    private val componentStore: BduiComponentStore by injectFeatureComponentStore(::BduiComponentStore)

    private val binding: FinsdkFragmentBduiBinding by viewBinding(
        viewBindingProducer = FinsdkFragmentBduiBinding::bind,
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.onCreate()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        ShimmersFragment.subscribeOnBackButton(
            fragmentManager = parentFragmentManager,
            lifecycleOwner = this,
            callback = viewModel::onBackPressed,
        )
        if (savedInstanceState == null) {
            ShimmersFragment.addShimmers(
                fragmentManager = parentFragmentManager,
                containerId = binding.finsdkShimmersContainer.id,
                shimmersLayoutProvider = componentStore.component.shimmersLayoutProvider,
            )
        }

        viewModel.initProviders(
            activity = requireActivity(),
            containerWithInsets = binding.finsdkContainerWithInsets,
            containerWithoutInsets = binding.finsdkContainerWithoutInsets,
            context = requireContext(),
            // if you use something other than childFragmentManager,
            // then back navigation in nested bdui fragments will not work
            fragmentManager = childFragmentManager,
        )
        viewModel.updateTheme()

        // do not initialize the adapter again if we start after changing the configuration
        if (isStartingFirstTime(state = savedInstanceState)) {
            viewModel.initAdapter(requireContext().applicationContext)
            viewModel.loadInitialScreen()
        } else if (isStartingAfterActivityDeath(state = savedInstanceState)) {
            // fallback to web if the activity has died in the background
            // (in this case, we have problems with flex, so we cannot continue)
            // TODO: learn to survive after activity death in the background
            viewModel.fallback()
        }

        viewModel.updateLifecycleObservers()
    }

    override fun onApplyWindowInsets(v: View, insets: WindowInsetsCompat): WindowInsetsCompat {
        // Do not set insets for root view, as they are supported inside Flex
        v.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            updateMargins(0, 0, 0, 0)
        }

        // Bank flows does not support insets, so we have to create another container with applied insets
        binding.finsdkContainerWithInsets.updateInsets(insets)
        binding.finsdkShimmersContainer.updateInsets(insets)

        return WindowInsetsCompat.CONSUMED
    }

    override fun sideEffect(sideEffect: BduiSideEffect) {
        when (sideEffect) {
            is BduiSideEffect.LaunchChromeTab -> launchChromeTab(url = sideEffect.url)
            is BduiSideEffect.ShowLoading -> {
                binding.finsdkContainerWithoutInsets.hide()
                binding.finsdkShimmersContainer.show()
            }
            is BduiSideEffect.HideLoading -> {
                binding.finsdkContainerWithoutInsets.show()
                binding.finsdkShimmersContainer.hide()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean(IS_CHANGING_CONFIGURATIONS_KEY, activity?.isChangingConfigurations == true)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroyView() {
        viewModel.clearProviders()
        super.onDestroyView()
    }

    private fun ViewGroup.updateInsets(insets: WindowInsetsCompat) {
        val insetsPx = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        updateLayoutParams<ViewGroup.MarginLayoutParams> {
            updateMargins(
                top = insetsPx.top,
                right = insetsPx.right,
                bottom = insetsPx.bottom,
                left = insetsPx.left,
            )
        }
    }

    private fun launchChromeTab(url: String) {
        val builder: CustomTabsIntent.Builder = CustomTabsIntent.Builder()
        val customTabsIntent: CustomTabsIntent = builder.build()

        val context = activity ?: return

        customTabsIntent.launchUrl(context, url.toUri())
    }

    private fun isStartingFirstTime(state: Bundle?) = state == null

    private fun isStartingAfterActivityDeath(state: Bundle?) = state?.getBoolean(IS_CHANGING_CONFIGURATIONS_KEY) == false

    private companion object {
        const val IS_CHANGING_CONFIGURATIONS_KEY = "is_changing_configurations"
    }
}
