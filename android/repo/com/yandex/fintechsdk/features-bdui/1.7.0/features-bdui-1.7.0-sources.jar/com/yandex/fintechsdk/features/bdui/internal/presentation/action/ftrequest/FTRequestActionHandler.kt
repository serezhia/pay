package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.core.bdui.api.action.NestedActionDispatcher
import com.yandex.fintechsdk.core.bdui.api.state.BduiStateManager
import com.yandex.fintechsdk.core.network.api.exception.NetworkException
import com.yandex.fintechsdk.features.bdui.internal.analytics.FTRequestActionEvent
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.requester.FTRequestActionRequester
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.DtoHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.parseBodyAsMap
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.updateVariable
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider
import kotlinx.coroutines.launch
import javax.inject.Inject

internal class FTRequestActionHandler @Inject constructor(
    private val analytics: Analytics,
    private val dtoHandler: DtoHandler,
    private val flexAdapter: FlexAdapter?,
    private val requester: FTRequestActionRequester,
    private val viewModelScopeProvider: ViewModelScopeProvider,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is FTRequestAction) return

        val scope = viewModelScopeProvider.get() ?: return
        val stateManager = flexAdapter?.stateManager ?: return
        val errorHandler = ErrorHandler(action = action, dispatcher = context.actionDispatcher, stateManager = stateManager, analytics = analytics)

        scope.launch {
            analytics.reportProductEvent(event = FTRequestActionEvent.Start(action = action))
            requester.execute(params = action)
                .onSuccess { result ->
                    action.statusCodeVarPath?.let { stateManager.updateVariable(path = it, value = STATUS_CODE_SUCCESS) }
                    dtoHandler.handle(dto = result, dtoMap = action.responseMap).onFailure(errorHandler::handle)
                    action.successAction?.let(context.actionDispatcher::dispatch)
                    analytics.reportProductEvent(event = FTRequestActionEvent.Success(action = action))
                }
                .onFailure { th ->
                    when (th) {
                        is NetworkException.BadCodeException -> {
                            analytics.reportProductEvent(event = FTRequestActionEvent.FailedResponse(action = action, code = th.code, body = th.body))
                            action.statusCodeVarPath?.let { stateManager.updateVariable(path = it, value = th.code) }
                            action.failedResponseMap?.let { failureDtoMap ->
                                val failureDto = th.body?.parseBodyAsMap().orEmpty()
                                dtoHandler.handle(dto = failureDto, dtoMap = failureDtoMap).onFailure(errorHandler::handle)
                            }
                            action.failureAction?.let(context.actionDispatcher::dispatch)
                        }

                        else -> errorHandler.handle(th = th)
                    }
                }
        }
    }

    private class ErrorHandler(
        private val action: FTRequestAction,
        private val dispatcher: NestedActionDispatcher,
        private val stateManager: BduiStateManager,
        private val analytics: Analytics,
    ) {
        fun handle(th: Throwable) {
            val reason = th.toString()
            action.errorVarPath?.let { stateManager.updateVariable(path = it, value = reason) }
            action.failureAction?.let(dispatcher::dispatch)

            val event = FTRequestActionEvent.Failure(action = action, reason = reason)
            analytics.reportProductEvent(event = event)
        }
    }

    companion object {
        private const val STATUS_CODE_SUCCESS = 200
    }
}
