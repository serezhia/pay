package com.yandex.fintechsdk.features.bdui.internal.presentation.action.finishflow

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate
import javax.inject.Inject

internal class FinishFlowActionHandler @Inject constructor(
    private val actionsDelegate: BduiActionsDelegate,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is FinishFlowAction) return

        actionsDelegate.finishFlow(status = action.status, params = action.params)
    }
}
