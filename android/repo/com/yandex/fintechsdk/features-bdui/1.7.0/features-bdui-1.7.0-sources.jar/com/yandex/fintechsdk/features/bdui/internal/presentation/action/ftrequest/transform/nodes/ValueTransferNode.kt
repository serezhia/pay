package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes

import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.serializers.ValueTransferNodeSerializer
import kotlinx.serialization.Serializable

/**
 * Representing a node for transferring values and their payload.
 * This class is serializable using a custom serializer [ValueTransferNodeSerializer].
 * It extends [DtoNode] and implements [SingleValueNode] to provide a unified interface for handling different.
 */
@Serializable(ValueTransferNodeSerializer::class)
internal sealed class ValueTransferNode : DtoNode(), SingleValueNode
