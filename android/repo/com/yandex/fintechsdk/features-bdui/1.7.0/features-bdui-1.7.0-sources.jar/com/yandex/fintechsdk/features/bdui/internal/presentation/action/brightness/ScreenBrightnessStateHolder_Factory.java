package com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ScreenBrightnessStateHolder_Factory implements Factory<ScreenBrightnessStateHolder> {
  @Override
  public ScreenBrightnessStateHolder get() {
    return newInstance();
  }

  public static ScreenBrightnessStateHolder_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ScreenBrightnessStateHolder newInstance() {
    return new ScreenBrightnessStateHolder();
  }

  private static final class InstanceHolder {
    static final ScreenBrightnessStateHolder_Factory INSTANCE = new ScreenBrightnessStateHolder_Factory();
  }
}
