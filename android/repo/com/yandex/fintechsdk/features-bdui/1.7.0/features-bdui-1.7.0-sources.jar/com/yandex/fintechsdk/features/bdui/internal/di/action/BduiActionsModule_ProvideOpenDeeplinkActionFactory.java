package com.yandex.fintechsdk.features.bdui.internal.di.action;

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction;
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionInfo;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink.OpenDeeplinkActionHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiActionsModule_ProvideOpenDeeplinkActionFactory implements Factory<BduiActionInfo<BduiAction>> {
  private final BduiActionsModule module;

  private final Provider<OpenDeeplinkActionHandler> handlerProvider;

  private BduiActionsModule_ProvideOpenDeeplinkActionFactory(BduiActionsModule module,
      Provider<OpenDeeplinkActionHandler> handlerProvider) {
    this.module = module;
    this.handlerProvider = handlerProvider;
  }

  @Override
  public BduiActionInfo<BduiAction> get() {
    return provideOpenDeeplinkAction(module, handlerProvider.get());
  }

  public static BduiActionsModule_ProvideOpenDeeplinkActionFactory create(BduiActionsModule module,
      Provider<OpenDeeplinkActionHandler> handlerProvider) {
    return new BduiActionsModule_ProvideOpenDeeplinkActionFactory(module, handlerProvider);
  }

  public static BduiActionInfo<BduiAction> provideOpenDeeplinkAction(BduiActionsModule instance,
      OpenDeeplinkActionHandler handler) {
    return Preconditions.checkNotNullFromProvides(instance.provideOpenDeeplinkAction(handler));
  }
}
