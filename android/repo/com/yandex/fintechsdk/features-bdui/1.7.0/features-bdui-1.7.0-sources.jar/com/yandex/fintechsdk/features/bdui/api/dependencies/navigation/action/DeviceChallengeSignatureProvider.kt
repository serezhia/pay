package com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action

import androidx.fragment.app.FragmentActivity

public interface DeviceChallengeSignatureProvider {
    public fun getSignature(
        activity: FragmentActivity,
        deviceChallengePostDelay: Int,
        deviceChallengeStartDelay: Int,
        paymentMethodId: String,
        purchaseToken: String,
        completion: (data: String?, signature: String?) -> Unit,
    )
}
