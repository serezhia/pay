package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.serializers

import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.TemplateNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.ValueTransferNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.VariableNode
import kotlinx.serialization.KSerializer
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.descriptors.buildClassSerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonDecoder
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

internal object ValueTransferNodeSerializer : KSerializer<ValueTransferNode> {
    override val descriptor: SerialDescriptor = buildClassSerialDescriptor(serialName = "ValueTransferNode")

    override fun serialize(encoder: Encoder, value: ValueTransferNode) {
        encoder.encodeSerializableValue(serializer = ValueTransferNode.serializer(), value = value)
    }

    override fun deserialize(decoder: Decoder): ValueTransferNode {
        val jsonDecoder = decoder as? JsonDecoder ?: throw IllegalStateException("Expected JsonDecoder")
        val element = jsonDecoder.decodeJsonElement()
        return deserializeFromJsonElement(element = element, decoder = jsonDecoder)
    }

    internal fun deserializeFromJsonElement(element: JsonElement, decoder: JsonDecoder): ValueTransferNode {
        if (element !is JsonObject) throw IllegalStateException("ValueTransferNodeSerializer: value should be a Map")
        val type = element.jsonObject.getValue(key = DtoNodeSerializer.FT_NODE_TYPE_KEY).jsonPrimitive.content

        val serializer = when (type) {
            GEN_UUID_KEY -> TemplateNode.GenUuid.serializer()
            OAUTH_TOKEN_KEY -> TemplateNode.Oauth.serializer()
            VARIABLE_KEY -> VariableNode.serializer()
            else -> throw IllegalStateException("Unsupported node type: $type")
        }

        return decoder.json.decodeFromJsonElement(deserializer = serializer, element = element)
    }

    private const val GEN_UUID_KEY = "gen_uuid"
    private const val OAUTH_TOKEN_KEY = "oauth_token"
    private const val VARIABLE_KEY = "variable"
}
