package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes

import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.serializers.DtoNodeSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

/**
 * Represents a node in a DTO structure.
 * Has different types of nodes: [Array], [Map], [Value], [Empty].
 * Each node type holds specific data relevant to its role in the hierarchy.
 * This class is serializable using [DtoNodeSerializer]
 */
@Serializable(DtoNodeSerializer::class)
internal sealed class DtoNode {
    data class Array(val value: List<DtoNode>) : DtoNode()

    data class Map(val value: kotlin.collections.Map<String, DtoNode>) : DtoNode()

    data class Value(val value: JsonElement) : DtoNode(), SingleValueNode

    data object Empty : DtoNode(), SingleValueNode
}

