package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FragmentManagerProvider_Factory implements Factory<FragmentManagerProvider> {
  @Override
  public FragmentManagerProvider get() {
    return newInstance();
  }

  public static FragmentManagerProvider_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static FragmentManagerProvider newInstance() {
    return new FragmentManagerProvider();
  }

  private static final class InstanceHolder {
    static final FragmentManagerProvider_Factory INSTANCE = new FragmentManagerProvider_Factory();
  }
}
