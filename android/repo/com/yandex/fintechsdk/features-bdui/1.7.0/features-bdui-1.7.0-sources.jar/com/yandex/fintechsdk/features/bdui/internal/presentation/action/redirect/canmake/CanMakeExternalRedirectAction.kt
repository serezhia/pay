package com.yandex.fintechsdk.features.bdui.internal.presentation.action.redirect.canmake

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class CanMakeExternalRedirectAction(
    @SerialName("deeplink")
    val deeplink: String,

    @SerialName("packageName")
    val packageName: String,

    @SerialName("boolVariableName")
    val boolVariableName: String,
) : BduiAction
