package com.yandex.fintechsdk.features.bdui.internal.presentation.action.finishflow;

import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FinishFlowActionHandler_Factory implements Factory<FinishFlowActionHandler> {
  private final Provider<BduiActionsDelegate> actionsDelegateProvider;

  private FinishFlowActionHandler_Factory(Provider<BduiActionsDelegate> actionsDelegateProvider) {
    this.actionsDelegateProvider = actionsDelegateProvider;
  }

  @Override
  public FinishFlowActionHandler get() {
    return newInstance(actionsDelegateProvider.get());
  }

  public static FinishFlowActionHandler_Factory create(
      Provider<BduiActionsDelegate> actionsDelegateProvider) {
    return new FinishFlowActionHandler_Factory(actionsDelegateProvider);
  }

  public static FinishFlowActionHandler newInstance(BduiActionsDelegate actionsDelegate) {
    return new FinishFlowActionHandler(actionsDelegate);
  }
}
