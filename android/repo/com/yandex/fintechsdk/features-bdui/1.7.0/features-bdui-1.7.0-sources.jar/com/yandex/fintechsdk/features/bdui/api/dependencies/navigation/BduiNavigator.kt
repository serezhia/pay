package com.yandex.fintechsdk.features.bdui.api.dependencies.navigation

import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery

public interface BduiNavigator {
    public fun back()
    public fun onError(query: BduiDocumentQuery, throwable: Throwable, responseCode: Int?)
}
