package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.validators

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetworkPattern
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNumber
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardRelatedData
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.Cvv
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.ExpiryDate
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNetworkWithPatternChecker

internal class ValidationFacade(
    private val cardNetworkChecker: CardNetworkWithPatternChecker = CardNetworkWithPatternChecker(),
    private val numberLengthValidator: NumberLengthValidator = NumberLengthValidator(),
    private val luhnValidator: LuhnValidator = LuhnValidator(),
    private val expiryDateNonEmptyValidator: ExpiryDateNonEmptyValidator = ExpiryDateNonEmptyValidator(),
    private val expiryDateValidator: ExpiryDateValidator = ExpiryDateValidator(),
    private val cvvLengthValidator: CvvLengthValidator = CvvLengthValidator(),
) {
    fun validateCardNumber(cardNumber: CardNumber): Boolean = validateCardNumberLength(cardNumber) && validateCardNumberLuhn(cardNumber)

    fun validateCardNumberLength(cardNumber: CardNumber): Boolean =
        numberLengthValidator.validate(CardRelatedData(cardNumber, cardPattern(cardNumber)))

    fun validateExpiryDate(expiryDate: ExpiryDate): Boolean = validateExpiryNonEmpty(expiryDate) && expiryDateValidator.validate(expiryDate)

    fun validateExpiryNonEmpty(expiryDate: ExpiryDate): Boolean = expiryDateNonEmptyValidator.validate(expiryDate)

    fun validateCvv(cvv: Cvv, cardNumber: CardNumber): Boolean = cvvLengthValidator.validate(
        CardRelatedData(cvv, cardPattern(cardNumber))
    )

    private fun validateCardNumberLuhn(cardNumber: CardNumber): Boolean = luhnValidator.validate(cardNumber)

    private fun cardPattern(cardNumber: CardNumber): CardNetworkPattern = cardNetworkChecker.lookup(cardNumber.value).pattern
}
