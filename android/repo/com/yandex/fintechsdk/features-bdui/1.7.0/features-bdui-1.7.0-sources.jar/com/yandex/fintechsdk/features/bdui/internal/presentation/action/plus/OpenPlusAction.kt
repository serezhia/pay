package com.yandex.fintechsdk.features.bdui.internal.presentation.action.plus

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.NestedAction
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class OpenPlusAction(
    @SerialName("onPlusOpened")
    val onPlusOpened: @Contextual NestedAction? = null,

    @SerialName("onCancelled")
    val onCancelled: @Contextual NestedAction? = null,
) : BduiAction
