package com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DevicePubkeyProvider
import com.yandex.fintechsdk.features.bdui.internal.analytics.BiometrySendPublicKey
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.updateVariable
import javax.inject.Inject

internal class DeviceChallengePubkeyActionHandler @Inject constructor(
    private val analytics: Analytics,
    private val devicePubkeyProvider: DevicePubkeyProvider,
    private val flexAdapter: FlexAdapter?,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is DeviceChallengePubkeyAction) return

        val publicKey = devicePubkeyProvider.getPublicKey()
        if (publicKey.isNullOrEmpty()) {
            onComplete(action = action, context = context)
            return
        }

        analytics.reportProductEvent(
            event = BiometrySendPublicKey(
                analyticsParams = action.analyticsParams ?: emptyMap(),
                devicePubkey = publicKey,
            ),
        )

        val publicKeyVarPath = action.publicKeyVarPath
        if (!publicKeyVarPath.isNullOrEmpty()) {
            flexAdapter?.stateManager?.updateVariable(
                path = publicKeyVarPath,
                value = publicKey,
            )
        }

        onComplete(action = action, context = context)
    }

    private fun onComplete(action: DeviceChallengePubkeyAction, context: BduiHandlingContext) {
        action.onCompleteAction?.let {
            onCompleteAction -> context.actionDispatcher.dispatch(action = onCompleteAction)
        }
    }
}
