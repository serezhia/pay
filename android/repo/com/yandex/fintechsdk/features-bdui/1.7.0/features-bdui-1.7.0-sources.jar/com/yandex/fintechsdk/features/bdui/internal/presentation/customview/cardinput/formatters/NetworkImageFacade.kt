package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters

import androidx.annotation.DrawableRes
import com.yandex.fintechsdk.entities.theme.Theme
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.CardNetworkData
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetwork
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNumber
import com.yandex.fintechsdk.resources.R

/**
 * Represents a card network icon.
 * The iconUrl is always used when available, and fallbackIconRes is used as a fallback
 * when iconUrl is null, blank, or fails to load.
 */
internal data class CardNetworkImage(
    @DrawableRes val fallbackIconRes: Int,
    val iconUrl: String?,
)

internal class NetworkImageFacade(
    cardNetworks: Map<String, CardNetworkData>? = null,
    private val enableDebranding: Boolean = false,
    private val cardNetworkChecker: CardNetworkWithPatternChecker = CardNetworkWithPatternChecker(),
) {

    private val networksByKey: Map<String, CardNetworkData>? = cardNetworks?.mapKeys { it.key.lowercase() }

    fun getCardNetworkImage(cardNumber: CardNumber, theme: Theme): CardNetworkImage {
        val cardNetwork = cardNetworkChecker.lookup(numStr = cardNumber.value).cardNetwork
        return getCardNetworkImage(value = cardNetwork, theme = theme)
    }

    fun getCardNetworkImage(value: CardNetwork, theme: Theme): CardNetworkImage {
        val fallback = value.toDrawable(isDebranding = enableDebranding)
        val key = value.stringCode.lowercase()
        val iconUrl = networksByKey?.get(key = key)?.iconUrl
        val unwrappedUrl = if (theme == Theme.DAY) iconUrl?.day else iconUrl?.night
        val resolvedUrl = unwrappedUrl?.takeUnless { it.isBlank() }
        return CardNetworkImage(
            fallbackIconRes = fallback,
            iconUrl = if (enableDebranding) null else resolvedUrl,
        )
    }

    @Suppress("CyclomaticComplexMethod") // because it's just mapping
    private fun CardNetwork.toDrawable(isDebranding: Boolean) = when (this) {
        CardNetwork.AMERICANEXPRESS -> R.drawable.finsdk_ic_card_network_amex
        CardNetwork.AMEX -> R.drawable.finsdk_ic_card_network_amex
        CardNetwork.ARCA -> R.drawable.finsdk_ic_card_network_unknown
        CardNetwork.BELKART -> R.drawable.finsdk_ic_card_network_unknown
        CardNetwork.DINACARD -> R.drawable.finsdk_ic_card_network_unknown
        CardNetwork.DISCOVER -> R.drawable.finsdk_ic_card_network_discover
        CardNetwork.ELCART -> R.drawable.finsdk_ic_card_network_unknown
        CardNetwork.HUMOCARD -> R.drawable.finsdk_ic_card_network_humocard
        CardNetwork.JCB -> R.drawable.finsdk_ic_card_network_jcb
        CardNetwork.MAESTRO -> R.drawable.finsdk_ic_card_network_maestro
        CardNetwork.MASTERCARD -> R.drawable.finsdk_ic_card_network_mastercard
        CardNetwork.MIR -> if (isDebranding)
            R.drawable.finsdk_ic_card_network_unknown else
                R.drawable.finsdk_ic_card_network_mir
        CardNetwork.RUPAY -> R.drawable.finsdk_ic_card_network_unknown
        CardNetwork.TROY -> R.drawable.finsdk_ic_card_network_unknown
        CardNetwork.UATP -> R.drawable.finsdk_ic_card_network_unknown
        CardNetwork.UNIONPAY -> R.drawable.finsdk_ic_card_network_unionpay
        CardNetwork.UNKNOWN -> R.drawable.finsdk_ic_card_network_unknown
        CardNetwork.UZCARD -> R.drawable.finsdk_ic_card_network_uzcard
        CardNetwork.VISA -> R.drawable.finsdk_ic_card_network_visa
        CardNetwork.VISAELECTRON -> R.drawable.finsdk_ic_card_network_visa_electron
    }
}
