package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

internal sealed interface ExpiryDate {
    object Empty : ExpiryDate

    data class NonEmpty(
        val month: Int,
        val year: Int,
    ) : ExpiryDate
}
