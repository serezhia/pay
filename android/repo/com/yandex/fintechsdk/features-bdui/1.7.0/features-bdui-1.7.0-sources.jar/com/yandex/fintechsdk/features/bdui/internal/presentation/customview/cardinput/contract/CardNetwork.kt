package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

import androidx.annotation.DrawableRes
import com.yandex.fintechsdk.resources.R

internal enum class CardNetwork(
    val stringCode: String,
    val lowercaseName: String,
    @DrawableRes val logoImageRes: Int,
) {
    AMERICANEXPRESS("AMERICANEXPRESS", "AmericanExpress", R.drawable.finsdk_ic_card_network_amex),
    AMEX("AMEX", "Amex", R.drawable.finsdk_ic_card_network_amex),
    ARCA("ARCA", "ArCa", R.drawable.finsdk_ic_card_network_unknown),
    BELKART("BELKART", "Белкарт", R.drawable.finsdk_ic_card_network_unknown),
    DINACARD("DINACARD", "DinaCard", R.drawable.finsdk_ic_card_network_unknown),
    DISCOVER("DISCOVER", "Discover", R.drawable.finsdk_ic_card_network_discover),
    ELCART("ELCART", "Elcart", R.drawable.finsdk_ic_card_network_unknown),
    HUMOCARD("HUMOCARD", "Humocard", R.drawable.finsdk_ic_card_network_humocard),
    JCB("JCB", "JCB", R.drawable.finsdk_ic_card_network_jcb),
    MAESTRO("MAESTRO", "Maestro", R.drawable.finsdk_ic_card_network_maestro),
    MASTERCARD("MASTERCARD", "Mastercard", R.drawable.finsdk_ic_card_network_mastercard),
    MIR("MIR", "", R.drawable.finsdk_ic_card_network_unknown),
    RUPAY("RUPAY", "RuPay", R.drawable.finsdk_ic_card_network_unknown),
    TROY("TROY", "Troy", R.drawable.finsdk_ic_card_network_unknown),
    UATP("UATP", "UATP", R.drawable.finsdk_ic_card_network_unknown),
    UNIONPAY("UNIONPAY", "UnionPay", R.drawable.finsdk_ic_card_network_unionpay),
    UNKNOWN("UNKNOWN", "Unknown", R.drawable.finsdk_ic_card_network_unknown),
    UZCARD("UZCARD", "Uzcard", R.drawable.finsdk_ic_card_network_uzcard),
    VISA("VISA", "Visa", R.drawable.finsdk_ic_card_network_visa),
    VISAELECTRON("VISAELECTRON", "Visa Electron", R.drawable.finsdk_ic_card_network_visa_electron);
}
