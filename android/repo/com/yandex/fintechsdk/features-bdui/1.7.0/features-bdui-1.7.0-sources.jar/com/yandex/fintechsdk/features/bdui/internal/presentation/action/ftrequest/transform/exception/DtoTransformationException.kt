package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.exception

internal sealed class DtoTransformationException : Exception() {

    abstract val path: String
}

internal data class JasonPathNotFoundException(override val path: String) : DtoTransformationException()

internal data class ValueNodeNotFoundException(override val path: String) : DtoTransformationException()

internal data class ValueNodeIsNotMapException(override val path: String) : DtoTransformationException()

internal data class ValueNodeIsNotArrayException(override val path: String) : DtoTransformationException()
