package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.textwatchers

import android.text.Editable
import android.text.TextWatcher
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.interfaces.CvvChangedListener

internal class CvvTextWatcher(
    private val listener: CvvChangedListener,
) : TextWatcher {

    override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) = Unit

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit

    override fun afterTextChanged(editable: Editable) {
        listener.onCvvChanged(editable.toString())
    }
}
