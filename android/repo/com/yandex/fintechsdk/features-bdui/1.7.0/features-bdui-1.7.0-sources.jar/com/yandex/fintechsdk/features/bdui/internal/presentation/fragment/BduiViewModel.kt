package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment

import android.content.Context
import android.widget.FrameLayout
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.viewModelScope
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexDependencies
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.architecture.api.mvi.intent
import com.yandex.fintechsdk.core.architecture.api.mvi.sideEffect
import com.yandex.fintechsdk.core.architecture.api.viewmodel.BaseViewModel
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionInfo
import com.yandex.fintechsdk.core.bdui.api.customview.configuration.CustomViewConfiguration
import com.yandex.fintechsdk.core.bdui.api.customview.factory.CustomViewFactoryDelegateCreator
import com.yandex.fintechsdk.core.bdui.api.eventhandler.BduiErrorHandler
import com.yandex.fintechsdk.core.bdui.api.eventhandler.BduiEventHandler
import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraHeadersProvider
import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraQueriesProvider
import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery
import com.yandex.fintechsdk.core.bdui.api.spinner.IsSpinnerPreviewEnabled
import com.yandex.fintechsdk.core.bdui.api.theme.BduiThemeProvider
import com.yandex.fintechsdk.core.navigation.api.Router
import com.yandex.fintechsdk.core.ui.impl.api.activity.InsetsConfig
import com.yandex.fintechsdk.features.bdui.api.dependencies.BduiHostUrlProvider
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.BduiNavigator
import com.yandex.fintechsdk.features.bdui.internal.analytics.LoadingBduiForm
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.ChromeTabLaunchActionsStore
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithInsetsProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithoutInsetsProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentManagerProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider
import okhttp3.OkHttpClient
import javax.inject.Inject

internal class BduiViewModel @Inject constructor(
    private val actionsInfo: Set<@JvmSuppressWildcards BduiActionInfo<BduiAction>>,
    private val analytics: Analytics,
    private val bduiErrorHandler: BduiErrorHandler,
    private val bduiHeadersProvider: BduiExtraHeadersProvider,
    private val bduiInitialDocumentQuery: BduiDocumentQuery,
    private val bduiNavigator: BduiNavigator,
    private val bduiQueriesProvider: BduiExtraQueriesProvider,
    private val bduiThemeProvider: BduiThemeProvider,
    private val chromeTabLaunchActionsStore: ChromeTabLaunchActionsStore,
    private val containerWithInsetsProvider: ContainerWithInsetsProvider,
    private val containerWithoutInsetsProvider: ContainerWithoutInsetsProvider,
    private val contextProvider: ContextProvider,
    private val customViewConfigurations: Map<String, @JvmSuppressWildcards CustomViewConfiguration>,
    private val customViewFactoryDelegateCreator: CustomViewFactoryDelegateCreator,
    private val flexAdapter: FlexAdapter?,
    private val fragmentActivityProvider: FragmentActivityProvider,
    private val fragmentManagerProvider: FragmentManagerProvider,
    private val bduiHostUrlProvider: BduiHostUrlProvider,
    private val insetsConfig: InsetsConfig,
    private val isSpinnerPreviewEnabled: IsSpinnerPreviewEnabled,
    private val okHttpClientBuilder: OkHttpClient.Builder,
    private val router: Router,
    private val viewModelScopeProvider: ViewModelScopeProvider,
) : BaseViewModel<Unit, BduiSideEffect>(
    initialState = Unit,
) {

    init {
        viewModelScopeProvider.set(value = viewModelScope)
        collectLaunchChromeTabActions()
    }

    override fun onCleared() {
        super.onCleared()
        clearProviders()
        flexAdapter?.clear()
        viewModelScopeProvider.set(value = null)
    }

    override fun onBackPressed() {
        val routeHandler = flexAdapter?.getCurrentRouteHandler()
        if (routeHandler != null && routeHandler.getBackStackEntryCount() > 1) {
            routeHandler.backward(animated = true, customProps = emptyMap())
        } else {
            bduiNavigator.back()
        }
    }

    fun onCreate() {
        analytics.reportProductEvent(event = LoadingBduiForm)
    }

    fun initProviders(
        activity: FragmentActivity,
        containerWithInsets: FrameLayout,
        containerWithoutInsets: FrameLayout,
        context: Context,
        fragmentManager: FragmentManager,
    ) {
        containerWithInsetsProvider.set(value = containerWithInsets)
        containerWithoutInsetsProvider.set(value = containerWithoutInsets)
        contextProvider.set(value = context)
        fragmentActivityProvider.set(value = activity)
        fragmentManagerProvider.set(value = fragmentManager)
    }

    fun initAdapter(applicationContext: Context) {
        flexAdapter?.init(
            dependencies = FlexDependencies(
                // Bdui dependencies
                actionsInfo = actionsInfo.toList(),
                customViewConfigurations = customViewConfigurations,
                customViewFactoryDelegateCreator = customViewFactoryDelegateCreator,
                errorHandler = bduiErrorHandler,
                eventHandler = createEventHandler(),
                isSpinnerPreviewEnabled = isSpinnerPreviewEnabled,
                themeProvider = bduiThemeProvider,

                // Network dependencies
                extraHeadersProvider = bduiHeadersProvider,
                extraQueriesProvider = bduiQueriesProvider,
                hostUrlProvider = bduiHostUrlProvider,
                okHttpClientBuilder = okHttpClientBuilder,

                // Navigation dependencies
                activityProvider = fragmentActivityProvider,
                applicationContext = applicationContext,
                containerProvider = containerWithoutInsetsProvider,
                fragmentManagerProvider = fragmentManagerProvider,
                isBottomSheet = insetsConfig.isBottomSheet,
                overlayTopMarginDp = insetsConfig.bottomSheetTopMarginDp,
                router = router,
            ),
        )
    }

    fun updateTheme() {
        val theme = bduiThemeProvider.getTheme()
        flexAdapter?.updateTheme(theme)
    }

    fun updateLifecycleObservers() {
        flexAdapter?.updateLifecycleObservers()
    }

    fun fallback() {
        bduiNavigator.onError(
            query = bduiInitialDocumentQuery,
            throwable = NotImplementedError(),
            responseCode = null,
        )
    }

    fun loadInitialScreen() {
        flexAdapter?.loadScreen(query = bduiInitialDocumentQuery)
    }

    fun clearProviders() {
        val providers = listOf(
            containerWithInsetsProvider,
            containerWithoutInsetsProvider,
            contextProvider,
            fragmentActivityProvider,
            fragmentManagerProvider,
        )
        providers.forEach { provider ->
            provider.set(value = null)
        }
    }

    private fun collectLaunchChromeTabActions() {
        intent {
            chromeTabLaunchActionsStore.events.collect { event ->
                sideEffect(BduiSideEffect.LaunchChromeTab(url = event))
            }
        }
    }

    private fun createEventHandler(): BduiEventHandler = object : BduiEventHandler {

        override fun onDocumentLoadingStarted(query: BduiDocumentQuery) = showShimmersIfNeeded(query)

        override fun onDocumentLoadingFailed(query: BduiDocumentQuery) = hideShimmersIfNeeded(query)

        override fun onDocumentLoadingCancelled(query: BduiDocumentQuery) = hideShimmersIfNeeded(query)

        override fun onDocumentLoadingFinished(query: BduiDocumentQuery) = hideShimmersIfNeeded(query)

        private fun showShimmersIfNeeded(query: BduiDocumentQuery?) = intent {
            if (query != null && isInitialScreen(query)) {
                sideEffect(BduiSideEffect.ShowLoading)
            }
        }

        private fun hideShimmersIfNeeded(query: BduiDocumentQuery?) = intent {
            if (query != null && isInitialScreen(query)) {
                sideEffect(BduiSideEffect.HideLoading)
            }
        }

        private fun isInitialScreen(query: BduiDocumentQuery): Boolean {
            val routeHandler = flexAdapter?.getCurrentRouteHandler()
            val currentFragmentQuery = routeHandler?.getCurrentFragmentQuery()
            return query == bduiInitialDocumentQuery && bduiInitialDocumentQuery == currentFragmentQuery
        }
    }
}
