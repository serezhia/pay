package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.open

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.NestedAction
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal class OpenPayCardAction(
    @SerialName("amount")
    val amount: Double? = null,

    @SerialName("currency")
    val currency: String? = null,

    @SerialName("onFinish")
    val onFinish: @Contextual NestedAction? = null,
) : BduiAction
