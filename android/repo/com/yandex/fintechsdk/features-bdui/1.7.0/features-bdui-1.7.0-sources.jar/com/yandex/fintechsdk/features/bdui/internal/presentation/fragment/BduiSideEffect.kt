package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment

internal sealed interface BduiSideEffect {
    data class LaunchChromeTab(val url: String) : BduiSideEffect
    data object ShowLoading : BduiSideEffect
    data object HideLoading : BduiSideEffect
}
