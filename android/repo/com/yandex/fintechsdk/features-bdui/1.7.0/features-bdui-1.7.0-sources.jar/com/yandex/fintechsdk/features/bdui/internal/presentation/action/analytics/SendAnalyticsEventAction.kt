package com.yandex.fintechsdk.features.bdui.internal.presentation.action.analytics

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class SendAnalyticsEventAction(
    @SerialName("eventName")
    val eventName: String,

    @SerialName("params")
    val params: Map<String, String>? = null,
) : BduiAction
