package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.barcode

import android.content.Context
import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomActionHandler
import com.yandex.fintechsdk.core.bdui.api.customview.expression.BduiExpressionResolver
import com.yandex.fintechsdk.core.bdui.api.customview.factory.BaseCustomViewFactory
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.model.CustomViewKeys

internal class BarcodeViewFactory : BaseCustomViewFactory<BarcodeView, BarcodeCustomProps>(
    paramsSerializer = BarcodeCustomProps.serializer(),
) {

    override val type: String = CustomViewKeys.BARCODE_VIEW_KEY

    override fun createViewWithParams(
        context: Context,
        params: BarcodeCustomProps?,
    ): BarcodeView = BarcodeView(
        context = context,
        props = params,
    )

    override fun bindView(
        actionHandler: DivCustomActionHandler,
        view: BarcodeView,
        expressionResolver: BduiExpressionResolver?,
    ) {
        view.bind()
    }
}

