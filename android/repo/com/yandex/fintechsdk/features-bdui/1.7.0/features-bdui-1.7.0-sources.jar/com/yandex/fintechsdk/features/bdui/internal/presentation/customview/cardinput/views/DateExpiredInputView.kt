package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.views

import android.content.Context
import android.os.Build
import android.text.InputFilter
import android.text.method.DigitsKeyListener
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.annotation.AttrRes
import androidx.annotation.StyleRes
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import com.yandex.fintechsdk.features.bdui.databinding.FinsdkViewDateExpiredInputBinding
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.Keyboard
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.setLocked
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.setLockedAndUnclickable
import com.yandex.fintechsdk.resources.R.color
import java.util.Locale

internal class DateExpiredInputView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    @AttrRes defStyleAttr: Int = 0,
    @StyleRes defStyleRes: Int = 0,
) : LinearLayout(context, attrs, defStyleAttr, defStyleRes) {

    val binding: FinsdkViewDateExpiredInputBinding = FinsdkViewDateExpiredInputBinding.inflate(LayoutInflater.from(context), this)

    private var textFieldValue: String
        get() = binding.finsdkExpirationDateInputText.text?.toString().orEmpty()
        set(value) {
            binding.finsdkExpirationDateInputText.setText(value)
        }

    init {
        orientation = VERTICAL
        gravity = Gravity.START or Gravity.CENTER_VERTICAL

        with(binding) {
            finsdkExpirationDateInputTextHint.isVisible = finsdkExpirationDateInputText.text.isEmpty()
            finsdkExpirationDateInputText.doAfterTextChanged { text ->
                finsdkExpirationDateInputTextHint.isVisible = text.isNullOrEmpty()
            }
        }
    }

    fun setLocked(isLocked: Boolean) {
        with(binding) {
            finsdkExpirationDateInputLabel.setLockedAndUnclickable(isLocked)
            finsdkExpirationDateInputText.setLocked(isLocked)
        }
    }

    fun showError(): Boolean {
        hideError()
        return textFieldValue.isNotBlank().also {
            binding.finsdkExpirationDateInputLabel.setTextColor(
                ResourcesCompat.getColor(
                    resources,
                    color.finsdk_text_negative,
                    context.theme
                )
            )
        }
    }

    fun hideError() {
        binding.finsdkExpirationDateInputLabel.setTextColor(
            ResourcesCompat.getColor(
                resources,
                color.finsdk_text_secondary,
                context.theme
            )
        )
    }

    fun gainFocus() {
        with(binding.finsdkExpirationDateInputText) {
            requestFocus()
            Keyboard.show(this)
        }
    }

    fun setInputFilters() {
        binding.finsdkExpirationDateInputText.filters = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                add(DigitsKeyListener(Locale.getDefault()))
            } else {
                add(DigitsKeyListener())
            }
            add(InputFilter.LengthFilter(MAX_CHAR_COUNT))
        }.toTypedArray()
    }

    internal fun setTextIfNew(text: String) {
        if (binding.finsdkExpirationDateInputText.text.toString() != text) {
            binding.finsdkExpirationDateInputText.setText(text)
        }
    }

    private companion object {
        const val MAX_CHAR_COUNT = 4
    }
}
