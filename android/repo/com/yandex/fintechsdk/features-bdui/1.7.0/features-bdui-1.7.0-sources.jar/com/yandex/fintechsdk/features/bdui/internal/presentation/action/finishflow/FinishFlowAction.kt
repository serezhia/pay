package com.yandex.fintechsdk.features.bdui.internal.presentation.action.finishflow

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class FinishFlowAction(
    @SerialName("status")
    val status: String,

    @SerialName("params")
    val params: Map<String, String>? = null,
) : BduiAction
