package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.interfaces

internal interface ExpirationDateChangedListener {

    fun onExpirationDateChanged(value: String)
}
