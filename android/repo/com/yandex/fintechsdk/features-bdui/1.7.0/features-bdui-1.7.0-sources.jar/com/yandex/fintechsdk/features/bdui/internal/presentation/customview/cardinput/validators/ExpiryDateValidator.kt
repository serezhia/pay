package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.validators

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.ExpiryDate

internal class ExpiryDateValidator : Validator<ExpiryDate> {

    @Suppress("MagicNumber") // TODO: define numbers as well named constant
    override fun validate(verifiable: ExpiryDate): Boolean {
        if (verifiable !is ExpiryDate.NonEmpty) return false

        val cardYear = verifiable.year
        val cardMonth = verifiable.month

        return when {
            cardMonth < 1 || cardMonth > 12 -> false
            cardYear < SPECIAL_MARK_YEAR || cardYear > SPECIAL_MARK_YEAR + 50 -> false
            cardYear == SPECIAL_MARK_YEAR && cardMonth < SPECIAL_MARK_MONTH -> false
            else -> true
        }
    }

    private companion object {
        private const val SPECIAL_MARK_YEAR = 22
        private const val SPECIAL_MARK_MONTH = 3
    }
}
