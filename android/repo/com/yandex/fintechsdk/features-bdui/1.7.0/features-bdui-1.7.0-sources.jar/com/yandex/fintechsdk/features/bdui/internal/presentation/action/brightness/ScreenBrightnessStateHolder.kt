package com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness

import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import javax.inject.Inject

@FeatureScope
internal class ScreenBrightnessStateHolder @Inject constructor() {

    private var previousBrightness: Float? = null

    fun saveBrightness(brightness: Float) {
        if (previousBrightness == null) {
            previousBrightness = brightness
        }
    }

    fun restoreBrightness(): Float? {
        return previousBrightness
    }

    fun clear() {
        previousBrightness = null
    }
}

