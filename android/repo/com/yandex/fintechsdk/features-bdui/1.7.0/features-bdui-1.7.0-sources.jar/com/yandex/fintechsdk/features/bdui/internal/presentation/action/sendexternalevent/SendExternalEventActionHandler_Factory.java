package com.yandex.fintechsdk.features.bdui.internal.presentation.action.sendexternalevent;

import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class SendExternalEventActionHandler_Factory implements Factory<SendExternalEventActionHandler> {
  private final Provider<BduiActionsDelegate> bduiActionsDelegateProvider;

  private SendExternalEventActionHandler_Factory(
      Provider<BduiActionsDelegate> bduiActionsDelegateProvider) {
    this.bduiActionsDelegateProvider = bduiActionsDelegateProvider;
  }

  @Override
  public SendExternalEventActionHandler get() {
    return newInstance(bduiActionsDelegateProvider.get());
  }

  public static SendExternalEventActionHandler_Factory create(
      Provider<BduiActionsDelegate> bduiActionsDelegateProvider) {
    return new SendExternalEventActionHandler_Factory(bduiActionsDelegateProvider);
  }

  public static SendExternalEventActionHandler newInstance(
      BduiActionsDelegate bduiActionsDelegate) {
    return new SendExternalEventActionHandler(bduiActionsDelegate);
  }
}
