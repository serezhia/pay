package com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action

public abstract class BduiActionsDelegate {

    public open fun finishFlow(status: String, params: Map<String, String>?) {}

    public open fun onTerminalState(result: String, description: String?, reasonCode: String?) {}

    public open fun onExternalEvent(eventName: String, params: Map<String, String>?) {}
}
