package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics

internal class DynamicBinEventWrapper private constructor(
    val maskedPrefix: String,
    val originalPrefixLength: Int,
) {
    constructor(prefix: String) : this(
        maskedPrefix = if (prefix.length > MAX_VISIBLE_PREFIX) {
            prefix.take(n = MAX_VISIBLE_PREFIX) + PLACEHOLDER
        } else {
            prefix
        },
        originalPrefixLength = prefix.length,
    )

    companion object {
        private const val MAX_VISIBLE_PREFIX = 6
        private const val PLACEHOLDER = "**"
    }
}
