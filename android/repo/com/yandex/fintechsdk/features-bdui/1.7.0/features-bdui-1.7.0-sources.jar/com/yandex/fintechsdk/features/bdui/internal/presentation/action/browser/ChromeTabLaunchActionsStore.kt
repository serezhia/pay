package com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser

import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow
import javax.inject.Inject

@FeatureScope
internal class ChromeTabLaunchActionsStore @Inject constructor() {

    private val _events = Channel<String>(
        capacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val events: Flow<String> = _events.receiveAsFlow()

    fun send(url: String) {
        _events.trySend(url)
    }
}
