package com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.NestedAction
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class DeviceChallengeSignatureAction(
    @SerialName("deviceChallengePostDelay")
    val deviceChallengePostDelay: Int,

    @SerialName("deviceChallengeStartDelay")
    val deviceChallengeStartDelay: Int,

    @SerialName("paymentMethodId")
    val paymentMethodId: String,

    @SerialName("purchaseToken")
    val purchaseToken: String,

    @SerialName("dataVarPath")
    val dataVarPath: List<String>? = null,

    @SerialName("onCompleteAction")
    val onCompleteAction: @Contextual NestedAction? = null,

    @SerialName("signatureVarPath")
    val signatureVarPath: List<String>? = null,

    @SerialName("userSuccessVarPath")
    val userSuccessVarPath: List<String>? = null,
) : BduiAction
