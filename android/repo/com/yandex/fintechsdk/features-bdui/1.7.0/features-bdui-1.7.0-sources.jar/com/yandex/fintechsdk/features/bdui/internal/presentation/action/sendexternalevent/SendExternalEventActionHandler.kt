package com.yandex.fintechsdk.features.bdui.internal.presentation.action.sendexternalevent

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate
import javax.inject.Inject

internal class SendExternalEventActionHandler @Inject constructor(
    private val bduiActionsDelegate: BduiActionsDelegate,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is SendExternalEventAction) return

        bduiActionsDelegate.onExternalEvent(
            eventName = action.event,
            params = action.params,
        )
    }
}
