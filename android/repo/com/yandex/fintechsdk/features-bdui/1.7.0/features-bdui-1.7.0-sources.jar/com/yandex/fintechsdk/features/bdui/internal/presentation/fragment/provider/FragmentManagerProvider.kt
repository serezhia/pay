package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider

import androidx.fragment.app.FragmentManager
import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import com.yandex.fintechsdk.core.utils.api.provider.BaseProvider
import javax.inject.Inject

@FeatureScope
internal class FragmentManagerProvider @Inject constructor() : BaseProvider<FragmentManager>()
