package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics

internal enum class DynamicBinInfoEventName(private val value: String) {
    INIT_EVENT(value = "init"),
    REQUEST_STARTED(value = "request_started"),
    REQUEST_SUCCESS(value = "request_success"),
    REQUEST_FAILED(value = "request_failed"),
    ICON_LOAD_STARTED(value = "icon_load_started"),
    ICON_LOAD_SUCCESS(value = "icon_load_success"),
    ICON_LOAD_FAILED(value = "icon_load_failed"),
    DATA_APPLIED(value = "data_applied"),
    FALLBACK_TO_STATIC(value = "fallback_to_static"),
    DATA_STATE_ON_SUBMIT(value = "data_state_on_submit"),
    REQUESTS_RACE(value = "requests_race"),
    REQUEST_CACHED(value = "request_cached"),
    DATA_RESET(value = "data_reset"),
    STATIC_DATA_APPLIED(value = "static_data_applied");

    val valueWithPrefix: String
        get() = "${EVENT_PREFIX}${this.value}"

    companion object {
        private const val EVENT_PREFIX = "dynamic_bin_"
    }
}
