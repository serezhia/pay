package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.net.http.SslError
import android.view.MotionEvent
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.yandex.fintechsdk.core.bdui.api.customview.BduiVariableController
import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomActionHandler
import com.yandex.fintechsdk.core.ui.impl.api.view.webview.NucErrorHandler
import com.yandex.fintechsdk.data.auth.api.AuthState
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment
import com.yandex.fintechsdk.features.bdui.BuildConfig
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.javascript.ConfigurablePostMessageJavascriptInterface
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.javascript.PayPostMessageJavascriptInterface
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.LoadCompleteAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.UrlMatch
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.WebViewConfiguration
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.WebViewCustomProps
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.newtab.NewTabHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.newtab.NewTabPolicy
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.newtab.NewWindowInterceptorWebViewFactory
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.newtab.asNewTabPolicy
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.postmessage.PostMessageHandler
import java.net.URI

internal class CustomWebView(
    context: Context,
    private val bduiVariableController: BduiVariableController,
    private val config: WebViewConfiguration,
    private val params: WebViewCustomProps?,
) : WebView(context) {

    private var configurablePostMessageInterface: ConfigurablePostMessageJavascriptInterface? = null
    private var lastY: Float = 0f
    private var isScrollingUp: Boolean = false
    private val newTabPolicy: NewTabPolicy = params?.allowNewTabType.asNewTabPolicy()
    private val newTabHandler = NewTabHandler(context = context, policy = newTabPolicy)

    private val newWindowInterceptorWebViewFactory = NewWindowInterceptorWebViewFactory()

    fun bind(actionHandler: DivCustomActionHandler) {
        setupJavascriptInterfaces()
        setupPostMessageHandlers(actionHandler = actionHandler)
        configureWebViewSettings()
        setupWebViewClient(actionHandler = actionHandler)
        setupWebChromeClient()
        loadInitialUrl(actionHandler = actionHandler)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastY = event.y
                // Always request to not intercept touch events initially
                parent?.requestDisallowInterceptTouchEvent(true)
            }

            MotionEvent.ACTION_MOVE -> {
                val deltaY = event.y - lastY
                isScrollingUp = deltaY > 0

                val canScrollDown = canScrollVertically(1)
                val canScrollUp = canScrollVertically(-1)

                // If scrolling down and WebView can scroll down, keep the touch
                // If scrolling up and WebView can scroll up, keep the touch
                // Otherwise, allow parent (BottomSheet) to intercept
                val shouldRequestDisallow = when {
                    isScrollingUp && canScrollUp -> true
                    !isScrollingUp && canScrollDown -> true
                    else -> false
                }

                parent?.requestDisallowInterceptTouchEvent(shouldRequestDisallow)
                lastY = event.y
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return super.onTouchEvent(event)
    }

    @SuppressLint("JavascriptInterface")
    private fun setupJavascriptInterfaces() {
        config.javascriptInterfaces?.forEach { jsInterface ->
            addJavascriptInterface(jsInterface, jsInterface.interfaceName)
        }
    }

    private fun setupPostMessageHandlers(actionHandler: DivCustomActionHandler) {
        val postMessageActions = params?.onPostMessage
        if (postMessageActions != null) {
            val postMessageHandler = PostMessageHandler(
                actionHandler = actionHandler,
                bduiVariableController = bduiVariableController,
                flexAdapter = config.flexAdapter,
            )

            configurablePostMessageInterface = ConfigurablePostMessageJavascriptInterface(
                postMessageHandler = postMessageHandler,
            ).also { jsInterface ->
                jsInterface.configureHandlers(postMessageActions = postMessageActions)
                addJavascriptInterface(
                    /* object = */ jsInterface,
                    /* name = */ jsInterface.interfaceName,
                )
            }
        }
    }

    private fun configureWebViewSettings() {
        isFocusable = true
        isFocusableInTouchMode = true

        with(settings) {
            javaScriptEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_NO_CACHE

            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(true)

            domStorageEnabled = true

            config.userAgentProvider?.invoke(userAgentString)?.let { userAgent ->
                userAgentString = userAgent
            }
        }
    }

    private fun loadInitialUrl(actionHandler: DivCustomActionHandler) {
        var url = params?.url ?: return

        val isAuthRequired = params.authRequired

        if (isAuthRequired) {
            val adapter = config.passportAdapter

            if (adapter == null) {
                runErrorAction(actionHandler = actionHandler)
                return
            }

            val authorizedState = config.authRepository.authState.value

            if (authorizedState !is AuthState.Authorized) {
                runErrorAction(actionHandler = actionHandler)
                return
            }

            val authorizedUrl = adapter.getUrlWithAuth(
                context = context,
                isTestEnvironment = config.environment == DefaultEnvironment.TESTING,
                tld = config.region.key,
                uid = authorizedState.credentials.uid,
                url = url,
            )

            if (authorizedUrl == null) {
                runErrorAction(actionHandler = actionHandler)
                return
            }

            url = authorizedUrl
        }

        setUrl(url = url)
    }

    private fun setupWebViewClient(actionHandler: DivCustomActionHandler) {
        val nucSslErrorHandler = NucErrorHandler(context)

        webViewClient = object : WebViewClient() {
            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(
                view: WebView?,
                handler: SslErrorHandler?,
                error: SslError,
            ) {
                nucSslErrorHandler.handleSslError(
                    callback = object : NucErrorHandler.Callback {
                        override fun onProceed() {
                            handler?.proceed()
                        }

                        override fun onCancelled() {
                            if (BuildConfig.DEBUG) handler?.proceed() else handler?.cancel()
                        }
                    },
                    error = error,
                )
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?,
            ) {
                super.onReceivedError(view, request, error)
                params?.onErrorAction?.let { action ->
                    actionHandler.handleAction(action = action)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                initializePostMessageInterfaces(view = view)
                handleLoadCompleteActions(
                    actionHandler = actionHandler,
                    url = url,
                )
            }

            private fun initializePostMessageInterfaces(view: WebView?) {
                if (view == null) return

                config.javascriptInterfaces
                    ?.mapNotNull { jsInterface -> jsInterface as? PayPostMessageJavascriptInterface }
                    ?.forEach { pmInterface ->
                        initPostMessageScript(
                            postMessageJavascriptInterface = pmInterface,
                            webView = view,
                        )
                    }

                configurablePostMessageInterface?.let { configurableInterface ->
                    initPostMessageScript(
                        postMessageJavascriptInterface = configurableInterface,
                        webView = view,
                    )
                }
            }

            private fun handleLoadCompleteActions(url: String?, actionHandler: DivCustomActionHandler) {
                val loadActionList = params?.onLoadCompleteList ?: return

                loadActionList
                    .filter { loadAction -> shouldHandleAction(loadAction = loadAction, url = url) }
                    .forEach { loadAction -> actionHandler.handleAction(action = loadAction.action) }
            }

            private fun shouldHandleAction(loadAction: LoadCompleteAction, url: String?): Boolean =
                when (loadAction.match) {
                    UrlMatch.CONTAINING -> url != null && url.contains(other = loadAction.url)
                    UrlMatch.EXACT -> loadAction.url == url
                }
        }
    }

    private fun setUrl(url: String) {
        config.cookies?.forEach { cookie ->
            CookieManager.getInstance().setCookie(
                URI(cookie.url).host,
                cookie.value,
            )
        }

        loadUrl(url)
    }

    private fun initPostMessageScript(
        webView: WebView,
        postMessageJavascriptInterface: PayPostMessageJavascriptInterface,
    ) {
        webView.loadUrl(
            "javascript:(function() {" +
                    "window.parent.addEventListener ('message', function(event) {" +
                    " ${postMessageJavascriptInterface.interfaceName}.receiveMessage(JSON.stringify(event.data));});" +
                    "})()"
        )
    }

    private fun setupWebChromeClient() {
        webChromeClient = object : WebChromeClient() {

            /**
             * Called by WebView when a page requests to open a new window (e.g. target="_blank" or window.open()).
             *
             * WebView does NOT automatically open the system browser here.
             * Instead, it expects the app to provide a "child" WebView via WebViewTransport.
             *
             * We intentionally provide a lightweight interceptor WebView:
             * it captures the first navigation URL, delegates it to our handler
             * (CustomTabs / external browser / ignore) and then destroys itself.
             */
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                // If opening new tabs is disabled, return false so WebView can fallback to default behavior
                // (or simply do nothing depending on WebView internals / site code).
                if (newTabPolicy == NewTabPolicy.Disabled) return false

                val transport = resultMsg?.obj as? WebViewTransport ?: return false

                // Provide a temporary WebView that will intercept the URL and immediately self-destruct.
                transport.webView = newWindowInterceptorWebViewFactory.create(parentContext = context, handleUrl = newTabHandler::handleUrl)

                // Let WebView proceed with creating the new "window" using the provided WebView.
                resultMsg.sendToTarget()
                return true
            }

            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?,
            ): Boolean {
                try {
                    AlertDialog.Builder(context)
                        .setMessage(message)
                        .setOnCancelListener { result?.cancel() }
                        .setPositiveButton(android.R.string.ok) { _, _ ->
                            result?.confirm()
                        }
                        .create()
                        .show()
                } catch (e: android.view.WindowManager.BadTokenException) {
                    // If dialog fails to show, cancel the result
                    result?.cancel()
                }
                return true
            }

            override fun onJsConfirm(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?,
            ): Boolean {
                try {
                    AlertDialog.Builder(context)
                        .setMessage(message)
                        .setNegativeButton(android.R.string.cancel) { _, _ ->
                            result?.cancel()
                        }
                        .setOnCancelListener { result?.cancel() }
                        .setPositiveButton(android.R.string.ok) { _, _ ->
                            result?.confirm()
                        }
                        .create()
                        .show()
                } catch (e: android.view.WindowManager.BadTokenException) {
                    // If dialog fails to show, cancel the result
                    result?.cancel()
                }
                return true
            }
        }
    }

    private fun runErrorAction(actionHandler: DivCustomActionHandler) {
        params?.onErrorAction?.let { action ->
            actionHandler.handleAction(action = action)
        }
    }
}
