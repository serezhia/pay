package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.javascript

import android.webkit.JavascriptInterface

internal abstract class PayPostMessageJavascriptInterface : FintechJavascriptInterface {
    /**
     * The name of the Javascript interface. The web page can access the
     * methods from this interface by referencing its name
     */
    override val interfaceName: String = "YandexPayAndroid"

    /**
     * Will be called from javascript and set [data] post message string in function
     */
    @JavascriptInterface
    fun receiveMessage(data: String) {
        messageReceived(data)
    }

    /**
     * Your logic with received data from post message
     *
     * Check the [data] carefully !!
     *
     * ## **With Man of the middle attack hacker can send malicious data whose execution can cause damage SDK**
     */
    abstract fun messageReceived(data: String)
}
