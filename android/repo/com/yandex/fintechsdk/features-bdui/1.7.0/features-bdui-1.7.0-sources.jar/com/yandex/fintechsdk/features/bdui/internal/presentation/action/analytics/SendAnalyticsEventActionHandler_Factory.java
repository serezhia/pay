package com.yandex.fintechsdk.features.bdui.internal.presentation.action.analytics;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class SendAnalyticsEventActionHandler_Factory implements Factory<SendAnalyticsEventActionHandler> {
  private final Provider<Analytics> analyticsProvider;

  private SendAnalyticsEventActionHandler_Factory(Provider<Analytics> analyticsProvider) {
    this.analyticsProvider = analyticsProvider;
  }

  @Override
  public SendAnalyticsEventActionHandler get() {
    return newInstance(analyticsProvider.get());
  }

  public static SendAnalyticsEventActionHandler_Factory create(
      Provider<Analytics> analyticsProvider) {
    return new SendAnalyticsEventActionHandler_Factory(analyticsProvider);
  }

  public static SendAnalyticsEventActionHandler newInstance(Analytics analytics) {
    return new SendAnalyticsEventActionHandler(analytics);
  }
}
