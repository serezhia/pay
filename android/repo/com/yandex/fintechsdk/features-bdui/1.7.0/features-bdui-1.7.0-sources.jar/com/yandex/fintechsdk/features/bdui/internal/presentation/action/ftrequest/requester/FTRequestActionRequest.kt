package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.requester

import com.yandex.fintechsdk.core.network.api.request.Request
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.toJsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject

internal class FTRequestActionRequest(
    override val method: RestMethod,
    override val baseUrl: String,
    override val requestPath: String,
    private val body: Map<String, Any>? = null,
    private val headers: Map<String, String>? = null,
    private val queries: Map<String, String>? = null,
) : Request() {
    override val requestName: String = "ft_request_action-$requestPath"

    override fun headers(): Map<String, String> {
        return headers.orEmpty()
    }

    override fun queries(): Map<String, String> {
        return queries.orEmpty()
    }

    override fun body(): JsonObject {
        return buildJsonObject {
            body?.mapValues { it.value.toJsonElement() }
                ?.forEach(::put)
        }
    }
}
