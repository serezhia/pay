package com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.NestedAction
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * OpenDeeplinkAction - action for opening deeplinks (custom schemes or https)
 *
 * @param deeplink URL to open (custom scheme or https)
 * @param universalLinksOnly Optional flag - universal links only (defaults to false)
 * @param onSuccess Action to execute when deeplink opens successfully
 * @param onFail Action to execute when deeplink fails to open
 */
@Serializable
@SerialName("OpenDeeplinkAction")
internal data class OpenDeeplinkAction(
    @SerialName("deeplink")
    val deeplink: String,

    @SerialName("universalLinksOnly")
    val universalLinksOnly: Boolean? = null,

    @SerialName("onSuccess")
    val onSuccess: @Contextual NestedAction? = null,

    @SerialName("onFail")
    val onFail: @Contextual NestedAction? = null,
) : BduiAction
