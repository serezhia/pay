package com.yandex.fintechsdk.features.bdui.internal.analytics

import com.yandex.fintechsdk.core.analytics.api.event.Event
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.FTRequestAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.errorBodyLogMessage
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.joinedUrl
import kotlinx.serialization.json.JsonObject

private const val KEY_DATA = "data"
private const val KEY_DESCRIPTION = "description"
private const val KEY_DEVICE_PUBKEY = "device_pubkey"
private const val KEY_SIGNATURE = "signature"
private const val KEY_TARGET_PATH = "target_path"
private const val KEY_TIMEOUT = "timeout"
private const val KEY_URL = "url"
private const val KEY_USER_SUCCESS = "user_success"

private const val NAME_BIOMETRY_SEND_PUBLIC_KEY = "biometry_send_public_key"
private const val NAME_BIOMETRY_SUPPLY_DEVICE_CHALLENGE_RESULT = "biometry_supply_device_challenge_result"

private const val DESCRIPTION_BIOMETRY_SEND_PUBLIC_KEY = "Отправка публичного ключа"
private const val DESCRIPTION_BIOMETRY_SUPPLY_DEVICE_CHALLENGE_RESULT = "Отправка результата нативного челленджа"

private const val SECURE_SIGNATURE_LENGTH = 10

internal data object LoadingBduiForm : Event(name = "loading_bdui_form")

internal data class BiometrySendPublicKey(
    val analyticsParams: Map<String, String>,
    val devicePubkey: String,
) : Event(
    name = NAME_BIOMETRY_SEND_PUBLIC_KEY,
    params = mapOf(
        KEY_DESCRIPTION to DESCRIPTION_BIOMETRY_SEND_PUBLIC_KEY,
        KEY_DEVICE_PUBKEY to devicePubkey,
    ) + analyticsParams,
)

internal data class BiometrySupplyDeviceChallengeResult(
    val data: String,
    val description: String,
    val secureSignature: String,
    val userSuccess: Boolean,
) : Event(
    name = NAME_BIOMETRY_SUPPLY_DEVICE_CHALLENGE_RESULT,
    params = mapOf(
        KEY_DATA to data,
        KEY_DESCRIPTION to description,
        KEY_SIGNATURE to secureSignature,
        KEY_USER_SUCCESS to userSuccess.toString(),
    ),
) {
    companion object {
        fun create(
            data: String,
            signature: String,
            userSuccess: Boolean
        ): BiometrySupplyDeviceChallengeResult {
            val secureSignature = "${signature.take(SECURE_SIGNATURE_LENGTH)}***"
            val description = buildString {
                append("$DESCRIPTION_BIOMETRY_SUPPLY_DEVICE_CHALLENGE_RESULT: ")
                append("$KEY_USER_SUCCESS = $userSuccess, ")
                append("$KEY_DATA = $data, ")
                append("$KEY_SIGNATURE = $secureSignature")
            }
            return BiometrySupplyDeviceChallengeResult(
                data = data,
                description = description,
                secureSignature = secureSignature,
                userSuccess = userSuccess
            )
        }
    }
}

internal sealed class FTRequestActionEvent(
    action: FTRequestAction,
    eventName: String,
    reason: String? = null,
) : Event(
    name = eventName,
    params = mapOf(
        KEY_DESCRIPTION to (reason ?: "$EVENT_NAME: методом ${action.method} в ручку ${action.joinedUrl} с ttl ${action.timeout}"),
        KEY_URL to action.baseUrl,
        KEY_TARGET_PATH to action.path,
        KEY_TIMEOUT to action.timeout.toString(),
    ),
) {
    class Start(action: FTRequestAction) : FTRequestActionEvent(
        action = action,
        eventName = EVENT_NAME,
    )

    class Success(action: FTRequestAction) : FTRequestActionEvent(
        action = action,
        eventName = EVENT_NAME_SUCCESS,
    )

    class Failure(action: FTRequestAction, reason: String? = null) : FTRequestActionEvent(
        action = action,
        eventName = EVENT_NAME_FAILURE,
        reason = reason,
    )

    class FailedResponse(action: FTRequestAction, code: Int, body: JsonObject?) : FTRequestActionEvent(
        action = action,
        eventName = EVENT_NAME_FAILED_RESPONSE,
        reason = action.errorBodyLogMessage(code = code, body = body),
    )

    companion object {
        private const val EVENT_NAME = "ft_request_action"
        private const val EVENT_NAME_SUCCESS = "${EVENT_NAME}_success"
        private const val EVENT_NAME_FAILURE = "${EVENT_NAME}_failure"
        private const val EVENT_NAME_FAILED_RESPONSE = "${EVENT_NAME}_failed_response"
    }
}
