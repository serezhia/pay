package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ContainerWithoutInsetsProvider_Factory implements Factory<ContainerWithoutInsetsProvider> {
  @Override
  public ContainerWithoutInsetsProvider get() {
    return newInstance();
  }

  public static ContainerWithoutInsetsProvider_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ContainerWithoutInsetsProvider newInstance() {
    return new ContainerWithoutInsetsProvider();
  }

  private static final class InstanceHolder {
    static final ContainerWithoutInsetsProvider_Factory INSTANCE = new ContainerWithoutInsetsProvider_Factory();
  }
}
