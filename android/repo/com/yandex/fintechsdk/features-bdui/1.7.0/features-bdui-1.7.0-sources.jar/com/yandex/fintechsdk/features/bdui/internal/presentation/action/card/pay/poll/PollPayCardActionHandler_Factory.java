package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.poll;

import com.yandex.fintechsdk.adapters.bank.sdk.api.BankAdapter;
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class PollPayCardActionHandler_Factory implements Factory<PollPayCardActionHandler> {
  private final Provider<BankAdapter> bankAdapterProvider;

  private final Provider<FlexAdapter> flexAdapterProvider;

  private final Provider<ViewModelScopeProvider> scopeProvider;

  private PollPayCardActionHandler_Factory(Provider<BankAdapter> bankAdapterProvider,
      Provider<FlexAdapter> flexAdapterProvider, Provider<ViewModelScopeProvider> scopeProvider) {
    this.bankAdapterProvider = bankAdapterProvider;
    this.flexAdapterProvider = flexAdapterProvider;
    this.scopeProvider = scopeProvider;
  }

  @Override
  public PollPayCardActionHandler get() {
    return newInstance(bankAdapterProvider.get(), flexAdapterProvider.get(), scopeProvider.get());
  }

  public static PollPayCardActionHandler_Factory create(Provider<BankAdapter> bankAdapterProvider,
      Provider<FlexAdapter> flexAdapterProvider, Provider<ViewModelScopeProvider> scopeProvider) {
    return new PollPayCardActionHandler_Factory(bankAdapterProvider, flexAdapterProvider, scopeProvider);
  }

  public static PollPayCardActionHandler newInstance(@Nullable BankAdapter bankAdapter,
      @Nullable FlexAdapter flexAdapter, ViewModelScopeProvider scopeProvider) {
    return new PollPayCardActionHandler(bankAdapter, flexAdapter, scopeProvider);
  }
}
