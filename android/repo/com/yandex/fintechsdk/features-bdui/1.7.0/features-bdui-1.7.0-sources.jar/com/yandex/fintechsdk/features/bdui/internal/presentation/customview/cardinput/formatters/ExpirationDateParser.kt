package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.ExpiryDate

internal class ExpirationDateParser {

    fun parseExpiryDate(rawExpirationDate: String): ExpiryDate {
        val month = rawExpirationDate.takeIf { it.length >= MONTH_LENGTH }
            ?.substring(0, MONTH_LENGTH)
            ?.toIntOrNull()

        val year = rawExpirationDate.takeIf { it.length >= MAX_NUM_CHARS }
            ?.substring(MONTH_LENGTH)
            ?.toIntOrNull()

        return if (month == null || year == null) ExpiryDate.Empty else ExpiryDate.NonEmpty(month, year)
    }

    private companion object {
        const val MONTH_LENGTH: Int = 2
        const val YEAR_LENGTH: Int = 2
        const val MAX_NUM_CHARS: Int = MONTH_LENGTH + YEAR_LENGTH
    }
}
