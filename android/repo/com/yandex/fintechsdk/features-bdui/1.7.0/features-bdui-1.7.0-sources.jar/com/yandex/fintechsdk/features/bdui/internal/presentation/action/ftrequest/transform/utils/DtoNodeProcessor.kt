package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils

import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.exception.ValueNodeIsNotArrayException
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.exception.ValueNodeIsNotMapException
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.exception.ValueNodeNotFoundException
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.DtoNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.TemplateNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.VariableNode
import javax.inject.Inject
import kotlin.collections.get

/**
 * Processes a [DtoNode] and its corresponding value, applying transformations and storing results in a [PatchHolder].
 *
 * This class traverses the structure of a [DtoNode], handling arrays, maps, and variables, and stores processed values
 * in the provided [PatchHolder] at the specified path. It supports nested structures and throws exceptions for
 * missing or mismatched node types.
 *
 * @constructor Creates a [DtoNodeProcessor] instance.
 */
internal class DtoNodeProcessor @Inject constructor() {

    fun process(node: DtoNode, nodeValue: Any?, patchHolder: PatchHolder, path: String) {
        when (node) {
            is DtoNode.Array -> {
                if (nodeValue == null) throw ValueNodeNotFoundException(path = path)
                val nodeArrayValue = nodeValue as? List<*> ?: throw ValueNodeIsNotArrayException(path = path)

                node.value.forEachIndexed { index, node ->
                    val indexedPath = "$path[$index]"
                    if (index >= nodeArrayValue.size) throw ValueNodeNotFoundException(indexedPath)
                    val itemValue = nodeArrayValue[index]

                    process(
                        node = node,
                        patchHolder = patchHolder,
                        nodeValue = itemValue,
                        path = indexedPath,
                    )
                }
            }

            is DtoNode.Map -> {
                if (nodeValue == null) throw ValueNodeNotFoundException(path)
                val value = nodeValue as? Map<*, *> ?: throw ValueNodeIsNotMapException(path)

                node.value.forEach { key, node ->
                    val newPath = "$path.$key"
                    val innerNodeValue = value[key]

                    process(
                        node = node,
                        nodeValue = innerNodeValue,
                        patchHolder = patchHolder,
                        path = newPath,
                    )
                }
            }

            is VariableNode -> {
                val value = when {
                    nodeValue != null -> nodeValue
                    node.isOptional -> node.optionalDescriptor?.toAny()
                    else -> throw ValueNodeNotFoundException(path)
                } ?: return

                patchHolder.storeValue(path = node.path, value = value)
            }

            is TemplateNode, is DtoNode.Value, DtoNode.Empty -> {
                /* Do nothing for this values */
            }
        }
    }
}
