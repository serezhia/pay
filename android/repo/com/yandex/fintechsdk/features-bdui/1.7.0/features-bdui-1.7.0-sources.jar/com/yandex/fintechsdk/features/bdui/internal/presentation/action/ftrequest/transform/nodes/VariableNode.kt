package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

/**
 * Represents a variable node that used for work with [JasonStateStore] variables.
 *
 * @property path A list of strings representing the path to the variable in [JasonStateStore].
 * @property isOptional Indicating whether the variable is optional.
 * @property optionalDescriptor An optional value for the variable.
 */
@Serializable
internal data class VariableNode(
    @SerialName("path")
    val path: List<String>,

    @SerialName("optional")
    val isOptional: Boolean = false,

    @SerialName("optionalDescriptor")
    val optionalDescriptor: JsonElement? = null,
) : ValueTransferNode()
