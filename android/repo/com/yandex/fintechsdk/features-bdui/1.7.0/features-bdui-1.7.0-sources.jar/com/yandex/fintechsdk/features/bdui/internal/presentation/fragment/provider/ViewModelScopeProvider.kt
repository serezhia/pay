package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider

import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import com.yandex.fintechsdk.core.utils.api.provider.BaseProvider
import kotlinx.coroutines.CoroutineScope
import javax.inject.Inject

@FeatureScope
internal class ViewModelScopeProvider @Inject constructor() : BaseProvider<CoroutineScope>()
