package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.barcode

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class BarcodeCustomProps(
    @SerialName("format")
    val format: String,

    @SerialName("value")
    val value: String,
)
