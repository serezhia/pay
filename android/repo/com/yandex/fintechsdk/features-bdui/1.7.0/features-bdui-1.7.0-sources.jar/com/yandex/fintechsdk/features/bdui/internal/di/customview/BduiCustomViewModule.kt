package com.yandex.fintechsdk.features.bdui.internal.di.customview

import com.yandex.finsdtechsdk.adapters.passport.sdk.api.PassportAdapter
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.bdui.api.customview.configuration.CustomViewConfiguration
import com.yandex.fintechsdk.core.bdui.api.customview.factory.CustomViewFactoryDelegateCreator
import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment
import com.yandex.fintechsdk.entities.region.Region
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.CustomViewFactoryDelegateCreatorImpl
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.CardInputViewConfiguration
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.WebViewConfiguration
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoMap
import dagger.multibindings.StringKey

@Module
internal interface BduiCustomViewModule {

    @FeatureScope
    @Binds
    fun bindCustomViewFactoryDelegateCreator(impl: CustomViewFactoryDelegateCreatorImpl): CustomViewFactoryDelegateCreator

    companion object {

        @Provides
        @IntoMap
        @StringKey(WebViewConfiguration.KEY)
        fun provideWebViewConfiguration(
            authRepository: AuthRepository,
            environment: DefaultEnvironment,
            flexAdapter: FlexAdapter?,
            region: Region,
            passportAdapter: PassportAdapter?,
            userAgentProvider: UserAgentProvider,
        ): CustomViewConfiguration {
            return WebViewConfiguration(
                authRepository = authRepository,
                environment = environment,
                flexAdapter = flexAdapter,
                region = region,
                passportAdapter = passportAdapter,
                cookies = listOf(),
                httpHeaders = null,
                javascriptInterfaces = null,
                userAgentProvider = { userAgent ->
                    "$userAgent ${userAgentProvider.get()}"
                },
            )
        }

        @Provides
        @IntoMap
        @StringKey(value = CardInputViewConfiguration.KEY)
        fun provideCardInputViewConfiguration(
            analytics: Analytics,
            cardBindingRepository: CardBindingRepository,
        ): CustomViewConfiguration {
            return CardInputViewConfiguration(
                analytics = analytics,
                cardBindingRepository = cardBindingRepository,
            )
        }
    }
}
