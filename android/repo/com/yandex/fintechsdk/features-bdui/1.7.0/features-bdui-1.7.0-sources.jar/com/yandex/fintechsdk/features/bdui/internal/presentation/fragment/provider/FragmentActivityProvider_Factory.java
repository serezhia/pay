package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FragmentActivityProvider_Factory implements Factory<FragmentActivityProvider> {
  @Override
  public FragmentActivityProvider get() {
    return newInstance();
  }

  public static FragmentActivityProvider_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static FragmentActivityProvider newInstance() {
    return new FragmentActivityProvider();
  }

  private static final class InstanceHolder {
    static final FragmentActivityProvider_Factory INSTANCE = new FragmentActivityProvider_Factory();
  }
}
