package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.textwatchers

import android.text.Editable
import android.text.TextWatcher
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.ExpirationDateFormatter
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.interfaces.ExpirationDateChangedListener

internal class ExpirationDateTextWatcher(
    private val listener: ExpirationDateChangedListener,
    private val expirationDateFormatter: ExpirationDateFormatter = ExpirationDateFormatter(),
) : TextWatcher {
    private var changeWasAddition = false

    override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) = Unit

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        changeWasAddition = count > before
    }

    override fun afterTextChanged(editable: Editable) {
        expirationDateFormatter.formatContent(editable, changeWasAddition)
        listener.onExpirationDateChanged(editable.toString())
    }
}
