package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DtoNodeProcessor_Factory implements Factory<DtoNodeProcessor> {
  @Override
  public DtoNodeProcessor get() {
    return newInstance();
  }

  public static DtoNodeProcessor_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DtoNodeProcessor newInstance() {
    return new DtoNodeProcessor();
  }

  private static final class InstanceHolder {
    static final DtoNodeProcessor_Factory INSTANCE = new DtoNodeProcessor_Factory();
  }
}
