package com.yandex.fintechsdk.features.bdui.internal.di

import androidx.lifecycle.ViewModel
import com.yandex.fintechsdk.core.architecture.api.component.FintechComponentStore
import com.yandex.fintechsdk.features.bdui.api.dependencies.BduiDependencies

internal class BduiComponentStore(
    dependencies: BduiDependencies,
) : ViewModel(), FintechComponentStore {
    override val component: BduiComponent = DaggerBduiComponent.factory().create(dependencies)
}
