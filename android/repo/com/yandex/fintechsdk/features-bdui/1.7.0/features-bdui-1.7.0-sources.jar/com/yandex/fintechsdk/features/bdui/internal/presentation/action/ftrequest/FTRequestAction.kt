package com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.NestedAction
import com.yandex.fintechsdk.core.network.api.request.RestMethod
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.DtoNode
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.nodes.SingleValueNode
import kotlinx.serialization.Contextual
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Kind of [BduiAction] intended for making network requests directly, bypassing frontback.
 * Contains all necessary information to construct the request and handle the response.
 *
 * @property method HTTP method (GET, POST, etc.)
 * @property baseUrl Base endpoint path
 * @property path Specific endpoint path
 * @property timeout Request timeout in seconds
 * @property headers HTTP headers map
 * @property queryItems Query parameters map
 * @property requestMap Request data map
 * @property responseMap Response parsing map
 * @property failedResponseMap Failed response parsing map
 * @property successAction Action to execute on successful response
 * @property failureAction Action to execute on fail
 * @property errorVarPath Path to variable in [JasonStateStore] where error value should be set
 * @property errorBodyLoggingRule Rule how to log failed response
 * @property statusCodeVarPath Path to variable in [JasonStateStore] where status code should be set
 */
@Serializable
internal data class FTRequestAction(
    @SerialName("baseURL")
    val baseUrl: String,

    @SerialName("errorBodyLoggingRule")
    val errorBodyLoggingRule: ErrorBodyLoggingRule?,

    @SerialName("errorVarPath")
    val errorVarPath: List<String>?,

    @SerialName("failedResponseMap")
    val failedResponseMap: Map<String, DtoNode>?,

    @SerialName("failureAction")
    val failureAction: @Contextual NestedAction?,

    @SerialName("headers")
    val headers: Map<String, SingleValueNode>?,

    @SerialName("method")
    val method: RestMethod,

    @SerialName("path")
    val path: String,

    @SerialName("queryItems")
    val queryItems: Map<String, SingleValueNode?>?,

    @SerialName("requestMap")
    val requestMap: Map<String, DtoNode>,

    @SerialName("responseMap")
    val responseMap: Map<String, DtoNode>,

    @SerialName("statusCodeVarPath")
    val statusCodeVarPath: List<String>?,

    @SerialName("successAction")
    val successAction: @Contextual NestedAction?,

    @SerialName("timeout")
    val timeout: Double,
) : BduiAction

@Serializable
internal data class ErrorBodyLoggingRule(
    val type: Type,
    val length: Int? = null,
) {
    enum class Type {
        Skip, Full, Partial
    }
}
