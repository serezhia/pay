package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.dynamicbininfo

internal data class BinRequestContext(
    val cardNumber: String,
    val prefix: String,
    val requestId: String,
    val startTime: Long,
)
