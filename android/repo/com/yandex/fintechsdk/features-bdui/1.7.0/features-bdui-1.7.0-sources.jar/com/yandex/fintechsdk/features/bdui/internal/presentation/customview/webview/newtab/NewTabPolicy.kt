package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.newtab

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.AllowNewTabType

internal enum class NewTabPolicy {
    Disabled,
    ExternalBrowser,
    CustomTabs,
}

internal fun AllowNewTabType?.asNewTabPolicy(): NewTabPolicy = when (this) {
    AllowNewTabType.BROWSER -> NewTabPolicy.ExternalBrowser
    AllowNewTabType.SYSTEM_TAB -> NewTabPolicy.CustomTabs
    AllowNewTabType.INPLACE, null -> NewTabPolicy.Disabled
}
