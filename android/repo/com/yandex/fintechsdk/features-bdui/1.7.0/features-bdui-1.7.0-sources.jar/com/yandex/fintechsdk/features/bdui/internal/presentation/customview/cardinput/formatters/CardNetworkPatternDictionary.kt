package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetwork
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetworkNumberInterval
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetworkPattern

internal class CardNetworkPatternDictionary(
    overrides: Map<CardNetwork, CardNetworkPattern> = emptyMap(),
) {

    val unknownPattern: CardNetworkPattern

    private val cardNetworkPatternsMap: Map<CardNetwork, CardNetworkPattern>

    init {
        // When dynamic BIN database is disabled, default values are used
        // When dynamic BIN database is enabled, the constructor receives
        // overrides: Map<CardNetwork, CardNetworkPattern> obtained from Tovarisch.
        val defaultPatterns = DEFAULT_PATTERNS.toMutableMap()

        // Apply overrides for all networks
        // (except UNKNOWN which is already handled above)
        overrides.forEach { (network, pattern) ->
            defaultPatterns[network] = pattern
        }

        // If an unknown case exists in overrides, it is used;
        // otherwise, the default pattern is used.
        val resolvedUnknown = defaultPatterns[CardNetwork.UNKNOWN] ?: DEFAULT_UNKNOWN_PATTERN
        unknownPattern = resolvedUnknown
        cardNetworkPatternsMap = defaultPatterns
    }

    fun getPatternFor(network: CardNetwork): CardNetworkPattern = cardNetworkPatternsMap[network] ?: unknownPattern

    companion object {
        private val SPACERS_4_6: List<Int> = listOf(4, 10)
        private val REGULAR_SPACERS: List<Int> = listOf(4, 8, 12)

        private val DEFAULT_UNKNOWN_PATTERN = CardNetworkPattern(
            intervals = listOf(),
            validLengths = listOf(12, 13, 14, 15, 16, 17, 18, 19),
            cvvLength = 3,
            spaceIndexes = REGULAR_SPACERS,
        )

        internal val DEFAULT_PATTERNS: Map<CardNetwork, CardNetworkPattern> = mapOf(
            CardNetwork.AMEX to CardNetworkPattern(
                intervals = listOf(
                    CardNetworkNumberInterval(start = "34", end = null),
                    CardNetworkNumberInterval(start = "37", end = null),
                ),
                validLengths = listOf(15),
                cvvLength = 4,
                spaceIndexes = SPACERS_4_6,
            ),
            CardNetwork.DISCOVER to CardNetworkPattern(
                intervals = listOf(
                    CardNetworkNumberInterval(start = "6011", end = null),
                    CardNetworkNumberInterval(start = "622126", end = "622925"),
                    CardNetworkNumberInterval(start = "644", end = "649"),
                    CardNetworkNumberInterval(start = "65", end = null),
                ),
                validLengths = listOf(16),
                cvvLength = 3,
                spaceIndexes = REGULAR_SPACERS,
            ),
            CardNetwork.JCB to CardNetworkPattern(
                intervals = listOf(CardNetworkNumberInterval(start = "3528", end = "3589")),
                validLengths = listOf(16),
                cvvLength = 3,
                spaceIndexes = REGULAR_SPACERS,
            ),
            CardNetwork.MAESTRO to CardNetworkPattern(
                intervals = listOf(
                    CardNetworkNumberInterval(start = "50", end = null),
                    CardNetworkNumberInterval(start = "56", end = "59"),
                    CardNetworkNumberInterval(start = "61", end = null),
                    CardNetworkNumberInterval(start = "63", end = null),
                    CardNetworkNumberInterval(start = "66", end = "69"),
                ),
                validLengths = listOf(12, 13, 14, 15, 16, 17, 18, 19),
                cvvLength = 3,
                spaceIndexes = REGULAR_SPACERS,
            ),
            CardNetwork.MASTERCARD to CardNetworkPattern(
                intervals = listOf(
                    CardNetworkNumberInterval(start = "222100", end = "272099"),
                    CardNetworkNumberInterval(start = "51", end = "55"),
                ),
                validLengths = listOf(16),
                cvvLength = 3,
                spaceIndexes = REGULAR_SPACERS,
            ),
            CardNetwork.MIR to CardNetworkPattern(
                intervals = listOf(CardNetworkNumberInterval(start = "2200", end = "2204")),
                validLengths = listOf(16, 17, 18, 19),
                cvvLength = 3,
                spaceIndexes = REGULAR_SPACERS,
            ),
            CardNetwork.UNIONPAY to CardNetworkPattern(
                intervals = listOf(
                    CardNetworkNumberInterval(start = "35", end = null),
                    CardNetworkNumberInterval(start = "62", end = null),
                    CardNetworkNumberInterval(start = "88", end = null),
                ),
                validLengths = listOf(16, 17, 18, 19),
                cvvLength = 3,
                spaceIndexes = REGULAR_SPACERS,
            ),
            CardNetwork.UZCARD to CardNetworkPattern(
                intervals = listOf(
                    CardNetworkNumberInterval(start = "860002", end = "860006"),
                    CardNetworkNumberInterval(start = "860008", end = "860009"),
                    CardNetworkNumberInterval(start = "860011", end = "860014"),
                    CardNetworkNumberInterval(start = "860020", end = null),
                    CardNetworkNumberInterval(start = "860030", end = "860031"),
                    CardNetworkNumberInterval(start = "860033", end = "860034"),
                    CardNetworkNumberInterval(start = "860038", end = null),
                    CardNetworkNumberInterval(start = "860043", end = null),
                    CardNetworkNumberInterval(start = "860048", end = "860051"),
                    CardNetworkNumberInterval(start = "860053", end = null),
                    CardNetworkNumberInterval(start = "860055", end = "860060"),
                ),
                validLengths = listOf(16),
                cvvLength = 3,
                spaceIndexes = REGULAR_SPACERS,
            ),
            CardNetwork.VISA to CardNetworkPattern(
                intervals = listOf(CardNetworkNumberInterval(start = "4", end = null)),
                validLengths = listOf(13, 16, 18, 19),
                cvvLength = 3,
                spaceIndexes = REGULAR_SPACERS,
            ),
            CardNetwork.VISAELECTRON to CardNetworkPattern(
                intervals = listOf(
                    CardNetworkNumberInterval(start = "4026", end = null),
                    CardNetworkNumberInterval(start = "417500", end = null),
                    CardNetworkNumberInterval(start = "4405", end = null),
                    CardNetworkNumberInterval(start = "4508", end = null),
                    CardNetworkNumberInterval(start = "4844", end = null),
                    CardNetworkNumberInterval(start = "4913", end = null),
                    CardNetworkNumberInterval(start = "4917", end = null),
                ),
                validLengths = listOf(16),
                cvvLength = 3,
                spaceIndexes = REGULAR_SPACERS,
            ),
            CardNetwork.HUMOCARD to CardNetworkPattern(
                intervals = listOf(CardNetworkNumberInterval(start = "9860", end = null)),
                validLengths = listOf(12, 13, 14, 15, 16, 17, 18, 19),
                cvvLength = 3,
                spaceIndexes = REGULAR_SPACERS,
            ),
            CardNetwork.UNKNOWN to DEFAULT_UNKNOWN_PATTERN,
        )
    }
}
