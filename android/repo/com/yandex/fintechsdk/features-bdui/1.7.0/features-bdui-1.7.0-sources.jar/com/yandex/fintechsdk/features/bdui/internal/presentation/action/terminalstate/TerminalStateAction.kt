package com.yandex.fintechsdk.features.bdui.internal.presentation.action.terminalstate

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class TerminalStateAction(
    @SerialName("result")
    val result: String,
    
    @SerialName("description")
    val description: String? = null,
    
    @SerialName("reasonCode")
    val reasonCode: String? = null,
) : BduiAction
