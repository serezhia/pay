package com.yandex.fintechsdk.features.bdui.internal.di.customview;

import com.yandex.finsdtechsdk.adapters.passport.sdk.api.PassportAdapter;
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.core.bdui.api.customview.configuration.CustomViewConfiguration;
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider;
import com.yandex.fintechsdk.data.auth.api.AuthRepository;
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment;
import com.yandex.fintechsdk.entities.region.Region;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiCustomViewModule_Companion_ProvideWebViewConfigurationFactory implements Factory<CustomViewConfiguration> {
  private final Provider<AuthRepository> authRepositoryProvider;

  private final Provider<DefaultEnvironment> environmentProvider;

  private final Provider<FlexAdapter> flexAdapterProvider;

  private final Provider<Region> regionProvider;

  private final Provider<PassportAdapter> passportAdapterProvider;

  private final Provider<UserAgentProvider> userAgentProvider;

  private BduiCustomViewModule_Companion_ProvideWebViewConfigurationFactory(
      Provider<AuthRepository> authRepositoryProvider,
      Provider<DefaultEnvironment> environmentProvider, Provider<FlexAdapter> flexAdapterProvider,
      Provider<Region> regionProvider, Provider<PassportAdapter> passportAdapterProvider,
      Provider<UserAgentProvider> userAgentProvider) {
    this.authRepositoryProvider = authRepositoryProvider;
    this.environmentProvider = environmentProvider;
    this.flexAdapterProvider = flexAdapterProvider;
    this.regionProvider = regionProvider;
    this.passportAdapterProvider = passportAdapterProvider;
    this.userAgentProvider = userAgentProvider;
  }

  @Override
  public CustomViewConfiguration get() {
    return provideWebViewConfiguration(authRepositoryProvider.get(), environmentProvider.get(), flexAdapterProvider.get(), regionProvider.get(), passportAdapterProvider.get(), userAgentProvider.get());
  }

  public static BduiCustomViewModule_Companion_ProvideWebViewConfigurationFactory create(
      Provider<AuthRepository> authRepositoryProvider,
      Provider<DefaultEnvironment> environmentProvider, Provider<FlexAdapter> flexAdapterProvider,
      Provider<Region> regionProvider, Provider<PassportAdapter> passportAdapterProvider,
      Provider<UserAgentProvider> userAgentProvider) {
    return new BduiCustomViewModule_Companion_ProvideWebViewConfigurationFactory(authRepositoryProvider, environmentProvider, flexAdapterProvider, regionProvider, passportAdapterProvider, userAgentProvider);
  }

  public static CustomViewConfiguration provideWebViewConfiguration(AuthRepository authRepository,
      DefaultEnvironment environment, @Nullable FlexAdapter flexAdapter, Region region,
      @Nullable PassportAdapter passportAdapter, UserAgentProvider userAgentProvider) {
    return Preconditions.checkNotNullFromProvides(BduiCustomViewModule.Companion.provideWebViewConfiguration(authRepository, environment, flexAdapter, region, passportAdapter, userAgentProvider));
  }
}
