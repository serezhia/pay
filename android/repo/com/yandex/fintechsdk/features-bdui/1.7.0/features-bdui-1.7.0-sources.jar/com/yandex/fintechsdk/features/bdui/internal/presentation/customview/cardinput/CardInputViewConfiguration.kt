package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.bdui.api.customview.configuration.CustomViewConfiguration
import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository

internal class CardInputViewConfiguration(
    val analytics: Analytics,
    val cardBindingRepository: CardBindingRepository,
) : CustomViewConfiguration {

    companion object {
        const val KEY: String = "CustomViewConfiguration"
    }
}
