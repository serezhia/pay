package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

internal data class CvvField(
    val cvv: Cvv,
    val showValidationStatus: Boolean,
    val validationStatus: ValidationStatus,
)
