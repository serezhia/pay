package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract

import androidx.annotation.StringRes

internal sealed interface ValidationStatus {
    object Success : ValidationStatus
    data class Error(@StringRes val errorMsgRes: Int) : ValidationStatus
}

internal fun ValidationStatus.isSuccess(): Boolean = this is ValidationStatus.Success
