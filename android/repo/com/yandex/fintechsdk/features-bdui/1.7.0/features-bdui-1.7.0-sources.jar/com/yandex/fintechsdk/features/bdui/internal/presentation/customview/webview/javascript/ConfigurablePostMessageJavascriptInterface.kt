package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.javascript

import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.model.PostMessageAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.webview.postmessage.PostMessageHandler

internal class ConfigurablePostMessageJavascriptInterface(
    private val postMessageHandler: PostMessageHandler,
) : PayPostMessageJavascriptInterface() {
    
    fun configureHandlers(postMessageActions: List<PostMessageAction>) {
        postMessageHandler.setHandlers(postMessageActions = postMessageActions)
    }
    
    fun clearHandlers() {
        postMessageHandler.unregisterHandlers()
    }
    
    override fun messageReceived(data: String) {
        postMessageHandler.handlePostMessage(data = data)
    }
}
