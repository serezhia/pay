package com.yandex.fintechsdk.features.bdui.api.dependencies

import com.yandex.finsdtechsdk.adapters.passport.sdk.api.PassportAdapter
import com.yandex.fintechsdk.adapters.yb.sdk.api.YbAdapter
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.adapters.plus.sdk.api.PlusAdapter
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.architecture.api.feature.dependencies.FeatureDependencies
import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraHeadersProvider
import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraQueriesProvider
import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery
import com.yandex.fintechsdk.core.bdui.api.spinner.IsSpinnerPreviewEnabled
import com.yandex.fintechsdk.core.bdui.api.theme.BduiThemeProvider
import com.yandex.fintechsdk.core.network.api.auth.AuthTokenProvider
import com.yandex.fintechsdk.core.navigation.api.Router
import com.yandex.fintechsdk.core.network.api.network.DefaultNetworkApi
import com.yandex.fintechsdk.core.ui.impl.api.activity.InsetsConfig
import com.yandex.fintechsdk.core.ui.impl.api.shimmers.ShimmersLayoutProvider
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment
import com.yandex.fintechsdk.entities.region.Region
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.BduiNavigator
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DeviceChallengeSignatureProvider
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DevicePubkeyProvider
import okhttp3.OkHttpClient

public interface BduiDependencies : FeatureDependencies {
    public val analytics: Analytics
    public val authRepository: AuthRepository
    public val authTokenProvider: AuthTokenProvider
    public val bduiActionsDelegate: BduiActionsDelegate
    public val bduiExtraHeadersProvider: BduiExtraHeadersProvider
    public val bduiExtraQueriesProvider: BduiExtraQueriesProvider
    public val bduiHostUrlProvider: BduiHostUrlProvider
    public val bduiNavigator: BduiNavigator
    public val bduiThemeProvider: BduiThemeProvider
    public val cardBindingRepository: CardBindingRepository
    public val defaultNetworkApi: DefaultNetworkApi
    public val deviceChallengeSignatureProvider: DeviceChallengeSignatureProvider
    public val devicePubkeyProvider: DevicePubkeyProvider
    public val environment: DefaultEnvironment
    public val flexAdapter: FlexAdapter?
    public val initialDocumentQuery: BduiDocumentQuery
    public val insetsConfig: InsetsConfig
    public val isSpinnerPreviewEnabled: IsSpinnerPreviewEnabled
    public val okHttpClientBuilder: OkHttpClient.Builder
    public val passportAdapter: PassportAdapter?
    public val plusAdapter: PlusAdapter?
    public val region: Region
    public val router: Router
    public val shimmersLayoutProvider: ShimmersLayoutProvider
    public val userAgentProvider: UserAgentProvider
    public val ybSdkAdapter: YbAdapter?
}
