package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment;

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction;
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionInfo;
import com.yandex.fintechsdk.core.bdui.api.customview.configuration.CustomViewConfiguration;
import com.yandex.fintechsdk.core.bdui.api.customview.factory.CustomViewFactoryDelegateCreator;
import com.yandex.fintechsdk.core.bdui.api.eventhandler.BduiErrorHandler;
import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraHeadersProvider;
import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraQueriesProvider;
import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery;
import com.yandex.fintechsdk.core.bdui.api.spinner.IsSpinnerPreviewEnabled;
import com.yandex.fintechsdk.core.bdui.api.theme.BduiThemeProvider;
import com.yandex.fintechsdk.core.navigation.api.Router;
import com.yandex.fintechsdk.core.ui.impl.api.activity.InsetsConfigHolder;
import com.yandex.fintechsdk.features.bdui.api.dependencies.BduiHostUrlProvider;
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.BduiNavigator;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.ChromeTabLaunchActionsStore;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithInsetsProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithoutInsetsProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentManagerProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;
import okhttp3.OkHttpClient;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiViewModel_Factory implements Factory<BduiViewModel> {
  private final Provider<Set<BduiActionInfo<BduiAction>>> actionsInfoProvider;

  private final Provider<Analytics> analyticsProvider;

  private final Provider<BduiErrorHandler> bduiErrorHandlerProvider;

  private final Provider<BduiExtraHeadersProvider> bduiHeadersProvider;

  private final Provider<BduiDocumentQuery> bduiInitialDocumentQueryProvider;

  private final Provider<BduiNavigator> bduiNavigatorProvider;

  private final Provider<BduiExtraQueriesProvider> bduiQueriesProvider;

  private final Provider<BduiThemeProvider> bduiThemeProvider;

  private final Provider<ChromeTabLaunchActionsStore> chromeTabLaunchActionsStoreProvider;

  private final Provider<ContainerWithInsetsProvider> containerWithInsetsProvider;

  private final Provider<ContainerWithoutInsetsProvider> containerWithoutInsetsProvider;

  private final Provider<ContextProvider> contextProvider;

  private final Provider<Map<String, CustomViewConfiguration>> customViewConfigurationsProvider;

  private final Provider<CustomViewFactoryDelegateCreator> customViewFactoryDelegateCreatorProvider;

  private final Provider<FlexAdapter> flexAdapterProvider;

  private final Provider<FragmentActivityProvider> fragmentActivityProvider;

  private final Provider<FragmentManagerProvider> fragmentManagerProvider;

  private final Provider<BduiHostUrlProvider> bduiHostUrlProvider;

  private final Provider<InsetsConfigHolder> insetsConfigHolderProvider;

  private final Provider<IsSpinnerPreviewEnabled> isSpinnerPreviewEnabledProvider;

  private final Provider<OkHttpClient.Builder> okHttpClientBuilderProvider;

  private final Provider<Router> routerProvider;

  private final Provider<ViewModelScopeProvider> viewModelScopeProvider;

  private BduiViewModel_Factory(Provider<Set<BduiActionInfo<BduiAction>>> actionsInfoProvider,
      Provider<Analytics> analyticsProvider, Provider<BduiErrorHandler> bduiErrorHandlerProvider,
      Provider<BduiExtraHeadersProvider> bduiHeadersProvider,
      Provider<BduiDocumentQuery> bduiInitialDocumentQueryProvider,
      Provider<BduiNavigator> bduiNavigatorProvider,
      Provider<BduiExtraQueriesProvider> bduiQueriesProvider,
      Provider<BduiThemeProvider> bduiThemeProvider,
      Provider<ChromeTabLaunchActionsStore> chromeTabLaunchActionsStoreProvider,
      Provider<ContainerWithInsetsProvider> containerWithInsetsProvider,
      Provider<ContainerWithoutInsetsProvider> containerWithoutInsetsProvider,
      Provider<ContextProvider> contextProvider,
      Provider<Map<String, CustomViewConfiguration>> customViewConfigurationsProvider,
      Provider<CustomViewFactoryDelegateCreator> customViewFactoryDelegateCreatorProvider,
      Provider<FlexAdapter> flexAdapterProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<FragmentManagerProvider> fragmentManagerProvider,
      Provider<BduiHostUrlProvider> bduiHostUrlProvider,
      Provider<InsetsConfigHolder> insetsConfigHolderProvider,
      Provider<IsSpinnerPreviewEnabled> isSpinnerPreviewEnabledProvider,
      Provider<OkHttpClient.Builder> okHttpClientBuilderProvider, Provider<Router> routerProvider,
      Provider<ViewModelScopeProvider> viewModelScopeProvider) {
    this.actionsInfoProvider = actionsInfoProvider;
    this.analyticsProvider = analyticsProvider;
    this.bduiErrorHandlerProvider = bduiErrorHandlerProvider;
    this.bduiHeadersProvider = bduiHeadersProvider;
    this.bduiInitialDocumentQueryProvider = bduiInitialDocumentQueryProvider;
    this.bduiNavigatorProvider = bduiNavigatorProvider;
    this.bduiQueriesProvider = bduiQueriesProvider;
    this.bduiThemeProvider = bduiThemeProvider;
    this.chromeTabLaunchActionsStoreProvider = chromeTabLaunchActionsStoreProvider;
    this.containerWithInsetsProvider = containerWithInsetsProvider;
    this.containerWithoutInsetsProvider = containerWithoutInsetsProvider;
    this.contextProvider = contextProvider;
    this.customViewConfigurationsProvider = customViewConfigurationsProvider;
    this.customViewFactoryDelegateCreatorProvider = customViewFactoryDelegateCreatorProvider;
    this.flexAdapterProvider = flexAdapterProvider;
    this.fragmentActivityProvider = fragmentActivityProvider;
    this.fragmentManagerProvider = fragmentManagerProvider;
    this.bduiHostUrlProvider = bduiHostUrlProvider;
    this.insetsConfigHolderProvider = insetsConfigHolderProvider;
    this.isSpinnerPreviewEnabledProvider = isSpinnerPreviewEnabledProvider;
    this.okHttpClientBuilderProvider = okHttpClientBuilderProvider;
    this.routerProvider = routerProvider;
    this.viewModelScopeProvider = viewModelScopeProvider;
  }

  @Override
  public BduiViewModel get() {
    return newInstance(actionsInfoProvider.get(), analyticsProvider.get(), bduiErrorHandlerProvider.get(), bduiHeadersProvider.get(), bduiInitialDocumentQueryProvider.get(), bduiNavigatorProvider.get(), bduiQueriesProvider.get(), bduiThemeProvider.get(), chromeTabLaunchActionsStoreProvider.get(), containerWithInsetsProvider.get(), containerWithoutInsetsProvider.get(), contextProvider.get(), customViewConfigurationsProvider.get(), customViewFactoryDelegateCreatorProvider.get(), flexAdapterProvider.get(), fragmentActivityProvider.get(), fragmentManagerProvider.get(), bduiHostUrlProvider.get(), insetsConfigHolderProvider.get(), isSpinnerPreviewEnabledProvider.get(), okHttpClientBuilderProvider.get(), routerProvider.get(), viewModelScopeProvider.get());
  }

  public static BduiViewModel_Factory create(
      Provider<Set<BduiActionInfo<BduiAction>>> actionsInfoProvider,
      Provider<Analytics> analyticsProvider, Provider<BduiErrorHandler> bduiErrorHandlerProvider,
      Provider<BduiExtraHeadersProvider> bduiHeadersProvider,
      Provider<BduiDocumentQuery> bduiInitialDocumentQueryProvider,
      Provider<BduiNavigator> bduiNavigatorProvider,
      Provider<BduiExtraQueriesProvider> bduiQueriesProvider,
      Provider<BduiThemeProvider> bduiThemeProvider,
      Provider<ChromeTabLaunchActionsStore> chromeTabLaunchActionsStoreProvider,
      Provider<ContainerWithInsetsProvider> containerWithInsetsProvider,
      Provider<ContainerWithoutInsetsProvider> containerWithoutInsetsProvider,
      Provider<ContextProvider> contextProvider,
      Provider<Map<String, CustomViewConfiguration>> customViewConfigurationsProvider,
      Provider<CustomViewFactoryDelegateCreator> customViewFactoryDelegateCreatorProvider,
      Provider<FlexAdapter> flexAdapterProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<FragmentManagerProvider> fragmentManagerProvider,
      Provider<BduiHostUrlProvider> bduiHostUrlProvider,
      Provider<InsetsConfigHolder> insetsConfigHolderProvider,
      Provider<IsSpinnerPreviewEnabled> isSpinnerPreviewEnabledProvider,
      Provider<OkHttpClient.Builder> okHttpClientBuilderProvider, Provider<Router> routerProvider,
      Provider<ViewModelScopeProvider> viewModelScopeProvider) {
    return new BduiViewModel_Factory(actionsInfoProvider, analyticsProvider, bduiErrorHandlerProvider, bduiHeadersProvider, bduiInitialDocumentQueryProvider, bduiNavigatorProvider, bduiQueriesProvider, bduiThemeProvider, chromeTabLaunchActionsStoreProvider, containerWithInsetsProvider, containerWithoutInsetsProvider, contextProvider, customViewConfigurationsProvider, customViewFactoryDelegateCreatorProvider, flexAdapterProvider, fragmentActivityProvider, fragmentManagerProvider, bduiHostUrlProvider, insetsConfigHolderProvider, isSpinnerPreviewEnabledProvider, okHttpClientBuilderProvider, routerProvider, viewModelScopeProvider);
  }

  public static BduiViewModel newInstance(Set<BduiActionInfo<BduiAction>> actionsInfo,
      Analytics analytics, BduiErrorHandler bduiErrorHandler,
      BduiExtraHeadersProvider bduiHeadersProvider, BduiDocumentQuery bduiInitialDocumentQuery,
      BduiNavigator bduiNavigator, BduiExtraQueriesProvider bduiQueriesProvider,
      BduiThemeProvider bduiThemeProvider, ChromeTabLaunchActionsStore chromeTabLaunchActionsStore,
      ContainerWithInsetsProvider containerWithInsetsProvider,
      ContainerWithoutInsetsProvider containerWithoutInsetsProvider,
      ContextProvider contextProvider,
      Map<String, CustomViewConfiguration> customViewConfigurations,
      CustomViewFactoryDelegateCreator customViewFactoryDelegateCreator,
      @Nullable FlexAdapter flexAdapter, FragmentActivityProvider fragmentActivityProvider,
      FragmentManagerProvider fragmentManagerProvider, BduiHostUrlProvider bduiHostUrlProvider,
      InsetsConfigHolder insetsConfigHolder, IsSpinnerPreviewEnabled isSpinnerPreviewEnabled,
      OkHttpClient.Builder okHttpClientBuilder, Router router,
      ViewModelScopeProvider viewModelScopeProvider) {
    return new BduiViewModel(actionsInfo, analytics, bduiErrorHandler, bduiHeadersProvider, bduiInitialDocumentQuery, bduiNavigator, bduiQueriesProvider, bduiThemeProvider, chromeTabLaunchActionsStore, containerWithInsetsProvider, containerWithoutInsetsProvider, contextProvider, customViewConfigurations, customViewFactoryDelegateCreator, flexAdapter, fragmentActivityProvider, fragmentManagerProvider, bduiHostUrlProvider, insetsConfigHolder, isSpinnerPreviewEnabled, okHttpClientBuilder, router, viewModelScopeProvider);
  }
}
