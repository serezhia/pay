package com.yandex.fintechsdk.features.bdui.internal.presentation.fragment

import com.yandex.fintechsdk.core.bdui.api.overlay.OverlayConfig
import com.yandex.fintechsdk.core.bdui.api.overlay.OverlayConfigProvider
import com.yandex.fintechsdk.core.ui.impl.api.activity.InsetsConfigHolder

/**
 * Provides current overlay configuration for FlexAdapter.
 * Reads fresh config from [insetsConfigHolder] on each [get] call.
 */
internal class BduiOverlayConfigProvider(
    private val insetsConfigHolder: InsetsConfigHolder,
) : OverlayConfigProvider {

    override fun get(): OverlayConfig {
        val config = insetsConfigHolder.config.value
        return OverlayConfig(
            bottomSheetMode = config.bottomSheetMode,
            overlayTopMarginDp = config.bottomSheetTopMarginDp,
        )
    }
}
