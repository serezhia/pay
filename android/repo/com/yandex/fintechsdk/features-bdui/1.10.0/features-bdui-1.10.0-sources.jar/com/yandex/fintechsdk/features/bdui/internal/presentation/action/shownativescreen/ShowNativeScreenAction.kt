package com.yandex.fintechsdk.features.bdui.internal.presentation.action.shownativescreen

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import kotlinx.serialization.Serializable

@Serializable
internal data class ShowNativeScreenAction(
    val params: Map<String, String>,
    val route: String,
) : BduiAction
