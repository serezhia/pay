package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput

import androidx.annotation.StringRes
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.bdui.api.customview.BduiVariableController
import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomActionHandler
import com.yandex.fintechsdk.core.bdui.api.customview.expression.BduiExpressionResolver
import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeCardData
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeMethod
import com.yandex.fintechsdk.entities.card.BinInfo
import com.yandex.fintechsdk.entities.theme.Theme
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.CardInputAnalyticsConstants
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinAnalyticsState
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinEventWrapper
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinInfoAnalyticsReporter
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinInfoAnalyticsResetReason
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.FieldCompletedEvent
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.FieldFocusedEvent
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.FieldValidationFailedEvent
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.FormSubmittedEvent
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.asEventParamValue
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardInputState
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNetwork
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNumber
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardNumberField
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.Cvv
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CvvField
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.ExpiryDate
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.ExpiryDateField
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.Step
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.ValidationStatus
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.isSuccess
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.dynamicbininfo.BinRequestContext
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.dynamicbininfo.DynamicBinInfoManager
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNetworkParser
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNetworkImage
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNetworkPatternDictionary
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNetworkWithPatternChecker
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.ExpirationDateParser
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.NetworkImageFacade
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.SecurityCodeTypeStringFacade
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.SecurityCodeLabel
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.interfaces.CardNumberChangedListener
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.interfaces.CvvChangedListener
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.interfaces.ExpirationDateChangedListener
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.validators.ValidationFacade
import com.yandex.fintechsdk.resources.R.string
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

@Suppress("LargeClass")
internal class CardInputViewController(
    cachedState: CardInputState?,
    private val analytics: Analytics,
    private val cardBindingRepository: CardBindingRepository,
    private val cardNetworkParser: CardNetworkParser = CardNetworkParser(),
    private val cardNetworkPatternDictionary: CardNetworkPatternDictionary = CardNetworkPatternDictionary(),
    private val cardNetworkChecker: CardNetworkWithPatternChecker = CardNetworkWithPatternChecker(
        cardNetworkPatternDictionary = cardNetworkPatternDictionary,
    ),
    private val customProps: CardInputCustomProps,
    private val expirationDateParser: ExpirationDateParser = ExpirationDateParser(),
    private val networkImageFacade: NetworkImageFacade = NetworkImageFacade(),
    private val securityCodeTypeStringFacade: SecurityCodeTypeStringFacade = SecurityCodeTypeStringFacade(),
    private val onWaitForBinInfoStartIfNeeded: () -> Unit,
    private val onWaitForBinInfoCancelIfNeeded: () -> Boolean,
    private val variableController: BduiVariableController,
    private val validationFacade: ValidationFacade = ValidationFacade(cardNetworkChecker = cardNetworkChecker),
) : CardNumberChangedListener, ExpirationDateChangedListener, CvvChangedListener {
    private val _state = MutableStateFlow(getInitialState(cachedState))
    internal val state: StateFlow<CardInputState> = _state

    private var actionHandler: DivCustomActionHandler? = null
    private var expressionResolver: BduiExpressionResolver? = null
    private var currentBinInfo: BinInfo? = null
    private var lastBinRequestContext: BinRequestContext? = null
    private var lastStaticDataAnalyticsCardNumber: String? = null
    private val cardNetworkDetailsByCode: Map<String, CardNetworkData> =
        customProps.dynamicBinInfoProps?.cardNetworkDetails
            ?.mapKeys { entry -> entry.key.lowercase() }
            ?: emptyMap()
    private val analyticsState = DynamicBinAnalyticsState()
    private val isBinInfoDynamicEnabled = customProps.enableDynamicBinInfo ?: false

    private val diehardBaseUrl = customProps.tokenizationData.diehardBaseUrl
    private val binInfoManager = DynamicBinInfoManager(
        analytics = analytics,
        analyticsState = analyticsState,
        getBinInfo = { prefix -> cardBindingRepository.getBinInfo(baseUrl = diehardBaseUrl, prefix = prefix) },
        isDynamicBinEnabled = isBinInfoDynamicEnabled,
        getCurrentCardNumber = { cleanCardNumber(cardNumber = _state.value.cardNumberField.cardNumber) },
        onSuccess = { binInfo, context ->
            currentBinInfo = binInfo
            lastBinRequestContext = context
            val cardNetwork = cardNetworkParser.mapPaymentSystemToCardNetwork(
                paymentSystem = binInfo.paymentSystem,
            )
            updateCardNetworkFromBin(
                cardNetwork = cardNetwork,
            )
            reportDynamicDataAppliedIfNeeded(
                binInfo = binInfo,
                context = context,
            )
        },
        onFallback = {
            currentBinInfo = null
            lastBinRequestContext = null
            updateCardNetworkFromBin()
        },
        resolveStaticPaymentSystem = { cardNumber ->
            val network = cardNetworkChecker.lookup(numStr = cardNumber).cardNetwork
            network.takeIf { it != CardNetwork.UNKNOWN }?.stringCode
        },
        resolveCardNetworkData = { paymentSystem ->
            cardNetworkDetailsByCode[paymentSystem.lowercase()]
        },
    )
    private val analyticsReporter = DynamicBinInfoAnalyticsReporter(
        analytics = analytics,
        analyticsState = analyticsState,
        cardNetworkChecker = cardNetworkChecker,
        isDynamicBinEnabled = isBinInfoDynamicEnabled,
    )

    private val nextActionLockDelayInMillis = customProps.dynamicBinInfoProps?.nextActionLockDelayInMillis ?: 0L

    override fun onCardNumberChanged(value: String) {
        val cardNumber = CardNumber(value = value)
        val cleanCardNumber = cleanCardNumber(cardNumber = cardNumber)
        if (resetIfEmpty(cardNumber = cardNumber, cleanCardNumber = cleanCardNumber)) return

        val previousCleanLength = cleanCardNumber(cardNumber = _state.value.cardNumberField.cardNumber).length
        val isSuccessValidation = validationFacade.validateCardNumber(cardNumber = cardNumber)

        handleBinResetIfNeeded(cleanCardNumber = cleanCardNumber)
        if (!isBinInfoDynamicEnabled) {
            handleStaticDataAppliedIfNeeded(cleanCardNumber = cleanCardNumber)
        }

        val shouldUpdateIcon = shouldUpdateIcon(currentLength = cleanCardNumber.length)
        _state.update {
            val networkImage = resolveNetworkImageForInput(
                cleanCardNumber = cleanCardNumber,
                cardNumber = cardNumber,
                shouldUpdateIcon = shouldUpdateIcon,
                previousState = it,
            )
            val securityCodeLabel = resolveSecurityCodeLabel(
                cleanCardNumber = cleanCardNumber,
                cardNumber = cardNumber,
                previousState = it,
            )
            val shouldHideCvv = shouldHideCvv(
                cardNumber = cleanCardNumber,
                binInfo = currentBinInfo,
            )
            val validationStatus = validationStatusFromResult(
                isSuccessValidate = isSuccessValidation,
                errorMsgRes = string.finsdk_wrong_card_number,
            )
            val showValidationStatus = validationFacade.validateCardNumberLength(cardNumber = cardNumber)
            sendCardInputFieldAnalyticsIfNeeded(validationStatus = validationStatus, showValidationStatus = showValidationStatus, step = it.step)

            it.copy(
                cardNumberField = CardNumberField(
                    cardNumber = cardNumber,
                    showValidationStatus = validationFacade.validateCardNumberLength(
                        cardNumber = cardNumber,
                    ),
                    validationStatus = validationStatusFromResult(
                        isSuccessValidate = isSuccessValidation,
                        errorMsgRes = string.finsdk_wrong_card_number,
                    ),
                ),
                isCvvHidden = shouldHideCvv,
                networkImageRes = networkImage.fallbackIconRes,
                networkIconUrl = networkImage.iconUrl,
                securityCodeStringRes = securityCodeLabel.fallbackRes,
                securityCodeLabel = securityCodeLabel.customLabel,
            )
        }

        if (isBinInfoDynamicEnabled && cleanCardNumber.length >= MIN_BIN_LENGTH_FOR_REQUEST) {
            val isBulkInput = cleanCardNumber.length - previousCleanLength > 1
            binInfoManager.load(cardNumber = cardNumber.value, isBulkInput = isBulkInput)
        }
    }

    override fun onExpirationDateChanged(value: String) {
        val expiryDate = expirationDateParser.parseExpiryDate(
            rawExpirationDate = value,
        )
        val isSuccessValidation = validationFacade.validateExpiryDate(
            expiryDate = expiryDate,
        )

        _state.update {
            val nextStep = if (isSuccessValidation && it.step == Step.CardExpirationDate) {
                if (it.isCvvHidden) Step.CardBinding() else Step.CardCvv
            } else {
                it.step
            }
            val showValidationStatus = validationFacade.validateExpiryNonEmpty(
                expiryDate = expiryDate,
            )
            val validationStatus = validationStatusFromResult(
                isSuccessValidate = isSuccessValidation,
                errorMsgRes = string.finsdk_wrong_expiration_date,
            )

            when {
                validationStatus is ValidationStatus.Success -> {
                    analytics.reportProductEvent(
                        event = FieldCompletedEvent(
                            fieldType = CardInputAnalyticsConstants.FieldType.EXPIRATION_DATE,
                            formStep = it.step.asEventParamValue(),
                        ),
                    )
                }

                validationStatus is ValidationStatus.Error && showValidationStatus -> {
                    analytics.reportProductEvent(
                        event = FieldValidationFailedEvent(
                            fieldType = CardInputAnalyticsConstants.FieldType.EXPIRATION_DATE,
                            formStep = it.step.asEventParamValue(),
                            error = CardInputAnalyticsConstants.ValidationError.INVALID_EXPIRATION_DATE,
                            trigger = CardInputAnalyticsConstants.Trigger.CHANGE,
                        ),
                    )
                }
            }

            it.copy(
                step = nextStep,
                expiryDateField = ExpiryDateField(
                    rawExpiryDate = value,
                    expiryDate = expiryDate,
                    showValidationStatus = showValidationStatus,
                    validationStatus = validationStatus,
                ),
            )
        }
    }

    override fun onCvvChanged(value: String) {
        val cvv = Cvv(value)

        _state.update {
            val cardNumber = it.cardNumberField.cardNumber
            val isSuccessValidation = validationFacade.validateCvv(
                cvv = cvv,
                cardNumber = cardNumber,
            )
            val showValidationStatus = it.cvvField.showValidationStatus || isSuccessValidation
            val validationStatus = validationStatusFromResult(
                isSuccessValidate = isSuccessValidation,
                errorMsgRes = string.finsdk_wrong_cvv,
            )

            when {
                validationStatus is ValidationStatus.Success -> {
                    analytics.reportProductEvent(
                        event = FieldCompletedEvent(
                            fieldType = CardInputAnalyticsConstants.FieldType.CVV,
                            formStep = it.step.asEventParamValue(),
                        ),
                    )
                }

                validationStatus is ValidationStatus.Error && showValidationStatus -> {
                    analytics.reportProductEvent(
                        event = FieldValidationFailedEvent(
                            fieldType = CardInputAnalyticsConstants.FieldType.CVV,
                            formStep = it.step.asEventParamValue(),
                            error = CardInputAnalyticsConstants.ValidationError.INVALID_CVV,
                            trigger = CardInputAnalyticsConstants.Trigger.CHANGE,
                        ),
                    )
                }
            }

            it.copy(
                cvvField = CvvField(
                    cvv = cvv,
                    showValidationStatus = showValidationStatus,
                    validationStatus = validationStatus,
                ),
            )
        }
    }

    internal fun setActionHandler(actionHandler: DivCustomActionHandler?) {
        this.actionHandler = actionHandler
    }

    internal suspend fun submitForm() {
        if (!_state.value.isCvvHidden) {
            proceedToCvv()
        }

        _state.update {
            analytics.reportProductEvent(event = FormSubmittedEvent)
            it.copy(
                step = Step.CardBinding(isInputsLocked = true),
            )
        }

        reportDataStateOnSubmit()

        val data = getTokenizeData(state = _state.value)
        if (data == null) {
            actionHandler?.handleAction(
                action = customProps.tokenizationData.tokenizeFailureAction,
            )
            return
        }

        withContext(context = Dispatchers.IO) {
            val tokenizeResult = cardBindingRepository.tokenize(
                baseUrl = diehardBaseUrl,
                method = TokenizeMethod.CARD,
                data = data,
                context = customProps.tokenizationData.tokenizationContext,
            )

            tokenizeResult
                .onSuccess { result ->
                    variableController.setVariable(
                        name = customProps.tokenizationData.pmdVariableName,
                        value = result.pmd,
                    )

                    result.psd?.let {
                        variableController.setVariable(
                            name = customProps.tokenizationData.psdVariableName,
                            value = it,
                        )
                    }
                    // Switch to main thread or actions, affecting UI logic, may be ignored
                    withContext(context = Dispatchers.Main) {
                        actionHandler?.handleAction(
                            action = customProps.tokenizationData.tokenizeSuccessAction,
                        )
                    }
                }
                .onFailure {
                    // Switch to main thread or actions, affecting UI logic, may be ignored
                    withContext(context = Dispatchers.Main) {
                        actionHandler?.handleAction(
                            action = customProps.tokenizationData.tokenizeFailureAction,
                        )
                    }
                }
        }
    }

    internal suspend fun waitForBinInfoIfNeeded() {
        val hasPending = binInfoManager.hasPendingRequests()
        if (!isBinInfoDynamicEnabled || nextActionLockDelayInMillis <= 0 || !hasPending) {
            finishWaitingBinInfo()
            return
        }
        _state.update { it.copy(isBinInfoLoading = true) }
        val finished = withTimeoutOrNull(timeMillis = nextActionLockDelayInMillis) {
            state.first {
                !binInfoManager.hasPendingRequests() ||
                    it.networkIconUrl != null || it.networkImageRes != 0
            }
        }

        if (finished == null) {
            binInfoManager.reset(
                cardNumberLength = cleanCardNumber(_state.value.cardNumberField.cardNumber).length,
                resetReason = DynamicBinInfoAnalyticsResetReason.TIMEOUT_WAIT_FOR_BIN_INFO,
            )
            updateCardNetworkFromBin(cardNetwork = CardNetwork.UNKNOWN)
        }
        finishWaitingBinInfo()
    }

    internal fun proceedToCardNumber() {
        _state.update {
            val prevStep = it.step
            val nextStep = Step.CardNumber
            if (prevStep != Step.CardNumber) {
                analytics.reportProductEvent(
                    event = FieldFocusedEvent(
                        fieldType = CardInputAnalyticsConstants.FieldType.CARD_NUMBER,
                        formStep = nextStep.asEventParamValue(),
                    ),
                )
            }
            it.copy(step = nextStep)
        }
    }

    internal fun proceedToDate() {
        if (onWaitForBinInfoCancelIfNeeded()) {
            finishWaitingBinInfo()
            return
        }
        if (isBinInfoDynamicEnabled && nextActionLockDelayInMillis > 0 && binInfoManager.hasPendingRequests()) {
            onWaitForBinInfoStartIfNeeded()
            return
        }
        _state.update {
            val prevStep = it.step
            val nextStep = Step.CardExpirationDate
            if (prevStep != Step.CardExpirationDate) {
                analytics.reportProductEvent(
                    event = FieldFocusedEvent(
                        fieldType = CardInputAnalyticsConstants.FieldType.EXPIRATION_DATE,
                        formStep = nextStep.asEventParamValue(),
                    )
                )
            }
            it.copy(step = Step.CardExpirationDate)
        }
    }

    internal fun cleanup() {
        binInfoManager.clear()
        onWaitForBinInfoCancelIfNeeded()
    }

    internal fun proceedToCvv() {
        _state.update {
            val nextStep = if (it.isCvvHidden) Step.CardBinding() else Step.CardCvv
            analytics.reportProductEvent(
                event = FieldFocusedEvent(
                    fieldType = CardInputAnalyticsConstants.FieldType.CVV,
                    formStep = nextStep.asEventParamValue(),
                ),
            )
            it.copy(step = nextStep)
        }
    }

    internal fun setExpressionResolver(resolver: BduiExpressionResolver) {
        this.expressionResolver = resolver
    }

    private fun finishWaitingBinInfo() {
        _state.update {
            it.copy(
                isBinInfoLoading = false,
                step = Step.CardExpirationDate,
            )
        }
    }

    private fun resetIfEmpty(cardNumber: CardNumber, cleanCardNumber: String): Boolean {
        if (cleanCardNumber.isNotEmpty()) return false

        currentBinInfo = null
        lastBinRequestContext = null
        val isSuccessValidation = validationFacade.validateCardNumber(cardNumber = cardNumber)
        _state.update {
            it.copy(
                cardNumberField = CardNumberField(
                    cardNumber = cardNumber,
                    showValidationStatus = validationFacade.validateCardNumberLength(
                        cardNumber = cardNumber,
                    ),
                    validationStatus = validationStatusFromResult(
                        isSuccessValidate = isSuccessValidation,
                        errorMsgRes = string.finsdk_wrong_card_number,
                    ),
                ),
                iconAnalytics = null,
                iconBinWrapper = null,
                isBinInfoLoading = false,
                isCvvHidden = false,
                networkImageRes = 0,
                networkIconUrl = null,
                securityCodeStringRes = string.finsdk_cvv,
                securityCodeLabel = null,
                trackedIconUrl = null,
            )
        }
        return true
    }

    private fun sendCardInputFieldAnalyticsIfNeeded(validationStatus: ValidationStatus, showValidationStatus: Boolean, step: Step) {
        when {
            validationStatus is ValidationStatus.Success -> {
                analytics.reportProductEvent(
                    event = FieldCompletedEvent(
                        fieldType = CardInputAnalyticsConstants.FieldType.CARD_NUMBER,
                        formStep = step.asEventParamValue(),
                    ),
                )
            }

            validationStatus is ValidationStatus.Error && showValidationStatus -> {
                analytics.reportProductEvent(
                    event = FieldValidationFailedEvent(
                        fieldType = CardInputAnalyticsConstants.FieldType.CARD_NUMBER,
                        formStep = step.asEventParamValue(),
                        error = CardInputAnalyticsConstants.ValidationError.INVALID_CARD_NUMBER,
                        trigger = CardInputAnalyticsConstants.Trigger.CHANGE,
                    ),
                )
            }
        }
    }

    private fun handleBinResetIfNeeded(cleanCardNumber: String) {
        if (!isBinInfoDynamicEnabled) return
        if (cleanCardNumber.length >= MIN_BIN_LENGTH_FOR_REQUEST) return
        val resetReason = if (cleanCardNumber.isEmpty()) {
            DynamicBinInfoAnalyticsResetReason.CARD_CLEARED
        } else {
            DynamicBinInfoAnalyticsResetReason.PREFIX_CHANGED
        }
        binInfoManager.reset(
            cardNumberLength = cleanCardNumber.length,
            resetReason = resetReason,
        )
    }

    private fun shouldUpdateIcon(currentLength: Int): Boolean {
        return currentLength < MIN_BIN_LENGTH_FOR_REQUEST ||
            currentLength == MIN_BIN_LENGTH_FOR_REQUEST ||
            currentLength == FINAL_BIN_LENGTH
    }

    private fun resolveNetworkImageForInput(
        cleanCardNumber: String,
        cardNumber: CardNumber,
        previousState: CardInputState,
        shouldUpdateIcon: Boolean,
    ): CardNetworkImage {
        if (!shouldUpdateIcon) {
            return CardNetworkImage(
                fallbackIconRes = previousState.networkImageRes,
                iconUrl = previousState.networkIconUrl,
            )
        }
        return when {
            cleanCardNumber.isEmpty() -> CardNetworkImage(
                fallbackIconRes = 0,
                iconUrl = null,
            )
            isBinInfoDynamicEnabled && cleanCardNumber.length < MIN_BIN_LENGTH_FOR_REQUEST -> CardNetworkImage(
                fallbackIconRes = 0,
                iconUrl = null,
            )
            isBinInfoDynamicEnabled -> CardNetworkImage(
                fallbackIconRes = previousState.networkImageRes,
                iconUrl = previousState.networkIconUrl,
            )
            else -> networkImageFacade.getCardNetworkImage(
                cardNumber = cardNumber,
                theme = resolveTheme(),
            )
        }
    }

    private fun resolveSecurityCodeLabel(
        cleanCardNumber: String,
        cardNumber: CardNumber,
        previousState: CardInputState,
    ): SecurityCodeLabel {
        return when {
            cleanCardNumber.isEmpty() -> SecurityCodeLabel(
                fallbackRes = string.finsdk_cvv,
                customLabel = null,
            )
            isBinInfoDynamicEnabled && cleanCardNumber.length < MIN_BIN_LENGTH_FOR_REQUEST ->
                SecurityCodeLabel(
                    fallbackRes = string.finsdk_cvv,
                    customLabel = null,
                )
            isBinInfoDynamicEnabled -> SecurityCodeLabel(
                fallbackRes = previousState.securityCodeStringRes,
                customLabel = previousState.securityCodeLabel,
            )
            else -> securityCodeTypeStringFacade.getSecurityCodeLabel(
                cardNumber = cardNumber,
            )
        }
    }

    private fun validationStatusFromResult(
        isSuccessValidate: Boolean,
        @StringRes errorMsgRes: Int,
    ): ValidationStatus {
        return if (isSuccessValidate) {
            ValidationStatus.Success
        } else {
            ValidationStatus.Error(
                errorMsgRes = errorMsgRes,
            )
        }
    }

    private fun getInitialState(cachedState: CardInputState?) = cachedState ?: CardInputState(
        cardNumberField = CardNumberField(
            cardNumber = CardNumber(value = EMPTY),
            showValidationStatus = false,
            validationStatus = ValidationStatus.Error(
                errorMsgRes = string.finsdk_wrong_card_number,
            ),
        ),
        cvvField = CvvField(
            cvv = Cvv(value = EMPTY),
            showValidationStatus = false,
            validationStatus = ValidationStatus.Error(
                errorMsgRes = string.finsdk_wrong_cvv,
            ),
        ),
        expiryDateField = ExpiryDateField(
            rawExpiryDate = EMPTY,
            expiryDate = ExpiryDate.Empty,
            showValidationStatus = false,
            validationStatus = ValidationStatus.Error(
                errorMsgRes = string.finsdk_wrong_expiration_date,
            ),
        ),
        iconAnalytics = null,
        iconBinWrapper = null,
        isCvvHidden = false,
        networkImageRes = 0,
        networkIconUrl = null,
        securityCodeStringRes = string.finsdk_cvv,
        securityCodeLabel = null,
        step = Step.CardNumber,
        trackedIconUrl = null,
    )

    private fun getTokenizeData(state: CardInputState): TokenizeCardData? {
        val cardNumber = if (state.cardNumberField.validationStatus.isSuccess()) {
            state.cardNumberField.cardNumber.value
        } else {
            return null
        }

        val cardExpiry = if (state.expiryDateField.validationStatus.isSuccess() && state.expiryDateField.expiryDate is ExpiryDate.NonEmpty) {
            state.expiryDateField.expiryDate
        } else {
            return null
        }

        val cardCode = if (state.isCvvHidden) {
            null
        } else if (state.cvvField.validationStatus.isSuccess()) {
            state.cvvField.cvv.value
        } else {
            return null
        }

        return TokenizeCardData(
            pan = cardNumber,
            expirationMonth = cardExpiry.month.toString(),
            expirationYear = cardExpiry.year.toString(),
            secretCode = cardCode,
            holderName = null,
        )
    }

    private fun updateCardNetworkFromBin(cardNetwork: CardNetwork? = null, binInfo: BinInfo? = null) {
        val cardNumber = _state.value.cardNumberField.cardNumber
        if (cleanCardNumber(cardNumber = cardNumber).isEmpty()) {
            _state.update {
                it.copy(
                    iconAnalytics = null,
                    iconBinWrapper = null,
                    isCvvHidden = false,
                    networkImageRes = 0,
                    networkIconUrl = null,
                    securityCodeStringRes = string.finsdk_cvv,
                    securityCodeLabel = null,
                    trackedIconUrl = null,
                )
            }
            return
        }
        val networkImage = resolveNetworkImage(
            cardNumber = cardNumber,
            cardNetwork = cardNetwork,
            theme = resolveTheme(),
        )
        val (iconAnalytics, iconBinWrapper) = resolveIconAnalytics(
            networkImage = networkImage,
            requestContext = lastBinRequestContext,
        )
        applyNetworkState(
            iconAnalytics = iconAnalytics,
            iconBinWrapper = iconBinWrapper,
            networkImage = networkImage,
            securityCodeLabel = resolveSecurityCodeLabel(
                cardNumber = cardNumber,
                cardNetwork = cardNetwork,
            ),
            shouldHideCvv = shouldHideCvv(
                cardNumber = cardNumber.value,
                binInfo = binInfo,
                cardNetwork = cardNetwork,
            ),
        )
    }

    private fun resolveNetworkImage(
        cardNumber: CardNumber,
        cardNetwork: CardNetwork?,
        theme: Theme,
    ): CardNetworkImage {
        return when {
            !isBinInfoDynamicEnabled -> {
                cardNetwork?.let {
                    networkImageFacade.getCardNetworkImage(
                        value = it,
                        theme = theme,
                    )
                } ?: networkImageFacade.getCardNetworkImage(
                    cardNumber = cardNumber,
                    theme = theme,
                )
            }
            cardNetwork == null || cardNetwork == CardNetwork.UNKNOWN -> CardNetworkImage(
                fallbackIconRes = 0,
                iconUrl = null,
            )
            else -> networkImageFacade.getCardNetworkImage(
                value = cardNetwork,
                theme = theme,
            )
        }
    }

    private fun resolveSecurityCodeLabel(
        cardNumber: CardNumber,
        cardNetwork: CardNetwork?,
    ): SecurityCodeLabel {
        return cardNetwork?.let {
            securityCodeTypeStringFacade.getSecurityCodeLabel(value = it)
        } ?: securityCodeTypeStringFacade.getSecurityCodeLabel(cardNumber = cardNumber)
    }

    private fun cleanCardNumber(cardNumber: CardNumber): String {
        return cardNumber.value.replace(oldValue = SPACE, newValue = EMPTY)
    }

    private fun resolveIconAnalytics(
        networkImage: CardNetworkImage,
        requestContext: BinRequestContext?,
    ): Pair<Analytics?, DynamicBinEventWrapper?> {
        val iconUrl = networkImage.iconUrl
        if (!isBinInfoDynamicEnabled || iconUrl == null || requestContext == null) {
            return null to null
        }
        return analytics to DynamicBinEventWrapper(prefix = requestContext.prefix)
    }

    private fun applyNetworkState(
        networkImage: CardNetworkImage,
        securityCodeLabel: SecurityCodeLabel,
        iconAnalytics: Analytics?,
        iconBinWrapper: DynamicBinEventWrapper?,
        shouldHideCvv: Boolean,
    ) {
        _state.update {
            it.copy(
                iconAnalytics = iconAnalytics,
                iconBinWrapper = iconBinWrapper,
                isCvvHidden = shouldHideCvv,
                networkImageRes = networkImage.fallbackIconRes,
                networkIconUrl = networkImage.iconUrl,
                securityCodeStringRes = securityCodeLabel.fallbackRes,
                securityCodeLabel = securityCodeLabel.customLabel,
                trackedIconUrl = networkImage.iconUrl,
            )
        }
    }

    private fun reportDynamicDataAppliedIfNeeded(
        binInfo: BinInfo,
        context: BinRequestContext,
    ) {
        analyticsReporter.reportDynamicDataApplied(
            binInfo = binInfo,
            context = context,
            currentState = _state.value,
        )
    }

    private fun handleStaticDataAppliedIfNeeded(cleanCardNumber: String) {
        if (cleanCardNumber.isEmpty()) {
            lastStaticDataAnalyticsCardNumber = null
            return
        }
        if (cleanCardNumber == lastStaticDataAnalyticsCardNumber) return
        val cardNetwork = cardNetworkChecker.lookup(numStr = cleanCardNumber).cardNetwork
        analyticsReporter.reportStaticDataApplied(
            cardNetwork = cardNetwork,
            cardNumberLength = cleanCardNumber.length,
        )
        lastStaticDataAnalyticsCardNumber = cleanCardNumber
    }

    private fun reportDataStateOnSubmit() {
        analyticsReporter.reportDataStateOnSubmit(
            state = _state.value,
            currentBinInfo = currentBinInfo,
            binInfoManager = binInfoManager,
        )
    }

    private fun shouldHideCvv(
        cardNumber: String,
        binInfo: BinInfo?,
        cardNetwork: CardNetwork? = null,
    ): Boolean {
        val withoutCvn = binInfo?.withoutCvn == true
        if (withoutCvn) return true
        val (_, pattern) = if (cardNetwork != null) {
            cardNetwork to cardNetworkPatternDictionary.getPatternFor(network = cardNetwork)
        } else {
            val lookup = cardNetworkChecker.lookup(numStr = cardNumber)
            lookup.cardNetwork to lookup.pattern
        }
        val hideByPattern = pattern.cvvLength == 0
        return hideByPattern
    }

    private fun resolveTheme(): Theme {
        val rawTheme = expressionResolver?.resolveString(expression = customProps.theme.orEmpty())
        return Theme.entries.firstOrNull { it.key.equals(other = rawTheme, ignoreCase = true) } ?: Theme.DAY
    }

    private companion object {
        private const val MIN_BIN_LENGTH_FOR_REQUEST = 3
        private const val FINAL_BIN_LENGTH = 8
        private const val SPACE = " "
        private const val EMPTY = ""
    }
}
