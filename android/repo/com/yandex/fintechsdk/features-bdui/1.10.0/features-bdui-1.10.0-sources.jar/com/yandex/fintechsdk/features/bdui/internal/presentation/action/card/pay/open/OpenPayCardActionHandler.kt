package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.open

import com.yandex.fintechsdk.adapters.yb.sdk.api.YbAdapter
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithInsetsProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider
import kotlinx.coroutines.launch
import javax.inject.Inject

internal class OpenPayCardActionHandler @Inject constructor(
    private val containerProvider: ContainerWithInsetsProvider,
    private val fragmentActivityProvider: FragmentActivityProvider,
    private val viewModelScopeProvider: ViewModelScopeProvider,
    private val ybAdapter: YbAdapter?,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is OpenPayCardAction) return

        val scope = viewModelScopeProvider.get() ?: return
        val container = containerProvider.get() ?: return
        val activity = fragmentActivityProvider.get() ?: return

        scope.launch {
            ybAdapter?.openPayCard(
                fragmentActivity = activity,
                container = container,
            )

            action.onFinish?.let { onFinish -> context.actionDispatcher.dispatch(action = onFinish) }
        }
    }
}
