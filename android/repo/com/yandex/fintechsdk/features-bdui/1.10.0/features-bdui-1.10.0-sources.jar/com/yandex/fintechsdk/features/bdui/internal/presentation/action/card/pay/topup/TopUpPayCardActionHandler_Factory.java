package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.topup;

import com.yandex.fintechsdk.adapters.yb.sdk.api.YbAdapter;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithInsetsProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class TopUpPayCardActionHandler_Factory implements Factory<TopUpPayCardActionHandler> {
  private final Provider<ContainerWithInsetsProvider> containerProvider;

  private final Provider<FragmentActivityProvider> fragmentActivityProvider;

  private final Provider<ViewModelScopeProvider> scopeProvider;

  private final Provider<YbAdapter> ybAdapterProvider;

  private TopUpPayCardActionHandler_Factory(Provider<ContainerWithInsetsProvider> containerProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<ViewModelScopeProvider> scopeProvider, Provider<YbAdapter> ybAdapterProvider) {
    this.containerProvider = containerProvider;
    this.fragmentActivityProvider = fragmentActivityProvider;
    this.scopeProvider = scopeProvider;
    this.ybAdapterProvider = ybAdapterProvider;
  }

  @Override
  public TopUpPayCardActionHandler get() {
    return newInstance(containerProvider.get(), fragmentActivityProvider.get(), scopeProvider.get(), ybAdapterProvider.get());
  }

  public static TopUpPayCardActionHandler_Factory create(
      Provider<ContainerWithInsetsProvider> containerProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<ViewModelScopeProvider> scopeProvider, Provider<YbAdapter> ybAdapterProvider) {
    return new TopUpPayCardActionHandler_Factory(containerProvider, fragmentActivityProvider, scopeProvider, ybAdapterProvider);
  }

  public static TopUpPayCardActionHandler newInstance(ContainerWithInsetsProvider containerProvider,
      FragmentActivityProvider fragmentActivityProvider, ViewModelScopeProvider scopeProvider,
      @Nullable YbAdapter ybAdapter) {
    return new TopUpPayCardActionHandler(containerProvider, fragmentActivityProvider, scopeProvider, ybAdapter);
  }
}
