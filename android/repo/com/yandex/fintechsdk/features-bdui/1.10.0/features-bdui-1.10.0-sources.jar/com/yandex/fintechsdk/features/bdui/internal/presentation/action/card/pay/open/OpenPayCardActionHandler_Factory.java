package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.open;

import com.yandex.fintechsdk.adapters.yb.sdk.api.YbAdapter;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithInsetsProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class OpenPayCardActionHandler_Factory implements Factory<OpenPayCardActionHandler> {
  private final Provider<ContainerWithInsetsProvider> containerProvider;

  private final Provider<FragmentActivityProvider> fragmentActivityProvider;

  private final Provider<ViewModelScopeProvider> viewModelScopeProvider;

  private final Provider<YbAdapter> ybAdapterProvider;

  private OpenPayCardActionHandler_Factory(Provider<ContainerWithInsetsProvider> containerProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<ViewModelScopeProvider> viewModelScopeProvider,
      Provider<YbAdapter> ybAdapterProvider) {
    this.containerProvider = containerProvider;
    this.fragmentActivityProvider = fragmentActivityProvider;
    this.viewModelScopeProvider = viewModelScopeProvider;
    this.ybAdapterProvider = ybAdapterProvider;
  }

  @Override
  public OpenPayCardActionHandler get() {
    return newInstance(containerProvider.get(), fragmentActivityProvider.get(), viewModelScopeProvider.get(), ybAdapterProvider.get());
  }

  public static OpenPayCardActionHandler_Factory create(
      Provider<ContainerWithInsetsProvider> containerProvider,
      Provider<FragmentActivityProvider> fragmentActivityProvider,
      Provider<ViewModelScopeProvider> viewModelScopeProvider,
      Provider<YbAdapter> ybAdapterProvider) {
    return new OpenPayCardActionHandler_Factory(containerProvider, fragmentActivityProvider, viewModelScopeProvider, ybAdapterProvider);
  }

  public static OpenPayCardActionHandler newInstance(ContainerWithInsetsProvider containerProvider,
      FragmentActivityProvider fragmentActivityProvider,
      ViewModelScopeProvider viewModelScopeProvider, @Nullable YbAdapter ybAdapter) {
    return new OpenPayCardActionHandler(containerProvider, fragmentActivityProvider, viewModelScopeProvider, ybAdapter);
  }
}
