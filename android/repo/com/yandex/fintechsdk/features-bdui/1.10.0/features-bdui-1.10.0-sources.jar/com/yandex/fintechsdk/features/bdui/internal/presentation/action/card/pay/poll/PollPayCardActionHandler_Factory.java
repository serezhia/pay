package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.poll;

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.adapters.yb.sdk.api.YbAdapter;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class PollPayCardActionHandler_Factory implements Factory<PollPayCardActionHandler> {
  private final Provider<FlexAdapter> flexAdapterProvider;

  private final Provider<ViewModelScopeProvider> scopeProvider;

  private final Provider<YbAdapter> ybAdapterProvider;

  private PollPayCardActionHandler_Factory(Provider<FlexAdapter> flexAdapterProvider,
      Provider<ViewModelScopeProvider> scopeProvider, Provider<YbAdapter> ybAdapterProvider) {
    this.flexAdapterProvider = flexAdapterProvider;
    this.scopeProvider = scopeProvider;
    this.ybAdapterProvider = ybAdapterProvider;
  }

  @Override
  public PollPayCardActionHandler get() {
    return newInstance(flexAdapterProvider.get(), scopeProvider.get(), ybAdapterProvider.get());
  }

  public static PollPayCardActionHandler_Factory create(Provider<FlexAdapter> flexAdapterProvider,
      Provider<ViewModelScopeProvider> scopeProvider, Provider<YbAdapter> ybAdapterProvider) {
    return new PollPayCardActionHandler_Factory(flexAdapterProvider, scopeProvider, ybAdapterProvider);
  }

  public static PollPayCardActionHandler newInstance(@Nullable FlexAdapter flexAdapter,
      ViewModelScopeProvider scopeProvider, @Nullable YbAdapter ybAdapter) {
    return new PollPayCardActionHandler(flexAdapter, scopeProvider, ybAdapter);
  }
}
