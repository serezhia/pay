package com.yandex.fintechsdk.features.bdui.internal.di.action

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionInfo
import com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.analytics.SendAnalyticsEventAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.analytics.SendAnalyticsEventActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness.SetBrightnessAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness.SetBrightnessActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge.DeviceChallengePubkeyAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge.DeviceChallengePubkeyActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge.DeviceChallengeSignatureAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge.DeviceChallengeSignatureActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.terminalstate.TerminalStateAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.terminalstate.TerminalStateActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.OpenBrowserAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.OpenBrowserActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.open.OpenPayCardAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.open.OpenPayCardActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.poll.PollPayCardAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.poll.PollPayCardActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.topup.TopUpPayCardAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.topup.TopUpPayCardActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink.OpenDeeplinkAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink.OpenDeeplinkActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.delayed.cancellable.CancellableDelayedAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.delayed.cancellable.CancellableDelayedActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.finishflow.FinishFlowAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.finishflow.FinishFlowActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.FTRequestAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.FTRequestActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.hideoverlay.CustomHideOverlayAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.hideoverlay.CustomHideOverlayActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.poptoroot.PopToRootAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.poptoroot.PopToRootActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.plus.OpenPlusAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.plus.OpenPlusActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.redirect.canmake.CanMakeExternalRedirectAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.redirect.canmake.CanMakeExternalRedirectActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.sendexternalevent.SendExternalEventAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.sendexternalevent.SendExternalEventActionHandler
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.shownativescreen.ShowNativeScreenAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.shownativescreen.ShowNativeScreenActionHandler
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoSet
import kotlinx.serialization.serializer

@Module
internal class BduiActionsModule {

    @FeatureScope
    @Provides
    @IntoSet
    fun provideSendAnalyticsEventAction(
        handler: SendAnalyticsEventActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "SendAnalyticsEventAction",
            handler = handler,
            serializer = serializer<SendAnalyticsEventAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideOpenBrowserAction(
        handler: OpenBrowserActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "OpenBrowserAction",
            handler = handler,
            serializer = serializer<OpenBrowserAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideOpenDeeplinkAction(
        handler: OpenDeeplinkActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "OpenDeeplinkAction",
            handler = handler,
            serializer = serializer<OpenDeeplinkAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideFinishFlowAction(
        handler: FinishFlowActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "FinishFlowAction",
            handler = handler,
            serializer = serializer<FinishFlowAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideCustomHideOverlayAction(
        handler: CustomHideOverlayActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "CustomHideOverlayAction",
            handler = handler,
            serializer = serializer<CustomHideOverlayAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun providePopToRootAction(
        handler: PopToRootActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "PopToRootAction",
            handler = handler,
            serializer = serializer<PopToRootAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideCanMakeExternalRedirectAction(
        handler: CanMakeExternalRedirectActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "CanMakeExternalRedirectAction",
            handler = handler,
            serializer = serializer<CanMakeExternalRedirectAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideOpenPayCardAction(
        handler: OpenPayCardActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "OpenPayCardAction",
            handler = handler,
            serializer = serializer<OpenPayCardAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun providePollPayCardAction(
        handler: PollPayCardActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "PollPayCardAction",
            handler = handler,
            serializer = serializer<PollPayCardAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideTopUpPayCardAction(
        handler: TopUpPayCardActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "TopUpPayCardAction",
            handler = handler,
            serializer = serializer<TopUpPayCardAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideOpenPlusAction(
        handler: OpenPlusActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "OpenPlusAction",
            handler = handler,
            serializer = serializer<OpenPlusAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideCancellableDelayedAction(
        handler: CancellableDelayedActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "CancellableDelayedAction",
            handler = handler,
            serializer = serializer<CancellableDelayedAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideFTRequestAction(
        handler: FTRequestActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "FTRequestAction",
            handler = handler,
            serializer = serializer<FTRequestAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideDeviceChallengePubkeyAction(
        handler: DeviceChallengePubkeyActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "DeviceChallengePubkeyAction",
            handler = handler,
            serializer = serializer<DeviceChallengePubkeyAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideDeviceChallengeSignatureAction(
        handler: DeviceChallengeSignatureActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "DeviceChallengeSignatureAction",
            handler = handler,
            serializer = serializer<DeviceChallengeSignatureAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideTerminalStateAction(
        handler: TerminalStateActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "TerminalStateAction",
            handler = handler,
            serializer = serializer<TerminalStateAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideSendExternalEventAction(
        handler: SendExternalEventActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "SendExternalEventAction",
            handler = handler,
            serializer = serializer<SendExternalEventAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideSetBrightnessAction(
        handler: SetBrightnessActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "SetBrightnessAction",
            handler = handler,
            serializer = serializer<SetBrightnessAction>(),
        )
    }

    @FeatureScope
    @Provides
    @IntoSet
    fun provideShowNativeScreenAction(
        handler: ShowNativeScreenActionHandler,
    ): BduiActionInfo<BduiAction> {
        return BduiActionInfo(
            type = "ShowNativeScreenAction",
            handler = handler,
            serializer = serializer<ShowNativeScreenAction>(),
        )
    }
}
