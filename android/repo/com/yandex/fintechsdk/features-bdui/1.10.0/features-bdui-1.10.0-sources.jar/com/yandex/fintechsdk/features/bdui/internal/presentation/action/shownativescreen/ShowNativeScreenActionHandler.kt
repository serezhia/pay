package com.yandex.fintechsdk.features.bdui.internal.presentation.action.shownativescreen

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.OpenBrowserAction
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.OpenBrowserActionHandler
import javax.inject.Inject

/**
 * Currently [ShowNativeScreenAction] is used only in Troika flow in PaymentSDK.
 * This handler has been added to FintechSDK for backward compatibility to prevent changes in PaymentSDK,
 * and is reusing logic from [OpenBrowserActionHandler] by calling handle().
 * When PaymentSDK is fully deprecated,
 * Troika flow will be able to migrate to using [OpenBrowserAction] in Tovarisch,
 * and after that this handler and corresponding action [ShowNativeScreenAction] can be removed.
 */
internal class ShowNativeScreenActionHandler @Inject constructor(
    private val openBrowserActionHandler: OpenBrowserActionHandler,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is ShowNativeScreenAction) return

        if (action.route == ROUTE_WEB) {
            action.params[URL]?.let { url ->
                openBrowserActionHandler.handle(
                    action = OpenBrowserAction(
                        params = action.params,
                        url = url,
                    ),
                    context = context,
                )
            }
        }
    }
}

private const val ROUTE_WEB = "web"
private const val URL = "url"
