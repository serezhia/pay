package com.yandex.fintechsdk.features.bdui.internal.di.action;

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction;
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionInfo;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.shownativescreen.ShowNativeScreenActionHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FeatureScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiActionsModule_ProvideShowNativeScreenActionFactory implements Factory<BduiActionInfo<BduiAction>> {
  private final BduiActionsModule module;

  private final Provider<ShowNativeScreenActionHandler> handlerProvider;

  private BduiActionsModule_ProvideShowNativeScreenActionFactory(BduiActionsModule module,
      Provider<ShowNativeScreenActionHandler> handlerProvider) {
    this.module = module;
    this.handlerProvider = handlerProvider;
  }

  @Override
  public BduiActionInfo<BduiAction> get() {
    return provideShowNativeScreenAction(module, handlerProvider.get());
  }

  public static BduiActionsModule_ProvideShowNativeScreenActionFactory create(
      BduiActionsModule module, Provider<ShowNativeScreenActionHandler> handlerProvider) {
    return new BduiActionsModule_ProvideShowNativeScreenActionFactory(module, handlerProvider);
  }

  public static BduiActionInfo<BduiAction> provideShowNativeScreenAction(BduiActionsModule instance,
      ShowNativeScreenActionHandler handler) {
    return Preconditions.checkNotNullFromProvides(instance.provideShowNativeScreenAction(handler));
  }
}
