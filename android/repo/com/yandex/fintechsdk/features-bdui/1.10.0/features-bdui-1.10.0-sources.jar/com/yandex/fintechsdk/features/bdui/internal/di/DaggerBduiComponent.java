package com.yandex.fintechsdk.features.bdui.internal.di;

import com.yandex.finsdtechsdk.adapters.passport.sdk.api.PassportAdapter;
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.adapters.plus.sdk.api.PlusAdapter;
import com.yandex.fintechsdk.adapters.yb.sdk.api.YbAdapter;
import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction;
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionInfo;
import com.yandex.fintechsdk.core.bdui.api.customview.configuration.CustomViewConfiguration;
import com.yandex.fintechsdk.core.bdui.api.customview.factory.CustomViewFactoryDelegateCreator;
import com.yandex.fintechsdk.core.network.api.auth.AuthTokenProvider;
import com.yandex.fintechsdk.core.network.api.network.DefaultNetworkApi;
import com.yandex.fintechsdk.core.ui.impl.api.shimmers.ShimmersLayoutProvider;
import com.yandex.fintechsdk.data.auth.api.AuthRepository;
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment;
import com.yandex.fintechsdk.entities.region.Region;
import com.yandex.fintechsdk.features.bdui.api.dependencies.BduiDependencies;
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate;
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DeviceChallengeSignatureProvider;
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DevicePubkeyProvider;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideCanMakeExternalRedirectActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideCancellableDelayedActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideCustomHideOverlayActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideDeviceChallengePubkeyActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideDeviceChallengeSignatureActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideFTRequestActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideFinishFlowActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideOpenBrowserActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideOpenDeeplinkActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideOpenPayCardActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideOpenPlusActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvidePollPayCardActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvidePopToRootActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideSendAnalyticsEventActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideSendExternalEventActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideSetBrightnessActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideShowNativeScreenActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideTerminalStateActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.action.BduiActionsModule_ProvideTopUpPayCardActionFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.customview.BduiCustomViewModule_Companion_ProvideCardInputViewConfigurationFactory;
import com.yandex.fintechsdk.features.bdui.internal.di.customview.BduiCustomViewModule_Companion_ProvideWebViewConfigurationFactory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.analytics.SendAnalyticsEventActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.analytics.SendAnalyticsEventActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness.ScreenBrightnessStateHolder;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness.ScreenBrightnessStateHolder_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness.SetBrightnessActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.brightness.SetBrightnessActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.ChromeTabLaunchActionsStore;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.ChromeTabLaunchActionsStore_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.OpenBrowserActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.OpenBrowserActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.open.OpenPayCardActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.open.OpenPayCardActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.poll.PollPayCardActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.poll.PollPayCardActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.topup.TopUpPayCardActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.topup.TopUpPayCardActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink.DeeplinkExecutor;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink.DeeplinkExecutor_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink.OpenDeeplinkActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.deeplink.OpenDeeplinkActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.delayed.cancellable.CancellableDelayedActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.delayed.cancellable.CancellableDelayedActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge.DeviceChallengePubkeyActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge.DeviceChallengePubkeyActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge.DeviceChallengeSignatureActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.devicechallenge.DeviceChallengeSignatureActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.finishflow.FinishFlowActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.finishflow.FinishFlowActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.FTRequestActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.FTRequestActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.requester.FTRequestActionRequester;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.requester.FTRequestActionRequester_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.DtoHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.DtoHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.ftrequest.transform.utils.DtoNodeProcessor_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.hideoverlay.CustomHideOverlayActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.hideoverlay.CustomHideOverlayActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.poptoroot.PopToRootActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.navigation.poptoroot.PopToRootActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.plus.OpenPlusActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.plus.OpenPlusActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.redirect.canmake.CanMakeExternalRedirectActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.redirect.canmake.CanMakeExternalRedirectActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.sendexternalevent.SendExternalEventActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.sendexternalevent.SendExternalEventActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.shownativescreen.ShowNativeScreenActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.shownativescreen.ShowNativeScreenActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.terminalstate.TerminalStateActionHandler;
import com.yandex.fintechsdk.features.bdui.internal.presentation.action.terminalstate.TerminalStateActionHandler_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.CustomViewFactoryDelegateCreatorImpl_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.error.BduiErrorHandlerImpl;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.BduiViewModel;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithInsetsProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithInsetsProvider_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithoutInsetsProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContainerWithoutInsetsProvider_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentActivityProvider_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentManagerProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.FragmentManagerProvider_Factory;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider_Factory;
import dagger.internal.DaggerGenerated;
import dagger.internal.DoubleCheck;
import dagger.internal.MapBuilder;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.SetBuilder;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DaggerBduiComponent {
  private DaggerBduiComponent() {
  }

  public static BduiComponent.Factory factory() {
    return new Factory();
  }

  private static final class Factory implements BduiComponent.Factory {
    @Override
    public BduiComponent create(BduiDependencies dependencies) {
      Preconditions.checkNotNull(dependencies);
      return new BduiComponentImpl(new BduiActionsModule(), dependencies);
    }
  }

  private static final class BduiComponentImpl implements BduiComponent {
    private final BduiDependencies bduiDependencies;

    private final BduiComponentImpl bduiComponentImpl = this;

    Provider<Analytics> getAnalyticsProvider;

    Provider<SendAnalyticsEventActionHandler> sendAnalyticsEventActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideSendAnalyticsEventActionProvider;

    Provider<AuthRepository> getAuthRepositoryProvider;

    Provider<ChromeTabLaunchActionsStore> chromeTabLaunchActionsStoreProvider;

    Provider<ContextProvider> contextProvider;

    Provider<DefaultEnvironment> getEnvironmentProvider;

    Provider<PassportAdapter> getPassportAdapterProvider;

    Provider<Region> getRegionProvider;

    Provider<OpenBrowserActionHandler> openBrowserActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideOpenBrowserActionProvider;

    Provider<DeeplinkExecutor> deeplinkExecutorProvider;

    Provider<OpenDeeplinkActionHandler> openDeeplinkActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideOpenDeeplinkActionProvider;

    Provider<BduiActionsDelegate> getBduiActionsDelegateProvider;

    Provider<FinishFlowActionHandler> finishFlowActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideFinishFlowActionProvider;

    Provider<FlexAdapter> getFlexAdapterProvider;

    Provider<CustomHideOverlayActionHandler> customHideOverlayActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideCustomHideOverlayActionProvider;

    Provider<PopToRootActionHandler> popToRootActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> providePopToRootActionProvider;

    Provider<CanMakeExternalRedirectActionHandler> canMakeExternalRedirectActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideCanMakeExternalRedirectActionProvider;

    Provider<ContainerWithInsetsProvider> containerWithInsetsProvider;

    Provider<FragmentActivityProvider> fragmentActivityProvider;

    Provider<ViewModelScopeProvider> viewModelScopeProvider;

    Provider<YbAdapter> getYbSdkAdapterProvider;

    Provider<OpenPayCardActionHandler> openPayCardActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideOpenPayCardActionProvider;

    Provider<PollPayCardActionHandler> pollPayCardActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> providePollPayCardActionProvider;

    Provider<TopUpPayCardActionHandler> topUpPayCardActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideTopUpPayCardActionProvider;

    Provider<PlusAdapter> getPlusAdapterProvider;

    Provider<OpenPlusActionHandler> openPlusActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideOpenPlusActionProvider;

    Provider<CancellableDelayedActionHandler> cancellableDelayedActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideCancellableDelayedActionProvider;

    Provider<AuthTokenProvider> getAuthTokenProvider;

    Provider<DtoHandler> dtoHandlerProvider;

    Provider<DefaultNetworkApi> getDefaultNetworkApiProvider;

    Provider<FTRequestActionRequester> fTRequestActionRequesterProvider;

    Provider<FTRequestActionHandler> fTRequestActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideFTRequestActionProvider;

    Provider<DevicePubkeyProvider> getDevicePubkeyProvider;

    Provider<DeviceChallengePubkeyActionHandler> deviceChallengePubkeyActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideDeviceChallengePubkeyActionProvider;

    Provider<DeviceChallengeSignatureProvider> getDeviceChallengeSignatureProvider;

    Provider<DeviceChallengeSignatureActionHandler> deviceChallengeSignatureActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideDeviceChallengeSignatureActionProvider;

    Provider<TerminalStateActionHandler> terminalStateActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideTerminalStateActionProvider;

    Provider<SendExternalEventActionHandler> sendExternalEventActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideSendExternalEventActionProvider;

    Provider<ScreenBrightnessStateHolder> screenBrightnessStateHolderProvider;

    Provider<SetBrightnessActionHandler> setBrightnessActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideSetBrightnessActionProvider;

    Provider<ShowNativeScreenActionHandler> showNativeScreenActionHandlerProvider;

    Provider<BduiActionInfo<BduiAction>> provideShowNativeScreenActionProvider;

    Provider<ContainerWithoutInsetsProvider> containerWithoutInsetsProvider;

    Provider<CustomViewFactoryDelegateCreator> bindCustomViewFactoryDelegateCreatorProvider;

    Provider<FragmentManagerProvider> fragmentManagerProvider;

    BduiComponentImpl(BduiActionsModule bduiActionsModuleParam,
        BduiDependencies bduiDependenciesParam) {
      this.bduiDependencies = bduiDependenciesParam;
      initialize(bduiActionsModuleParam, bduiDependenciesParam);
      initialize2(bduiActionsModuleParam, bduiDependenciesParam);
      initialize3(bduiActionsModuleParam, bduiDependenciesParam);

    }

    Set<BduiActionInfo<BduiAction>> setOfBduiActionInfoOfBduiAction() {
      return SetBuilder.<BduiActionInfo<BduiAction>>newSetBuilder(19).add(provideSendAnalyticsEventActionProvider.get()).add(provideOpenBrowserActionProvider.get()).add(provideOpenDeeplinkActionProvider.get()).add(provideFinishFlowActionProvider.get()).add(provideCustomHideOverlayActionProvider.get()).add(providePopToRootActionProvider.get()).add(provideCanMakeExternalRedirectActionProvider.get()).add(provideOpenPayCardActionProvider.get()).add(providePollPayCardActionProvider.get()).add(provideTopUpPayCardActionProvider.get()).add(provideOpenPlusActionProvider.get()).add(provideCancellableDelayedActionProvider.get()).add(provideFTRequestActionProvider.get()).add(provideDeviceChallengePubkeyActionProvider.get()).add(provideDeviceChallengeSignatureActionProvider.get()).add(provideTerminalStateActionProvider.get()).add(provideSendExternalEventActionProvider.get()).add(provideSetBrightnessActionProvider.get()).add(provideShowNativeScreenActionProvider.get()).build();
    }

    BduiErrorHandlerImpl bduiErrorHandlerImpl() {
      return new BduiErrorHandlerImpl(Preconditions.checkNotNullFromComponent(bduiDependencies.getBduiNavigator()));
    }

    CustomViewConfiguration provideWebViewConfiguration() {
      return BduiCustomViewModule_Companion_ProvideWebViewConfigurationFactory.provideWebViewConfiguration(Preconditions.checkNotNullFromComponent(bduiDependencies.getAuthRepository()), Preconditions.checkNotNullFromComponent(bduiDependencies.getEnvironment()), bduiDependencies.getFlexAdapter(), Preconditions.checkNotNullFromComponent(bduiDependencies.getRegion()), bduiDependencies.getPassportAdapter(), Preconditions.checkNotNullFromComponent(bduiDependencies.getUserAgentProvider()));
    }

    CustomViewConfiguration provideCardInputViewConfiguration() {
      return BduiCustomViewModule_Companion_ProvideCardInputViewConfigurationFactory.provideCardInputViewConfiguration(Preconditions.checkNotNullFromComponent(bduiDependencies.getAnalytics()), Preconditions.checkNotNullFromComponent(bduiDependencies.getCardBindingRepository()));
    }

    Map<String, CustomViewConfiguration> mapOfStringAndCustomViewConfiguration() {
      return MapBuilder.<String, CustomViewConfiguration>newMapBuilder(2).put("WebViewConfiguration", provideWebViewConfiguration()).put("CustomViewConfiguration", provideCardInputViewConfiguration()).build();
    }

    @SuppressWarnings("unchecked")
    private void initialize(final BduiActionsModule bduiActionsModuleParam,
        final BduiDependencies bduiDependenciesParam) {
      this.getAnalyticsProvider = new GetAnalyticsProvider(bduiDependenciesParam);
      this.sendAnalyticsEventActionHandlerProvider = SendAnalyticsEventActionHandler_Factory.create(getAnalyticsProvider);
      this.provideSendAnalyticsEventActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideSendAnalyticsEventActionFactory.create(bduiActionsModuleParam, sendAnalyticsEventActionHandlerProvider));
      this.getAuthRepositoryProvider = new GetAuthRepositoryProvider(bduiDependenciesParam);
      this.chromeTabLaunchActionsStoreProvider = DoubleCheck.provider(ChromeTabLaunchActionsStore_Factory.create());
      this.contextProvider = DoubleCheck.provider(ContextProvider_Factory.create());
      this.getEnvironmentProvider = new GetEnvironmentProvider(bduiDependenciesParam);
      this.getPassportAdapterProvider = new GetPassportAdapterProvider(bduiDependenciesParam);
      this.getRegionProvider = new GetRegionProvider(bduiDependenciesParam);
      this.openBrowserActionHandlerProvider = OpenBrowserActionHandler_Factory.create(getAuthRepositoryProvider, chromeTabLaunchActionsStoreProvider, contextProvider, getEnvironmentProvider, getPassportAdapterProvider, getRegionProvider);
      this.provideOpenBrowserActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideOpenBrowserActionFactory.create(bduiActionsModuleParam, openBrowserActionHandlerProvider));
      this.deeplinkExecutorProvider = DeeplinkExecutor_Factory.create(contextProvider);
      this.openDeeplinkActionHandlerProvider = OpenDeeplinkActionHandler_Factory.create(deeplinkExecutorProvider);
      this.provideOpenDeeplinkActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideOpenDeeplinkActionFactory.create(bduiActionsModuleParam, openDeeplinkActionHandlerProvider));
      this.getBduiActionsDelegateProvider = new GetBduiActionsDelegateProvider(bduiDependenciesParam);
      this.finishFlowActionHandlerProvider = FinishFlowActionHandler_Factory.create(getBduiActionsDelegateProvider);
      this.provideFinishFlowActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideFinishFlowActionFactory.create(bduiActionsModuleParam, finishFlowActionHandlerProvider));
      this.getFlexAdapterProvider = new GetFlexAdapterProvider(bduiDependenciesParam);
      this.customHideOverlayActionHandlerProvider = CustomHideOverlayActionHandler_Factory.create(getFlexAdapterProvider);
      this.provideCustomHideOverlayActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideCustomHideOverlayActionFactory.create(bduiActionsModuleParam, customHideOverlayActionHandlerProvider));
      this.popToRootActionHandlerProvider = PopToRootActionHandler_Factory.create(getFlexAdapterProvider);
      this.providePopToRootActionProvider = DoubleCheck.provider(BduiActionsModule_ProvidePopToRootActionFactory.create(bduiActionsModuleParam, popToRootActionHandlerProvider));
      this.canMakeExternalRedirectActionHandlerProvider = CanMakeExternalRedirectActionHandler_Factory.create(contextProvider, getFlexAdapterProvider);
      this.provideCanMakeExternalRedirectActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideCanMakeExternalRedirectActionFactory.create(bduiActionsModuleParam, canMakeExternalRedirectActionHandlerProvider));
      this.containerWithInsetsProvider = DoubleCheck.provider(ContainerWithInsetsProvider_Factory.create());
    }

    @SuppressWarnings("unchecked")
    private void initialize2(final BduiActionsModule bduiActionsModuleParam,
        final BduiDependencies bduiDependenciesParam) {
      this.fragmentActivityProvider = DoubleCheck.provider(FragmentActivityProvider_Factory.create());
      this.viewModelScopeProvider = DoubleCheck.provider(ViewModelScopeProvider_Factory.create());
      this.getYbSdkAdapterProvider = new GetYbSdkAdapterProvider(bduiDependenciesParam);
      this.openPayCardActionHandlerProvider = OpenPayCardActionHandler_Factory.create(containerWithInsetsProvider, fragmentActivityProvider, viewModelScopeProvider, getYbSdkAdapterProvider);
      this.provideOpenPayCardActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideOpenPayCardActionFactory.create(bduiActionsModuleParam, openPayCardActionHandlerProvider));
      this.pollPayCardActionHandlerProvider = PollPayCardActionHandler_Factory.create(getFlexAdapterProvider, viewModelScopeProvider, getYbSdkAdapterProvider);
      this.providePollPayCardActionProvider = DoubleCheck.provider(BduiActionsModule_ProvidePollPayCardActionFactory.create(bduiActionsModuleParam, pollPayCardActionHandlerProvider));
      this.topUpPayCardActionHandlerProvider = TopUpPayCardActionHandler_Factory.create(containerWithInsetsProvider, fragmentActivityProvider, viewModelScopeProvider, getYbSdkAdapterProvider);
      this.provideTopUpPayCardActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideTopUpPayCardActionFactory.create(bduiActionsModuleParam, topUpPayCardActionHandlerProvider));
      this.getPlusAdapterProvider = new GetPlusAdapterProvider(bduiDependenciesParam);
      this.openPlusActionHandlerProvider = OpenPlusActionHandler_Factory.create(getAuthRepositoryProvider, contextProvider, getEnvironmentProvider, getPlusAdapterProvider, viewModelScopeProvider);
      this.provideOpenPlusActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideOpenPlusActionFactory.create(bduiActionsModuleParam, openPlusActionHandlerProvider));
      this.cancellableDelayedActionHandlerProvider = DoubleCheck.provider(CancellableDelayedActionHandler_Factory.create(fragmentActivityProvider, viewModelScopeProvider));
      this.provideCancellableDelayedActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideCancellableDelayedActionFactory.create(bduiActionsModuleParam, cancellableDelayedActionHandlerProvider));
      this.getAuthTokenProvider = new GetAuthTokenProviderProvider(bduiDependenciesParam);
      this.dtoHandlerProvider = DtoHandler_Factory.create(getAuthTokenProvider, DtoNodeProcessor_Factory.create(), getFlexAdapterProvider);
      this.getDefaultNetworkApiProvider = new GetDefaultNetworkApiProvider(bduiDependenciesParam);
      this.fTRequestActionRequesterProvider = FTRequestActionRequester_Factory.create(getDefaultNetworkApiProvider, dtoHandlerProvider);
      this.fTRequestActionHandlerProvider = FTRequestActionHandler_Factory.create(getAnalyticsProvider, dtoHandlerProvider, getFlexAdapterProvider, fTRequestActionRequesterProvider, viewModelScopeProvider);
      this.provideFTRequestActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideFTRequestActionFactory.create(bduiActionsModuleParam, fTRequestActionHandlerProvider));
      this.getDevicePubkeyProvider = new GetDevicePubkeyProviderProvider(bduiDependenciesParam);
      this.deviceChallengePubkeyActionHandlerProvider = DeviceChallengePubkeyActionHandler_Factory.create(getAnalyticsProvider, getDevicePubkeyProvider, getFlexAdapterProvider);
      this.provideDeviceChallengePubkeyActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideDeviceChallengePubkeyActionFactory.create(bduiActionsModuleParam, deviceChallengePubkeyActionHandlerProvider));
      this.getDeviceChallengeSignatureProvider = new GetDeviceChallengeSignatureProviderProvider(bduiDependenciesParam);
      this.deviceChallengeSignatureActionHandlerProvider = DeviceChallengeSignatureActionHandler_Factory.create(getAnalyticsProvider, getFlexAdapterProvider, fragmentActivityProvider, getDeviceChallengeSignatureProvider);
    }

    @SuppressWarnings("unchecked")
    private void initialize3(final BduiActionsModule bduiActionsModuleParam,
        final BduiDependencies bduiDependenciesParam) {
      this.provideDeviceChallengeSignatureActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideDeviceChallengeSignatureActionFactory.create(bduiActionsModuleParam, deviceChallengeSignatureActionHandlerProvider));
      this.terminalStateActionHandlerProvider = TerminalStateActionHandler_Factory.create(getBduiActionsDelegateProvider);
      this.provideTerminalStateActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideTerminalStateActionFactory.create(bduiActionsModuleParam, terminalStateActionHandlerProvider));
      this.sendExternalEventActionHandlerProvider = SendExternalEventActionHandler_Factory.create(getBduiActionsDelegateProvider);
      this.provideSendExternalEventActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideSendExternalEventActionFactory.create(bduiActionsModuleParam, sendExternalEventActionHandlerProvider));
      this.screenBrightnessStateHolderProvider = DoubleCheck.provider(ScreenBrightnessStateHolder_Factory.create());
      this.setBrightnessActionHandlerProvider = SetBrightnessActionHandler_Factory.create(fragmentActivityProvider, screenBrightnessStateHolderProvider);
      this.provideSetBrightnessActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideSetBrightnessActionFactory.create(bduiActionsModuleParam, setBrightnessActionHandlerProvider));
      this.showNativeScreenActionHandlerProvider = ShowNativeScreenActionHandler_Factory.create(openBrowserActionHandlerProvider);
      this.provideShowNativeScreenActionProvider = DoubleCheck.provider(BduiActionsModule_ProvideShowNativeScreenActionFactory.create(bduiActionsModuleParam, showNativeScreenActionHandlerProvider));
      this.containerWithoutInsetsProvider = DoubleCheck.provider(ContainerWithoutInsetsProvider_Factory.create());
      this.bindCustomViewFactoryDelegateCreatorProvider = DoubleCheck.provider((Provider) (CustomViewFactoryDelegateCreatorImpl_Factory.create()));
      this.fragmentManagerProvider = DoubleCheck.provider(FragmentManagerProvider_Factory.create());
    }

    @Override
    public BduiViewModel getViewModel() {
      return new BduiViewModel(setOfBduiActionInfoOfBduiAction(), Preconditions.checkNotNullFromComponent(bduiDependencies.getAnalytics()), bduiErrorHandlerImpl(), Preconditions.checkNotNullFromComponent(bduiDependencies.getBduiExtraHeadersProvider()), Preconditions.checkNotNullFromComponent(bduiDependencies.getInitialDocumentQuery()), Preconditions.checkNotNullFromComponent(bduiDependencies.getBduiNavigator()), Preconditions.checkNotNullFromComponent(bduiDependencies.getBduiExtraQueriesProvider()), Preconditions.checkNotNullFromComponent(bduiDependencies.getBduiThemeProvider()), chromeTabLaunchActionsStoreProvider.get(), containerWithInsetsProvider.get(), containerWithoutInsetsProvider.get(), contextProvider.get(), mapOfStringAndCustomViewConfiguration(), bindCustomViewFactoryDelegateCreatorProvider.get(), bduiDependencies.getFlexAdapter(), fragmentActivityProvider.get(), fragmentManagerProvider.get(), Preconditions.checkNotNullFromComponent(bduiDependencies.getBduiHostUrlProvider()), Preconditions.checkNotNullFromComponent(bduiDependencies.getInsetsConfigHolder()), Preconditions.checkNotNullFromComponent(bduiDependencies.isEngineErrorViewEnabled()), Preconditions.checkNotNullFromComponent(bduiDependencies.isSpinnerPreviewEnabled()), Preconditions.checkNotNullFromComponent(bduiDependencies.getOkHttpClientBuilder()), Preconditions.checkNotNullFromComponent(bduiDependencies.getRouter()), viewModelScopeProvider.get(), bduiDependencies.getErrorViewFactory());
    }

    @Override
    public ShimmersLayoutProvider getShimmersLayoutProvider() {
      return Preconditions.checkNotNullFromComponent(bduiDependencies.getShimmersLayoutProvider());
    }

    private static final class GetAnalyticsProvider implements Provider<Analytics> {
      private final BduiDependencies bduiDependencies;

      GetAnalyticsProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      public Analytics get() {
        return Preconditions.checkNotNullFromComponent(bduiDependencies.getAnalytics());
      }
    }

    private static final class GetAuthRepositoryProvider implements Provider<AuthRepository> {
      private final BduiDependencies bduiDependencies;

      GetAuthRepositoryProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      public AuthRepository get() {
        return Preconditions.checkNotNullFromComponent(bduiDependencies.getAuthRepository());
      }
    }

    private static final class GetEnvironmentProvider implements Provider<DefaultEnvironment> {
      private final BduiDependencies bduiDependencies;

      GetEnvironmentProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      public DefaultEnvironment get() {
        return Preconditions.checkNotNullFromComponent(bduiDependencies.getEnvironment());
      }
    }

    private static final class GetPassportAdapterProvider implements Provider<PassportAdapter> {
      private final BduiDependencies bduiDependencies;

      GetPassportAdapterProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      @Nullable
      public PassportAdapter get() {
        return bduiDependencies.getPassportAdapter();
      }
    }

    private static final class GetRegionProvider implements Provider<Region> {
      private final BduiDependencies bduiDependencies;

      GetRegionProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      public Region get() {
        return Preconditions.checkNotNullFromComponent(bduiDependencies.getRegion());
      }
    }

    private static final class GetBduiActionsDelegateProvider implements Provider<BduiActionsDelegate> {
      private final BduiDependencies bduiDependencies;

      GetBduiActionsDelegateProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      public BduiActionsDelegate get() {
        return Preconditions.checkNotNullFromComponent(bduiDependencies.getBduiActionsDelegate());
      }
    }

    private static final class GetFlexAdapterProvider implements Provider<FlexAdapter> {
      private final BduiDependencies bduiDependencies;

      GetFlexAdapterProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      @Nullable
      public FlexAdapter get() {
        return bduiDependencies.getFlexAdapter();
      }
    }

    private static final class GetYbSdkAdapterProvider implements Provider<YbAdapter> {
      private final BduiDependencies bduiDependencies;

      GetYbSdkAdapterProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      @Nullable
      public YbAdapter get() {
        return bduiDependencies.getYbSdkAdapter();
      }
    }

    private static final class GetPlusAdapterProvider implements Provider<PlusAdapter> {
      private final BduiDependencies bduiDependencies;

      GetPlusAdapterProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      @Nullable
      public PlusAdapter get() {
        return bduiDependencies.getPlusAdapter();
      }
    }

    private static final class GetAuthTokenProviderProvider implements Provider<AuthTokenProvider> {
      private final BduiDependencies bduiDependencies;

      GetAuthTokenProviderProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      public AuthTokenProvider get() {
        return Preconditions.checkNotNullFromComponent(bduiDependencies.getAuthTokenProvider());
      }
    }

    private static final class GetDefaultNetworkApiProvider implements Provider<DefaultNetworkApi> {
      private final BduiDependencies bduiDependencies;

      GetDefaultNetworkApiProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      public DefaultNetworkApi get() {
        return Preconditions.checkNotNullFromComponent(bduiDependencies.getDefaultNetworkApi());
      }
    }

    private static final class GetDevicePubkeyProviderProvider implements Provider<DevicePubkeyProvider> {
      private final BduiDependencies bduiDependencies;

      GetDevicePubkeyProviderProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      public DevicePubkeyProvider get() {
        return Preconditions.checkNotNullFromComponent(bduiDependencies.getDevicePubkeyProvider());
      }
    }

    private static final class GetDeviceChallengeSignatureProviderProvider implements Provider<DeviceChallengeSignatureProvider> {
      private final BduiDependencies bduiDependencies;

      GetDeviceChallengeSignatureProviderProvider(BduiDependencies bduiDependencies) {
        this.bduiDependencies = bduiDependencies;
      }

      @Override
      public DeviceChallengeSignatureProvider get() {
        return Preconditions.checkNotNullFromComponent(bduiDependencies.getDeviceChallengeSignatureProvider());
      }
    }
  }
}
