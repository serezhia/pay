package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.utils

import android.graphics.drawable.BitmapDrawable
import android.widget.ImageView
import androidx.annotation.DrawableRes
import androidx.core.view.isVisible
import coil.load
import coil.request.Disposable
import coil.size.Size
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinEventWrapper
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinInfoAnalyticsErrorType
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinInfoEvent
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.reportDynamicBinEvent
import java.util.WeakHashMap

internal object CardNetworkIconLoader {

    private val jobs = WeakHashMap<ImageView, Disposable>()
    private val requests = WeakHashMap<ImageView, IconRequest>()

    fun load(context: IconLoadContext, request: IconRequest) {
        val previousRequest = requests[context.imageView]
        val runningJob = jobs[context.imageView]

        if (handleMissingIcon(context = context, runningJob = runningJob, request = request)) {
            return
        }

        requests[context.imageView] = request

        if (handleCachedIcon(
                context = context,
                previousRequest = previousRequest,
                request = request,
                runningJob = runningJob,
            )
        ) {
            return
        }

        startIconLoad(
            context = context,
            request = request,
        )
    }

    private fun startIconLoad(
        context: IconLoadContext,
        request: IconRequest,
    ) {
        disposeRunningJob(imageView = context.imageView)
        applyFallback(fallbackRes = request.fallbackRes, imageView = context.imageView)
        val loadStartTime = System.currentTimeMillis()
        reportIconLoadStarted(
            context = context,
            request = request,
        )
        enqueueIconLoad(
            context = context,
            request = request,
            startTime = loadStartTime,
        )
    }

    private fun enqueueIconLoad(
        context: IconLoadContext,
        request: IconRequest,
        startTime: Long,
    ) {
        val disposable = context.imageView.load(data = request.iconUrl) {
            crossfade(enable = true)
            size(size = Size.ORIGINAL)
            if (request.fallbackRes != 0) {
                error(drawableResId = request.fallbackRes)
                fallback(drawableResId = request.fallbackRes)
            }
            listener(
                onSuccess = { _, _ ->
                    context.imageView.isVisible = true
                    jobs.remove(key = context.imageView)
                    requests[context.imageView] = request
                    reportIconLoadSuccess(
                        context = context,
                        request = request,
                        startTime = startTime,
                        wasCached = false,
                    )
                },
                onError = { _, throwable ->
                    applyFallback(fallbackRes = request.fallbackRes, imageView = context.imageView)
                    jobs.remove(key = context.imageView)
                    requests.remove(key = context.imageView)
                    reportIconLoadFailed(
                        context = context,
                        error = throwable.throwable,
                        request = request,
                        startTime = startTime,
                        willFallback = request.fallbackRes != 0,
                    )
                }
            )
        }

        jobs[context.imageView] = disposable
    }

    private fun handleMissingIcon(
        context: IconLoadContext,
        runningJob: Disposable?,
        request: IconRequest,
    ): Boolean {
        if (!request.iconUrl.isNullOrBlank()) {
            return false
        }
        runningJob?.dispose()
        jobs.remove(key = context.imageView)
        requests[context.imageView] = request
         applyFallback(fallbackRes = request.fallbackRes, imageView = context.imageView)
        return true
    }

    private fun handleCachedIcon(
        context: IconLoadContext,
        previousRequest: IconRequest?,
        request: IconRequest,
        runningJob: Disposable?,
    ): Boolean {
        if (previousRequest != requests[context.imageView] || runningJob != null) {
            return false
        }
        context.imageView.isVisible = true
        reportIconLoadSuccess(
            context = context,
            request = request,
            startTime = System.currentTimeMillis(),
            wasCached = true,
        )
        return true
    }

    private fun reportIconLoadStarted(
        context: IconLoadContext,
        request: IconRequest,
    ) {
        if (context.analytics == null || context.binWrapper == null) return
        request.iconUrl?.let {
            context.analytics.reportDynamicBinEvent(
                event = DynamicBinInfoEvent.IconLoadStarted(
                    binWrapper = context.binWrapper,
                    iconUrl = it,
                    isCached = false,
                ),
                isFeatureEnabled = context.isDynamicBinEnabled,
            )
        }
    }

    private fun reportIconLoadSuccess(
        context: IconLoadContext,
        request: IconRequest,
        startTime: Long,
        wasCached: Boolean,
    ) {
        if (context.analytics == null || context.binWrapper == null) return
        val imageSizeBytes = getImageSizeBytesFromView(imageView = context.imageView)
        request.iconUrl?.let {
            context.analytics.reportDynamicBinEvent(
                event = DynamicBinInfoEvent.IconLoadSuccess(
                    binWrapper = context.binWrapper,
                    iconUrl = it,
                    imageSizeBytes = imageSizeBytes,
                    startTime = startTime,
                    wasCached = wasCached,
                ),
                isFeatureEnabled = context.isDynamicBinEnabled,
            )
        }
    }

    private fun reportIconLoadFailed(
        context: IconLoadContext,
        error: Throwable?,
        request: IconRequest,
        startTime: Long,
        willFallback: Boolean,
    ) {
        if (context.analytics == null || context.binWrapper == null) return
        request.iconUrl?.let {
            context.analytics.reportDynamicBinEvent(
                event = DynamicBinInfoEvent.IconLoadFailed(
                    binWrapper = context.binWrapper,
                    errorMessage = error?.message ?: AnalyticsMessages.ICON_LOAD_FAILED,
                    errorType = DynamicBinInfoAnalyticsErrorType.NETWORK_ERROR,
                    iconUrl = it,
                    startTime = startTime,
                    willFallback = willFallback,
                ),
                isFeatureEnabled = context.isDynamicBinEnabled,
            )
        }
    }

    private fun disposeRunningJob(imageView: ImageView) {
        jobs.remove(key = imageView)?.dispose()
    }

    private fun getImageSizeBytesFromView(imageView: ImageView): Int? {
        val drawable = imageView.drawable
        return if (drawable is BitmapDrawable) {
            drawable.bitmap.byteCount
        } else {
            null
        }
    }

    private fun applyFallback(@DrawableRes fallbackRes: Int, imageView: ImageView) {
        if (fallbackRes == 0) {
            imageView.setImageDrawable(null)
            imageView.isVisible = false
        } else {
            imageView.setImageResource(fallbackRes)
            imageView.isVisible = true
        }
    }
    internal data class IconRequest(
        val iconUrl: String?,
        @DrawableRes val fallbackRes: Int,
    )

    internal data class IconLoadContext(
        val analytics: Analytics? = null,
        val binWrapper: DynamicBinEventWrapper? = null,
        val imageView: ImageView,
        val isDynamicBinEnabled: Boolean,
        val trackedIconUrl: String? = null,
    )

    private object AnalyticsMessages {
        const val ICON_LOAD_FAILED = "icon_load_failed"
    }
}

