package com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser

import com.yandex.finsdtechsdk.adapters.passport.sdk.api.PassportAdapter
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.auth.api.AuthState
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment
import com.yandex.fintechsdk.entities.region.Region
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider
import javax.inject.Inject

/**
 * Currently this handler is also used in [ShowNativeScreenActionHandler]
 * by Troika flow for backward compatibility with PaymentSDK.
 * Don't forget to check Troika flow when making changes to this handler.
 */
internal class OpenBrowserActionHandler @Inject constructor(
    private val authRepository: AuthRepository,
    private val chromeTabLaunchActionsStore: ChromeTabLaunchActionsStore,
    private val contextProvider: ContextProvider,
    private val environment: DefaultEnvironment,
    private val passportAdapter: PassportAdapter?,
    private val region: Region,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is OpenBrowserAction) return

        val withPassportAuth = action.params?.get(WITH_PASSPORT_AUTH) == "true"

        var finalUrl = action.url
        if (withPassportAuth) {
            val authorizedState = authRepository.authState.value

            if (authorizedState is AuthState.Authorized) {
                contextProvider.get()?.let { androidContext ->
                    val authorizedUrl = passportAdapter?.getUrlWithAuth(
                        context = androidContext,
                        isTestEnvironment = environment == DefaultEnvironment.TESTING,
                        tld = region.key,
                        uid = authorizedState.credentials.uid,
                        url = action.url,
                    )

                    if (authorizedUrl != null) {
                        finalUrl = authorizedUrl
                    }
                }
            }
        }

        chromeTabLaunchActionsStore.send(url = finalUrl)
    }
}

private const val WITH_PASSPORT_AUTH = "with_passport_auth"
