package com.yandex.fintechsdk.features.bdui.internal.presentation.action.shownativescreen;

import com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser.OpenBrowserActionHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ShowNativeScreenActionHandler_Factory implements Factory<ShowNativeScreenActionHandler> {
  private final Provider<OpenBrowserActionHandler> openBrowserActionHandlerProvider;

  private ShowNativeScreenActionHandler_Factory(
      Provider<OpenBrowserActionHandler> openBrowserActionHandlerProvider) {
    this.openBrowserActionHandlerProvider = openBrowserActionHandlerProvider;
  }

  @Override
  public ShowNativeScreenActionHandler get() {
    return newInstance(openBrowserActionHandlerProvider.get());
  }

  public static ShowNativeScreenActionHandler_Factory create(
      Provider<OpenBrowserActionHandler> openBrowserActionHandlerProvider) {
    return new ShowNativeScreenActionHandler_Factory(openBrowserActionHandlerProvider);
  }

  public static ShowNativeScreenActionHandler newInstance(
      OpenBrowserActionHandler openBrowserActionHandler) {
    return new ShowNativeScreenActionHandler(openBrowserActionHandler);
  }
}
