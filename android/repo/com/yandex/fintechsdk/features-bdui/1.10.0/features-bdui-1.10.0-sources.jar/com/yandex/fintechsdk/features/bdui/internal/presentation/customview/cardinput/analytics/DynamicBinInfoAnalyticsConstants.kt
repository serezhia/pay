package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics

internal enum class DynamicBinInfoAnalyticsDataSource(val value: String) {
    DIEHARD(value = "diehard"),
    TOVARISCH(value = "tovarisch"),
    LOCAL(value = "local"),
    CACHED(value = "cached"),
}

internal enum class DynamicBinInfoAnalyticsErrorType(val value: String) {
    NETWORK_ERROR(value = "network_error"),
    HTTP_ERROR(value = "http_error"),
    CARD_NETWORK_NOT_FOUND(value = "card_network_not_found"),
    UNKNOWN(value = "unknown"),
}

internal enum class DynamicBinInfoAnalyticsResetReason(val value: String) {
    CARD_CLEARED(value = "card_cleared"),
    PREFIX_CHANGED(value = "prefix_changed"),
    MANUAL_RESET(value = "manual_reset"),
    TIMEOUT_WAIT_FOR_BIN_INFO(value = "timeout_wait_for_bin_info"),
}

internal enum class DynamicBinInfoAnalyticsStaticDataReason(val value: String) {
    FEATURE_DISABLED(value = "feature_disabled"),
    NO_REQUEST_MADE(value = "no_request_made"),
    OTHER(value = "other"),
}

internal enum class DynamicBinInfoAnalyticsTrigger(val value: String) {
    SUBMIT(value = "submit"),
}
