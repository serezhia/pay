package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.dynamicbininfo

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.entities.card.BinInfo
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.CardNetworkData
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinAnalyticsState
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinEventWrapper
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinInfoAnalyticsDataSource
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinInfoAnalyticsErrorType
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinInfoAnalyticsResetReason
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinInfoEvent
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.reportDynamicBinEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

internal class DynamicBinInfoManager(
    private val analytics: Analytics,
    private val analyticsState: DynamicBinAnalyticsState,
    private val getBinInfo: suspend (prefix: String) -> Result<BinInfo>,
    private val isDynamicBinEnabled: Boolean,
    private val getCurrentCardNumber: () -> String,
    private val onSuccess: (BinInfo, BinRequestContext) -> Unit,
    private val onFallback: () -> Unit,
    private val resolveStaticPaymentSystem: (cardNumber: String) -> String?,
    private val resolveCardNetworkData: (paymentSystem: String) -> CardNetworkData?,
) {
    private val scope = MainScope()
    private var binJob: Job? = null
    private val cachedBins: MutableMap<String, CachedBin> = mutableMapOf()
    private val requestStates = mutableMapOf<String, RequestState>()
    private val requestIds = mutableMapOf<String, String>()
    private val requestStartTimes = mutableMapOf<String, Long>()
    private val requestPaymentSystems = mutableMapOf<String, String?>()

    fun load(cardNumber: String, isBulkInput: Boolean) {
        val cleanNumber = cardNumber.replace(oldValue = SPACE, newValue = EMPTY)
        val targetLength = when {
            // length is below the minimum we care about — exit early
            cleanNumber.length < MIN_BIN_LENGTH -> return
            // bulk paste and length is already above the max — clamp to max length
            isBulkInput && cleanNumber.length >= FINAL_BIN_LENGTH -> FINAL_BIN_LENGTH
            // typed exactly the minimum amount — use the minimum length
            cleanNumber.length == MIN_BIN_LENGTH -> MIN_BIN_LENGTH
            // typed exactly the maximum amount — use the maximum length
            cleanNumber.length == FINAL_BIN_LENGTH -> FINAL_BIN_LENGTH
            // bulk paste (and we’re between bounds) — fall back to the minimum length
            isBulkInput -> MIN_BIN_LENGTH
            else -> return
        }

        val prefix = cleanNumber.take(n = targetLength)
        binJob?.cancel()
        binJob = scope.launch {
            val requestId = UUID.randomUUID().toString()
            val requestStartTime = System.currentTimeMillis()
            val context = BinRequestContext(
                cardNumber = cleanNumber,
                prefix = prefix,
                requestId = requestId,
                startTime = requestStartTime,
            )
            try {
                delay(timeMillis = DEBOUNCE_DELAY_MS)
                requestBin(context = context)
            } catch (_: Exception) {
                handleFailure(context = context)
            }
        }
    }

    suspend fun ensureFinalBin(cardNumber: String) {
        val cleanNumber = cardNumber.replace(oldValue = SPACE, newValue = EMPTY)
        if (cleanNumber.length < FINAL_BIN_LENGTH) return

        val finalPrefix = cleanNumber.take(n = FINAL_BIN_LENGTH)
        if (cachedBins[finalPrefix] != null) return
        val requestId = UUID.randomUUID().toString()
        val requestStartTime = System.currentTimeMillis()
        val context = BinRequestContext(
            cardNumber = cleanNumber,
            prefix = finalPrefix,
            requestId = requestId,
            startTime = requestStartTime,
        )
        withContext(context = Dispatchers.IO) {
            val completed = withTimeoutOrNull(timeMillis = ENSURE_TIMEOUT_MS) {
                requestBin(context = context)
                true
            }

            if (completed == null) {
                handleFailure(context = context)
            }
        }
    }

    fun reset(
        cardNumberLength: Int = 0,
        resetReason: DynamicBinInfoAnalyticsResetReason = DynamicBinInfoAnalyticsResetReason.CARD_CLEARED,
    ) {
        binJob?.cancel()
        val previousPrefixes = requestStates.keys.map { DynamicBinEventWrapper(prefix = it) }
        requestStates.clear()
        requestIds.clear()
        requestStartTimes.clear()
        requestPaymentSystems.clear()
        cachedBins.clear()

        if (resetReason != DynamicBinInfoAnalyticsResetReason.PREFIX_CHANGED) {
            analytics.reportDynamicBinEvent(
                event = DynamicBinInfoEvent.DataReset(
                    previousPrefixes = previousPrefixes,
                    cardNumberLength = cardNumberLength,
                    resetReason = resetReason,
                ),
                isFeatureEnabled = isDynamicBinEnabled,
            )
            analyticsState.reset()
        }
    }

    fun clear() {
        scope.cancel()
        reset(resetReason = DynamicBinInfoAnalyticsResetReason.MANUAL_RESET)
    }

    fun hasPendingRequests(): Boolean = requestStates.values.any { it == RequestState.PENDING }

    fun getPendingPrefixes(): List<DynamicBinEventWrapper> = requestStates
        .filterValues { it == RequestState.PENDING }
        .keys
        .map(transform = ::DynamicBinEventWrapper)

    fun getSuccessfulPrefixes(): List<DynamicBinEventWrapper> = requestStates
        .filterValues { it == RequestState.SUCCESS }
        .keys
        .map(transform = ::DynamicBinEventWrapper)

    fun getFailedPrefixes(): List<DynamicBinEventWrapper> = requestStates
        .filterValues { it == RequestState.FAILED }
        .keys
        .map(transform = ::DynamicBinEventWrapper)

    private suspend fun requestBin(context: BinRequestContext) {
        val binWrapper = DynamicBinEventWrapper(prefix = context.prefix)
        requestIds[context.prefix] = context.requestId
        val cardNumberLength = context.cardNumber.length
        val staticPaymentSystem = resolveStaticPaymentSystem(context.cardNumber)

        if (serveFromCacheIfPossible(binWrapper = binWrapper, context = context)) {
            return
        }

        if (!markRequestPending(context = context)) {
            return
        }

        if (isTrackedPrefix(prefixLength = context.prefix.length)) {
            analyticsState.onTrackedRequestStarted(startTimeMs = context.startTime)
            analytics.reportDynamicBinEvent(
                event = DynamicBinInfoEvent.RequestStarted(
                    binWrapper = binWrapper,
                    cardNumberLength = cardNumberLength,
                    requestId = context.requestId,
                ),
                isFeatureEnabled = isDynamicBinEnabled,
            )
        }

        val result = getBinInfo(context.prefix)
        result.onSuccess { binInfo ->
            handleRequestSuccess(
                binInfo = binInfo,
                binWrapper = binWrapper,
                context = context,
                staticPaymentSystem = staticPaymentSystem,
            )
        }.onFailure { error ->
            handleRequestError(
                binWrapper = binWrapper,
                cardNumberLength = cardNumberLength,
                context = context,
                error = error,
                staticPaymentSystem = staticPaymentSystem,
            )
        }
    }

    private fun serveFromCacheIfPossible(
        binWrapper: DynamicBinEventWrapper,
        context: BinRequestContext,
    ): Boolean {
        val cachedState = requestStates[context.prefix]
        if (cachedState != RequestState.SUCCESS) {
            return false
        }
        val cachedBin = cachedBins[context.prefix] ?: return false

        if (isTrackedPrefix(prefixLength = context.prefix.length)) {
            analytics.reportDynamicBinEvent(
                event = DynamicBinInfoEvent.RequestCached(
                    binWrapper = binWrapper,
                    paymentSystem = cachedBin.binInfo.paymentSystem,
                ),
                isFeatureEnabled = isDynamicBinEnabled,
            )
        }
        onSuccess(cachedBin.binInfo, context)
        return true
    }

    private fun markRequestPending(context: BinRequestContext): Boolean {
        val cachedState = requestStates[context.prefix]
        if (cachedState == RequestState.PENDING) {
            return false
        }
        requestStates[context.prefix] = RequestState.PENDING
        requestStartTimes[context.prefix] = context.startTime
        return true
    }

    private fun handleRequestSuccess(
        binInfo: BinInfo,
        binWrapper: DynamicBinEventWrapper,
        context: BinRequestContext,
        staticPaymentSystem: String?,
    ) {
        val currentState = requestStates[context.prefix]
        val currentId = requestIds[context.prefix]
        if (currentId != context.requestId || currentState != RequestState.PENDING) return
        requestStates[context.prefix] = RequestState.SUCCESS
        requestPaymentSystems[context.prefix] = binInfo.paymentSystem
        cachedBins[context.prefix] = CachedBin(prefix = context.prefix, binInfo = binInfo, context = context)
        val networkData = resolveCardNetworkData(binInfo.paymentSystem)

        if (isTrackedPrefix(prefixLength = context.prefix.length)) {
            analytics.reportDynamicBinEvent(
                event = DynamicBinInfoEvent.RequestSuccess(
                    binWrapper = binWrapper,
                    iconUrl = networkData?.iconUrl?.day?.takeIf { it.isNotBlank() },
                    networkFoundInTovarish = networkData != null,
                    paymentSystem = binInfo.paymentSystem,
                    requestId = context.requestId,
                    startTime = context.startTime,
                    staticPaymentSystem = staticPaymentSystem,
                    systemsMatch = staticPaymentSystem?.equals(other = binInfo.paymentSystem),
                    withoutCvn = binInfo.withoutCvn,
                ),
                isFeatureEnabled = isDynamicBinEnabled,
            )
        }

        reportRaceEvent(cardNumber = context.cardNumber)
        deliverResult(binInfo = binInfo, context = context)
    }

    private fun handleRequestError(
        binWrapper: DynamicBinEventWrapper,
        cardNumberLength: Int,
        context: BinRequestContext,
        error: Throwable,
        staticPaymentSystem: String?,
    ) {
        val currentState = requestStates[context.prefix]
        val currentId = requestIds[context.prefix]
        if (currentId != context.requestId || currentState != RequestState.PENDING) return
        requestStates[context.prefix] = RequestState.FAILED
        requestPaymentSystems[context.prefix] = null
        val willFallback = cachedBins.isEmpty()

        if (isTrackedPrefix(prefixLength = context.prefix.length)) {
            analytics.reportDynamicBinEvent(
                event = DynamicBinInfoEvent.RequestFailed(
                    binWrapper = binWrapper,
                    errorMessage = error.message ?: UNKNOWN_ERROR,
                    errorType = DynamicBinInfoAnalyticsErrorType.NETWORK_ERROR,
                    requestId = context.requestId,
                    startTime = context.startTime,
                    staticPaymentSystem = staticPaymentSystem,
                    willFallback = willFallback,
                ),
                isFeatureEnabled = isDynamicBinEnabled,
            )
        }
        val failedPrefixes = requestStates.filter { it.value == RequestState.FAILED }
            .keys.map { DynamicBinEventWrapper(prefix = it) }
        val totalRequestsCount = requestStates.size
        val failedRequestsCount = failedPrefixes.size

        if (willFallback) {
            analytics.reportDynamicBinEvent(
                event = DynamicBinInfoEvent.FallbackToStatic(
                    cardNumberLength = cardNumberLength,
                    failedPrefixes = failedPrefixes,
                    failedRequestsCount = failedRequestsCount,
                    iconSource = DynamicBinInfoAnalyticsDataSource.LOCAL,
                    staticPaymentSystem = staticPaymentSystem,
                    timeSinceFirstRequestMs = analyticsState.timeSinceFirstRequest(),
                    totalRequestsCount = totalRequestsCount,
                ),
                isFeatureEnabled = isDynamicBinEnabled,
            )
        }
        reportRaceEvent(cardNumber = context.cardNumber)
        handleFailure(context = context)
    }

    private fun isTrackedPrefix(prefixLength: Int): Boolean =
        prefixLength == MIN_BIN_LENGTH || prefixLength == FINAL_BIN_LENGTH

    private fun handleFailure(context: BinRequestContext) {
        val cached = getLastCached(cardNumber = context.cardNumber)?.binInfo
        if (cached != null) {
            onSuccess(cached, context)
        } else {
            onFallback()
        }
    }

    private fun reportRaceEvent(cardNumber: String) {
        val prefix3 = cardNumber.take(n = MIN_BIN_LENGTH)
        val prefix8 = cardNumber.take(n = FINAL_BIN_LENGTH)

        val state3 = requestStates[prefix3]
        val state8 = requestStates[prefix8]

        if (state3 == null || state8 == null || state3 == RequestState.PENDING || state8 == RequestState.PENDING) {
            return
        }

        val startTime3 = requestStartTimes[prefix3] ?: return
        val startTime8 = requestStartTimes[prefix8] ?: return
        val duration3 = (System.currentTimeMillis() - startTime3).toInt().takeIf { it >= 0 }
        val duration8 = (System.currentTimeMillis() - startTime8).toInt().takeIf { it >= 0 }

        val paymentSystem3 = requestPaymentSystems[prefix3]
        val paymentSystem8 = requestPaymentSystems[prefix8]
        val systemsMatch = if (paymentSystem3 != null && paymentSystem8 != null) {
            paymentSystem3.equals(other = paymentSystem8, ignoreCase = true)
        } else null

        val usedPrefix = when {
            state3 == RequestState.SUCCESS && state8 == RequestState.SUCCESS -> UsedPrefixValue.BOTH
            state8 == RequestState.SUCCESS -> UsedPrefixValue.EIGHT
            state3 == RequestState.SUCCESS -> UsedPrefixValue.THREE
            else -> UsedPrefixValue.NONE
        }

        analytics.reportDynamicBinEvent(
            event = DynamicBinInfoEvent.RequestsRace(
                paymentSystem3 = paymentSystem3,
                paymentSystem8 = paymentSystem8,
                prefix3DurationMs = duration3,
                prefix3Status = state3.value,
                prefix8DurationMs = duration8,
                prefix8Status = state8.value,
                systemsMatch = systemsMatch,
                usedPrefix = DynamicBinEventWrapper(prefix = usedPrefix),
            ),
            isFeatureEnabled = isDynamicBinEnabled,
        )
    }

    private fun getLastCached(cardNumber: String): CachedBin? {
        return cachedBins
            .filterKeys { prefix -> cardNumber.startsWith(prefix) }
            .maxByOrNull { it.key.length }
            ?.value
    }

    private fun deliverResult(binInfo: BinInfo, context: BinRequestContext) {
        val currentNumber = getCurrentCardNumber()
        val isActual = currentNumber.isNotEmpty() && currentNumber.startsWith(context.prefix)
        if (isActual) {
            onSuccess(binInfo, context)
            return
        }

        if (currentNumber.length < MIN_BIN_LENGTH) {
            onFallback()
            return
        }

        val cached = getLastCached(cardNumber = currentNumber)
        if (cached != null) {
            onSuccess(cached.binInfo, cached.context)
        } else {
            onFallback()
        }
    }

    private companion object {
        private const val DEBOUNCE_DELAY_MS = 300L
        private const val ENSURE_TIMEOUT_MS = 2000L
        private const val FINAL_BIN_LENGTH = 8
        private const val MIN_BIN_LENGTH = 3

        private const val UNKNOWN_ERROR = "Unknown error"
        private const val SPACE = " "
        private const val EMPTY = ""
    }
}

private data class CachedBin(
    val prefix: String,
    val binInfo: BinInfo,
    val context: BinRequestContext,
)

private object UsedPrefixValue {
    const val BOTH = "both"
    const val EIGHT = "8"
    const val NONE = "none"
    const val THREE = "3"
}

private enum class RequestState(val value: String) {
    FAILED(value = "failed"),
    PENDING(value = "pending"),
    SUCCESS(value = "success");
}
