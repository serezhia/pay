package com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser

import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class OpenBrowserAction(
    @SerialName("params")
    val params: Map<String, String>? = null,

    @SerialName("url")
    val url: String,
) : BduiAction
