package com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.annotation.StringRes
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.bdui.api.customview.BduiVariableController
import com.yandex.fintechsdk.core.bdui.api.customview.action.DivCustomActionHandler
import com.yandex.fintechsdk.core.bdui.api.customview.expression.BduiExpressionResolver
import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository
import com.yandex.fintechsdk.features.bdui.R
import com.yandex.fintechsdk.features.bdui.databinding.FinsdkViewCardInputMainBinding
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.DynamicBinInfoEvent
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.analytics.reportDynamicBinEvent
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.CardInputState
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.Step
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.TextState
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.ValidationStatus
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.contract.isSuccess
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNetworkPatternDictionary
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNetworkWithPatternChecker
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.CardNumberFormatter
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.NetworkImageFacade
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.formatters.SecurityCodeTypeStringFacade
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.textwatchers.CardNumberTextWatcher
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.textwatchers.CvvTextWatcher
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.textwatchers.ExpirationDateTextWatcher
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.views.CardPanInputView
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.views.DateExpiredInputView
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.cardinput.views.SecretCodeInputView
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.Keyboard
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.hide
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.runLayoutChangesAnimation
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.setLocked
import com.yandex.fintechsdk.features.bdui.internal.presentation.customview.utils.show
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.launch

@SuppressLint("ClickableViewAccessibility")
internal class CardInputMainView(
    analytics: Analytics,
    context: Context,
    cardBindingRepository: CardBindingRepository,
    private val params: CardInputCustomProps,
    private val variableController: BduiVariableController,
) : ConstraintLayout(context) {

    private val binding: FinsdkViewCardInputMainBinding = FinsdkViewCardInputMainBinding.inflate(LayoutInflater.from(context), this, true)
    private val cardNumberInput: CardPanInputView = binding.finsdkCardNumberInput
    private val cardExpirationDateInput: DateExpiredInputView = binding.finsdkCardExpirationDateInput
    private val cardCvvInput: SecretCodeInputView = binding.finsdkCardCvvInput
    private val useDynamicPatterns = params.enableDynamicBinInfo == true

    private val cardNetworkPatternDictionary: CardNetworkPatternDictionary =
        CardNetworkPatternDictionaryFactory.create(
            cardNetworks = params.dynamicBinInfoProps?.cardNetworkDetails,
            enableDynamicBinInfo = useDynamicPatterns,
        )

    private val cachedStateForController: CardInputState? = if (useDynamicPatterns) {
        CardInputStateCacheHolder.state
    } else {
        null
    }

    private val cardNetworkChecker: CardNetworkWithPatternChecker = CardNetworkWithPatternChecker(
        cardNetworkPatternDictionary = cardNetworkPatternDictionary,
    )
    private val cardNumberFormatter: CardNumberFormatter = CardNumberFormatter(
        cardNetworkChecker = cardNetworkChecker,
    )
    private val networkImageFacade: NetworkImageFacade = NetworkImageFacade(
        cardNetworkChecker = cardNetworkChecker,
        enableDebranding = params.enableDebranding,
        cardNetworks = if (useDynamicPatterns) params.dynamicBinInfoProps?.cardNetworkDetails else null,
    )
    private val securityCodeTypeStringFacade: SecurityCodeTypeStringFacade = SecurityCodeTypeStringFacade(
        cardNetworkChecker = cardNetworkChecker,
        cardNetworks = if (useDynamicPatterns) params.dynamicBinInfoProps?.cardNetworkDetails else null,
    )

    private val viewController: CardInputViewController = CardInputViewController(
        analytics = analytics,
        cachedState = cachedStateForController,
        cardBindingRepository = cardBindingRepository,
        cardNetworkPatternDictionary = cardNetworkPatternDictionary,
        cardNetworkChecker = cardNetworkChecker,
        customProps = params,
        networkImageFacade = networkImageFacade,
        onWaitForBinInfoCancelIfNeeded = { cancelWaitingForBin() },
        onWaitForBinInfoStartIfNeeded = { startWaitingForBin() },
        securityCodeTypeStringFacade = securityCodeTypeStringFacade,
        variableController = variableController,
    )

    private var isExpandedNumber: Boolean = true
    private val expandedConstrainSet = ConstraintSet().apply { clone(context, R.layout.finsdk_view_card_input_main) }
    private val collapsedCardInput = ConstraintSet().apply { clone(context, R.layout.finsdk_view_card_input_collapsed_card_pan) }
    private val collapsedCardInputWithoutCvv = ConstraintSet().apply {
        clone(context, R.layout.finsdk_view_card_input_collapsed_card_pan)
        setVisibility(R.id.finsdkCardCvvInput, ConstraintSet.GONE)

        clear(R.id.finsdkCardNumberInput, ConstraintSet.END)
        clear(R.id.finsdkCardExpirationDateInput, ConstraintSet.END)
        clear(R.id.finsdkCardExpirationDateInput, ConstraintSet.START)

        connect(
            R.id.finsdkCardNumberInput,
            ConstraintSet.START,
            ConstraintSet.PARENT_ID,
            ConstraintSet.START,
        )
        connect(
            R.id.finsdkCardNumberInput,
            ConstraintSet.END,
            R.id.finsdkCardExpirationDateInput,
            ConstraintSet.START,
        )
        connect(
            R.id.finsdkCardExpirationDateInput,
            ConstraintSet.START,
            R.id.finsdkCardNumberInput,
            ConstraintSet.END,
        )
        setMargin(
            R.id.finsdkCardExpirationDateInput,
            ConstraintSet.START,
            (DEFAULT_PADDING * resources.displayMetrics.density).toInt(),
        )
    }

    private val animationDuration: Long = resources.getInteger(android.R.integer.config_longAnimTime).toLong()
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var submitJob: Job? = null
    private var waitingJob: Job? = null

    private var expressionResolver: BduiExpressionResolver? = null

    private var resolvedTextColor: Int? = null
    private var resolvedPlaceholderColor: Int? = null
    private var resolvedTopLabelColor: Int? = null
    private var resolvedErrorTextColor: Int? = null

    init {
        analytics.reportDynamicBinEvent(
            event = DynamicBinInfoEvent.Init(
                enabledDynamicBinInfo = useDynamicPatterns,
                cardNetworksCount = params.dynamicBinInfoProps?.cardNetworkDetails?.size,
                nextActionTimeoutMs = params.dynamicBinInfoProps?.nextActionLockDelayInMillis,
            ),
            isFeatureEnabled = useDynamicPatterns,
        )

        with(receiver = cardNumberInput.binding) {
            finsdkPanInputText.addTextChangedListener(
                CardNumberTextWatcher(
                    listener = viewController,
                    cardNumberFormatter = cardNumberFormatter,
                ),
            )
            finsdkPanInputTextMasked.setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_DOWN) {
                    viewController.proceedToCardNumber()
                }
                false
            }
        }

        with(receiver = cardExpirationDateInput) {
            setInputFilters()
            binding.finsdkExpirationDateInputText.addTextChangedListener(
                ExpirationDateTextWatcher(
                    listener = viewController,
                ),
            )
            binding.finsdkExpirationDateInputText.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    viewController.proceedToDate()
                }
            }
        }

        with(receiver = cardCvvInput) {
            updateLengthFilter()
            binding
        }

        with(receiver = cardCvvInput) {
            updateLengthFilter()
            binding.finsdkCvvInputText.addTextChangedListener(
                CvvTextWatcher(
                    listener = viewController,
                ),
            )
            binding.finsdkCvvInputText.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    val currentState = viewController.state.value
                    if (!currentState.isCvvHidden) {
                        viewController.proceedToCvv()
                    }
                }
            }
        }

        setEditorActions(
            onCardEditDone = ::gainFocusExpirationDate,
            onExpirationDateEditDone = {
                val currentState = viewController.state.value
                if (currentState.isCvvHidden) {
                    submitForm()
                } else {
                    gainFocusCvv()
                }
            },
            onCvvEditDone = ::submitForm,
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()

        scope.launch {
            viewController.state.collect { state ->
                render(state = state)
            }
        }

        // Update variables, so we are sure that they are created in variables store
        updateVariables(state = viewController.state.value)
        variableController.setVariableListener(
            variableName = FULL_FORM_STATE_VARIABLE,
            listenerKey = LISTENER_KEY,
        ) { fullFormState ->
            val fullFormStateString = fullFormState as? String ?: return@setVariableListener
            when (fullFormStateString) {
                FULL_FORM_STATE_CARD_NUMBER_INPUT_IN_PROGRESS -> viewController.proceedToCardNumber()
                FULL_FORM_STATE_DATE_CVV_IN_PROGRESS -> viewController.proceedToDate()
                FULL_FORM_STATE_SUBMITTED -> submitForm()
            }
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        CardInputStateCacheHolder.clearCache()
        scope.coroutineContext.cancelChildren()
        variableController.removeVariableListener(variableName = FULL_FORM_STATE_VARIABLE, listenerKey = LISTENER_KEY)
        viewController.cleanup()
    }

    fun setActionHandler(actionHandler: DivCustomActionHandler) {
        viewController.setActionHandler(actionHandler = actionHandler)
    }

    fun setExpressionResolver(resolver: BduiExpressionResolver) {
        this.expressionResolver = resolver
        viewController.setExpressionResolver(resolver = resolver)
        evaluateExpressions()
    }

    private fun evaluateExpressions() {
        val resolver = expressionResolver ?: return

        fun resolveColorExpression(expr: String?): Int? {
            val expression = expr ?: return null
            return resolver.resolveColor(expression = expression)
        }

        resolvedTextColor = resolveColorExpression(expr = params.textColorExpression)
        resolvedPlaceholderColor = resolveColorExpression(expr = params.placeholderColorExpression)
        resolvedTopLabelColor = resolveColorExpression(expr = params.topLabelColorExpression)
        resolvedErrorTextColor = resolveColorExpression(expr = params.errorTextColorExpression)

        applyResolvedColors()
    }

    private fun applyResolvedColors() {
        val textColor = resolvedTextColor
        val placeholderColor = resolvedPlaceholderColor
        val topLabelColor = resolvedTopLabelColor

        // Card number
        with(receiver = cardNumberInput.binding) {
            topLabelColor?.let { finsdkPanInputLabel.setTextColor(it) }
            textColor?.let {
                finsdkPanInputText.setTextColor(it)
                finsdkPanInputTextMasked.setTextColor(it)
            }
            placeholderColor?.let {
                finsdkPanInputText.setHintTextColor(it)
                finsdkPanInputTextMasked.setHintTextColor(it)
                finsdkPanInputTextHint.setTextColor(it)
            }
        }

        // Expiration date
        with(receiver = cardExpirationDateInput.binding) {
            topLabelColor?.let { finsdkExpirationDateInputLabel.setTextColor(it) }
            textColor?.let { finsdkExpirationDateInputText.setTextColor(it) }
            placeholderColor?.let {
                finsdkExpirationDateInputText.setHintTextColor(it)
                finsdkExpirationDateInputTextHint.setTextColor(it)
            }
        }

        // CVV
        with(receiver = cardCvvInput.binding) {
            topLabelColor?.let { finsdkCvvInputLabel.setTextColor(it) }
            textColor?.let { finsdkCvvInputText.setTextColor(it) }
            placeholderColor?.let {
                finsdkCvvInputText.setHintTextColor(it)
                finsdkCvvInputTextHint.setTextColor(it)
            }
        }
    }

    private fun render(state: CardInputState) {
        CardInputStateCacheHolder.saveCache(state = state)
        updateVariables(state = state)
        setInputsText(state = state)

        setLocked(isLocked = state.step.isLocker())
        setSecurityCodeType(
            codeType = state.securityCodeStringRes,
            customLabel = state.securityCodeLabel,
        )
        updateCardNumberInput(details = state)
        when (state.step) {
            is Step.CardNumber -> {
                updateCardNumberTextState(state = TextState.REGULAR)
                switchToCardNumber()
                gainFocusNumber()
            }

            is Step.CardExpirationDate -> {
                updateCardNumberTextState(state = TextState.MASKED)
                switchToCardDetails()
                gainFocusExpirationDate()
            }

            is Step.CardCvv -> {
                updateCardNumberTextState(state = TextState.MASKED)
                switchToCardDetails()
                if (!state.isCvvHidden) {
                    gainFocusCvv()
                }
            }

            is Step.CardBinding -> {
                updateCardNumberTextState(state = TextState.MASKED)
                Keyboard.hide(view = this)
                switchToCardDetails()
            }
        }
        updateCvvVisibility(state = state)
        highlightValidationErrors(details = state)
    }

    private fun startWaitingForBin() {
        waitingJob?.cancel()
        waitingJob = scope.launch {
            viewController.waitForBinInfoIfNeeded()
        }
    }

    private fun cancelWaitingForBin(): Boolean {
        if (waitingJob != null) {
            waitingJob?.cancel()
            waitingJob = null
            return true
        }
        return false
    }

    @Suppress("CyclomaticComplexMethod") // TODO: split the method into several and simplify it
    private fun CardInputMainView.highlightValidationErrors(details: CardInputState) {
        with(receiver = cardNumberInput) {
            val label = binding.finsdkPanInputLabel
            if (details.cardNumberField.showValidationStatus) {
                when (details.cardNumberField.validationStatus) {
                    is ValidationStatus.Error -> {
                        showError()
                        resolvedErrorTextColor?.let { label.setTextColor(it) }
                    }

                    is ValidationStatus.Success -> {
                        hideError()
                        resolvedTopLabelColor?.let { label.setTextColor(it) }
                    }
                }
            } else {
                hideError()
                resolvedTopLabelColor?.let { label.setTextColor(it) }
            }
        }

        with(receiver = cardExpirationDateInput) {
            val label = binding.finsdkExpirationDateInputLabel
            if (details.expiryDateField.showValidationStatus) {
                when (details.expiryDateField.validationStatus) {
                    is ValidationStatus.Error -> {
                        showError()
                        resolvedErrorTextColor?.let { label.setTextColor(it) }
                    }

                    is ValidationStatus.Success -> {
                        hideError()
                        resolvedTopLabelColor?.let { label.setTextColor(it) }
                    }
                }
            } else {
                hideError()
                resolvedTopLabelColor?.let { label.setTextColor(it) }
            }
        }

        with(receiver = cardCvvInput) {
            val label = binding.finsdkCvvInputLabel
            if (!details.isCvvHidden && details.cvvField.showValidationStatus) {
                when (details.cvvField.validationStatus) {
                    is ValidationStatus.Error -> {
                        showError()
                        resolvedErrorTextColor?.let { label.setTextColor(it) }
                    }

                    is ValidationStatus.Success -> {
                        hideError()
                        resolvedTopLabelColor?.let { label.setTextColor(it) }
                    }
                }
            } else {
                resolvedTopLabelColor?.let { label.setTextColor(it) }
            }
        }
    }

    private fun setInputsText(state: CardInputState) {
        cardNumberInput.setCardNumberIfNew(text = state.cardNumberField.cardNumber.value)
        cardExpirationDateInput.setTextIfNew(text = state.expiryDateField.rawExpiryDate)
        cardCvvInput.setTextIfNew(text = state.cvvField.cvv.value)
    }

    private fun setLocked(isLocked: Boolean) {
        binding.finsdkCardBindingLayout.setLocked(isLocked = isLocked)
        cardNumberInput.setLocked(isLocked = isLocked)
        cardCvvInput.setLocked(isLocked = isLocked)
        cardExpirationDateInput.setLocked(isLocked = isLocked)
    }

    private fun setSecurityCodeType(@StringRes codeType: Int, customLabel: String?) {
        cardCvvInput.setSecurityCodeType(codeType = codeType, customLabel = customLabel)
    }

    private fun switchToCardNumber() {
        if (isExpandedNumber) {
            return
        }
        isExpandedNumber = true
        expandCardNumber()
    }

    private fun switchToCardDetails() {
        if (!isExpandedNumber) {
            return
        }
        isExpandedNumber = false
        collapseCardNumber()
    }

    private fun updateCardNumberInput(details: CardInputState) {
        with(receiver = cardNumberInput) {
            textFieldValueMasked = "%s".format(details.cardNumberField.cardNumber.value.takeLast(PAN_LAST_DIGITS_NUMBER))
            moveCursor()
            updateCardTypeView(
                analytics = details.iconAnalytics,
                binWrapper = details.iconBinWrapper,
                fallbackImage = details.networkImageRes,
                iconUrl = details.networkIconUrl,
                isDynamicBinEnabled = useDynamicPatterns,
                trackedIconUrl = details.trackedIconUrl,
            )
        }
    }

    private fun updateCardNumberTextState(state: TextState) {
        with(receiver = cardNumberInput) {
            when (state) {
                TextState.REGULAR -> {
                    binding.finsdkPanInputText.show()
                    binding.finsdkPanInputTextMasked.hide()
                }

                TextState.MASKED -> {
                    binding.finsdkPanInputText.hide()
                    binding.finsdkPanInputTextMasked.show()
                }
            }
        }
    }

    private fun updateCvvVisibility(state: CardInputState) {
        val visibility = if (state.isCvvHidden) GONE else VISIBLE
        if (cardCvvInput.visibility != visibility) {
            if (state.isCvvHidden && cardCvvInput.hasFocus()) {
                cardExpirationDateInput.gainFocus()
            }
            cardCvvInput.visibility = visibility
            if (state.isCvvHidden && !isExpandedNumber) {
                collapsedCardInputWithoutCvv.applyTo(binding.root)
                binding.root.runLayoutChangesAnimation(duration = animationDuration)
            } else if (!state.isCvvHidden && !isExpandedNumber) {
                collapsedCardInput.applyTo(binding.root)
                binding.root.runLayoutChangesAnimation(duration = animationDuration)
            }
        }
    }

    private fun gainFocusExpirationDate() {
        cardExpirationDateInput.gainFocus()
    }

    private fun gainFocusCvv() {
        cardCvvInput.gainFocus()
    }

    private fun gainFocusNumber() {
        cardNumberInput.gainFocus()
    }

    private fun setEditorActions(
        onCardEditDone: (() -> Unit)? = null,
        onExpirationDateEditDone: (() -> Unit)? = null,
        onCvvEditDone: (() -> Unit)? = null
    ) {
        cardNumberInput.binding.finsdkPanInputText.setOnEditorActionListener(
            createNextActionListener(
                action = onCardEditDone,
            ),
        )
        cardExpirationDateInput.binding.finsdkExpirationDateInputText.setOnEditorActionListener(
            createNextActionListener(
                action = onExpirationDateEditDone,
            ),
        )
        cardCvvInput.binding.finsdkCvvInputText.setOnEditorActionListener(
            createNextActionListener(
                action = onCvvEditDone,
            ),
        )
    }

    private fun submitForm() {
        // If we are already tokenizing card, do not do anything
        if (submitJob?.isActive == true) return

        // Cancel, so we are sure there is no active job
        submitJob?.cancel()
        submitJob = scope.launch { viewController.submitForm() }
    }

    private fun expandCardNumber() {
        expandedConstrainSet.applyTo(binding.root)
        binding.root.runLayoutChangesAnimation(duration = animationDuration)
    }

    private fun collapseCardNumber() {
        collapsedCardInput.applyTo(binding.root)
        binding.root.runLayoutChangesAnimation(duration = animationDuration)
    }

    private fun createNextActionListener(action: (() -> Unit)?): TextView.OnEditorActionListener {
        return TextView.OnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_NEXT && action != null) {
                action()
            }
            return@OnEditorActionListener true
        }
    }

    private fun updateVariables(state: CardInputState) {
        variableController.setVariable(name = CARD_NUMBER_INPUT_STATE_VARIABLE, value = state.toCardNumberInputState())
        variableController.setVariable(name = DATE_INPUT_STATE_VARIABLE, value = state.toDateInputState())
        variableController.setVariable(name = CVV_INPUT_STATE_VARIABLE, value = state.toCvvInputState())
        variableController.setVariable(name = FULL_FORM_STATE_VARIABLE, value = state.toFullFormInputState())
        variableController.setVariable(name = PAYMENT_SYSTEM_LOADING_VARIABLE, value = state.isBinInfoLoading)
    }

    private fun CardInputState.toCardNumberInputState() = when {
        cardNumberField.validationStatus.isSuccess() -> INPUT_STATE_COMPLETED
        cardNumberField.showValidationStatus && step is Step.CardNumber -> INPUT_STATE_FOCUSED_WITH_ERROR
        cardNumberField.showValidationStatus -> INPUT_STATE_ERROR
        step is Step.CardNumber -> INPUT_STATE_FOCUSED
        else -> { INPUT_STATE_EMPTY }
    }

    private fun CardInputState.toDateInputState() = when {
        expiryDateField.validationStatus.isSuccess() -> INPUT_STATE_COMPLETED
        expiryDateField.showValidationStatus && step is Step.CardExpirationDate -> INPUT_STATE_FOCUSED_WITH_ERROR
        expiryDateField.showValidationStatus -> INPUT_STATE_ERROR
        step is Step.CardExpirationDate -> INPUT_STATE_FOCUSED
        else -> { INPUT_STATE_EMPTY }
    }

    private fun CardInputState.toCvvInputState() = when {
        isCvvHidden -> INPUT_STATE_EMPTY
        cvvField.validationStatus.isSuccess() -> INPUT_STATE_COMPLETED
        cvvField.showValidationStatus && step is Step.CardCvv -> INPUT_STATE_FOCUSED_WITH_ERROR
        cvvField.showValidationStatus -> INPUT_STATE_ERROR
        step is Step.CardCvv -> INPUT_STATE_FOCUSED
        else -> { INPUT_STATE_EMPTY }
    }

    private fun CardInputState.toFullFormInputState() = when (step) {
        Step.CardNumber -> FULL_FORM_STATE_CARD_NUMBER_INPUT_IN_PROGRESS
        Step.CardExpirationDate, Step.CardCvv -> FULL_FORM_STATE_DATE_CVV_IN_PROGRESS
        is Step.CardBinding -> FULL_FORM_STATE_SUBMITTED
    }

    private companion object {

        const val INPUT_STATE_EMPTY = "empty"
        const val INPUT_STATE_FOCUSED = "focused"
        const val INPUT_STATE_ERROR = "error"
        const val INPUT_STATE_FOCUSED_WITH_ERROR = "focusedWithError"
        const val INPUT_STATE_COMPLETED = "completed"

        const val FULL_FORM_STATE_CARD_NUMBER_INPUT_IN_PROGRESS = "cardNumberInputInProgress"
        const val FULL_FORM_STATE_DATE_CVV_IN_PROGRESS = "dateCvvInputInProgress"
        const val FULL_FORM_STATE_SUBMITTED = "submitted"

        const val TOKENIZATION_SCREEN_STATE = "js.TokenizationScreenState"
        const val CARD_NUMBER_INPUT_STATE_VARIABLE = "$TOKENIZATION_SCREEN_STATE.cardNumberInputState"
        const val DATE_INPUT_STATE_VARIABLE = "$TOKENIZATION_SCREEN_STATE.dateInputState"
        const val CVV_INPUT_STATE_VARIABLE = "$TOKENIZATION_SCREEN_STATE.cvvInputState"
        const val FULL_FORM_STATE_VARIABLE = "$TOKENIZATION_SCREEN_STATE.fullFormState"
        const val PAYMENT_SYSTEM_LOADING_VARIABLE = "$TOKENIZATION_SCREEN_STATE.paymentSystemLoadingState"

        const val LISTENER_KEY = "CARD_INPUT_VIEW_LISTENER"

        const val PAN_LAST_DIGITS_NUMBER = 4
        const val DEFAULT_PADDING = 16
    }
}
