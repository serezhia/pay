package com.yandex.fintechsdk.features.bdui.internal.presentation.action.browser;

import com.yandex.finsdtechsdk.adapters.passport.sdk.api.PassportAdapter;
import com.yandex.fintechsdk.data.auth.api.AuthRepository;
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment;
import com.yandex.fintechsdk.entities.region.Region;
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ContextProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class OpenBrowserActionHandler_Factory implements Factory<OpenBrowserActionHandler> {
  private final Provider<AuthRepository> authRepositoryProvider;

  private final Provider<ChromeTabLaunchActionsStore> chromeTabLaunchActionsStoreProvider;

  private final Provider<ContextProvider> contextProvider;

  private final Provider<DefaultEnvironment> environmentProvider;

  private final Provider<PassportAdapter> passportAdapterProvider;

  private final Provider<Region> regionProvider;

  private OpenBrowserActionHandler_Factory(Provider<AuthRepository> authRepositoryProvider,
      Provider<ChromeTabLaunchActionsStore> chromeTabLaunchActionsStoreProvider,
      Provider<ContextProvider> contextProvider, Provider<DefaultEnvironment> environmentProvider,
      Provider<PassportAdapter> passportAdapterProvider, Provider<Region> regionProvider) {
    this.authRepositoryProvider = authRepositoryProvider;
    this.chromeTabLaunchActionsStoreProvider = chromeTabLaunchActionsStoreProvider;
    this.contextProvider = contextProvider;
    this.environmentProvider = environmentProvider;
    this.passportAdapterProvider = passportAdapterProvider;
    this.regionProvider = regionProvider;
  }

  @Override
  public OpenBrowserActionHandler get() {
    return newInstance(authRepositoryProvider.get(), chromeTabLaunchActionsStoreProvider.get(), contextProvider.get(), environmentProvider.get(), passportAdapterProvider.get(), regionProvider.get());
  }

  public static OpenBrowserActionHandler_Factory create(
      Provider<AuthRepository> authRepositoryProvider,
      Provider<ChromeTabLaunchActionsStore> chromeTabLaunchActionsStoreProvider,
      Provider<ContextProvider> contextProvider, Provider<DefaultEnvironment> environmentProvider,
      Provider<PassportAdapter> passportAdapterProvider, Provider<Region> regionProvider) {
    return new OpenBrowserActionHandler_Factory(authRepositoryProvider, chromeTabLaunchActionsStoreProvider, contextProvider, environmentProvider, passportAdapterProvider, regionProvider);
  }

  public static OpenBrowserActionHandler newInstance(AuthRepository authRepository,
      ChromeTabLaunchActionsStore chromeTabLaunchActionsStore, ContextProvider contextProvider,
      DefaultEnvironment environment, @Nullable PassportAdapter passportAdapter, Region region) {
    return new OpenBrowserActionHandler(authRepository, chromeTabLaunchActionsStore, contextProvider, environment, passportAdapter, region);
  }
}
