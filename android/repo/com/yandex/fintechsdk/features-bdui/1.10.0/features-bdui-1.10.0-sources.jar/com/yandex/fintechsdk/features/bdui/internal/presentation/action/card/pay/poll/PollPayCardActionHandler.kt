package com.yandex.fintechsdk.features.bdui.internal.presentation.action.card.pay.poll

import com.yandex.fintechsdk.adapters.yb.sdk.api.YbAdapter
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.bdui.api.action.BduiAction
import com.yandex.fintechsdk.core.bdui.api.action.BduiActionHandler
import com.yandex.fintechsdk.core.bdui.api.action.BduiHandlingContext
import com.yandex.fintechsdk.features.bdui.internal.presentation.fragment.provider.ViewModelScopeProvider
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

internal class PollPayCardActionHandler @Inject constructor(
    private val flexAdapter: FlexAdapter?,
    private val scopeProvider: ViewModelScopeProvider,
    private val ybAdapter: YbAdapter?,
) : BduiActionHandler {

    override fun handle(action: BduiAction, context: BduiHandlingContext) {
        if (action !is PollPayCardAction) return

        val bankAdapter = ybAdapter

        if (bankAdapter == null) {
            action.onError?.let { onError ->
                context.actionDispatcher.dispatch(action = onError)
            }
            return
        }

        val scope = scopeProvider.get() ?: return

        // Make +1 to get total count of tries (one normal attempt + retries count)
        val triesCount = action.retryCount + 1

        scope.launch {
            repeat(triesCount) {
                val cardInfo = bankAdapter.getPayCardInfo()

                if (cardInfo != null) {
                    val trustId = cardInfo.trustId

                    flexAdapter?.updateStateValue(stateName = action.trustIdStateName, valueName = action.trustIdStateKey, newValue = trustId)

                    action.onFinish?.let { onFinish ->
                        context.actionDispatcher.dispatch(action = onFinish)
                    }

                    return@launch
                }

                delay(action.intervalSec.toInt() * INTERVAL_MILLIS)
            }

            action.onError?.let { onError ->
                context.actionDispatcher.dispatch(action = onError)
            }
        }
    }

    private companion object {
        const val INTERVAL_MILLIS = 1000L
    }
}
