package com.yandex.fintechsdk.core.network.api.auth

/**
 * Interface for generating new authentication token.
 * 
 * Implementation must be provided by each flow.
 */
public interface AuthTokenGenerator {
    /**
     * Generate new authentication token.
     * 
     * @return true if token was successfully generated, false otherwise
     */
    public fun generateNewToken(): Boolean
}
