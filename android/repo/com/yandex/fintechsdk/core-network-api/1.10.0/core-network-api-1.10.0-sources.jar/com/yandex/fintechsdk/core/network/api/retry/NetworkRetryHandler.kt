package com.yandex.fintechsdk.core.network.api.retry

import okhttp3.Request
import okhttp3.Response

/**
 * Interface for retry strategy for network requests.
 * Implemented in specific flows for specific use cases.
 */
public interface NetworkRetryHandler {
    /**
     * Maximum number of attempts (including the first one).
     * Default is 1 (one attempt without retries).
     */
    public val maxAttempts: Int get() = 1
    
    /**
     * Check if retry is needed.
     * Handler can perform any preparation (e.g., refresh token) before returning.
     * 
     * @param attempt attempt number (0 = first, 1 = first retry, etc)
     * @param bodyPeek response body
     * @param request original OkHttp Request
     * @param response OkHttp Response (can read code, headers)
     * @return RetryDecision with shouldRetry flag and optional modified request
     */
    public fun shouldRetry(
        attempt: Int,
        bodyPeek: String,
        request: Request,
        response: Response,
    ): RetryDecision
}
