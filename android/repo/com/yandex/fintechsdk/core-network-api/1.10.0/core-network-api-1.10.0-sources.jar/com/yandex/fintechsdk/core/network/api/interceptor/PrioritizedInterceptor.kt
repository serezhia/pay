package com.yandex.fintechsdk.core.network.api.interceptor

import okhttp3.Interceptor

/**
 * Wrapper for OkHttp interceptor with priority.
 * Lower priority value means earlier execution.
 */
public interface PrioritizedInterceptor {
    public val priority: Int
    public val interceptor: Interceptor

    public companion object {
        public const val PRIORITY_HIGH: Int = 0

        public const val PRIORITY_NORMAL: Int = 100

        public const val PRIORITY_LOW: Int = 200
    }
}
