package com.yandex.fintechsdk.core.network.api.host

public interface PayUrlProvider : HostUrlProvider
