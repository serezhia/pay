package com.yandex.fintechsdk.core.network.api.host

public interface HostUrlProvider {

    public fun getHostUrl(): String
}
