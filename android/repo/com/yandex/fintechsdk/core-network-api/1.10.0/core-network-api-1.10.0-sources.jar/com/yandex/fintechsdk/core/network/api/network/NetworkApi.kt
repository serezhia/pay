package com.yandex.fintechsdk.core.network.api.network

import com.yandex.fintechsdk.core.network.api.request.Request
import kotlin.reflect.KType
import kotlin.reflect.typeOf

public interface NetworkApi {
    public suspend fun <T : Any> sendRequest(request: Request, returnType: KType): Result<T>
}

public suspend inline fun <reified T : Any> NetworkApi.sendRequest(request: Request): Result<T> = sendRequest(request, typeOf<T>())
