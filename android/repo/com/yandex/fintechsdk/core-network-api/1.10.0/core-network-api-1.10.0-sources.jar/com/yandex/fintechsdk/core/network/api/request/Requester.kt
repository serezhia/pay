package com.yandex.fintechsdk.core.network.api.request

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

public abstract class Requester<TParams, TRequest, TResponse, TResult>(
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
) {

    public suspend fun execute(params: TParams): Result<TResult> = withContext(dispatcher) {
        try {
            executeRequest(createRequest(params))
                .map(::transformResponse)
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    protected abstract fun createRequest(params: TParams): TRequest

    protected abstract suspend fun executeRequest(request: TRequest): Result<TResponse>

    protected abstract fun transformResponse(response: TResponse): TResult
}

public suspend fun <TRequest, TResponse, TResult> Requester<Unit, TRequest, TResponse, TResult>.execute(): Result<TResult> {
    return execute(Unit)
}
