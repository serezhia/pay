package com.yandex.fintechsdk.core.network.api.retry

import okhttp3.Request

/**
 * Result of retry decision.
 */
public sealed interface RetryDecision {
    /** No retry needed */
    public data object NoRetry : RetryDecision

    /** Retry with original request (no modifications) */
    public data object RetryWithOriginalRequest : RetryDecision

    /** Retry with modified request */
    public class RetryWithModifiedRequest(public val modifiedRequest: Request) : RetryDecision
}
