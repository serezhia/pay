package com.yandex.fintechsdk.core.network.api.request

public enum class RestMethod {
    DELETE,
    GET,
    PATCH,
    POST,
    PUT,
}
