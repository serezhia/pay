package com.yandex.fintechsdk.core.network.api.auth

public interface AuthTokenProvider {
    public fun getToken(): String?
}
