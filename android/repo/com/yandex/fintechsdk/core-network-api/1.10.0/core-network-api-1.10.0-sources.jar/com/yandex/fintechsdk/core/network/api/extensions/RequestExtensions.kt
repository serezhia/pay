package com.yandex.fintechsdk.core.network.api.extensions

import okhttp3.Request

public val Request.baseUrl: String
    get() = url.newBuilder()
        .encodedPath("/")
        .encodedQuery(null)
        .encodedFragment(null)
        .build()
        .toString()
        .removeSuffix("/")

public val Request.path: String
    get() = url.encodedPath
