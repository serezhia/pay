package com.yandex.fintechsdk.core.network.api.network

public interface DiehardNetworkApi : NetworkApi
