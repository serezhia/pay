package com.yandex.fintechsdk.core.network.api.exception

import kotlinx.serialization.json.JsonObject
import java.io.IOException

public sealed class NetworkException(message: String) : IOException(message) {

    public class BadCodeException(
        requestName: String,
        requestId: String,
        public val code: Int,
        public val body: JsonObject?,
        public val retryAttempt: Int = 0,
    ) : NetworkException("Server responded with code $code for requestName: $requestName, requestId: $requestId, retryAttempt: $retryAttempt")

    public class EmptyBodyException(
        requestName: String,
        requestId: String,
        public val retryAttempt: Int = 0,
    ) : NetworkException("Empty response body for requestName: $requestName, requestId: $requestId, retryAttempt: $retryAttempt")

    public class OkHttpCommonException(
        requestName: String,
        message: String?,
        public val retryAttempt: Int = 0,
    ) : NetworkException("Request $requestName could not be executed due to the exception in okHttp flow, message: $message, retryAttempt: $retryAttempt")
}
