package com.yandex.fintechsdk.core.network.api.request

import kotlinx.serialization.json.JsonObject

public abstract class Request(configure: (Configuration.() -> Unit)? = null) {

    public val configuration: Configuration = Configuration()

    init {
        configure?.let { prepare ->
            configuration.prepare()
        }
    }

    public abstract val requestName: String
    public abstract val requestPath: String
    public abstract val method: RestMethod
    public open val baseUrl: String? = null

    public open fun headers(): Map<String, String> = emptyMap()
    public open fun queries(): Map<String, String> = emptyMap()

    public open fun body(): JsonObject? {
        return when (method) {
            RestMethod.DELETE,
            RestMethod.GET -> null

            // For these methods body is required
            RestMethod.PATCH,
            RestMethod.POST,
            RestMethod.PUT -> JsonObject(content = emptyMap())
        }
    }

    public class Configuration {
        public var isAuthNeeded: Boolean = true
    }
}
