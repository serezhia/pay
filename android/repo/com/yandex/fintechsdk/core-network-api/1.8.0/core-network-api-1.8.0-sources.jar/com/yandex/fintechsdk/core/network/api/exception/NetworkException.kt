package com.yandex.fintechsdk.core.network.api.exception

import kotlinx.serialization.json.JsonObject
import java.io.IOException

public sealed class NetworkException(message: String) : IOException(message) {

    public class BadCodeException(
        requestName: String,
        requestId: String,
        public val code: Int,
        public val body: JsonObject?,
    ) : NetworkException("Server responded with code $code for requestName: $requestName, requestId: $requestId")

    public class EmptyBodyException(
        requestName: String,
        requestId: String,
    ) : NetworkException("Empty response body for requestName: $requestName, requestId: $requestId")

    public class OkHttpCommonException(
        requestName: String,
        message: String?,
    ) : NetworkException("Request $requestName could not be executed due to the exception in okHttp flow, message: $message")
}
