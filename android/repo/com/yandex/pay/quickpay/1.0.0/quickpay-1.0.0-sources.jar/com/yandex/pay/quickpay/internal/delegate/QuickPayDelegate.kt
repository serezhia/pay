package com.yandex.pay.quickpay.internal.delegate

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import com.yandex.fintechsdk.data.auth.api.AuthState
import com.yandex.fintechsdk.entities.region.Region
import com.yandex.pay.quickpay.api.QuickPayConfig
import com.yandex.pay.quickpay.api.QuickPaymentStateListener
import com.yandex.pay.quickpay.api.YandexQuickPay
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsErrorKeys
import com.yandex.pay.quickpay.internal.di.QuickPayComponentStore
import com.yandex.pay.quickpay.internal.lifecycle.AppLifecycleObserver
import com.yandex.pay.quickpay.internal.polling.QuickPaymentEvent
import com.yandex.pay.quickpay.internal.presentation.QuickPayBduiBottomSheet
import com.yandex.pay.quickpay.internal.widget.ActivePaymentMethodBadgeController
import com.yandex.pay.quickpay.internal.widget.WidgetController
import kotlinx.coroutines.launch

/**
 * Delegate for managing Quick Payment flow
 */
internal class QuickPayDelegate(
    private val application: Application,
    private val config: QuickPayConfig,
    private val stateListener: QuickPaymentStateListener,
) {

    var isActivePaymentMethodVisible: Boolean = false
        set(value) {
            field = value
            componentStore.component.quickPayWidgetRepository.isActivePaymentMethodVisible = value
        }

    val componentStore: QuickPayComponentStore = QuickPayComponentStore(
        config = config,
        context = application,
        region = Region.RU,
        stateListener = stateListener,
    ).also { store ->
        val component = store.component
        component.divKitAdapter.init(dependencies = component.divKitDependencies)
        component.bottomSheetHolder.setShowBottomSheet {
            showBottomSheetInternal()
        }
        component.bottomSheetHolder.setOnDismissCallback {
            component.paymentProcessManager.emitPendingResult()
        }
        component.widgetController.onBeforeLoad = {
            ensureBstForWidget()
            showPendingOrders()
            component.paymentProcessManager.resumePollingIfNeeded()
        }
        component.activePaymentMethodBadgeController.onBeforeLoad = {
            ensureBstForWidget()
        }
    }

    private val scope by lazy { componentStore.component.flowCoroutineScope }

    private val appLifecycleObserver = AppLifecycleObserver(
        paymentProcessManager = componentStore.component.paymentProcessManager,
    )

    init {
        subscribeToPaymentEvents()
        ProcessLifecycleOwner.get().lifecycle.addObserver(appLifecycleObserver)
    }

    private var currentBottomSheet: QuickPayBduiBottomSheet? = null

    fun closeBottomSheet() {
        currentBottomSheet?.close()
        currentBottomSheet = null
        val bottomSheetHolder = componentStore.component.bottomSheetHolder
        bottomSheetHolder.clear()
        bottomSheetHolder.clearExtras()
    }

    fun clear() {
        closeBottomSheet()
        componentStore.component.paymentProcessManager.stopPolling()
        ProcessLifecycleOwner.get().lifecycle.removeObserver(appLifecycleObserver)
    }

    fun getWidgetController(): WidgetController {
        return componentStore.component.widgetController
    }

    fun getActivePaymentMethodBadgeController(): ActivePaymentMethodBadgeController {
        return componentStore.component.activePaymentMethodBadgeController
    }

    /**
     * Start polling for active orders
     */
    fun startOrderPolling() {
        componentStore.component.paymentProcessManager.startActiveOrderPolling()
    }

    /**
     * Ensure BST is generated if needed before loading widget.
     * Called before widget load.
     */
    private suspend fun ensureBstForWidget() {
        val component = componentStore.component
        val activity = YandexQuickPay.activityRef?.get() ?: return

        runCatching {
            component.authorizationManager.ensureBstIfNeeded(
                activity = activity,
                withRedraw = true,
            )
        }.onFailure { error ->
            component.analyticsReporter.reportError(
                key = QuickPayAnalyticsErrorKeys.GENERATE_BST,
                throwable = error,
            )
        }
    }

    /**
     * Check for pending orders and show bottom sheet if any exist.
     * Called before widget load.
     */
    suspend fun showPendingOrders() {
        val component = componentStore.component
        val authState = component.authRepository.authState.value

        if (authState !is AuthState.Authorized) return

        try {
            val orders = component.ordersRepository.getAllOrders()
            if (orders.isNotEmpty()) {
                component.paymentProcessManager.showPendingOrder(orders.first())
            }
        } catch (exception: Exception) {
            // 401 or other error - ignore but report
            component.analyticsReporter.reportError(
                key = QuickPayAnalyticsErrorKeys.SHOW_PENDING_ORDERS,
                throwable = exception,
            )
        }
    }

    private fun subscribeToPaymentEvents() {
        scope.launch {
            componentStore.component.paymentProcessManager.events.collect { event ->
                handlePaymentEvent(event = event)
            }
        }
    }

    private fun handlePaymentEvent(event: QuickPaymentEvent) {
        val component = componentStore.component

        when (event) {
            is QuickPaymentEvent.SetPaymentInProgress -> {
                component.widgetController.setPaymentInProgress(inProgress = event.isInProgress)
            }

            is QuickPaymentEvent.ShowPaymentStatusScreen -> {
                component.bottomSheetHolder.showPaymentStatusScreen(
                    transactionId = event.transactionId,
                    paymentUrl = event.paymentUrl,
                )
            }

            is QuickPaymentEvent.PaymentFinished -> {
                stateListener.onPaymentResult(quickpayResult = event.result)
            }

            is QuickPaymentEvent.TokenExpired -> {
                stateListener.onSessionExpired()
            }

            is QuickPaymentEvent.PollingError -> {
                component.widgetController.setPaymentInProgress(inProgress = false)
            }

            is QuickPaymentEvent.WidgetRefresh -> {
                component.widgetController.triggerReload()
            }
        }
    }

    /**
     * Shows bottom sheet with BDUI content
     *
     * @param fragmentManager FragmentManager to show the bottom sheet
     * @param sessionId Payment session ID
     * @param orderId Order ID to display screens for
     */
    @Synchronized
    fun showBottomSheet() {
        closeBottomSheet()
        showBottomSheetInternal()
    }

    private fun showBottomSheetInternal() {
        val fragmentManager = YandexQuickPay.getFragmentManager() ?: return

        val component = componentStore.component
        val bottomSheetHolder = component.bottomSheetHolder

        val bottomSheet = QuickPayBduiBottomSheet.show(
            component = component,
            fragmentManager = fragmentManager,
            onDismiss = {
                currentBottomSheet = null
                bottomSheetHolder.clear()
                bottomSheetHolder.clearExtras()
                bottomSheetHolder.notifyDismissed()

                component.analyticsReporter.reportPaymentProcessScreenClosed()
            },
            theme = YandexQuickPay.theme,
        )

        currentBottomSheet = bottomSheet
        bottomSheetHolder.set(bottomSheet = bottomSheet)
    }
}
