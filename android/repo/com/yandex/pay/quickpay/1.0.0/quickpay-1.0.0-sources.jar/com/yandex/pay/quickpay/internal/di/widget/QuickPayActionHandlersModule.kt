package com.yandex.pay.quickpay.internal.di.widget

import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.core.divkit.api.action.DivActionsDelegate
import com.yandex.fintechsdk.core.divkit.api.di.DivkitCoroutineScope
import com.yandex.fintechsdk.core.divkit.impl.api.di.DivkitModule
import com.yandex.pay.quickpay.internal.widget.actions.DivActionsDelegateImpl
import dagger.Binds
import dagger.Module
import dagger.Provides
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

@Module(
    includes = [
        DivkitModule::class,
    ],
)
internal interface QuickPayActionHandlersModule {

    @Binds
    fun bindOpenBottomSheetActionsDelegate(delegate: DivActionsDelegateImpl): DivActionsDelegate

    companion object {
        @FlowScope
        @DivkitCoroutineScope
        @Provides
        fun provideDivkitCoroutineScope(): CoroutineScope {
            return CoroutineScope(SupervisorJob() + Dispatchers.Main)
        }
    }
}
