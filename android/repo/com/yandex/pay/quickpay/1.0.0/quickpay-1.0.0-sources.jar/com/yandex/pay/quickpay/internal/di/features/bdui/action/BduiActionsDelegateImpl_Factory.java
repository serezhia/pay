package com.yandex.pay.quickpay.internal.di.features.bdui.action;

import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiActionsDelegateImpl_Factory implements Factory<BduiActionsDelegateImpl> {
  private final Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider;

  private BduiActionsDelegateImpl_Factory(
      Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider) {
    this.bottomSheetHolderProvider = bottomSheetHolderProvider;
  }

  @Override
  public BduiActionsDelegateImpl get() {
    return newInstance(bottomSheetHolderProvider.get());
  }

  public static BduiActionsDelegateImpl_Factory create(
      Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider) {
    return new BduiActionsDelegateImpl_Factory(bottomSheetHolderProvider);
  }

  public static BduiActionsDelegateImpl newInstance(QuickPayBottomSheetHolder bottomSheetHolder) {
    return new BduiActionsDelegateImpl(bottomSheetHolder);
  }
}
