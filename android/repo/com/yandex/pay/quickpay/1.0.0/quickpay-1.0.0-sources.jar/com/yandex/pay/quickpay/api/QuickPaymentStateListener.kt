package com.yandex.pay.quickpay.api

/**
 * Listener for quick payment state changes
 */
public interface QuickPaymentStateListener {
    /**
     * Called when the payment enabled state changes
     *
     * @param isEnabled Current payment enabled state
     */
    public fun onPaymentEnabledStateChanged(isEnabled: IsPaymentEnabled)

    /**
     * Called when the payment session expires
     */
    public fun onSessionExpired()

    /**
     * Called when a payment operation completes
     *
     * @param quickpayResult Result of the payment operation
     */
    public fun onPaymentResult(quickpayResult: QuickPayResult)
}

