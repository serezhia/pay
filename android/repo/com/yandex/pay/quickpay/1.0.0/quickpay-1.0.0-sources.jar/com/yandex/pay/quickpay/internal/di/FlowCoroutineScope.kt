package com.yandex.pay.quickpay.internal.di

import javax.inject.Qualifier

@Qualifier
@Retention(AnnotationRetention.RUNTIME)
internal annotation class FlowCoroutineScope

