package com.yandex.pay.quickpay.internal.di.adapters.flex;

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.core.utils.api.adapter.AdapterFinder;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlexAdapterModule_Companion_ProvideFlexAdapterFactory implements Factory<FlexAdapter> {
  private final Provider<AdapterFinder> adapterFinderProvider;

  private FlexAdapterModule_Companion_ProvideFlexAdapterFactory(
      Provider<AdapterFinder> adapterFinderProvider) {
    this.adapterFinderProvider = adapterFinderProvider;
  }

  @Override
  @Nullable
  public FlexAdapter get() {
    return provideFlexAdapter(adapterFinderProvider.get());
  }

  public static FlexAdapterModule_Companion_ProvideFlexAdapterFactory create(
      Provider<AdapterFinder> adapterFinderProvider) {
    return new FlexAdapterModule_Companion_ProvideFlexAdapterFactory(adapterFinderProvider);
  }

  @Nullable
  public static FlexAdapter provideFlexAdapter(AdapterFinder adapterFinder) {
    return FlexAdapterModule.Companion.provideFlexAdapter(adapterFinder);
  }
}
