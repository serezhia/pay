package com.yandex.pay.quickpay.internal.di.adapters.divkit;

import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DivKitAdapterModule_ProvideDivKitAdapterFactory implements Factory<DivKitAdapter> {
  private final DivKitAdapterModule module;

  private DivKitAdapterModule_ProvideDivKitAdapterFactory(DivKitAdapterModule module) {
    this.module = module;
  }

  @Override
  public DivKitAdapter get() {
    return provideDivKitAdapter(module);
  }

  public static DivKitAdapterModule_ProvideDivKitAdapterFactory create(DivKitAdapterModule module) {
    return new DivKitAdapterModule_ProvideDivKitAdapterFactory(module);
  }

  public static DivKitAdapter provideDivKitAdapter(DivKitAdapterModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideDivKitAdapter());
  }
}
