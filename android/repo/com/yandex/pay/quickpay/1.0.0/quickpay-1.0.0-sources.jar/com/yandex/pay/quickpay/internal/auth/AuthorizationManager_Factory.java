package com.yandex.pay.quickpay.internal.auth;

import com.yandex.fintechsdk.data.auth.api.AuthRepository;
import com.yandex.fintechsdk.data.auth.api.dpop.DpopRepository;
import com.yandex.fitnechsdk.adapters.login.sdk.api.LoginAdapter;
import com.yandex.pay.quickpay.api.QuickPayConfig;
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter;
import com.yandex.pay.quickpay.internal.presentation.UserFeedbackPresenter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class AuthorizationManager_Factory implements Factory<AuthorizationManager> {
  private final Provider<QuickPayAnalyticsReporter> analyticsReporterProvider;

  private final Provider<AuthRepository> authRepositoryProvider;

  private final Provider<DpopRepository> dpopRepositoryProvider;

  private final Provider<LoginAdapter> loginAdapterProvider;

  private final Provider<UserFeedbackPresenter> userFeedbackPresenterProvider;

  private final Provider<QuickPayConfig> configProvider;

  private AuthorizationManager_Factory(
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider,
      Provider<AuthRepository> authRepositoryProvider,
      Provider<DpopRepository> dpopRepositoryProvider, Provider<LoginAdapter> loginAdapterProvider,
      Provider<UserFeedbackPresenter> userFeedbackPresenterProvider,
      Provider<QuickPayConfig> configProvider) {
    this.analyticsReporterProvider = analyticsReporterProvider;
    this.authRepositoryProvider = authRepositoryProvider;
    this.dpopRepositoryProvider = dpopRepositoryProvider;
    this.loginAdapterProvider = loginAdapterProvider;
    this.userFeedbackPresenterProvider = userFeedbackPresenterProvider;
    this.configProvider = configProvider;
  }

  @Override
  public AuthorizationManager get() {
    return newInstance(analyticsReporterProvider.get(), authRepositoryProvider.get(), dpopRepositoryProvider.get(), loginAdapterProvider.get(), userFeedbackPresenterProvider.get(), configProvider.get());
  }

  public static AuthorizationManager_Factory create(
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider,
      Provider<AuthRepository> authRepositoryProvider,
      Provider<DpopRepository> dpopRepositoryProvider, Provider<LoginAdapter> loginAdapterProvider,
      Provider<UserFeedbackPresenter> userFeedbackPresenterProvider,
      Provider<QuickPayConfig> configProvider) {
    return new AuthorizationManager_Factory(analyticsReporterProvider, authRepositoryProvider, dpopRepositoryProvider, loginAdapterProvider, userFeedbackPresenterProvider, configProvider);
  }

  public static AuthorizationManager newInstance(QuickPayAnalyticsReporter analyticsReporter,
      AuthRepository authRepository, DpopRepository dpopRepository, LoginAdapter loginAdapter,
      UserFeedbackPresenter userFeedbackPresenter, QuickPayConfig config) {
    return new AuthorizationManager(analyticsReporter, authRepository, dpopRepository, loginAdapter, userFeedbackPresenter, config);
  }
}
