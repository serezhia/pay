package com.yandex.pay.quickpay.api

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Result of a quick payment operation
 */
public sealed interface QuickPayResult : Parcelable {
    /**
     * Payment completed successfully
     */
    @Parcelize
    public data object Success : QuickPayResult

    /**
     * Payment failed
     */
    @Parcelize
    public data object Failure : QuickPayResult
}

