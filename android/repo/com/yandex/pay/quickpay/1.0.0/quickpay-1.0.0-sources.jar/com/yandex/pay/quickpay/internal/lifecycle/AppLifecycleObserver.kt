package com.yandex.pay.quickpay.internal.lifecycle

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.yandex.pay.quickpay.internal.polling.PaymentProcessManager

/**
 * Observer that handles app lifecycle events to manage payment polling.
 * Pauses polling when app goes to background and resumes when returning to foreground.
 */
internal class AppLifecycleObserver(
    private val paymentProcessManager: PaymentProcessManager,
) : DefaultLifecycleObserver {

    override fun onStart(owner: LifecycleOwner) {
        paymentProcessManager.resumePollingIfNeeded()
    }

    override fun onStop(owner: LifecycleOwner) {
        paymentProcessManager.pausePolling()
    }
}

