package com.yandex.pay.quickpay.internal.di.widget;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlinx.coroutines.CoroutineScope;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata("com.yandex.fintechsdk.core.divkit.api.di.DivkitCoroutineScope")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class QuickPayActionHandlersModule_Companion_ProvideDivkitCoroutineScopeFactory implements Factory<CoroutineScope> {
  @Override
  public CoroutineScope get() {
    return provideDivkitCoroutineScope();
  }

  public static QuickPayActionHandlersModule_Companion_ProvideDivkitCoroutineScopeFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static CoroutineScope provideDivkitCoroutineScope() {
    return Preconditions.checkNotNullFromProvides(QuickPayActionHandlersModule.Companion.provideDivkitCoroutineScope());
  }

  private static final class InstanceHolder {
    static final QuickPayActionHandlersModule_Companion_ProvideDivkitCoroutineScopeFactory INSTANCE = new QuickPayActionHandlersModule_Companion_ProvideDivkitCoroutineScopeFactory();
  }
}
