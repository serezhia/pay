package com.yandex.pay.quickpay.internal.di.features.bdui.theme

import android.content.Context
import com.yandex.fintechsdk.core.bdui.api.theme.BduiThemeProvider
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.utils.impl.api.context.isNightMode
import com.yandex.fintechsdk.entities.theme.Theme
import com.yandex.pay.quickpay.api.QuickPayThemeColorScheme
import com.yandex.pay.quickpay.api.YandexQuickPay
import javax.inject.Inject

internal class BduiThemeProviderImpl @Inject constructor(
    @ApplicationContext private val context: Context,
) : BduiThemeProvider {

    override fun getTheme(): Theme {
        return when (YandexQuickPay.theme) {
            QuickPayThemeColorScheme.LIGHT -> Theme.DAY
            QuickPayThemeColorScheme.DARK -> Theme.NIGHT
            QuickPayThemeColorScheme.SYSTEM -> {
                if (context.isNightMode()) Theme.NIGHT else Theme.DAY
            }
        }
    }
}

