package com.yandex.pay.quickpay.internal.di.features.bdui;

import com.yandex.fintechsdk.core.bdui.api.error.IsEngineErrorViewEnabled;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiFeatureModule_Companion_ProvideIsEngineErrorViewEnabledFactory implements Factory<IsEngineErrorViewEnabled> {
  @Override
  public IsEngineErrorViewEnabled get() {
    return provideIsEngineErrorViewEnabled();
  }

  public static BduiFeatureModule_Companion_ProvideIsEngineErrorViewEnabledFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static IsEngineErrorViewEnabled provideIsEngineErrorViewEnabled() {
    return Preconditions.checkNotNullFromProvides(BduiFeatureModule.Companion.provideIsEngineErrorViewEnabled());
  }

  private static final class InstanceHolder {
    static final BduiFeatureModule_Companion_ProvideIsEngineErrorViewEnabledFactory INSTANCE = new BduiFeatureModule_Companion_ProvideIsEngineErrorViewEnabledFactory();
  }
}
