package com.yandex.pay.quickpay.internal.polling

import com.yandex.pay.quickpay.api.QuickPayResult

internal sealed interface QuickPaymentEvent {

    data class SetPaymentInProgress(val isInProgress: Boolean) : QuickPaymentEvent

    data class ShowPaymentStatusScreen(
        val transactionId: String,
        val paymentUrl: String,
    ) : QuickPaymentEvent

    data class PaymentFinished(val result: QuickPayResult) : QuickPaymentEvent

    data object TokenExpired : QuickPaymentEvent

    data object PollingError : QuickPaymentEvent

    data object WidgetRefresh : QuickPaymentEvent
}

