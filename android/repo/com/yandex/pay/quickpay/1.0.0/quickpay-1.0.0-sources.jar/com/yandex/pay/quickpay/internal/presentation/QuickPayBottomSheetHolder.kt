package com.yandex.pay.quickpay.internal.presentation

import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.pay.quickpay.api.YandexQuickPay
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiDocumentQueryHolder
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiExtraHeadersProviderImpl
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiExtraQueriesProviderImpl
import java.lang.ref.WeakReference
import javax.inject.Inject

@FlowScope
internal class QuickPayBottomSheetHolder @Inject constructor(
    private val documentQueryHolder: BduiDocumentQueryHolder,
    private val headersProvider: BduiExtraHeadersProviderImpl,
    private val queriesProvider: BduiExtraQueriesProviderImpl,
) {

    private var bottomSheetRef: WeakReference<QuickPayBduiBottomSheet>? = null
    private var showBottomSheet: (() -> Unit)? = null
    private var onDismissCallback: (() -> Unit)? = null

    fun clear() {
        bottomSheetRef = null
    }

    fun close() {
        bottomSheetRef?.get()?.close()
    }

    fun isShowing(): Boolean = bottomSheetRef?.get()?.dialog?.isShowing == true

    fun set(bottomSheet: QuickPayBduiBottomSheet) {
        bottomSheetRef = WeakReference(bottomSheet)
    }

    fun setShowBottomSheet(callback: () -> Unit) {
        showBottomSheet = callback
    }

    fun setOnDismissCallback(callback: () -> Unit) {
        onDismissCallback = callback
    }

    fun notifyDismissed() {
        onDismissCallback?.invoke()
    }

    fun openNewBottomSheet(
        endpoint: String,
        query: Map<String, String>,
        headers: Map<String, String>,
    ) {
        if (YandexQuickPay.getFragmentManager() == null) return

        queriesProvider.addExtraQueries(queries = query)
        headersProvider.addExtraHeaders(headers = headers)
        documentQueryHolder.set(query = BduiDocumentQuery(path = endpoint))

        close()

        showBottomSheet?.invoke()
    }

    fun clearExtras() {
        queriesProvider.clearExtraQueries()
        headersProvider.clearExtraHeaders()
        documentQueryHolder.clear()
    }

    fun showPaymentStatusScreen(
        transactionId: String,
        paymentUrl: String,
    ) {
        if (isShowing()) return

        if (YandexQuickPay.getFragmentManager() == null) return

        queriesProvider.addExtraQueries(
            mapOf(
                QUERY_TRANSACTION_ID to transactionId,
                QUERY_PAYMENT_URL to paymentUrl,
            ),
        )

        showBottomSheet?.invoke()
    }

    private companion object {
        private const val QUERY_TRANSACTION_ID = "transaction_id"
        private const val QUERY_PAYMENT_URL = "payment_url"
    }
}

