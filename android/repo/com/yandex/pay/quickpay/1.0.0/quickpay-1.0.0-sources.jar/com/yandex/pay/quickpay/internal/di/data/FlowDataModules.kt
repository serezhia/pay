package com.yandex.pay.quickpay.internal.di.data

import com.yandex.fintechsdk.data.auth.impl.api.di.DataAuthModule
import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository
import com.yandex.fintechsdk.data.quickpay.api.MerchantIdProvider
import com.yandex.fintechsdk.data.quickpay.impl.api.di.DataQuickPayModule
import com.yandex.pay.quickpay.internal.data.MerchantIdProviderImpl
import com.yandex.pay.quickpay.internal.di.data.stubs.CardBindingRepositoryStub
import dagger.Binds
import dagger.Module
import dagger.Provides

@Module(
    includes = [
        DataAuthModule::class,
        DataQuickPayModule::class,
        FlowDataModules.Bindings::class,
    ],
)
internal object FlowDataModules {
    @Provides
    fun provideCardBindingRepository(): CardBindingRepository {
        return CardBindingRepositoryStub()
    }

    @Module
    internal interface Bindings {
        @Binds
        fun bindMerchantIdProvider(impl: MerchantIdProviderImpl): MerchantIdProvider
    }
}
