package com.yandex.pay.quickpay.internal.widget

import android.view.View
import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter
import com.yandex.fintechsdk.adapters.divkit.sdk.api.loader.DivViewJsonLoader
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

internal abstract class BaseWidgetController(
    private val analyticsReporter: QuickPayAnalyticsReporter,
    private val analyticsSource: String,
    private val divKitAdapter: DivKitAdapter,
    private val jsonLoader: DivViewJsonLoader,
) {

    private val _reloadTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val reloadTrigger: SharedFlow<Unit> = _reloadTrigger.asSharedFlow()

    private val _hideTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val hideTrigger: SharedFlow<Unit> = _hideTrigger.asSharedFlow()

    var onBeforeLoad: (suspend () -> Unit)? = null

    fun hideWidget() {
        _hideTrigger.tryEmit(Unit)
    }

    fun triggerReload() {
        _reloadTrigger.tryEmit(Unit)
    }

    suspend fun loadWidget(): Result<View> {
        onBeforeLoad?.invoke()
        analyticsReporter.reportMainScreenOpened(source = analyticsSource)
        return divKitAdapter.loadView(jsonLoader = jsonLoader)
    }
}
