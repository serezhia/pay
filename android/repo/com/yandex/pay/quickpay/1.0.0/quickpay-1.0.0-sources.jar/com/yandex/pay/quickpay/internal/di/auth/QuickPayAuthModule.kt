package com.yandex.pay.quickpay.internal.di.auth

import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.data.auth.api.AuthOptionsProvider
import dagger.Binds
import dagger.Module

@Module
internal interface QuickPayAuthModule {
    @Binds
    @FlowScope
    fun bindAuthOptionsProvider(impl: QuickPayAuthOptionsProviderImpl): AuthOptionsProvider
}

