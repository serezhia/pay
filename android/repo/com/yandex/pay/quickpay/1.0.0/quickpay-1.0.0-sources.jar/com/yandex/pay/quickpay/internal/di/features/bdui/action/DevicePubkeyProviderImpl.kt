package com.yandex.pay.quickpay.internal.di.features.bdui.action

import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DevicePubkeyProvider
import javax.inject.Inject

internal class DevicePubkeyProviderImpl @Inject constructor() : DevicePubkeyProvider
