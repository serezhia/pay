package com.yandex.pay.quickpay.internal.di.core.analytics.errorbooster;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ErrorBoosterProjectNameProviderImpl_Factory implements Factory<ErrorBoosterProjectNameProviderImpl> {
  @Override
  public ErrorBoosterProjectNameProviderImpl get() {
    return newInstance();
  }

  public static ErrorBoosterProjectNameProviderImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ErrorBoosterProjectNameProviderImpl newInstance() {
    return new ErrorBoosterProjectNameProviderImpl();
  }

  private static final class InstanceHolder {
    static final ErrorBoosterProjectNameProviderImpl_Factory INSTANCE = new ErrorBoosterProjectNameProviderImpl_Factory();
  }
}
