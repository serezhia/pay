package com.yandex.pay.quickpay.internal.di.features.bdui.data;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiExtraQueriesProviderImpl_Factory implements Factory<BduiExtraQueriesProviderImpl> {
  @Override
  public BduiExtraQueriesProviderImpl get() {
    return newInstance();
  }

  public static BduiExtraQueriesProviderImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static BduiExtraQueriesProviderImpl newInstance() {
    return new BduiExtraQueriesProviderImpl();
  }

  private static final class InstanceHolder {
    static final BduiExtraQueriesProviderImpl_Factory INSTANCE = new BduiExtraQueriesProviderImpl_Factory();
  }
}
