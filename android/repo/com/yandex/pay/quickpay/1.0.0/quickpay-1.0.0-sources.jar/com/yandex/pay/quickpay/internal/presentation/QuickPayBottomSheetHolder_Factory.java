package com.yandex.pay.quickpay.internal.presentation;

import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiDocumentQueryHolder;
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiExtraHeadersProviderImpl;
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiExtraQueriesProviderImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class QuickPayBottomSheetHolder_Factory implements Factory<QuickPayBottomSheetHolder> {
  private final Provider<BduiDocumentQueryHolder> documentQueryHolderProvider;

  private final Provider<BduiExtraHeadersProviderImpl> headersProvider;

  private final Provider<BduiExtraQueriesProviderImpl> queriesProvider;

  private QuickPayBottomSheetHolder_Factory(
      Provider<BduiDocumentQueryHolder> documentQueryHolderProvider,
      Provider<BduiExtraHeadersProviderImpl> headersProvider,
      Provider<BduiExtraQueriesProviderImpl> queriesProvider) {
    this.documentQueryHolderProvider = documentQueryHolderProvider;
    this.headersProvider = headersProvider;
    this.queriesProvider = queriesProvider;
  }

  @Override
  public QuickPayBottomSheetHolder get() {
    return newInstance(documentQueryHolderProvider.get(), headersProvider.get(), queriesProvider.get());
  }

  public static QuickPayBottomSheetHolder_Factory create(
      Provider<BduiDocumentQueryHolder> documentQueryHolderProvider,
      Provider<BduiExtraHeadersProviderImpl> headersProvider,
      Provider<BduiExtraQueriesProviderImpl> queriesProvider) {
    return new QuickPayBottomSheetHolder_Factory(documentQueryHolderProvider, headersProvider, queriesProvider);
  }

  public static QuickPayBottomSheetHolder newInstance(BduiDocumentQueryHolder documentQueryHolder,
      BduiExtraHeadersProviderImpl headersProvider, BduiExtraQueriesProviderImpl queriesProvider) {
    return new QuickPayBottomSheetHolder(documentQueryHolder, headersProvider, queriesProvider);
  }
}
