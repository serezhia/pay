package com.yandex.pay.quickpay.internal.data;

import com.yandex.pay.quickpay.api.QuickPayConfig;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class MerchantIdProviderImpl_Factory implements Factory<MerchantIdProviderImpl> {
  private final Provider<QuickPayConfig> configProvider;

  private MerchantIdProviderImpl_Factory(Provider<QuickPayConfig> configProvider) {
    this.configProvider = configProvider;
  }

  @Override
  public MerchantIdProviderImpl get() {
    return newInstance(configProvider.get());
  }

  public static MerchantIdProviderImpl_Factory create(Provider<QuickPayConfig> configProvider) {
    return new MerchantIdProviderImpl_Factory(configProvider);
  }

  public static MerchantIdProviderImpl newInstance(QuickPayConfig config) {
    return new MerchantIdProviderImpl(config);
  }
}
