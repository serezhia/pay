package com.yandex.pay.quickpay.internal.di.core.analytics.event;

import android.content.Context;
import com.yandex.fintechsdk.core.utils.api.session.SessionId;
import com.yandex.fintechsdk.data.auth.api.AuthRepository;
import com.yandex.fintechsdk.entities.region.Region;
import com.yandex.pay.quickpay.api.QuickPayConfig;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BaseEventParamsProviderImpl_Factory implements Factory<BaseEventParamsProviderImpl> {
  private final Provider<Context> contextProvider;

  private final Provider<AuthRepository> authRepositoryProvider;

  private final Provider<QuickPayConfig> configProvider;

  private final Provider<Region> regionProvider;

  private final Provider<SessionId> sessionIdProvider;

  private BaseEventParamsProviderImpl_Factory(Provider<Context> contextProvider,
      Provider<AuthRepository> authRepositoryProvider, Provider<QuickPayConfig> configProvider,
      Provider<Region> regionProvider, Provider<SessionId> sessionIdProvider) {
    this.contextProvider = contextProvider;
    this.authRepositoryProvider = authRepositoryProvider;
    this.configProvider = configProvider;
    this.regionProvider = regionProvider;
    this.sessionIdProvider = sessionIdProvider;
  }

  @Override
  public BaseEventParamsProviderImpl get() {
    return newInstance(contextProvider.get(), authRepositoryProvider.get(), configProvider.get(), regionProvider.get(), sessionIdProvider.get());
  }

  public static BaseEventParamsProviderImpl_Factory create(Provider<Context> contextProvider,
      Provider<AuthRepository> authRepositoryProvider, Provider<QuickPayConfig> configProvider,
      Provider<Region> regionProvider, Provider<SessionId> sessionIdProvider) {
    return new BaseEventParamsProviderImpl_Factory(contextProvider, authRepositoryProvider, configProvider, regionProvider, sessionIdProvider);
  }

  public static BaseEventParamsProviderImpl newInstance(Context context,
      AuthRepository authRepository, QuickPayConfig config, Region region, SessionId sessionId) {
    return new BaseEventParamsProviderImpl(context, authRepository, config, region, sessionId);
  }
}
