package com.yandex.pay.quickpay.internal.di.core.navigation

import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.core.navigation.api.Router
import com.yandex.fintechsdk.core.navigation.impl.api.router.RouterImpl
import dagger.Binds
import dagger.Module
import dagger.Provides

@Module
internal interface CoreNavigationModule {

    @Binds
    fun bindRouter(impl: RouterImpl): Router

    companion object {
        @FlowScope
        @Provides
        fun provideRouterImpl(): RouterImpl = RouterImpl()
    }
}

