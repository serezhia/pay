package com.yandex.pay.quickpay.internal.di.core.analytics.appmetrica

import com.yandex.fintechsdk.core.analytics.impl.external.api.appmetrica.AppMetricaApiKeyProvider
import com.yandex.pay.quickpay.BuildConfig
import javax.inject.Inject

internal class AppMetricaApiKeyProviderImpl @Inject constructor() : AppMetricaApiKeyProvider {

    override fun getApiKey(): String {
        return if (BuildConfig.DEBUG) {
            API_KEY_DEBUG
        } else {
            API_KEY_RELEASE
        }
    }

    private companion object {
        const val API_KEY_DEBUG = "70a2d59f-2a96-4d65-a0e3-4dd82737b3f6"
        const val API_KEY_RELEASE = "281bdee0-f9c2-40cb-9863-888a83534f91"
    }
}

