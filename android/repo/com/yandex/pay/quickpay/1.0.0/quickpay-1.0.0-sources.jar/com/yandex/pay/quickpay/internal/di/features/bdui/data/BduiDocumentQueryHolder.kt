package com.yandex.pay.quickpay.internal.di.features.bdui.data

import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import javax.inject.Inject

@FlowScope
internal class BduiDocumentQueryHolder @Inject constructor() {

    private var customQuery: BduiDocumentQuery? = null

    fun set(query: BduiDocumentQuery) {
        customQuery = query
    }

    fun get(): BduiDocumentQuery? = customQuery

    fun clear() {
        customQuery = null
    }
}

