package com.yandex.pay.quickpay.internal.di.core.analytics

import com.yandex.fintechsdk.core.analytics.api.event.BaseEventParamsProvider
import com.yandex.fintechsdk.core.analytics.impl.external.api.appmetrica.AppMetricaApiKeyProvider
import com.yandex.fintechsdk.core.analytics.impl.external.api.di.AnalyticsExternalModule
import com.yandex.fintechsdk.core.analytics.impl.external.api.errorbooster.ErrorBoosterProjectNameProvider
import com.yandex.fintechsdk.core.analytics.impl.external.api.rum.RumConfigurationProvider
import com.yandex.pay.quickpay.internal.di.core.analytics.appmetrica.AppMetricaApiKeyProviderImpl
import com.yandex.pay.quickpay.internal.di.core.analytics.errorbooster.ErrorBoosterProjectNameProviderImpl
import com.yandex.pay.quickpay.internal.di.core.analytics.event.BaseEventParamsProviderImpl
import com.yandex.pay.quickpay.internal.di.core.analytics.rum.RumConfigurationProviderImpl
import dagger.Binds
import dagger.Module

@Module(
    includes = [
        AnalyticsExternalModule::class,
    ]
)
internal interface CoreAnalyticsModule {

    @Binds
    fun bindAppMetricaApiKeyProvider(impl: AppMetricaApiKeyProviderImpl): AppMetricaApiKeyProvider

    @Binds
    fun bindBaseEventParamsProvider(impl: BaseEventParamsProviderImpl): BaseEventParamsProvider

    @Binds
    fun bindErrorBoosterProjectNameProvider(impl: ErrorBoosterProjectNameProviderImpl): ErrorBoosterProjectNameProvider

    @Binds
    fun bindRumConfigurationProvider(impl: RumConfigurationProviderImpl): RumConfigurationProvider
}
