package com.yandex.pay.quickpay.internal.di.core.network;

import com.yandex.fintechsdk.entities.environment.DefaultEnvironment;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CoreNetworkModule_Companion_ProvideEnvironmentFactory implements Factory<DefaultEnvironment> {
  @Override
  public DefaultEnvironment get() {
    return provideEnvironment();
  }

  public static CoreNetworkModule_Companion_ProvideEnvironmentFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DefaultEnvironment provideEnvironment() {
    return Preconditions.checkNotNullFromProvides(CoreNetworkModule.Companion.provideEnvironment());
  }

  private static final class InstanceHolder {
    static final CoreNetworkModule_Companion_ProvideEnvironmentFactory INSTANCE = new CoreNetworkModule_Companion_ProvideEnvironmentFactory();
  }
}
