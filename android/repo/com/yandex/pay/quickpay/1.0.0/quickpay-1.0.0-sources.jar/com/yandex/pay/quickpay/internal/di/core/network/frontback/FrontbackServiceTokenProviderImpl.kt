package com.yandex.pay.quickpay.internal.di.core.network.frontback

import com.yandex.fintechsdk.core.network.impl.api.frontback.FrontbackServiceTokenProvider
import com.yandex.fintechsdk.entities.environment.PayEnvironment
import javax.inject.Inject

internal class FrontbackServiceTokenProviderImpl @Inject constructor() : FrontbackServiceTokenProvider {

    override fun getServiceToken(environment: PayEnvironment): String {
        return when (environment) {
            PayEnvironment.TESTING -> SERVICE_TOKEN_DEV
            PayEnvironment.PRODUCTION, PayEnvironment.SANDBOX -> SERVICE_TOKEN_PROD
        }
    }

    private companion object {
        private const val SERVICE_TOKEN_DEV = "payment_sdk_19d9962ddd08e7d52a2668cbcd5f7b7e"
        private const val SERVICE_TOKEN_PROD = "yandex_pay_plus_backend_f8c528b768e7421ee0e3258995201aaa"
    }
}
