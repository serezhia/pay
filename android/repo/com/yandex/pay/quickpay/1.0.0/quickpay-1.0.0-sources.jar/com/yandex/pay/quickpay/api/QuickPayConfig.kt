package com.yandex.pay.quickpay.api

/**
 * Configuration for Yandex Quick Payment SDK
 *
 * @param merchantId Unique identifier for the merchant
 * @param environment Environment for the SDK (default is SANDBOX)
 */
public class QuickPayConfig(
    public val merchantId: String,
    public val environment: QuickPayEnvironment = QuickPayEnvironment.SANDBOX,
)

