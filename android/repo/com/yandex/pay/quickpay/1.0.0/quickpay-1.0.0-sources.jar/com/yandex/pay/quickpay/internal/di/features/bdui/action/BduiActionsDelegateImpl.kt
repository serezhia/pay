package com.yandex.pay.quickpay.internal.di.features.bdui.action

import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate
import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder
import javax.inject.Inject

internal class BduiActionsDelegateImpl @Inject constructor(
    private val bottomSheetHolder: QuickPayBottomSheetHolder,
) : BduiActionsDelegate() {

    override fun finishFlow(
        status: String,
        params: Map<String, String>?,
    ) {
        bottomSheetHolder.close()
    }
}

