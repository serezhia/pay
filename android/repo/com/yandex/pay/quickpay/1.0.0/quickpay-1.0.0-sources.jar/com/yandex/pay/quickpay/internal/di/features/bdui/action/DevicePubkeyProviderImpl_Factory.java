package com.yandex.pay.quickpay.internal.di.features.bdui.action;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DevicePubkeyProviderImpl_Factory implements Factory<DevicePubkeyProviderImpl> {
  @Override
  public DevicePubkeyProviderImpl get() {
    return newInstance();
  }

  public static DevicePubkeyProviderImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DevicePubkeyProviderImpl newInstance() {
    return new DevicePubkeyProviderImpl();
  }

  private static final class InstanceHolder {
    static final DevicePubkeyProviderImpl_Factory INSTANCE = new DevicePubkeyProviderImpl_Factory();
  }
}
