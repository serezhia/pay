package com.yandex.pay.quickpay.internal.widget

import android.view.View
import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

@FlowScope
internal class WidgetController @Inject constructor(
    private val divKitAdapter: DivKitAdapter,
    private val paymentMethodsWidgetJsonLoader: PaymentMethodsWidgetJsonLoader,
    private val analyticsReporter: QuickPayAnalyticsReporter,
) {

    private val _reloadTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val reloadTrigger: SharedFlow<Unit> = _reloadTrigger.asSharedFlow()

    private val _hideTrigger = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val hideTrigger: SharedFlow<Unit> = _hideTrigger.asSharedFlow()

    /**
     * Callback called before widget load.
     * Used to check for pending orders.
     */
    var onBeforeLoad: (suspend () -> Unit)? = null

    fun setPaymentInProgress(inProgress: Boolean) {
        divKitAdapter.setVariable(VARIABLE_IS_PAYMENT_PROCESS, inProgress)
    }

    suspend fun loadWidget(): Result<View> {
        onBeforeLoad?.invoke()

        analyticsReporter.reportMainScreenOpened(source = SOURCE_MAIN_SCREEN)

        return divKitAdapter.loadView(jsonLoader = paymentMethodsWidgetJsonLoader)
    }

    fun triggerReload() {
        _reloadTrigger.tryEmit(Unit)
    }

    fun hideWidget() {
        _hideTrigger.tryEmit(Unit)
    }

    private companion object {
        private const val VARIABLE_IS_PAYMENT_PROCESS = "isPaymentProcess"
        private const val SOURCE_MAIN_SCREEN = "main_screen"
    }
}
