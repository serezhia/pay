package com.yandex.pay.quickpay.internal.widget

import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter
import javax.inject.Inject

@FlowScope
internal class WidgetController @Inject constructor(
    analyticsReporter: QuickPayAnalyticsReporter,
    private val divKitAdapter: DivKitAdapter,
    paymentMethodsWidgetJsonLoader: PaymentMethodsWidgetJsonLoader,
) : BaseWidgetController(
    analyticsReporter = analyticsReporter,
    analyticsSource = SOURCE_MAIN_SCREEN,
    divKitAdapter = divKitAdapter,
    jsonLoader = paymentMethodsWidgetJsonLoader,
) {

    fun setPaymentInProgress(inProgress: Boolean) {
        divKitAdapter.setVariable(VARIABLE_IS_PAYMENT_PROCESS, inProgress)
    }

    private companion object {
        private const val VARIABLE_IS_PAYMENT_PROCESS = "isPaymentProcess"
        private const val SOURCE_MAIN_SCREEN = "main_screen"
    }
}
