package com.yandex.pay.quickpay.internal.presentation;

import android.content.Context;
import com.yandex.fintechsdk.core.security.api.biometric.AuthenticationAvailabilityChecker;
import com.yandex.pay.quickpay.internal.widget.WidgetController;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UserFeedbackPresenter_Factory implements Factory<UserFeedbackPresenter> {
  private final Provider<Context> contextProvider;

  private final Provider<AuthenticationAvailabilityChecker> authenticationAvailabilityCheckerProvider;

  private final Provider<WidgetController> widgetControllerProvider;

  private UserFeedbackPresenter_Factory(Provider<Context> contextProvider,
      Provider<AuthenticationAvailabilityChecker> authenticationAvailabilityCheckerProvider,
      Provider<WidgetController> widgetControllerProvider) {
    this.contextProvider = contextProvider;
    this.authenticationAvailabilityCheckerProvider = authenticationAvailabilityCheckerProvider;
    this.widgetControllerProvider = widgetControllerProvider;
  }

  @Override
  public UserFeedbackPresenter get() {
    return newInstance(contextProvider.get(), authenticationAvailabilityCheckerProvider.get(), widgetControllerProvider.get());
  }

  public static UserFeedbackPresenter_Factory create(Provider<Context> contextProvider,
      Provider<AuthenticationAvailabilityChecker> authenticationAvailabilityCheckerProvider,
      Provider<WidgetController> widgetControllerProvider) {
    return new UserFeedbackPresenter_Factory(contextProvider, authenticationAvailabilityCheckerProvider, widgetControllerProvider);
  }

  public static UserFeedbackPresenter newInstance(Context context,
      AuthenticationAvailabilityChecker authenticationAvailabilityChecker,
      WidgetController widgetController) {
    return new UserFeedbackPresenter(context, authenticationAvailabilityChecker, widgetController);
  }
}
