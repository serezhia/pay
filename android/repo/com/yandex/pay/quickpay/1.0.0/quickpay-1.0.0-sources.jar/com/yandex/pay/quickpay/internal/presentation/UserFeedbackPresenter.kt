package com.yandex.pay.quickpay.internal.presentation

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.core.security.api.biometric.AuthenticationAvailabilityChecker
import com.yandex.fintechsdk.core.security.api.biometric.AuthenticationStatus
import com.yandex.fintechsdk.resources.api.ResStrings
import com.yandex.pay.quickpay.internal.widget.WidgetController
import javax.inject.Inject

/**
 * Handles user feedback for various error conditions.
 * Shows Toast messages and controls widget visibility.
 */
@FlowScope
internal class UserFeedbackPresenter @Inject constructor(
    @ApplicationContext private val context: Context,
    private val authenticationAvailabilityChecker: AuthenticationAvailabilityChecker,
    private val widgetController: WidgetController,
) {

    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * Checks authentication availability (biometric OR device credential) and shows appropriate error message to user.
     *
     * - NoHardware + no device credential: hides the widget (device cannot use any authentication)
     * - NotEnrolled: shows Toast asking user to set up biometrics or device lock in settings
     *
     * @return AuthenticationStatus indicating the authentication status
     */
    fun checkBiometricAndShowErrorIfNeeded(): AuthenticationStatus {
        // Check availability of any authentication method (biometric OR device credential)
        return when (val status = authenticationAvailabilityChecker.checkAuthenticationAvailability()) {
            AuthenticationStatus.NoHardware -> {
                hideWidget()
                status
            }
            AuthenticationStatus.NotEnrolled -> {
                showToast(ResStrings.finsdk_setup_biometry_in_settings)
                status
            }
            AuthenticationStatus.Unavailable,
            AuthenticationStatus.Available -> status
        }
    }

    /**
     * Shows a toast indicating that re-authorization is required.
     * Called when 409 Conflict occurs during token binding.
     */
    fun showReauthorizationRequired() {
        showToast(ResStrings.finsdk_reauthorization_required)
    }

    private fun showToast(message: Int) {
        mainHandler.post {
            Toast.makeText(
                context,
                message,
                Toast.LENGTH_LONG,
            ).show()
        }
    }

    private fun hideWidget() {
        widgetController.hideWidget()
    }
}

