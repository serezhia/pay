package com.yandex.pay.quickpay.internal.di.core.analytics.rum;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RumConfigurationProviderImpl_Factory implements Factory<RumConfigurationProviderImpl> {
  @Override
  public RumConfigurationProviderImpl get() {
    return newInstance();
  }

  public static RumConfigurationProviderImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static RumConfigurationProviderImpl newInstance() {
    return new RumConfigurationProviderImpl();
  }

  private static final class InstanceHolder {
    static final RumConfigurationProviderImpl_Factory INSTANCE = new RumConfigurationProviderImpl_Factory();
  }
}
