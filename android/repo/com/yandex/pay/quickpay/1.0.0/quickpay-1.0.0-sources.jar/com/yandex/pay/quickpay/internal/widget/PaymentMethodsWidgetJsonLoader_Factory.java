package com.yandex.pay.quickpay.internal.widget;

import com.yandex.fintechsdk.data.quickpay.api.widget.QuickPayWidgetRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class PaymentMethodsWidgetJsonLoader_Factory implements Factory<PaymentMethodsWidgetJsonLoader> {
  private final Provider<QuickPayWidgetRepository> quickPayWidgetRepositoryProvider;

  private PaymentMethodsWidgetJsonLoader_Factory(
      Provider<QuickPayWidgetRepository> quickPayWidgetRepositoryProvider) {
    this.quickPayWidgetRepositoryProvider = quickPayWidgetRepositoryProvider;
  }

  @Override
  public PaymentMethodsWidgetJsonLoader get() {
    return newInstance(quickPayWidgetRepositoryProvider.get());
  }

  public static PaymentMethodsWidgetJsonLoader_Factory create(
      Provider<QuickPayWidgetRepository> quickPayWidgetRepositoryProvider) {
    return new PaymentMethodsWidgetJsonLoader_Factory(quickPayWidgetRepositoryProvider);
  }

  public static PaymentMethodsWidgetJsonLoader newInstance(
      QuickPayWidgetRepository quickPayWidgetRepository) {
    return new PaymentMethodsWidgetJsonLoader(quickPayWidgetRepository);
  }
}
