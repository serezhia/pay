package com.yandex.pay.quickpay.api

/**
 * Defines a color style of the theme
 */
public enum class QuickPayThemeColorScheme {
    /**
     * Theme adapt by system configuration
     */
    SYSTEM,

    /**
     * Light theme for screens
     */
    LIGHT,

    /**
     * Dark theme for screens
     */
    DARK,
}

