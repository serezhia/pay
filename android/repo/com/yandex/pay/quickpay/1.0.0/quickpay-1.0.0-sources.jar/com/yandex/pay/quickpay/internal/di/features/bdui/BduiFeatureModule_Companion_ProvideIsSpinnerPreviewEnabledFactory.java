package com.yandex.pay.quickpay.internal.di.features.bdui;

import com.yandex.fintechsdk.core.bdui.api.spinner.IsSpinnerPreviewEnabled;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiFeatureModule_Companion_ProvideIsSpinnerPreviewEnabledFactory implements Factory<IsSpinnerPreviewEnabled> {
  @Override
  public IsSpinnerPreviewEnabled get() {
    return provideIsSpinnerPreviewEnabled();
  }

  public static BduiFeatureModule_Companion_ProvideIsSpinnerPreviewEnabledFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static IsSpinnerPreviewEnabled provideIsSpinnerPreviewEnabled() {
    return Preconditions.checkNotNullFromProvides(BduiFeatureModule.Companion.provideIsSpinnerPreviewEnabled());
  }

  private static final class InstanceHolder {
    static final BduiFeatureModule_Companion_ProvideIsSpinnerPreviewEnabledFactory INSTANCE = new BduiFeatureModule_Companion_ProvideIsSpinnerPreviewEnabledFactory();
  }
}
