package com.yandex.pay.quickpay.internal.widget;

import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter;
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ActivePaymentMethodBadgeController_Factory implements Factory<ActivePaymentMethodBadgeController> {
  private final Provider<ActivePaymentMethodBadgeJsonLoader> activePaymentMethodBadgeJsonLoaderProvider;

  private final Provider<QuickPayAnalyticsReporter> analyticsReporterProvider;

  private final Provider<DivKitAdapter> divKitAdapterProvider;

  private ActivePaymentMethodBadgeController_Factory(
      Provider<ActivePaymentMethodBadgeJsonLoader> activePaymentMethodBadgeJsonLoaderProvider,
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider,
      Provider<DivKitAdapter> divKitAdapterProvider) {
    this.activePaymentMethodBadgeJsonLoaderProvider = activePaymentMethodBadgeJsonLoaderProvider;
    this.analyticsReporterProvider = analyticsReporterProvider;
    this.divKitAdapterProvider = divKitAdapterProvider;
  }

  @Override
  public ActivePaymentMethodBadgeController get() {
    return newInstance(activePaymentMethodBadgeJsonLoaderProvider.get(), analyticsReporterProvider.get(), divKitAdapterProvider.get());
  }

  public static ActivePaymentMethodBadgeController_Factory create(
      Provider<ActivePaymentMethodBadgeJsonLoader> activePaymentMethodBadgeJsonLoaderProvider,
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider,
      Provider<DivKitAdapter> divKitAdapterProvider) {
    return new ActivePaymentMethodBadgeController_Factory(activePaymentMethodBadgeJsonLoaderProvider, analyticsReporterProvider, divKitAdapterProvider);
  }

  public static ActivePaymentMethodBadgeController newInstance(
      ActivePaymentMethodBadgeJsonLoader activePaymentMethodBadgeJsonLoader,
      QuickPayAnalyticsReporter analyticsReporter, DivKitAdapter divKitAdapter) {
    return new ActivePaymentMethodBadgeController(activePaymentMethodBadgeJsonLoader, analyticsReporter, divKitAdapter);
  }
}
