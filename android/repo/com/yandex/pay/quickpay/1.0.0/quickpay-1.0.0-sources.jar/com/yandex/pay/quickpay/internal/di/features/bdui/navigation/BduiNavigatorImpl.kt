package com.yandex.pay.quickpay.internal.di.features.bdui.navigation

import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery
import com.yandex.fintechsdk.core.navigation.api.FintechNavOptions
import com.yandex.fintechsdk.core.navigation.api.Router
import com.yandex.fintechsdk.features.bdui.api.BduiFeature
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.BduiNavigator
import com.yandex.fintechsdk.features.error.api.ErrorFeature
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsErrorKeys
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter
import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder
import javax.inject.Inject

internal class BduiNavigatorImpl @Inject constructor(
    private val router: Router,
    private val bottomSheetHolder: QuickPayBottomSheetHolder,
    private val analyticsReporter: QuickPayAnalyticsReporter,
) : BduiNavigator {

    override fun back() {
        bottomSheetHolder.close()
    }

    override fun onError(
        query: BduiDocumentQuery,
        throwable: Throwable,
        responseCode: Int?,
    ) {
        analyticsReporter.reportError(
            key = QuickPayAnalyticsErrorKeys.BDUI_LOAD,
            throwable = throwable,
        )

        router.toScreen(
            route = ErrorFeature.GRAPH_ROUTE,
            navOptions = FintechNavOptions(
                popUpToRoute = BduiFeature.GRAPH_ROUTE,
                popUpToInclusive = true,
            ),
        )
    }
}
