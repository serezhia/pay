package com.yandex.pay.quickpay.internal.di;

import android.content.Context;
import android.content.SharedPreferences;
import com.yandex.finsdtechsdk.adapters.passport.sdk.api.PassportAdapter;
import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter;
import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitDependencies;
import com.yandex.fintechsdk.adapters.divkit.sdk.api.version.DivKitVersionProvider;
import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter;
import com.yandex.fintechsdk.adapters.plus.sdk.api.PlusAdapter;
import com.yandex.fintechsdk.adapters.yb.sdk.api.YbAdapter;
import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.core.analytics.impl.external.internal.AnalyticsExternalImpl;
import com.yandex.fintechsdk.core.analytics.impl.external.internal.AnalyticsExternalImpl_Factory;
import com.yandex.fintechsdk.core.architecture.api.feature.graph.FeatureGraphProvider;
import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraHeadersProvider;
import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraQueriesProvider;
import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery;
import com.yandex.fintechsdk.core.bdui.api.spinner.IsSpinnerPreviewEnabled;
import com.yandex.fintechsdk.core.bdui.api.theme.BduiThemeProvider;
import com.yandex.fintechsdk.core.divkit.api.action.DivActionHandler;
import com.yandex.fintechsdk.core.divkit.impl.internal.action.authorize.AuthorizeActionHandler;
import com.yandex.fintechsdk.core.divkit.impl.internal.action.authorize.AuthorizeActionHandler_Factory;
import com.yandex.fintechsdk.core.divkit.impl.internal.action.list.ListActionDivHandler_Factory;
import com.yandex.fintechsdk.core.divkit.impl.internal.action.openflex.OpenFlexScreenActionHandler;
import com.yandex.fintechsdk.core.divkit.impl.internal.action.openflex.OpenFlexScreenActionHandler_Factory;
import com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.RemoteActionDivHandler;
import com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.RemoteActionDivHandler_Factory;
import com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.requester.DivRemoteActionRequester;
import com.yandex.fintechsdk.core.divkit.impl.internal.action.remote.requester.DivRemoteActionRequester_Factory;
import com.yandex.fintechsdk.core.navigation.impl.api.router.RouterImpl;
import com.yandex.fintechsdk.core.network.api.auth.AuthTokenProvider;
import com.yandex.fintechsdk.core.network.api.interceptor.PrioritizedInterceptor;
import com.yandex.fintechsdk.core.network.api.network.DefaultNetworkApi;
import com.yandex.fintechsdk.core.network.api.retry.NetworkRetryHandler;
import com.yandex.fintechsdk.core.network.impl.api.di.NetworkModule_Companion_ProvideDefaultNetworkApi$impl_releaseFactory;
import com.yandex.fintechsdk.core.network.impl.api.di.NetworkModule_Companion_ProvideOkHttpClient$impl_releaseFactory;
import com.yandex.fintechsdk.core.network.impl.api.di.NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory;
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor;
import com.yandex.fintechsdk.core.network.impl.internal.executor.RequestExecutor_Factory;
import com.yandex.fintechsdk.core.network.impl.internal.host.FrontbackUrlProviderImpl;
import com.yandex.fintechsdk.core.network.impl.internal.host.FrontbackUrlProviderImpl_Factory;
import com.yandex.fintechsdk.core.network.impl.internal.host.PayUrlProviderImpl;
import com.yandex.fintechsdk.core.network.impl.internal.host.PayUrlProviderImpl_Factory;
import com.yandex.fintechsdk.core.network.impl.internal.host.custom.CustomBackendUrlProvider;
import com.yandex.fintechsdk.core.network.impl.internal.host.custom.CustomBackendUrlProvider_Factory;
import com.yandex.fintechsdk.core.network.impl.internal.interceptor.OverrideTovarischUrlInterceptor;
import com.yandex.fintechsdk.core.network.impl.internal.interceptor.OverrideTovarischUrlInterceptor_Factory;
import com.yandex.fintechsdk.core.network.impl.internal.interceptor.RetryInterceptor;
import com.yandex.fintechsdk.core.network.impl.internal.interceptor.RetryInterceptor_Factory;
import com.yandex.fintechsdk.core.network.impl.internal.network.frontback.FrontbackNetworkApiImpl;
import com.yandex.fintechsdk.core.network.impl.internal.network.frontback.FrontbackNetworkApiImpl_Factory;
import com.yandex.fintechsdk.core.network.impl.internal.network.pay.PayNetworkApiImpl;
import com.yandex.fintechsdk.core.network.impl.internal.network.pay.PayNetworkApiImpl_Factory;
import com.yandex.fintechsdk.core.network.impl.internal.retry.DefaultNetworkRetryHandlerImpl;
import com.yandex.fintechsdk.core.network.impl.internal.retry.DefaultNetworkRetryHandlerImpl_Factory;
import com.yandex.fintechsdk.core.sharedprefs.impl.CoreSharedPrefsModule_ProvideSharedPreferences$impl_releaseFactory;
import com.yandex.fintechsdk.core.telemetry.api.OpenTelemetryTracer;
import com.yandex.fintechsdk.core.ui.impl.api.activity.InsetsConfigHolder;
import com.yandex.fintechsdk.core.ui.impl.api.shimmers.ShimmersLayoutProvider;
import com.yandex.fintechsdk.core.utils.api.session.SessionId;
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider;
import com.yandex.fintechsdk.core.utils.impl.internal.adapter.AdapterFinderImpl;
import com.yandex.fintechsdk.core.utils.impl.internal.adapter.AdapterFinderImpl_Factory;
import com.yandex.fintechsdk.core.utils.impl.internal.environment.DebugEnvironmentCheckerImpl;
import com.yandex.fintechsdk.core.utils.impl.internal.environment.DebugEnvironmentCheckerImpl_Factory;
import com.yandex.fintechsdk.core.utils.impl.internal.useragent.UserAgentProviderImpl;
import com.yandex.fintechsdk.core.utils.impl.internal.useragent.UserAgentProviderImpl_Factory;
import com.yandex.fintechsdk.data.auth.api.AuthOptionsProvider;
import com.yandex.fintechsdk.data.auth.api.AuthRepository;
import com.yandex.fintechsdk.data.auth.api.dpop.DpopRepository;
import com.yandex.fintechsdk.data.auth.impl.api.di.DataAuthModule_Companion_ProvideSecureTokenStorage$impl_releaseFactory;
import com.yandex.fintechsdk.data.auth.impl.internal.auth.AuthRepositoryImpl;
import com.yandex.fintechsdk.data.auth.impl.internal.auth.AuthRepositoryImpl_Factory;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.DpopRepositoryImpl;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.DpopRepositoryImpl_Factory;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.memory.DpopMemoryDataSource_Factory;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.DpopNetworkDataSource;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.DpopNetworkDataSource_Factory;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind.BindAuthRequester;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.bind.BindAuthRequester_Factory;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.GenerateAuthSessionRequester;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.generate.GenerateAuthSessionRequester_Factory;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.revoke.RevokeTokenRequester;
import com.yandex.fintechsdk.data.auth.impl.internal.dpop.datasources.network.requesters.revoke.RevokeTokenRequester_Factory;
import com.yandex.fintechsdk.data.auth.impl.internal.storage.SecureTokenStorage;
import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository;
import com.yandex.fintechsdk.data.quickpay.api.orders.OrdersRepository;
import com.yandex.fintechsdk.data.quickpay.api.settings.QuickPaySettingsRepository;
import com.yandex.fintechsdk.data.quickpay.api.widget.QuickPayWidgetRepository;
import com.yandex.fintechsdk.data.quickpay.impl.api.di.DataQuickPayModule_Companion_ProvideQuickPayEnabledStateStorage$impl_releaseFactory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.OrdersRepositoryImpl;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.OrdersRepositoryImpl_Factory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.OrdersNetworkDataSource;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.OrdersNetworkDataSource_Factory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.GetActiveOrdersRequester;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.active.GetActiveOrdersRequester_Factory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.all.GetAllOrdersRequester;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.all.GetAllOrdersRequester_Factory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.GetOrderStatusRequester;
import com.yandex.fintechsdk.data.quickpay.impl.internal.orders.datasources.network.requesters.status.GetOrderStatusRequester_Factory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.QuickPaySettingsRepositoryImpl;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.QuickPaySettingsRepositoryImpl_Factory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.local.QuickPayEnabledStateStorage;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.QuickPaySettingsNetworkDataSource;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.QuickPaySettingsNetworkDataSource_Factory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.GetSettingsRequester;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.get.GetSettingsRequester_Factory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.UpdateSettingsRequester;
import com.yandex.fintechsdk.data.quickpay.impl.internal.settings.datasources.network.requesters.settings.update.UpdateSettingsRequester_Factory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.QuickPayWidgetRepositoryImpl;
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.QuickPayWidgetRepositoryImpl_Factory;
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.get.GetWidgetRequester;
import com.yandex.fintechsdk.data.quickpay.impl.internal.widget.datasources.network.requesters.get.GetWidgetRequester_Factory;
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment;
import com.yandex.fintechsdk.entities.environment.PayEnvironment;
import com.yandex.fintechsdk.entities.region.Region;
import com.yandex.fintechsdk.features.bdui.api.dependencies.BduiHostUrlProvider;
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.BduiNavigator;
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate;
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DeviceChallengeSignatureProvider;
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DevicePubkeyProvider;
import com.yandex.fintechsdk.features.bdui.api.di.BduiModule;
import com.yandex.fintechsdk.features.bdui.api.di.BduiModule_ProvideFeatureGraphProviderFactory;
import com.yandex.fintechsdk.features.error.api.dependencies.navigation.ErrorNavigator;
import com.yandex.fintechsdk.features.error.api.di.ErrorModule;
import com.yandex.fintechsdk.features.error.api.di.ErrorModule_ProvideFeatureGraphProviderFactory;
import com.yandex.fintechsdk.security.impl.internal.biometric.AuthenticationAvailabilityCheckerImpl;
import com.yandex.fintechsdk.security.impl.internal.biometric.AuthenticationAvailabilityCheckerImpl_Factory;
import com.yandex.fintechsdk.security.impl.internal.dpop.DpopEncoder_Factory;
import com.yandex.fintechsdk.security.impl.internal.dpop.DpopHeaderCreator;
import com.yandex.fintechsdk.security.impl.internal.dpop.DpopHeaderCreator_Factory;
import com.yandex.fintechsdk.security.impl.internal.dpop.DpopJwkCreator;
import com.yandex.fintechsdk.security.impl.internal.dpop.DpopJwkCreator_Factory;
import com.yandex.fintechsdk.security.impl.internal.dpop.DpopKeyPairManager;
import com.yandex.fintechsdk.security.impl.internal.dpop.DpopKeyPairManager_Factory;
import com.yandex.fintechsdk.security.impl.internal.dpop.DpopManagerImpl;
import com.yandex.fintechsdk.security.impl.internal.dpop.DpopManagerImpl_Factory;
import com.yandex.fitnechsdk.adapters.login.sdk.api.LoginAdapter;
import com.yandex.pay.quickpay.api.QuickPayConfig;
import com.yandex.pay.quickpay.api.QuickPaymentStateListener;
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter;
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter_Factory;
import com.yandex.pay.quickpay.internal.auth.AuthorizationManager;
import com.yandex.pay.quickpay.internal.auth.AuthorizationManager_Factory;
import com.yandex.pay.quickpay.internal.data.MerchantIdProviderImpl;
import com.yandex.pay.quickpay.internal.data.MerchantIdProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.adapters.FlowAdaptersModule;
import com.yandex.pay.quickpay.internal.di.adapters.divkit.DivKitAdapterModule;
import com.yandex.pay.quickpay.internal.di.adapters.divkit.DivKitAdapterModule_ProvideDivKitAdapterFactory;
import com.yandex.pay.quickpay.internal.di.adapters.divkit.DivKitAdapterModule_ProvideDivKitDependenciesFactory;
import com.yandex.pay.quickpay.internal.di.adapters.divkit.DivKitAdapterModule_ProvideDivKitVersionProviderFactory;
import com.yandex.pay.quickpay.internal.di.adapters.flex.FlexAdapterModule_Companion_ProvideFlexAdapterFactory;
import com.yandex.pay.quickpay.internal.di.adapters.login.LoginAdapterModule_Companion_ProvideLoginAdapterFactory;
import com.yandex.pay.quickpay.internal.di.auth.QuickPayAuthOptionsProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.core.analytics.appmetrica.AppMetricaApiKeyProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.core.analytics.event.BaseEventParamsProviderImpl;
import com.yandex.pay.quickpay.internal.di.core.analytics.event.BaseEventParamsProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.core.analytics.rum.RumConfigurationProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.core.coroutine.FlowCoroutineModule_ProvideFlowCoroutineScopeFactory;
import com.yandex.pay.quickpay.internal.di.core.navigation.CoreNavigationModule_Companion_ProvideRouterImplFactory;
import com.yandex.pay.quickpay.internal.di.core.network.CoreNetworkModule_Companion_ProvideBduiHostUrlProviderFactory;
import com.yandex.pay.quickpay.internal.di.core.network.CoreNetworkModule_Companion_ProvideEnvironmentFactory;
import com.yandex.pay.quickpay.internal.di.core.network.CoreNetworkModule_Companion_ProvidePayEnvironmentFactory;
import com.yandex.pay.quickpay.internal.di.core.network.auth.AuthTokenProviderImpl;
import com.yandex.pay.quickpay.internal.di.core.network.auth.AuthTokenProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.core.network.frontback.FrontbackServiceTokenProviderImpl;
import com.yandex.pay.quickpay.internal.di.core.network.frontback.FrontbackServiceTokenProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.core.network.headers.BaseHeadersProviderImpl;
import com.yandex.pay.quickpay.internal.di.core.network.headers.BaseHeadersProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.data.FlowDataModules_ProvideCardBindingRepositoryFactory;
import com.yandex.pay.quickpay.internal.di.features.bdui.BduiFeatureModule_Companion_ProvideInitialDocumentQueryFactory;
import com.yandex.pay.quickpay.internal.di.features.bdui.BduiFeatureModule_Companion_ProvideIsSpinnerPreviewEnabledFactory;
import com.yandex.pay.quickpay.internal.di.features.bdui.action.BduiActionsDelegateImpl;
import com.yandex.pay.quickpay.internal.di.features.bdui.action.DeviceChallengeSignatureProviderImpl;
import com.yandex.pay.quickpay.internal.di.features.bdui.action.DevicePubkeyProviderImpl;
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiDocumentQueryHolder;
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiDocumentQueryHolder_Factory;
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiExtraHeadersProviderImpl;
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiExtraHeadersProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiExtraQueriesProviderImpl;
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiExtraQueriesProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.features.bdui.navigation.BduiNavigatorImpl;
import com.yandex.pay.quickpay.internal.di.features.bdui.theme.BduiThemeProviderImpl;
import com.yandex.pay.quickpay.internal.di.features.bdui.theme.BduiThemeProviderImpl_Factory;
import com.yandex.pay.quickpay.internal.di.features.error.navigation.ErrorNavigatorImpl;
import com.yandex.pay.quickpay.internal.di.features.shimmers.ShimmersLayoutProviderImpl;
import com.yandex.pay.quickpay.internal.di.widget.QuickPayActionHandlersModule_Companion_ProvideDivkitCoroutineScopeFactory;
import com.yandex.pay.quickpay.internal.polling.PaymentProcessManager;
import com.yandex.pay.quickpay.internal.polling.PaymentProcessManager_Factory;
import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder;
import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder_Factory;
import com.yandex.pay.quickpay.internal.presentation.UserFeedbackPresenter;
import com.yandex.pay.quickpay.internal.presentation.UserFeedbackPresenter_Factory;
import com.yandex.pay.quickpay.internal.widget.PaymentMethodsWidgetJsonLoader;
import com.yandex.pay.quickpay.internal.widget.PaymentMethodsWidgetJsonLoader_Factory;
import com.yandex.pay.quickpay.internal.widget.WidgetController;
import com.yandex.pay.quickpay.internal.widget.WidgetController_Factory;
import com.yandex.pay.quickpay.internal.widget.actions.DivActionsDelegateImpl;
import com.yandex.pay.quickpay.internal.widget.actions.DivActionsDelegateImpl_Factory;
import dagger.internal.DaggerGenerated;
import dagger.internal.DelegateFactory;
import dagger.internal.DoubleCheck;
import dagger.internal.InstanceFactory;
import dagger.internal.MapFactory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.SetBuilder;
import dagger.internal.SetFactory;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import javax.annotation.processing.Generated;
import kotlinx.coroutines.CoroutineScope;
import okhttp3.OkHttpClient;
import org.jetbrains.annotations.Nullable;

@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DaggerQuickPayComponent {
  /**
   * A {@link Provider} that returns {@code Optional.empty()}.
   */
  @SuppressWarnings("rawtypes")
  private static final Provider ABSENT_JDK_OPTIONAL_PROVIDER = InstanceFactory.create(Optional.empty());

  private DaggerQuickPayComponent() {
  }

  public static QuickPayComponent.Factory factory() {
    return new Factory();
  }

  /**
   * Returns a {@link Provider} that returns {@code Optional.empty()}.
   */
  private static <T> Provider<Optional<T>> absentJdkOptionalProvider() {
    @SuppressWarnings("unchecked") // safe covariant cast
    Provider<Optional<T>> provider = (Provider<Optional<T>>) ABSENT_JDK_OPTIONAL_PROVIDER;
    return provider;
  }

  private static final class Factory implements QuickPayComponent.Factory {
    @Override
    public QuickPayComponent create(QuickPayConfig config, Context context,
        InsetsConfigHolder insetsConfigHolder, Region region, SessionId sessionId,
        QuickPaymentStateListener stateListener) {
      Preconditions.checkNotNull(config);
      Preconditions.checkNotNull(context);
      Preconditions.checkNotNull(insetsConfigHolder);
      Preconditions.checkNotNull(region);
      Preconditions.checkNotNull(sessionId);
      Preconditions.checkNotNull(stateListener);
      return new QuickPayComponentImpl(new FlowAdaptersModule(), new DivKitAdapterModule(), new BduiModule(), new ErrorModule(), config, context, insetsConfigHolder, region, sessionId, stateListener);
    }
  }

  private static final class QuickPayComponentImpl implements QuickPayComponent {
    private final Context context;

    private final QuickPayConfig config;

    private final SessionId sessionId;

    private final InsetsConfigHolder insetsConfigHolder;

    private final FlowAdaptersModule flowAdaptersModule;

    private final Region region;

    private final QuickPaymentStateListener stateListener;

    private final BduiModule bduiModule;

    private final ErrorModule errorModule;

    private final QuickPayComponentImpl quickPayComponentImpl = this;

    Provider<Context> contextProvider;

    Provider<AuthOptionsProvider> bindAuthOptionsProvider;

    Provider<SecureTokenStorage> provideSecureTokenStorage$impl_releaseProvider;

    Provider<AuthRepositoryImpl> authRepositoryImplProvider;

    Provider<QuickPayConfig> configProvider;

    Provider<Region> regionProvider;

    Provider<SessionId> sessionIdProvider;

    Provider<BaseEventParamsProviderImpl> baseEventParamsProviderImplProvider;

    Provider<AnalyticsExternalImpl> analyticsExternalImplProvider;

    Provider<Analytics> bindAnalytics$external_releaseProvider;

    Provider<BduiDocumentQueryHolder> bduiDocumentQueryHolderProvider;

    Provider<DpopHeaderCreator> dpopHeaderCreatorProvider;

    Provider<DpopJwkCreator> dpopJwkCreatorProvider;

    Provider<DebugEnvironmentCheckerImpl> debugEnvironmentCheckerImplProvider;

    Provider<DpopKeyPairManager> dpopKeyPairManagerProvider;

    Provider<DpopManagerImpl> dpopManagerImplProvider;

    Provider<SharedPreferences> provideSharedPreferences$impl_releaseProvider;

    Provider<CustomBackendUrlProvider> customBackendUrlProvider;

    Provider<PayEnvironment> providePayEnvironmentProvider;

    Provider<PayUrlProviderImpl> payUrlProviderImplProvider;

    Provider<AuthTokenProviderImpl> authTokenProviderImplProvider;

    Provider<DpopRepositoryImpl> dpopRepositoryImplProvider;

    Provider<UserAgentProviderImpl> userAgentProviderImplProvider;

    Provider<BaseHeadersProviderImpl> baseHeadersProviderImplProvider;

    Provider<FrontbackUrlProviderImpl> frontbackUrlProviderImplProvider;

    Provider<OverrideTovarischUrlInterceptor> overrideTovarischUrlInterceptorProvider;

    Provider<Optional<OpenTelemetryTracer>> optionalOfOpenTelemetryTracerProvider;

    Provider<Set<NetworkRetryHandler>> setOfNetworkRetryHandlerProvider;

    Provider<RetryInterceptor> retryInterceptorProvider;

    Provider<OkHttpClient.Builder> provideOkHttpClientBuilder$impl_releaseProvider;

    Provider<OkHttpClient> provideOkHttpClient$impl_releaseProvider;

    Provider<RequestExecutor> requestExecutorProvider;

    Provider<PayNetworkApiImpl> payNetworkApiImplProvider;

    Provider<BindAuthRequester> bindAuthRequesterProvider;

    Provider<GenerateAuthSessionRequester> generateAuthSessionRequesterProvider;

    Provider<RevokeTokenRequester> revokeTokenRequesterProvider;

    Provider<DpopNetworkDataSource> dpopNetworkDataSourceProvider;

    Provider<MerchantIdProviderImpl> merchantIdProviderImplProvider;

    Provider<BduiExtraHeadersProviderImpl> bduiExtraHeadersProviderImplProvider;

    Provider<BduiExtraQueriesProviderImpl> bduiExtraQueriesProviderImplProvider;

    Provider<QuickPayBottomSheetHolder> quickPayBottomSheetHolderProvider;

    Provider<RouterImpl> provideRouterImplProvider;

    Provider<QuickPayAnalyticsReporter> quickPayAnalyticsReporterProvider;

    Provider<AdapterFinderImpl> adapterFinderImplProvider;

    Provider<FlexAdapter> provideFlexAdapterProvider;

    Provider<LoginAdapter> provideLoginAdapterProvider;

    Provider<AuthenticationAvailabilityCheckerImpl> authenticationAvailabilityCheckerImplProvider;

    Provider<DivKitAdapter> provideDivKitAdapterProvider;

    Provider<DivKitVersionProvider> provideDivKitVersionProvider;

    Provider<FrontbackNetworkApiImpl> frontbackNetworkApiImplProvider;

    Provider<GetWidgetRequester> getWidgetRequesterProvider;

    Provider<QuickPayWidgetRepositoryImpl> quickPayWidgetRepositoryImplProvider;

    Provider<QuickPayWidgetRepository> bindPaymentMethodsWidgetRepository$impl_releaseProvider;

    Provider<PaymentMethodsWidgetJsonLoader> paymentMethodsWidgetJsonLoaderProvider;

    Provider<WidgetController> widgetControllerProvider;

    Provider<UserFeedbackPresenter> userFeedbackPresenterProvider;

    Provider<AuthorizationManager> authorizationManagerProvider;

    Provider<CoroutineScope> provideDivkitCoroutineScopeProvider;

    Provider<QuickPayEnabledStateStorage> provideQuickPayEnabledStateStorage$impl_releaseProvider;

    Provider<GetSettingsRequester> getSettingsRequesterProvider;

    Provider<UpdateSettingsRequester> updateSettingsRequesterProvider;

    Provider<QuickPaySettingsNetworkDataSource> quickPaySettingsNetworkDataSourceProvider;

    Provider<QuickPaySettingsRepositoryImpl> quickPaySettingsRepositoryImplProvider;

    Provider<QuickPaySettingsRepository> bindQuickPaySettingsRepository$impl_releaseProvider;

    Provider<DivActionsDelegateImpl> divActionsDelegateImplProvider;

    Provider<AuthorizeActionHandler> authorizeActionHandlerProvider;

    Provider<DivRemoteActionRequester> divRemoteActionRequesterProvider;

    Provider<RemoteActionDivHandler> remoteActionDivHandlerProvider;

    Provider<OpenFlexScreenActionHandler> openFlexScreenActionHandlerProvider;

    Provider<Map<String, DivActionHandler>> mapOfStringAndDivActionHandlerProvider;

    Provider<BduiThemeProviderImpl> bduiThemeProviderImplProvider;

    Provider<DivKitDependencies> provideDivKitDependenciesProvider;

    Provider<CoroutineScope> provideFlowCoroutineScopeProvider;

    Provider<GetActiveOrdersRequester> getActiveOrdersRequesterProvider;

    Provider<GetAllOrdersRequester> getAllOrdersRequesterProvider;

    Provider<GetOrderStatusRequester> getOrderStatusRequesterProvider;

    Provider<OrdersNetworkDataSource> ordersNetworkDataSourceProvider;

    Provider<OrdersRepositoryImpl> ordersRepositoryImplProvider;

    Provider<OrdersRepository> bindOrdersRepository$impl_releaseProvider;

    Provider<PaymentProcessManager> paymentProcessManagerProvider;

    QuickPayComponentImpl(FlowAdaptersModule flowAdaptersModuleParam,
        DivKitAdapterModule divKitAdapterModuleParam, BduiModule bduiModuleParam,
        ErrorModule errorModuleParam, QuickPayConfig configParam, Context contextParam,
        InsetsConfigHolder insetsConfigHolderParam, Region regionParam, SessionId sessionIdParam,
        QuickPaymentStateListener stateListenerParam) {
      this.context = contextParam;
      this.config = configParam;
      this.sessionId = sessionIdParam;
      this.insetsConfigHolder = insetsConfigHolderParam;
      this.flowAdaptersModule = flowAdaptersModuleParam;
      this.region = regionParam;
      this.stateListener = stateListenerParam;
      this.bduiModule = bduiModuleParam;
      this.errorModule = errorModuleParam;
      initialize(flowAdaptersModuleParam, divKitAdapterModuleParam, bduiModuleParam, errorModuleParam, configParam, contextParam, insetsConfigHolderParam, regionParam, sessionIdParam, stateListenerParam);
      initialize2(flowAdaptersModuleParam, divKitAdapterModuleParam, bduiModuleParam, errorModuleParam, configParam, contextParam, insetsConfigHolderParam, regionParam, sessionIdParam, stateListenerParam);
      initialize3(flowAdaptersModuleParam, divKitAdapterModuleParam, bduiModuleParam, errorModuleParam, configParam, contextParam, insetsConfigHolderParam, regionParam, sessionIdParam, stateListenerParam);
      initialize4(flowAdaptersModuleParam, divKitAdapterModuleParam, bduiModuleParam, errorModuleParam, configParam, contextParam, insetsConfigHolderParam, regionParam, sessionIdParam, stateListenerParam);

    }

    AuthTokenProviderImpl authTokenProviderImpl() {
      return new AuthTokenProviderImpl(authRepositoryImplProvider.get());
    }

    BduiActionsDelegateImpl bduiActionsDelegateImpl() {
      return new BduiActionsDelegateImpl(quickPayBottomSheetHolderProvider.get());
    }

    SharedPreferences sharedPreferences() {
      return CoreSharedPrefsModule_ProvideSharedPreferences$impl_releaseFactory.provideSharedPreferences$impl_release(context);
    }

    CustomBackendUrlProvider customBackendUrlProvider() {
      return new CustomBackendUrlProvider(sharedPreferences());
    }

    PayEnvironment payEnvironment() {
      return CoreNetworkModule_Companion_ProvidePayEnvironmentFactory.providePayEnvironment(config);
    }

    FrontbackUrlProviderImpl frontbackUrlProviderImpl() {
      return new FrontbackUrlProviderImpl(customBackendUrlProvider(), payEnvironment());
    }

    BduiNavigatorImpl bduiNavigatorImpl() {
      return new BduiNavigatorImpl(provideRouterImplProvider.get(), quickPayBottomSheetHolderProvider.get(), quickPayAnalyticsReporterProvider.get());
    }

    BduiThemeProviderImpl bduiThemeProviderImpl() {
      return new BduiThemeProviderImpl(context);
    }

    UserAgentProviderImpl userAgentProviderImpl() {
      return new UserAgentProviderImpl(context);
    }

    BaseHeadersProviderImpl baseHeadersProviderImpl() {
      return new BaseHeadersProviderImpl(context, config, DoubleCheck.lazy(((Provider) (dpopRepositoryImplProvider))), payEnvironment(), new FrontbackServiceTokenProviderImpl(), sessionId, userAgentProviderImpl());
    }

    OkHttpClient okHttpClient() {
      return NetworkModule_Companion_ProvideOkHttpClient$impl_releaseFactory.provideOkHttpClient$impl_release(getOkHttpClientBuilder());
    }

    RequestExecutor requestExecutor() {
      return new RequestExecutor(authTokenProviderImpl(), baseHeadersProviderImpl(), okHttpClient(), userAgentProviderImpl());
    }

    OverrideTovarischUrlInterceptor overrideTovarischUrlInterceptor() {
      return new OverrideTovarischUrlInterceptor(customBackendUrlProvider(), frontbackUrlProviderImpl());
    }

    Set<NetworkRetryHandler> setOfNetworkRetryHandler() {
      return Collections.<NetworkRetryHandler>singleton(new DefaultNetworkRetryHandlerImpl());
    }

    RetryInterceptor retryInterceptor() {
      return new RetryInterceptor(bindAnalytics$external_releaseProvider.get(), setOfNetworkRetryHandler());
    }

    ErrorNavigatorImpl errorNavigatorImpl() {
      return new ErrorNavigatorImpl(quickPayBottomSheetHolderProvider.get(), stateListener);
    }

    @SuppressWarnings("unchecked")
    private void initialize(final FlowAdaptersModule flowAdaptersModuleParam,
        final DivKitAdapterModule divKitAdapterModuleParam, final BduiModule bduiModuleParam,
        final ErrorModule errorModuleParam, final QuickPayConfig configParam,
        final Context contextParam, final InsetsConfigHolder insetsConfigHolderParam,
        final Region regionParam, final SessionId sessionIdParam,
        final QuickPaymentStateListener stateListenerParam) {
      this.contextProvider = InstanceFactory.create(contextParam);
      this.bindAuthOptionsProvider = DoubleCheck.provider((Provider) (QuickPayAuthOptionsProviderImpl_Factory.create()));
      this.provideSecureTokenStorage$impl_releaseProvider = DoubleCheck.provider(DataAuthModule_Companion_ProvideSecureTokenStorage$impl_releaseFactory.create(contextProvider));
      this.authRepositoryImplProvider = DoubleCheck.provider(AuthRepositoryImpl_Factory.create(bindAuthOptionsProvider, provideSecureTokenStorage$impl_releaseProvider));
      this.configProvider = InstanceFactory.create(configParam);
      this.regionProvider = InstanceFactory.create(regionParam);
      this.sessionIdProvider = InstanceFactory.create(sessionIdParam);
      this.baseEventParamsProviderImplProvider = BaseEventParamsProviderImpl_Factory.create(contextProvider, ((Provider) (authRepositoryImplProvider)), configProvider, regionProvider, sessionIdProvider);
      this.analyticsExternalImplProvider = AnalyticsExternalImpl_Factory.create(((Provider) (AppMetricaApiKeyProviderImpl_Factory.create())), ((Provider) (baseEventParamsProviderImplProvider)), contextProvider, ((Provider) (RumConfigurationProviderImpl_Factory.create())));
      this.bindAnalytics$external_releaseProvider = DoubleCheck.provider((Provider) (analyticsExternalImplProvider));
      this.bduiDocumentQueryHolderProvider = DoubleCheck.provider(BduiDocumentQueryHolder_Factory.create());
      this.dpopHeaderCreatorProvider = DpopHeaderCreator_Factory.create(bindAnalytics$external_releaseProvider, DpopEncoder_Factory.create());
      this.dpopJwkCreatorProvider = DpopJwkCreator_Factory.create(DpopEncoder_Factory.create());
      this.debugEnvironmentCheckerImplProvider = DebugEnvironmentCheckerImpl_Factory.create(contextProvider);
      this.dpopKeyPairManagerProvider = DpopKeyPairManager_Factory.create(bindAnalytics$external_releaseProvider, ((Provider) (debugEnvironmentCheckerImplProvider)));
      this.dpopManagerImplProvider = DpopManagerImpl_Factory.create(dpopHeaderCreatorProvider, dpopJwkCreatorProvider, dpopKeyPairManagerProvider);
      this.provideSharedPreferences$impl_releaseProvider = CoreSharedPrefsModule_ProvideSharedPreferences$impl_releaseFactory.create(contextProvider);
      this.customBackendUrlProvider = CustomBackendUrlProvider_Factory.create(provideSharedPreferences$impl_releaseProvider);
      this.providePayEnvironmentProvider = CoreNetworkModule_Companion_ProvidePayEnvironmentFactory.create(configProvider);
      this.payUrlProviderImplProvider = PayUrlProviderImpl_Factory.create(customBackendUrlProvider, providePayEnvironmentProvider);
      this.authTokenProviderImplProvider = AuthTokenProviderImpl_Factory.create(((Provider) (authRepositoryImplProvider)));
      this.dpopRepositoryImplProvider = new DelegateFactory<>();
      this.userAgentProviderImplProvider = UserAgentProviderImpl_Factory.create(contextProvider);
      this.baseHeadersProviderImplProvider = BaseHeadersProviderImpl_Factory.create(contextProvider, configProvider, ((Provider) (dpopRepositoryImplProvider)), providePayEnvironmentProvider, ((Provider) (FrontbackServiceTokenProviderImpl_Factory.create())), sessionIdProvider, ((Provider) (userAgentProviderImplProvider)));
      this.frontbackUrlProviderImplProvider = FrontbackUrlProviderImpl_Factory.create(customBackendUrlProvider, providePayEnvironmentProvider);
    }

    @SuppressWarnings("unchecked")
    private void initialize2(final FlowAdaptersModule flowAdaptersModuleParam,
        final DivKitAdapterModule divKitAdapterModuleParam, final BduiModule bduiModuleParam,
        final ErrorModule errorModuleParam, final QuickPayConfig configParam,
        final Context contextParam, final InsetsConfigHolder insetsConfigHolderParam,
        final Region regionParam, final SessionId sessionIdParam,
        final QuickPaymentStateListener stateListenerParam) {
      this.overrideTovarischUrlInterceptorProvider = OverrideTovarischUrlInterceptor_Factory.create(customBackendUrlProvider, ((Provider) (frontbackUrlProviderImplProvider)));
      this.optionalOfOpenTelemetryTracerProvider = absentJdkOptionalProvider();
      this.setOfNetworkRetryHandlerProvider = setOfNetworkRetryHandlerBuilder(flowAdaptersModuleParam, divKitAdapterModuleParam, bduiModuleParam, errorModuleParam, configParam, contextParam, insetsConfigHolderParam, regionParam, sessionIdParam, stateListenerParam);
      this.retryInterceptorProvider = RetryInterceptor_Factory.create(bindAnalytics$external_releaseProvider, setOfNetworkRetryHandlerProvider);
      this.provideOkHttpClientBuilder$impl_releaseProvider = NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory.create(overrideTovarischUrlInterceptorProvider, optionalOfOpenTelemetryTracerProvider, retryInterceptorProvider, SetFactory.<PrioritizedInterceptor>empty());
      this.provideOkHttpClient$impl_releaseProvider = NetworkModule_Companion_ProvideOkHttpClient$impl_releaseFactory.create(provideOkHttpClientBuilder$impl_releaseProvider);
      this.requestExecutorProvider = RequestExecutor_Factory.create(((Provider) (authTokenProviderImplProvider)), ((Provider) (baseHeadersProviderImplProvider)), provideOkHttpClient$impl_releaseProvider, ((Provider) (userAgentProviderImplProvider)));
      this.payNetworkApiImplProvider = PayNetworkApiImpl_Factory.create(((Provider) (payUrlProviderImplProvider)), requestExecutorProvider, bindAnalytics$external_releaseProvider);
      this.bindAuthRequesterProvider = BindAuthRequester_Factory.create(((Provider) (payNetworkApiImplProvider)));
      this.generateAuthSessionRequesterProvider = GenerateAuthSessionRequester_Factory.create(((Provider) (payNetworkApiImplProvider)));
      this.revokeTokenRequesterProvider = RevokeTokenRequester_Factory.create(((Provider) (payNetworkApiImplProvider)));
      this.dpopNetworkDataSourceProvider = DpopNetworkDataSource_Factory.create(bindAuthRequesterProvider, generateAuthSessionRequesterProvider, revokeTokenRequesterProvider);
      DelegateFactory.setDelegate(dpopRepositoryImplProvider, DoubleCheck.provider(DpopRepositoryImpl_Factory.create(((Provider) (dpopManagerImplProvider)), DpopMemoryDataSource_Factory.create(), dpopNetworkDataSourceProvider)));
      this.merchantIdProviderImplProvider = MerchantIdProviderImpl_Factory.create(configProvider);
      this.bduiExtraHeadersProviderImplProvider = DoubleCheck.provider(BduiExtraHeadersProviderImpl_Factory.create(contextProvider, ((Provider) (dpopRepositoryImplProvider)), providePayEnvironmentProvider, ((Provider) (FrontbackServiceTokenProviderImpl_Factory.create())), ((Provider) (merchantIdProviderImplProvider)), sessionIdProvider, ((Provider) (userAgentProviderImplProvider))));
      this.bduiExtraQueriesProviderImplProvider = DoubleCheck.provider(BduiExtraQueriesProviderImpl_Factory.create());
      this.quickPayBottomSheetHolderProvider = DoubleCheck.provider(QuickPayBottomSheetHolder_Factory.create(bduiDocumentQueryHolderProvider, bduiExtraHeadersProviderImplProvider, bduiExtraQueriesProviderImplProvider));
      this.provideRouterImplProvider = DoubleCheck.provider(CoreNavigationModule_Companion_ProvideRouterImplFactory.create());
      this.quickPayAnalyticsReporterProvider = DoubleCheck.provider(QuickPayAnalyticsReporter_Factory.create(bindAnalytics$external_releaseProvider, ((Provider) (authRepositoryImplProvider))));
      this.adapterFinderImplProvider = AdapterFinderImpl_Factory.create(bindAnalytics$external_releaseProvider);
      this.provideFlexAdapterProvider = DoubleCheck.provider(FlexAdapterModule_Companion_ProvideFlexAdapterFactory.create(((Provider) (adapterFinderImplProvider))));
      this.provideLoginAdapterProvider = DoubleCheck.provider(LoginAdapterModule_Companion_ProvideLoginAdapterFactory.create());
      this.authenticationAvailabilityCheckerImplProvider = AuthenticationAvailabilityCheckerImpl_Factory.create(contextProvider);
      this.provideDivKitAdapterProvider = DoubleCheck.provider(DivKitAdapterModule_ProvideDivKitAdapterFactory.create(divKitAdapterModuleParam));
      this.provideDivKitVersionProvider = DoubleCheck.provider(DivKitAdapterModule_ProvideDivKitVersionProviderFactory.create(divKitAdapterModuleParam));
    }

    @SuppressWarnings("unchecked")
    private void initialize3(final FlowAdaptersModule flowAdaptersModuleParam,
        final DivKitAdapterModule divKitAdapterModuleParam, final BduiModule bduiModuleParam,
        final ErrorModule errorModuleParam, final QuickPayConfig configParam,
        final Context contextParam, final InsetsConfigHolder insetsConfigHolderParam,
        final Region regionParam, final SessionId sessionIdParam,
        final QuickPaymentStateListener stateListenerParam) {
      this.frontbackNetworkApiImplProvider = FrontbackNetworkApiImpl_Factory.create(((Provider) (frontbackUrlProviderImplProvider)), requestExecutorProvider, bindAnalytics$external_releaseProvider, providePayEnvironmentProvider, ((Provider) (FrontbackServiceTokenProviderImpl_Factory.create())), customBackendUrlProvider);
      this.getWidgetRequesterProvider = GetWidgetRequester_Factory.create(((Provider) (frontbackNetworkApiImplProvider)));
      this.quickPayWidgetRepositoryImplProvider = QuickPayWidgetRepositoryImpl_Factory.create(provideDivKitVersionProvider, getWidgetRequesterProvider);
      this.bindPaymentMethodsWidgetRepository$impl_releaseProvider = DoubleCheck.provider((Provider) (quickPayWidgetRepositoryImplProvider));
      this.paymentMethodsWidgetJsonLoaderProvider = PaymentMethodsWidgetJsonLoader_Factory.create(bindPaymentMethodsWidgetRepository$impl_releaseProvider);
      this.widgetControllerProvider = DoubleCheck.provider(WidgetController_Factory.create(provideDivKitAdapterProvider, paymentMethodsWidgetJsonLoaderProvider, quickPayAnalyticsReporterProvider));
      this.userFeedbackPresenterProvider = DoubleCheck.provider(UserFeedbackPresenter_Factory.create(contextProvider, ((Provider) (authenticationAvailabilityCheckerImplProvider)), widgetControllerProvider));
      this.authorizationManagerProvider = DoubleCheck.provider(AuthorizationManager_Factory.create(quickPayAnalyticsReporterProvider, ((Provider) (authRepositoryImplProvider)), ((Provider) (dpopRepositoryImplProvider)), provideLoginAdapterProvider, userFeedbackPresenterProvider, configProvider));
      this.provideDivkitCoroutineScopeProvider = DoubleCheck.provider(QuickPayActionHandlersModule_Companion_ProvideDivkitCoroutineScopeFactory.create());
      this.provideQuickPayEnabledStateStorage$impl_releaseProvider = DoubleCheck.provider(DataQuickPayModule_Companion_ProvideQuickPayEnabledStateStorage$impl_releaseFactory.create(provideSharedPreferences$impl_releaseProvider));
      this.getSettingsRequesterProvider = GetSettingsRequester_Factory.create(((Provider) (frontbackNetworkApiImplProvider)));
      this.updateSettingsRequesterProvider = UpdateSettingsRequester_Factory.create(((Provider) (frontbackNetworkApiImplProvider)));
      this.quickPaySettingsNetworkDataSourceProvider = QuickPaySettingsNetworkDataSource_Factory.create(getSettingsRequesterProvider, updateSettingsRequesterProvider);
      this.quickPaySettingsRepositoryImplProvider = QuickPaySettingsRepositoryImpl_Factory.create(provideQuickPayEnabledStateStorage$impl_releaseProvider, quickPaySettingsNetworkDataSourceProvider);
      this.bindQuickPaySettingsRepository$impl_releaseProvider = DoubleCheck.provider((Provider) (quickPaySettingsRepositoryImplProvider));
      this.divActionsDelegateImplProvider = DivActionsDelegateImpl_Factory.create(quickPayBottomSheetHolderProvider, provideDivkitCoroutineScopeProvider, bindQuickPaySettingsRepository$impl_releaseProvider);
      this.authorizeActionHandlerProvider = AuthorizeActionHandler_Factory.create(((Provider) (divActionsDelegateImplProvider)));
      this.divRemoteActionRequesterProvider = DivRemoteActionRequester_Factory.create(((Provider) (frontbackNetworkApiImplProvider)), ((Provider) (bduiExtraQueriesProviderImplProvider)));
      this.remoteActionDivHandlerProvider = RemoteActionDivHandler_Factory.create(((Provider) (divActionsDelegateImplProvider)), divRemoteActionRequesterProvider, provideDivkitCoroutineScopeProvider);
      this.openFlexScreenActionHandlerProvider = OpenFlexScreenActionHandler_Factory.create(((Provider) (divActionsDelegateImplProvider)));
      this.mapOfStringAndDivActionHandlerProvider = mapOfStringAndDivActionHandlerBuilder(flowAdaptersModuleParam, divKitAdapterModuleParam, bduiModuleParam, errorModuleParam, configParam, contextParam, insetsConfigHolderParam, regionParam, sessionIdParam, stateListenerParam);
      this.bduiThemeProviderImplProvider = BduiThemeProviderImpl_Factory.create(contextProvider);
      this.provideDivKitDependenciesProvider = DoubleCheck.provider(DivKitAdapterModule_ProvideDivKitDependenciesFactory.create(divKitAdapterModuleParam, contextProvider, mapOfStringAndDivActionHandlerProvider, provideOkHttpClientBuilder$impl_releaseProvider, ((Provider) (bduiThemeProviderImplProvider))));
      this.provideFlowCoroutineScopeProvider = DoubleCheck.provider(FlowCoroutineModule_ProvideFlowCoroutineScopeFactory.create());
      this.getActiveOrdersRequesterProvider = GetActiveOrdersRequester_Factory.create(((Provider) (frontbackNetworkApiImplProvider)));
    }

    @SuppressWarnings("unchecked")
    private void initialize4(final FlowAdaptersModule flowAdaptersModuleParam,
        final DivKitAdapterModule divKitAdapterModuleParam, final BduiModule bduiModuleParam,
        final ErrorModule errorModuleParam, final QuickPayConfig configParam,
        final Context contextParam, final InsetsConfigHolder insetsConfigHolderParam,
        final Region regionParam, final SessionId sessionIdParam,
        final QuickPaymentStateListener stateListenerParam) {
      this.getAllOrdersRequesterProvider = GetAllOrdersRequester_Factory.create(((Provider) (frontbackNetworkApiImplProvider)));
      this.getOrderStatusRequesterProvider = GetOrderStatusRequester_Factory.create(((Provider) (frontbackNetworkApiImplProvider)));
      this.ordersNetworkDataSourceProvider = OrdersNetworkDataSource_Factory.create(getActiveOrdersRequesterProvider, getAllOrdersRequesterProvider, getOrderStatusRequesterProvider);
      this.ordersRepositoryImplProvider = OrdersRepositoryImpl_Factory.create(ordersNetworkDataSourceProvider);
      this.bindOrdersRepository$impl_releaseProvider = DoubleCheck.provider((Provider) (ordersRepositoryImplProvider));
      this.paymentProcessManagerProvider = DoubleCheck.provider(PaymentProcessManager_Factory.create(bindOrdersRepository$impl_releaseProvider, quickPayAnalyticsReporterProvider, provideFlowCoroutineScopeProvider));
    }

    SetFactory<NetworkRetryHandler> setOfNetworkRetryHandlerBuilder(
        FlowAdaptersModule flowAdaptersModuleParam, DivKitAdapterModule divKitAdapterModuleParam,
        BduiModule bduiModuleParam, ErrorModule errorModuleParam, QuickPayConfig configParam,
        Context contextParam, InsetsConfigHolder insetsConfigHolderParam, Region regionParam,
        SessionId sessionIdParam, QuickPaymentStateListener stateListenerParam) {
      SetFactory.Builder<NetworkRetryHandler> builder = SetFactory.builder(1, 0);
      builder.addProvider(((Provider) (DefaultNetworkRetryHandlerImpl_Factory.create())));
      return builder.build();
    }

    MapFactory<String, DivActionHandler> mapOfStringAndDivActionHandlerBuilder(
        FlowAdaptersModule flowAdaptersModuleParam, DivKitAdapterModule divKitAdapterModuleParam,
        BduiModule bduiModuleParam, ErrorModule errorModuleParam, QuickPayConfig configParam,
        Context contextParam, InsetsConfigHolder insetsConfigHolderParam, Region regionParam,
        SessionId sessionIdParam, QuickPaymentStateListener stateListenerParam) {
      MapFactory.Builder<String, DivActionHandler> builder = MapFactory.builder(4);
      builder.put("authorize", ((Provider) (authorizeActionHandlerProvider)));
      builder.put("remote_action", ((Provider) (remoteActionDivHandlerProvider)));
      builder.put("open_flex_screen", ((Provider) (openFlexScreenActionHandlerProvider)));
      builder.put("list_action", ((Provider) (ListActionDivHandler_Factory.create())));
      return builder.build();
    }

    @Override
    public Analytics getAnalytics() {
      return bindAnalytics$external_releaseProvider.get();
    }

    @Override
    public AuthRepository getAuthRepository() {
      return authRepositoryImplProvider.get();
    }

    @Override
    public AuthTokenProvider getAuthTokenProvider() {
      return authTokenProviderImpl();
    }

    @Override
    public BduiActionsDelegate getBduiActionsDelegate() {
      return bduiActionsDelegateImpl();
    }

    @Override
    public BduiExtraHeadersProvider getBduiExtraHeadersProvider() {
      return bduiExtraHeadersProviderImplProvider.get();
    }

    @Override
    public BduiExtraQueriesProvider getBduiExtraQueriesProvider() {
      return bduiExtraQueriesProviderImplProvider.get();
    }

    @Override
    public BduiHostUrlProvider getBduiHostUrlProvider() {
      return CoreNetworkModule_Companion_ProvideBduiHostUrlProviderFactory.provideBduiHostUrlProvider(frontbackUrlProviderImpl());
    }

    @Override
    public BduiNavigator getBduiNavigator() {
      return bduiNavigatorImpl();
    }

    @Override
    public BduiThemeProvider getBduiThemeProvider() {
      return bduiThemeProviderImpl();
    }

    @Override
    public CardBindingRepository getCardBindingRepository() {
      return FlowDataModules_ProvideCardBindingRepositoryFactory.provideCardBindingRepository();
    }

    @Override
    public DefaultNetworkApi getDefaultNetworkApi() {
      return NetworkModule_Companion_ProvideDefaultNetworkApi$impl_releaseFactory.provideDefaultNetworkApi$impl_release(bindAnalytics$external_releaseProvider.get(), requestExecutor());
    }

    @Override
    public DeviceChallengeSignatureProvider getDeviceChallengeSignatureProvider() {
      return new DeviceChallengeSignatureProviderImpl();
    }

    @Override
    public DevicePubkeyProvider getDevicePubkeyProvider() {
      return new DevicePubkeyProviderImpl();
    }

    @Override
    public DefaultEnvironment getEnvironment() {
      return CoreNetworkModule_Companion_ProvideEnvironmentFactory.provideEnvironment();
    }

    @Override
    @Nullable
    public FlexAdapter getFlexAdapter() {
      return provideFlexAdapterProvider.get();
    }

    @Override
    public BduiDocumentQuery getInitialDocumentQuery() {
      return BduiFeatureModule_Companion_ProvideInitialDocumentQueryFactory.provideInitialDocumentQuery(bduiDocumentQueryHolderProvider.get());
    }

    @Override
    public InsetsConfigHolder getInsetsConfigHolder() {
      return insetsConfigHolder;
    }

    @Override
    public IsSpinnerPreviewEnabled isSpinnerPreviewEnabled() {
      return BduiFeatureModule_Companion_ProvideIsSpinnerPreviewEnabledFactory.provideIsSpinnerPreviewEnabled();
    }

    @Override
    public OkHttpClient.Builder getOkHttpClientBuilder() {
      return NetworkModule_Companion_ProvideOkHttpClientBuilder$impl_releaseFactory.provideOkHttpClientBuilder$impl_release(overrideTovarischUrlInterceptor(), Optional.empty(), retryInterceptor(), Collections.<PrioritizedInterceptor>emptySet());
    }

    @Override
    @Nullable
    public PassportAdapter getPassportAdapter() {
      return flowAdaptersModule.providePassportAdapter();
    }

    @Override
    @Nullable
    public PlusAdapter getPlusAdapter() {
      return flowAdaptersModule.providePlusAdapter();
    }

    @Override
    public Region getRegion() {
      return region;
    }

    @Override
    public RouterImpl getRouter() {
      return provideRouterImplProvider.get();
    }

    @Override
    public ShimmersLayoutProvider getShimmersLayoutProvider() {
      return new ShimmersLayoutProviderImpl();
    }

    @Override
    public UserAgentProvider getUserAgentProvider() {
      return userAgentProviderImpl();
    }

    @Override
    @Nullable
    public YbAdapter getYbSdkAdapter() {
      return flowAdaptersModule.provideYbAdapter();
    }

    @Override
    public ErrorNavigator getErrorNavigator() {
      return errorNavigatorImpl();
    }

    @Override
    public QuickPayAnalyticsReporter getAnalyticsReporter() {
      return quickPayAnalyticsReporterProvider.get();
    }

    @Override
    public AuthorizationManager getAuthorizationManager() {
      return authorizationManagerProvider.get();
    }

    @Override
    public UserFeedbackPresenter getUserFeedbackPresenter() {
      return userFeedbackPresenterProvider.get();
    }

    @Override
    public QuickPayBottomSheetHolder getBottomSheetHolder() {
      return quickPayBottomSheetHolderProvider.get();
    }

    @Override
    public Context getContext() {
      return context;
    }

    @Override
    public DivKitAdapter getDivKitAdapter() {
      return provideDivKitAdapterProvider.get();
    }

    @Override
    public DivKitDependencies getDivKitDependencies() {
      return provideDivKitDependenciesProvider.get();
    }

    @Override
    public DpopRepository getDpopRepository() {
      return dpopRepositoryImplProvider.get();
    }

    @Override
    public Set<FeatureGraphProvider> getFeatureGraphProviders() {
      return SetBuilder.<FeatureGraphProvider>newSetBuilder(2).add(BduiModule_ProvideFeatureGraphProviderFactory.provideFeatureGraphProvider(bduiModule)).add(ErrorModule_ProvideFeatureGraphProviderFactory.provideFeatureGraphProvider(errorModule)).build();
    }

    @Override
    public CoroutineScope getFlowCoroutineScope() {
      return provideFlowCoroutineScopeProvider.get();
    }

    @Override
    public LoginAdapter getLoginAdapter() {
      return provideLoginAdapterProvider.get();
    }

    @Override
    public OrdersRepository getOrdersRepository() {
      return bindOrdersRepository$impl_releaseProvider.get();
    }

    @Override
    public PaymentMethodsWidgetJsonLoader getPaymentMethodsWidgetJsonLoader() {
      return new PaymentMethodsWidgetJsonLoader(bindPaymentMethodsWidgetRepository$impl_releaseProvider.get());
    }

    @Override
    public PaymentProcessManager getPaymentProcessManager() {
      return paymentProcessManagerProvider.get();
    }

    @Override
    public QuickPayWidgetRepository getQuickPayWidgetRepository() {
      return bindPaymentMethodsWidgetRepository$impl_releaseProvider.get();
    }

    @Override
    public SessionId getSessionId() {
      return sessionId;
    }

    @Override
    public QuickPaySettingsRepository getSettingsRepository() {
      return bindQuickPaySettingsRepository$impl_releaseProvider.get();
    }

    @Override
    public WidgetController getWidgetController() {
      return widgetControllerProvider.get();
    }
  }
}
