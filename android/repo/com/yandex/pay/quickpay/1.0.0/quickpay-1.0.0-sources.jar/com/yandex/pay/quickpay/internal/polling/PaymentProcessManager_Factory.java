package com.yandex.pay.quickpay.internal.polling;

import com.yandex.fintechsdk.data.quickpay.api.orders.OrdersRepository;
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlinx.coroutines.CoroutineScope;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata("com.yandex.pay.quickpay.internal.di.FlowCoroutineScope")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class PaymentProcessManager_Factory implements Factory<PaymentProcessManager> {
  private final Provider<OrdersRepository> ordersRepositoryProvider;

  private final Provider<QuickPayAnalyticsReporter> analyticsReporterProvider;

  private final Provider<CoroutineScope> scopeProvider;

  private PaymentProcessManager_Factory(Provider<OrdersRepository> ordersRepositoryProvider,
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider,
      Provider<CoroutineScope> scopeProvider) {
    this.ordersRepositoryProvider = ordersRepositoryProvider;
    this.analyticsReporterProvider = analyticsReporterProvider;
    this.scopeProvider = scopeProvider;
  }

  @Override
  public PaymentProcessManager get() {
    return newInstance(ordersRepositoryProvider.get(), analyticsReporterProvider.get(), scopeProvider.get());
  }

  public static PaymentProcessManager_Factory create(
      Provider<OrdersRepository> ordersRepositoryProvider,
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider,
      Provider<CoroutineScope> scopeProvider) {
    return new PaymentProcessManager_Factory(ordersRepositoryProvider, analyticsReporterProvider, scopeProvider);
  }

  public static PaymentProcessManager newInstance(OrdersRepository ordersRepository,
      QuickPayAnalyticsReporter analyticsReporter, CoroutineScope scope) {
    return new PaymentProcessManager(ordersRepository, analyticsReporter, scope);
  }
}
