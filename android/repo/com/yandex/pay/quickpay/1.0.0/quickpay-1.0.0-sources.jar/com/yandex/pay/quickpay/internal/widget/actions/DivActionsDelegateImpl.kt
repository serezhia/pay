package com.yandex.pay.quickpay.internal.widget.actions

import com.yandex.fintechsdk.core.divkit.api.action.DivActionsDelegate
import com.yandex.fintechsdk.core.divkit.api.di.DivkitCoroutineScope
import com.yandex.fintechsdk.data.quickpay.api.settings.QuickPaySettingsRepository
import com.yandex.pay.quickpay.api.YandexQuickPay
import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import javax.inject.Inject

internal class DivActionsDelegateImpl @Inject constructor(
    private val bottomSheetHolder: QuickPayBottomSheetHolder,
    @DivkitCoroutineScope private val coroutineScope: CoroutineScope,
    private val settingsRepository: QuickPaySettingsRepository,
) : DivActionsDelegate() {

    override fun openFlexScreen(
        endpoint: String,
        query: Map<String, String>,
        headers: Map<String, String>,
    ) {
        bottomSheetHolder.openNewBottomSheet(
            endpoint = endpoint,
            query = query,
            headers = headers,
        )
    }

    override fun authorize() {
        coroutineScope.launch {
            YandexQuickPay.enableQuickPayment()
        }
    }

    override fun onRemoteAction(path: String) {
        if (path == SETTINGS_PATH) {
            coroutineScope.launch {
                settingsRepository.getSettingsFromBackend()
                    .onSuccess { settings ->
                        YandexQuickPay.notifyPaymentEnabledStateChanged(
                            isEnabled = settings.isEnabled,
                        )
                    }
            }
        }
    }

    private companion object {
        private const val SETTINGS_PATH = "pay/v1/quickpay/settings"
    }
}

