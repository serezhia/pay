package com.yandex.pay.quickpay.internal.widget;

import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter;
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class WidgetController_Factory implements Factory<WidgetController> {
  private final Provider<QuickPayAnalyticsReporter> analyticsReporterProvider;

  private final Provider<DivKitAdapter> divKitAdapterProvider;

  private final Provider<PaymentMethodsWidgetJsonLoader> paymentMethodsWidgetJsonLoaderProvider;

  private WidgetController_Factory(Provider<QuickPayAnalyticsReporter> analyticsReporterProvider,
      Provider<DivKitAdapter> divKitAdapterProvider,
      Provider<PaymentMethodsWidgetJsonLoader> paymentMethodsWidgetJsonLoaderProvider) {
    this.analyticsReporterProvider = analyticsReporterProvider;
    this.divKitAdapterProvider = divKitAdapterProvider;
    this.paymentMethodsWidgetJsonLoaderProvider = paymentMethodsWidgetJsonLoaderProvider;
  }

  @Override
  public WidgetController get() {
    return newInstance(analyticsReporterProvider.get(), divKitAdapterProvider.get(), paymentMethodsWidgetJsonLoaderProvider.get());
  }

  public static WidgetController_Factory create(
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider,
      Provider<DivKitAdapter> divKitAdapterProvider,
      Provider<PaymentMethodsWidgetJsonLoader> paymentMethodsWidgetJsonLoaderProvider) {
    return new WidgetController_Factory(analyticsReporterProvider, divKitAdapterProvider, paymentMethodsWidgetJsonLoaderProvider);
  }

  public static WidgetController newInstance(QuickPayAnalyticsReporter analyticsReporter,
      DivKitAdapter divKitAdapter, PaymentMethodsWidgetJsonLoader paymentMethodsWidgetJsonLoader) {
    return new WidgetController(analyticsReporter, divKitAdapter, paymentMethodsWidgetJsonLoader);
  }
}
