package com.yandex.pay.quickpay.internal.widget;

import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter;
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class WidgetController_Factory implements Factory<WidgetController> {
  private final Provider<DivKitAdapter> divKitAdapterProvider;

  private final Provider<PaymentMethodsWidgetJsonLoader> paymentMethodsWidgetJsonLoaderProvider;

  private final Provider<QuickPayAnalyticsReporter> analyticsReporterProvider;

  private WidgetController_Factory(Provider<DivKitAdapter> divKitAdapterProvider,
      Provider<PaymentMethodsWidgetJsonLoader> paymentMethodsWidgetJsonLoaderProvider,
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider) {
    this.divKitAdapterProvider = divKitAdapterProvider;
    this.paymentMethodsWidgetJsonLoaderProvider = paymentMethodsWidgetJsonLoaderProvider;
    this.analyticsReporterProvider = analyticsReporterProvider;
  }

  @Override
  public WidgetController get() {
    return newInstance(divKitAdapterProvider.get(), paymentMethodsWidgetJsonLoaderProvider.get(), analyticsReporterProvider.get());
  }

  public static WidgetController_Factory create(Provider<DivKitAdapter> divKitAdapterProvider,
      Provider<PaymentMethodsWidgetJsonLoader> paymentMethodsWidgetJsonLoaderProvider,
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider) {
    return new WidgetController_Factory(divKitAdapterProvider, paymentMethodsWidgetJsonLoaderProvider, analyticsReporterProvider);
  }

  public static WidgetController newInstance(DivKitAdapter divKitAdapter,
      PaymentMethodsWidgetJsonLoader paymentMethodsWidgetJsonLoader,
      QuickPayAnalyticsReporter analyticsReporter) {
    return new WidgetController(divKitAdapter, paymentMethodsWidgetJsonLoader, analyticsReporter);
  }
}
