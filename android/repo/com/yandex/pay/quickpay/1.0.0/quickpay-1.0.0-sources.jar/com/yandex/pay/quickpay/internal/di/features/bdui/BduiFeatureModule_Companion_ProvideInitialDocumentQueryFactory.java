package com.yandex.pay.quickpay.internal.di.features.bdui;

import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery;
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiDocumentQueryHolder;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiFeatureModule_Companion_ProvideInitialDocumentQueryFactory implements Factory<BduiDocumentQuery> {
  private final Provider<BduiDocumentQueryHolder> holderProvider;

  private BduiFeatureModule_Companion_ProvideInitialDocumentQueryFactory(
      Provider<BduiDocumentQueryHolder> holderProvider) {
    this.holderProvider = holderProvider;
  }

  @Override
  public BduiDocumentQuery get() {
    return provideInitialDocumentQuery(holderProvider.get());
  }

  public static BduiFeatureModule_Companion_ProvideInitialDocumentQueryFactory create(
      Provider<BduiDocumentQueryHolder> holderProvider) {
    return new BduiFeatureModule_Companion_ProvideInitialDocumentQueryFactory(holderProvider);
  }

  public static BduiDocumentQuery provideInitialDocumentQuery(BduiDocumentQueryHolder holder) {
    return Preconditions.checkNotNullFromProvides(BduiFeatureModule.Companion.provideInitialDocumentQuery(holder));
  }
}
