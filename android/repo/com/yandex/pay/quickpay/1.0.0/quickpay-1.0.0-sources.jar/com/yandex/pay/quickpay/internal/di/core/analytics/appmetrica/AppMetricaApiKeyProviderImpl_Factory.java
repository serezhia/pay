package com.yandex.pay.quickpay.internal.di.core.analytics.appmetrica;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class AppMetricaApiKeyProviderImpl_Factory implements Factory<AppMetricaApiKeyProviderImpl> {
  @Override
  public AppMetricaApiKeyProviderImpl get() {
    return newInstance();
  }

  public static AppMetricaApiKeyProviderImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static AppMetricaApiKeyProviderImpl newInstance() {
    return new AppMetricaApiKeyProviderImpl();
  }

  private static final class InstanceHolder {
    static final AppMetricaApiKeyProviderImpl_Factory INSTANCE = new AppMetricaApiKeyProviderImpl_Factory();
  }
}
