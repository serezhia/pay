package com.yandex.pay.quickpay.internal.di

import android.content.Context
import androidx.lifecycle.ViewModel
import com.yandex.fintechsdk.core.architecture.api.component.FintechComponentStore
import com.yandex.fintechsdk.core.ui.impl.api.activity.InsetsConfig
import com.yandex.fintechsdk.core.ui.impl.api.activity.InsetsConfigHolder
import com.yandex.fintechsdk.core.utils.api.session.SessionId
import com.yandex.fintechsdk.core.utils.api.session.SessionIdGenerator
import com.yandex.fintechsdk.entities.region.Region
import com.yandex.fintechsdk.entities.ui.BottomSheetMode
import com.yandex.pay.quickpay.api.QuickPayConfig
import com.yandex.pay.quickpay.api.QuickPaymentStateListener

internal class QuickPayComponentStore(
    config: QuickPayConfig,
    context: Context,
    region: Region,
    stateListener: QuickPaymentStateListener,
) : ViewModel(), FintechComponentStore {

    val insetsConfigHolder = InsetsConfigHolder(
        initialConfig = InsetsConfig(
            bottomSheetMode = BottomSheetMode.REGULAR,
        ),
    )

    override val component: QuickPayComponent = DaggerQuickPayComponent.factory().create(
        config = config,
        context = context,
        insetsConfigHolder = insetsConfigHolder,
        region = region,
        sessionId = SessionId(value = SessionIdGenerator().generate(merchantId = config.merchantId)),
        stateListener = stateListener,
    )
}
