package com.yandex.pay.quickpay.internal.di.adapters;

import com.yandex.fintechsdk.adapters.plus.sdk.api.PlusAdapter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlowAdaptersModule_ProvidePlusAdapterFactory implements Factory<PlusAdapter> {
  private final FlowAdaptersModule module;

  private FlowAdaptersModule_ProvidePlusAdapterFactory(FlowAdaptersModule module) {
    this.module = module;
  }

  @Override
  @Nullable
  public PlusAdapter get() {
    return providePlusAdapter(module);
  }

  public static FlowAdaptersModule_ProvidePlusAdapterFactory create(FlowAdaptersModule module) {
    return new FlowAdaptersModule_ProvidePlusAdapterFactory(module);
  }

  @Nullable
  public static PlusAdapter providePlusAdapter(FlowAdaptersModule instance) {
    return instance.providePlusAdapter();
  }
}
