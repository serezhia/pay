package com.yandex.pay.quickpay.internal.di

import android.content.Context
import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter
import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitDependencies
import com.yandex.fintechsdk.core.architecture.api.component.FintechComponent
import com.yandex.fintechsdk.core.architecture.api.feature.graph.FeatureGraphProvider
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.auth.api.dpop.DpopRepository
import com.yandex.fintechsdk.data.quickpay.api.orders.OrdersRepository
import com.yandex.fintechsdk.data.quickpay.api.settings.QuickPaySettingsRepository
import com.yandex.fintechsdk.core.utils.api.session.SessionId
import com.yandex.fintechsdk.data.quickpay.api.widget.QuickPayWidgetRepository
import com.yandex.fintechsdk.entities.region.Region
import com.yandex.fitnechsdk.adapters.login.sdk.api.LoginAdapter
import com.yandex.pay.quickpay.api.QuickPayConfig
import com.yandex.pay.quickpay.api.QuickPaymentStateListener
import com.yandex.pay.quickpay.internal.di.adapters.FlowAdaptersModule
import com.yandex.pay.quickpay.internal.di.core.FlowCoreModules
import com.yandex.pay.quickpay.internal.di.data.FlowDataModules
import com.yandex.pay.quickpay.internal.di.features.FlowFeaturesDependencies
import com.yandex.pay.quickpay.internal.di.features.FlowFeaturesModule
import com.yandex.pay.quickpay.internal.di.widget.QuickPayActionHandlersModule
import com.yandex.fintechsdk.core.navigation.impl.api.router.RouterImpl
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter
import com.yandex.pay.quickpay.internal.auth.AuthorizationManager
import com.yandex.pay.quickpay.internal.polling.PaymentProcessManager
import com.yandex.pay.quickpay.internal.presentation.UserFeedbackPresenter
import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder
import com.yandex.pay.quickpay.internal.widget.PaymentMethodsWidgetJsonLoader
import com.yandex.pay.quickpay.internal.widget.WidgetController
import dagger.BindsInstance
import dagger.Component
import kotlinx.coroutines.CoroutineScope

@Component(
    modules = [
        FlowAdaptersModule::class,
        FlowCoreModules::class,
        FlowDataModules::class,
        FlowFeaturesModule::class,
        QuickPayActionHandlersModule::class,
    ],
)
@FlowScope
internal interface QuickPayComponent : FintechComponent, FlowFeaturesDependencies {

    val analyticsReporter: QuickPayAnalyticsReporter

    override val authRepository: AuthRepository

    val authorizationManager: AuthorizationManager

    val userFeedbackPresenter: UserFeedbackPresenter

    val bottomSheetHolder: QuickPayBottomSheetHolder

    @get:ApplicationContext val context: Context

    val divKitAdapter: DivKitAdapter

    val divKitDependencies: DivKitDependencies

    val dpopRepository: DpopRepository

    val featureGraphProviders: Set<FeatureGraphProvider>

    @get:FlowCoroutineScope val flowCoroutineScope: CoroutineScope

    val loginAdapter: LoginAdapter

    val ordersRepository: OrdersRepository

    val paymentMethodsWidgetJsonLoader: PaymentMethodsWidgetJsonLoader

    val paymentProcessManager: PaymentProcessManager

    val quickPayWidgetRepository: QuickPayWidgetRepository

    override val router: RouterImpl

    val sessionId: SessionId

    val settingsRepository: QuickPaySettingsRepository

    val widgetController: WidgetController

    @Component.Factory
    interface Factory {
        fun create(
            @BindsInstance config: QuickPayConfig,
            @BindsInstance @ApplicationContext context: Context,
            @BindsInstance region: Region,
            @BindsInstance sessionId: SessionId,
            @BindsInstance stateListener: QuickPaymentStateListener,
        ): QuickPayComponent
    }
}
