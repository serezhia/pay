package com.yandex.pay.quickpay.internal.di.adapters.divkit;

import com.yandex.fintechsdk.adapters.divkit.sdk.api.version.DivKitVersionProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DivKitAdapterModule_ProvideDivKitVersionProviderFactory implements Factory<DivKitVersionProvider> {
  private final DivKitAdapterModule module;

  private DivKitAdapterModule_ProvideDivKitVersionProviderFactory(DivKitAdapterModule module) {
    this.module = module;
  }

  @Override
  public DivKitVersionProvider get() {
    return provideDivKitVersionProvider(module);
  }

  public static DivKitAdapterModule_ProvideDivKitVersionProviderFactory create(
      DivKitAdapterModule module) {
    return new DivKitAdapterModule_ProvideDivKitVersionProviderFactory(module);
  }

  public static DivKitVersionProvider provideDivKitVersionProvider(DivKitAdapterModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideDivKitVersionProvider());
  }
}
