package com.yandex.pay.quickpay.internal.di.features.bdui;

import com.yandex.fintechsdk.core.bdui.api.error.ErrorViewFactory;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiFeatureModule_Companion_ProvideErrorViewConfigFactory implements Factory<ErrorViewFactory> {
  @Override
  @Nullable
  public ErrorViewFactory get() {
    return provideErrorViewConfig();
  }

  public static BduiFeatureModule_Companion_ProvideErrorViewConfigFactory create() {
    return InstanceHolder.INSTANCE;
  }

  @Nullable
  public static ErrorViewFactory provideErrorViewConfig() {
    return BduiFeatureModule.Companion.provideErrorViewConfig();
  }

  private static final class InstanceHolder {
    static final BduiFeatureModule_Companion_ProvideErrorViewConfigFactory INSTANCE = new BduiFeatureModule_Companion_ProvideErrorViewConfigFactory();
  }
}
