package com.yandex.pay.quickpay.internal.di.features.error

import com.yandex.fintechsdk.features.error.api.dependencies.layout.ErrorLayoutOptions
import com.yandex.fintechsdk.features.error.api.dependencies.navigation.ErrorNavigator
import com.yandex.fintechsdk.features.error.api.di.ErrorModule
import com.yandex.pay.quickpay.internal.di.features.error.layout.ErrorLayoutOptionsImpl
import com.yandex.pay.quickpay.internal.di.features.error.navigation.ErrorNavigatorImpl
import dagger.Binds
import dagger.Module

@Module(
    includes = [ErrorModule::class],
)
internal interface ErrorFeatureModule {

    @Binds
    fun bindErrorNavigator(impl: ErrorNavigatorImpl): ErrorNavigator

    @Binds
    fun bindErrorLayoutOptions(impl: ErrorLayoutOptionsImpl): ErrorLayoutOptions
}

