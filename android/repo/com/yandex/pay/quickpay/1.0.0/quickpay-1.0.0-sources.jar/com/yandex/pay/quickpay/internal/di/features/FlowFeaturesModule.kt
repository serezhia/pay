package com.yandex.pay.quickpay.internal.di.features

import com.yandex.pay.quickpay.internal.di.auth.QuickPayAuthModule
import com.yandex.pay.quickpay.internal.di.features.bdui.BduiFeatureModule
import com.yandex.pay.quickpay.internal.di.features.error.ErrorFeatureModule
import dagger.Module

@Module(
    includes = [
        BduiFeatureModule::class,
        ErrorFeatureModule::class,
        QuickPayAuthModule::class,
    ],
)
internal interface FlowFeaturesModule

