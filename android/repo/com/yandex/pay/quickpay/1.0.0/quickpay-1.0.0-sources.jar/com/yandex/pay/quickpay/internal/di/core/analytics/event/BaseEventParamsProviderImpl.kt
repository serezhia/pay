package com.yandex.pay.quickpay.internal.di.core.analytics.event

import android.content.Context
import com.yandex.fintechsdk.core.analytics.api.event.BaseEventParamsProvider
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.utils.api.packagemanager.getAppVersion
import com.yandex.fintechsdk.core.utils.api.session.SessionId
import com.yandex.fintechsdk.core.utils.api.time.millisToSeconds
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.auth.api.AuthState
import com.yandex.fintechsdk.entities.region.Region
import com.yandex.pay.quickpay.BuildConfig
import com.yandex.pay.quickpay.api.QuickPayConfig
import com.yandex.pay.quickpay.api.YandexQuickPay
import javax.inject.Inject

internal class BaseEventParamsProviderImpl @Inject constructor(
    @ApplicationContext context: Context,
    private val authRepository: AuthRepository,
    private val config: QuickPayConfig,
    private val region: Region,
    private val sessionId: SessionId,
) : BaseEventParamsProvider {

    private val hostPackageName: String = context.applicationInfo.packageName
    private val hostAppVersion: String? = context.packageManager.getAppVersion(packageName = hostPackageName)

    override fun getParams(): Map<String, String> {
        return buildMap {
            put(KEY_EVENT_TIMESTAMP, (System.currentTimeMillis().millisToSeconds()).toString())
            put(KEY_PLATFORM, PLATFORM_ANDROID)
            put(KEY_SDK_VERSION, BuildConfig.VERSION_NAME)
            put(KEY_MERCHANT_ID, config.merchantId)
            put(KEY_HOST_APP, hostPackageName)
            put(KEY_IS_INTERNAL, false.toString())
            put(KEY_REGION, region.key)
            put(KEY_SESSION_ID, sessionId.value)
            put(KEY_SOURCE_SDK, QUICKPAY)

            hostAppVersion?.let { put(KEY_APP_VERSION, it) }
            getUid()?.let { put(KEY_UID, it.toString()) }
            getQuickPaymentEnabled()?.let { put(KEY_QUICK_PAYMENT_ENABLED, it.toString()) }
        }
    }

    private fun getUid(): Long? {
        val authState = authRepository.authState.value

        return when (authState) {
            is AuthState.Authorized -> authState.credentials.uid.takeIf { it != -1L }
            is AuthState.GotUid -> authState.uid
            AuthState.Initial,
            is AuthState.Unauthorized -> null
        }
    }

    private fun getQuickPaymentEnabled(): Boolean? {
        return YandexQuickPay.getLastNotifiedPaymentEnabledState()
    }

    private companion object {
        // Keys
        const val KEY_APP_VERSION = "app_version"
        const val KEY_EVENT_TIMESTAMP = "event_timestamp"
        const val KEY_QUICK_PAYMENT_ENABLED = "quick_payment_enabled"
        const val KEY_HOST_APP = "host_app"
        const val KEY_IS_INTERNAL = "is_internal"
        const val KEY_MERCHANT_ID = "merchant_id"
        const val KEY_PLATFORM = "platform"
        const val KEY_REGION = "region"
        const val KEY_SDK_VERSION = "sdk_version"
        const val KEY_SESSION_ID = "session_id"
        const val KEY_SOURCE_SDK = "source_sdk"
        const val KEY_UID = "uid"

        // Values
        const val PLATFORM_ANDROID = "android"
        const val QUICKPAY = "quickpay"
    }
}
