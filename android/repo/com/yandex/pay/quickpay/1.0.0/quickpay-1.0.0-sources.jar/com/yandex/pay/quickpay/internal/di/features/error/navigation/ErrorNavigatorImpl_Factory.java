package com.yandex.pay.quickpay.internal.di.features.error.navigation;

import com.yandex.pay.quickpay.api.QuickPaymentStateListener;
import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ErrorNavigatorImpl_Factory implements Factory<ErrorNavigatorImpl> {
  private final Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider;

  private final Provider<QuickPaymentStateListener> stateListenerProvider;

  private ErrorNavigatorImpl_Factory(Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider,
      Provider<QuickPaymentStateListener> stateListenerProvider) {
    this.bottomSheetHolderProvider = bottomSheetHolderProvider;
    this.stateListenerProvider = stateListenerProvider;
  }

  @Override
  public ErrorNavigatorImpl get() {
    return newInstance(bottomSheetHolderProvider.get(), stateListenerProvider.get());
  }

  public static ErrorNavigatorImpl_Factory create(
      Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider,
      Provider<QuickPaymentStateListener> stateListenerProvider) {
    return new ErrorNavigatorImpl_Factory(bottomSheetHolderProvider, stateListenerProvider);
  }

  public static ErrorNavigatorImpl newInstance(QuickPayBottomSheetHolder bottomSheetHolder,
      QuickPaymentStateListener stateListener) {
    return new ErrorNavigatorImpl(bottomSheetHolder, stateListener);
  }
}
