package com.yandex.pay.quickpay.internal.di.core.analytics.rum

import com.yandex.fintechsdk.core.analytics.impl.external.api.rum.RumConfiguration
import com.yandex.fintechsdk.core.analytics.impl.external.api.rum.RumConfigurationProvider
import javax.inject.Inject

internal class RumConfigurationProviderImpl @Inject constructor() : RumConfigurationProvider {

    override fun getConfiguration(): RumConfiguration? {
        return RumConfiguration(
            path = PATH,
            project = PROJECT,
            page = PAGE,
            service = SERVICE,
            rumId = RUM_ID,
        )
    }

    private companion object {
        const val PATH = "690.32"
        const val PROJECT = "pay"
        const val PAGE = "payment"
        const val SERVICE = "android"
        const val RUM_ID = "ru.pay"
    }
}

