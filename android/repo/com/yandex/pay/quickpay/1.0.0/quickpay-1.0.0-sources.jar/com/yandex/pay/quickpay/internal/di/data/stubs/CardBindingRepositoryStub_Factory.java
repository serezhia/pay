package com.yandex.pay.quickpay.internal.di.data.stubs;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CardBindingRepositoryStub_Factory implements Factory<CardBindingRepositoryStub> {
  @Override
  public CardBindingRepositoryStub get() {
    return newInstance();
  }

  public static CardBindingRepositoryStub_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static CardBindingRepositoryStub newInstance() {
    return new CardBindingRepositoryStub();
  }

  private static final class InstanceHolder {
    static final CardBindingRepositoryStub_Factory INSTANCE = new CardBindingRepositoryStub_Factory();
  }
}
