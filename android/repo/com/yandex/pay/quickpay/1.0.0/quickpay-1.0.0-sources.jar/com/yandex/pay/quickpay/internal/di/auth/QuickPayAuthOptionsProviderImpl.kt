package com.yandex.pay.quickpay.internal.di.auth

import com.yandex.fintechsdk.data.auth.api.AuthOptionsProvider
import javax.inject.Inject

internal class QuickPayAuthOptionsProviderImpl @Inject constructor() : AuthOptionsProvider {
    override fun isAuthTokenCachingEnabled(): Boolean = true
}

