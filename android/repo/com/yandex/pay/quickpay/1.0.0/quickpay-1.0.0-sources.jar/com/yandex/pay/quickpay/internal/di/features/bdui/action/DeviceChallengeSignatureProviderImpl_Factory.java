package com.yandex.pay.quickpay.internal.di.features.bdui.action;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DeviceChallengeSignatureProviderImpl_Factory implements Factory<DeviceChallengeSignatureProviderImpl> {
  @Override
  public DeviceChallengeSignatureProviderImpl get() {
    return newInstance();
  }

  public static DeviceChallengeSignatureProviderImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static DeviceChallengeSignatureProviderImpl newInstance() {
    return new DeviceChallengeSignatureProviderImpl();
  }

  private static final class InstanceHolder {
    static final DeviceChallengeSignatureProviderImpl_Factory INSTANCE = new DeviceChallengeSignatureProviderImpl_Factory();
  }
}
