package com.yandex.pay.quickpay.internal.di.data.stubs

import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository
import com.yandex.fintechsdk.data.card.api.binding.model.CardBindingCurrency
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeCardData
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeMethod
import com.yandex.fintechsdk.data.card.api.binding.model.TokenizeResult
import com.yandex.fintechsdk.entities.card.BinInfo
import kotlinx.serialization.json.JsonObject
import javax.inject.Inject

internal class CardBindingRepositoryStub @Inject constructor() : CardBindingRepository {

    override suspend fun initVerification(currency: CardBindingCurrency): Result<JsonObject> {
        return Result.failure(exception = NotImplementedError("Card binding not supported in QuickPay"))
    }

    override suspend fun tokenize(
        baseUrl: String,
        method: TokenizeMethod,
        data: TokenizeCardData,
        context: JsonObject,
    ): Result<TokenizeResult> {
        return Result.failure(exception = NotImplementedError("Card tokenization not supported in QuickPay"))
    }

    override suspend fun getBinInfo(baseUrl: String, prefix: String): Result<BinInfo> {
        return Result.failure(exception = NotImplementedError("BIN info not supported in QuickPay"))
    }
}

