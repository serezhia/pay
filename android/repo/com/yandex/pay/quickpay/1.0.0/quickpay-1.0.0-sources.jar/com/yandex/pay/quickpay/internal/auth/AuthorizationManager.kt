package com.yandex.pay.quickpay.internal.auth

import androidx.activity.result.ActivityResultCaller
import androidx.fragment.app.FragmentActivity
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.core.network.api.exception.NetworkException
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.auth.api.AuthState
import com.yandex.fintechsdk.data.auth.api.dpop.DpopRepository
import com.yandex.fintechsdk.entities.auth.AccountCredentials
import com.yandex.fitnechsdk.adapters.login.sdk.api.LoginAdapter
import com.yandex.fitnechsdk.adapters.login.sdk.api.auth.AuthLauncher
import com.yandex.pay.quickpay.api.QuickPayConfig
import com.yandex.pay.quickpay.api.YandexQuickPay
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsErrorKeys
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter
import com.yandex.pay.quickpay.internal.extensions.generateAuthSessionWithRedraw
import com.yandex.pay.quickpay.internal.presentation.UserFeedbackPresenter
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.firstOrNull
import java.net.HttpURLConnection
import javax.inject.Inject

/**
 * Manages authorization flow including OAuth, token generation and conflict handling.
 */
@FlowScope
internal class AuthorizationManager @Inject constructor(
    private val analyticsReporter: QuickPayAnalyticsReporter,
    private val authRepository: AuthRepository,
    private val dpopRepository: DpopRepository,
    private val loginAdapter: LoginAdapter,
    private val userFeedbackPresenter: UserFeedbackPresenter,
    private val config: QuickPayConfig,
) {

    private val authFinishedEventFlow: MutableSharedFlow<Unit> = MutableSharedFlow(
        replay = 0,
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    private var authLauncher: AuthLauncher? = null

    /**
     * Initializes auth launcher for the given activity.
     * Must be called before using authorization features.
     */
    fun initAuthLauncher(
        activityResultCaller: ActivityResultCaller,
        context: android.content.Context,
    ) {
        authLauncher = loginAdapter.createAuthLauncher(
            activityResultCaller = activityResultCaller,
            context = context,
        ) { token ->
            if (token == null) {
                analyticsReporter.reportAuthProcessFailed()
                return@createAuthLauncher
            }

            analyticsReporter.reportAuthProcessCompleted()

            authRepository.setAuthState(
                authState = AuthState.Authorized(
                    credentials = AccountCredentials(
                        token = token,
                        uid = -1,
                    ),
                ),
            )

            authFinishedEventFlow.tryEmit(Unit)
        }
    }

    /**
     * Ensures user is authorized. If not, launches OAuth flow and waits for result.
     *
     * @return Result with AuthState.Authorized or failure
     */
    suspend fun ensureAuthorized(): Result<AuthState.Authorized> {
        val currentState = authRepository.authState.value

        if (currentState is AuthState.Authorized) {
            return Result.success(currentState)
        }

        val launcher = authLauncher
            ?: return Result.failure(IllegalStateException(AUTH_LAUNCHER_NOT_INITIALIZED))

        analyticsReporter.reportAuthProcessStarted()
        launcher.launchAuth()

        // Wait until user finishes auth
        authFinishedEventFlow.firstOrNull()

        val newState = authRepository.authState.value
        return if (newState is AuthState.Authorized) {
            Result.success(newState)
        } else {
            analyticsReporter.reportAuthProcessFailed()
            Result.failure(IllegalStateException(AUTH_REQUIRED_ERROR_MSG))
        }
    }

    /**
     * Generates BST token with bind and biometric authentication.
     * Handles 409 Conflict by revoking token, clearing credentials and showing toast.
     * Clears OAuth credentials if token is invalid (401).
     *
     * @param activity Activity for biometric prompt
     * @param merchantId Merchant ID for session generation
     * @param withRedraw If true, triggers widget reload after BST generation
     * @return Result with BST token or error
     */
    suspend fun generateBst(
        activity: FragmentActivity,
        merchantId: String,
        withRedraw: Boolean,
    ): Result<String> {
        val authState = authRepository.authState.value as? AuthState.Authorized
            ?: return reportAndReturnFailure(IllegalStateException(AUTH_REQUIRED_ERROR_MSG))

        val bindResult = dpopRepository.bindAuth()

        if (bindResult.isFailure) {
            val error = bindResult.exceptionOrNull()
            if (error is NetworkException.BadCodeException) {
                when (error.code) {
                    HttpURLConnection.HTTP_CONFLICT -> {
                        return handleTokenConflict(
                            token = authState.credentials.token,
                            error = error,
                        )
                    }
                    HttpURLConnection.HTTP_UNAUTHORIZED -> {
                        YandexQuickPay.logout()
                        return reportAndReturnFailure(error)
                    }
                }
            }
            return reportAndReturnFailure(error ?: IllegalStateException(BIND_FAILED_ERROR_MSG))
        }

        val generateResult = if (withRedraw) {
            dpopRepository.generateAuthSessionWithRedraw(
                activity = activity,
                authToken = authState.credentials.token,
                merchantId = merchantId,
            )
        } else {
            dpopRepository.generateAuthSession(
                activity = activity,
                authToken = authState.credentials.token,
                merchantId = merchantId,
            )
        }

        return generateResult.onFailure { error ->
            if (error is NetworkException.BadCodeException &&
                error.code == HttpURLConnection.HTTP_UNAUTHORIZED) {
                YandexQuickPay.logout()
            }
            analyticsReporter.reportError(
                key = QuickPayAnalyticsErrorKeys.GENERATE_BST,
                throwable = error,
            )
        }
    }

    /**
     * Ensures BST is generated if user is authorized but BST is missing.
     * Does nothing if BST already exists or user is not authorized.
     *
     * @param activity Activity for biometric prompt
     * @param withRedraw If true, triggers widget reload after BST generation
     * @return Result with Unit on success or error
     */
    suspend fun ensureBstIfNeeded(
        activity: FragmentActivity,
        withRedraw: Boolean = false,
    ): Result<Unit> {
        val isAuthorized = authRepository.authState.value is AuthState.Authorized
        val hasCachedBst = dpopRepository.getCachedAuthSession() != null

        if (!isAuthorized || hasCachedBst) {
            return Result.success(Unit)
        }

        return generateBst(
            activity = activity,
            merchantId = config.merchantId,
            withRedraw = withRedraw,
        ).map { Unit }
    }

    /**
     * Handles 409 Conflict error by revoking token, clearing credentials
     * and showing a toast asking user to try again.
     */
    private suspend fun handleTokenConflict(
        token: String,
        error: Throwable,
    ): Result<String> {
        // 1. Revoke token on server
        dpopRepository.revokeToken(token)

        // 2. Clear credentials from local storage
        authRepository.clearCredentials()

        // 3. Report reauthorization required event to analytics
        analyticsReporter.reportReauthorizationRequired()

        // 4. Show toast to user
        userFeedbackPresenter.showReauthorizationRequired()

        // 5. Return error without additional reporting
        return Result.failure(error)
    }

    private fun reportAndReturnFailure(error: Throwable): Result<String> {
        analyticsReporter.reportError(
            key = QuickPayAnalyticsErrorKeys.GENERATE_BST,
            throwable = error,
        )
        return Result.failure(error)
    }

    private companion object {
        const val AUTH_LAUNCHER_NOT_INITIALIZED = "Auth launcher not initialized. Call initAuthLauncher() first."
        const val AUTH_REQUIRED_ERROR_MSG = "User is not authorized"
        const val BIND_FAILED_ERROR_MSG = "Failed to register device for quick payment"
    }
}
