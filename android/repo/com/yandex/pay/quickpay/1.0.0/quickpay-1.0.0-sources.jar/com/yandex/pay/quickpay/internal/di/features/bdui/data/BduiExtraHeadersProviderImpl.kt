package com.yandex.pay.quickpay.internal.di.features.bdui.data

import android.content.Context
import android.os.Build
import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraHeadersProvider
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.core.network.api.model.Header
import com.yandex.fintechsdk.core.network.impl.api.frontback.FrontbackServiceTokenProvider
import com.yandex.fintechsdk.core.utils.api.session.SessionId
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider
import com.yandex.fintechsdk.data.auth.api.dpop.DpopRepository
import com.yandex.fintechsdk.data.quickpay.api.MerchantIdProvider
import com.yandex.fintechsdk.entities.environment.PayEnvironment
import com.yandex.pay.quickpay.BuildConfig
import com.yandex.pay.quickpay.api.YandexQuickPay
import com.yandex.pay.quickpay.internal.extensions.toLanguageCode
import dagger.Lazy
import javax.inject.Inject

@FlowScope
internal class BduiExtraHeadersProviderImpl @Inject constructor(
    @ApplicationContext context: Context,
    private val dpopRepository: Lazy<DpopRepository>,
    private val environment: PayEnvironment,
    private val frontbackServiceTokenProvider: FrontbackServiceTokenProvider,
    private val merchantIdProvider: MerchantIdProvider,
    private val sessionId: SessionId,
    private val userAgentProvider: UserAgentProvider,
) : BduiExtraHeadersProvider {

    private val packageName = context.packageName
    private val appVersion = context.packageManager.getPackageInfo(packageName, 0).versionName ?: ""

    private var extraHeaders: Map<String, String> = emptyMap()

    override fun getHeaders(): Map<String, String> = getBaseHeaders() + extraHeaders

    fun addExtraHeaders(headers: Map<String, String>) {
        extraHeaders = extraHeaders + headers.filterKeys { it !in extraHeaders }
    }

    fun clearExtraHeaders() {
        extraHeaders = emptyMap()
    }

    private fun getBaseHeaders(): Map<String, String> {
        val androidVersion = Build.VERSION.SDK_INT.toString()
        val language = YandexQuickPay.locale.toLanguageCode()
        val sdkVersion = BuildConfig.VERSION_NAME
        val serviceToken = frontbackServiceTokenProvider.getServiceToken(environment)

        return buildMap {
            put(Header.Accept.key, ACCEPT_AND_CONTENT_TYPE_HEADER_VALUE)
            put(Header.AcceptLanguage.key, language)
            put(Header.ClientApp.key, packageName)
            put(Header.ClientVersion.key, appVersion)
            put(Header.ContentType.key, ACCEPT_AND_CONTENT_TYPE_HEADER_VALUE)
            put(Header.MerchantId.key, merchantIdProvider.getMerchantId())
            put(Header.PlatformVersion.key, androidVersion)
            put(Header.SdkPlatform.key, SDK_PLATFORM_HEADER_VALUE)
            put(Header.SdkType.key, SDK_TYPE_HEADER_VALUE)
            put(Header.SdkVersion.key, sdkVersion)
            put(Header.ServiceToken.key, serviceToken)
            put(Header.SessionId.key, sessionId.value)
            put(Header.UserAgent.key, userAgentProvider.get())

            dpopRepository.get().getCachedAuthSession()?.let { bst ->
                put(Header.Bst.key, bst)
            }
        }
    }

    private companion object {
        private const val ACCEPT_AND_CONTENT_TYPE_HEADER_VALUE = "application/json"
        private const val SDK_PLATFORM_HEADER_VALUE = "android"
        private const val SDK_TYPE_HEADER_VALUE = "quickpay"
    }
}
