package com.yandex.pay.quickpay.internal.di.features.bdui.theme;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiThemeProviderImpl_Factory implements Factory<BduiThemeProviderImpl> {
  private final Provider<Context> contextProvider;

  private BduiThemeProviderImpl_Factory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public BduiThemeProviderImpl get() {
    return newInstance(contextProvider.get());
  }

  public static BduiThemeProviderImpl_Factory create(Provider<Context> contextProvider) {
    return new BduiThemeProviderImpl_Factory(contextProvider);
  }

  public static BduiThemeProviderImpl newInstance(Context context) {
    return new BduiThemeProviderImpl(context);
  }
}
