package com.yandex.pay.quickpay.api

/**
 * Represents whether quick payment is enabled for the current user
 */
@JvmInline
public value class IsPaymentEnabled(public val value: Boolean)
