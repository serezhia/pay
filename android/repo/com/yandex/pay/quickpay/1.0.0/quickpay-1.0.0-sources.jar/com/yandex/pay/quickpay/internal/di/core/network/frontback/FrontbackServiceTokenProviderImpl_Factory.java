package com.yandex.pay.quickpay.internal.di.core.network.frontback;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FrontbackServiceTokenProviderImpl_Factory implements Factory<FrontbackServiceTokenProviderImpl> {
  @Override
  public FrontbackServiceTokenProviderImpl get() {
    return newInstance();
  }

  public static FrontbackServiceTokenProviderImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static FrontbackServiceTokenProviderImpl newInstance() {
    return new FrontbackServiceTokenProviderImpl();
  }

  private static final class InstanceHolder {
    static final FrontbackServiceTokenProviderImpl_Factory INSTANCE = new FrontbackServiceTokenProviderImpl_Factory();
  }
}
