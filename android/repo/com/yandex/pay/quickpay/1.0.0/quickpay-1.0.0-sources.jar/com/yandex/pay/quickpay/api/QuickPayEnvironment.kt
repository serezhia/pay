package com.yandex.pay.quickpay.api

/**
 * Defines the environment for
 */
public enum class QuickPayEnvironment {
    /**
     * Production environment
     * Processes real payments
     */
    PRODUCTION,

    /**
     * Sandbox environment
     * FOR TESTING PURPOSES ONLY. Does not process real payments
     */
    SANDBOX,
}

