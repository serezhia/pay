package com.yandex.pay.quickpay.internal.di.adapters

import com.yandex.finsdtechsdk.adapters.passport.sdk.api.PassportAdapter
import com.yandex.fintechsdk.adapters.yb.sdk.api.YbAdapter
import com.yandex.fintechsdk.adapters.plus.sdk.api.PlusAdapter
import com.yandex.pay.quickpay.internal.di.adapters.divkit.DivKitAdapterModule
import com.yandex.pay.quickpay.internal.di.adapters.flex.FlexAdapterModule
import com.yandex.pay.quickpay.internal.di.adapters.login.LoginAdapterModule
import dagger.Module
import dagger.Provides

@Module(
    includes = [
        DivKitAdapterModule::class,
        FlexAdapterModule::class,
        LoginAdapterModule::class,
    ],
)
internal class FlowAdaptersModule {

    @Provides
    fun provideYbAdapter(): YbAdapter? = null

    @Provides
    fun providePassportAdapter(): PassportAdapter? = null

    @Provides
    fun providePlusAdapter(): PlusAdapter? = null
}
