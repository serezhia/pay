package com.yandex.pay.quickpay.internal.di.features.bdui.navigation;

import com.yandex.fintechsdk.core.navigation.api.Router;
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter;
import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiNavigatorImpl_Factory implements Factory<BduiNavigatorImpl> {
  private final Provider<Router> routerProvider;

  private final Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider;

  private final Provider<QuickPayAnalyticsReporter> analyticsReporterProvider;

  private BduiNavigatorImpl_Factory(Provider<Router> routerProvider,
      Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider,
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider) {
    this.routerProvider = routerProvider;
    this.bottomSheetHolderProvider = bottomSheetHolderProvider;
    this.analyticsReporterProvider = analyticsReporterProvider;
  }

  @Override
  public BduiNavigatorImpl get() {
    return newInstance(routerProvider.get(), bottomSheetHolderProvider.get(), analyticsReporterProvider.get());
  }

  public static BduiNavigatorImpl_Factory create(Provider<Router> routerProvider,
      Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider,
      Provider<QuickPayAnalyticsReporter> analyticsReporterProvider) {
    return new BduiNavigatorImpl_Factory(routerProvider, bottomSheetHolderProvider, analyticsReporterProvider);
  }

  public static BduiNavigatorImpl newInstance(Router router,
      QuickPayBottomSheetHolder bottomSheetHolder, QuickPayAnalyticsReporter analyticsReporter) {
    return new BduiNavigatorImpl(router, bottomSheetHolder, analyticsReporter);
  }
}
