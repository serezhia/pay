package com.yandex.pay.quickpay.internal.di.features.error.navigation

import com.yandex.fintechsdk.features.error.api.dependencies.navigation.ErrorNavigator
import com.yandex.pay.quickpay.api.QuickPayResult
import com.yandex.pay.quickpay.api.QuickPaymentStateListener
import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder
import javax.inject.Inject

internal class ErrorNavigatorImpl @Inject constructor(
    private val bottomSheetHolder: QuickPayBottomSheetHolder,
    private val stateListener: QuickPaymentStateListener,
) : ErrorNavigator {

    override fun back() {
        stateListener.onPaymentResult(quickpayResult = QuickPayResult.Failure)
        bottomSheetHolder.close()
    }

    override fun toNextScreen() {
        bottomSheetHolder.close()
    }
}

