package com.yandex.pay.quickpay.api

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.findViewTreeLifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.yandex.pay.quickpay.internal.widget.BaseWidgetController
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

public abstract class BaseQuickPayWidget @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    private var reloadSubscriptionJob: Job? = null
    private var hideSubscriptionJob: Job? = null
    private var refreshJob: Job? = null

    internal open val refreshIntervalMs: Long = 0L

    internal abstract fun getController(): BaseWidgetController?
    internal abstract fun reportLoadError(throwable: Throwable)

    init {
        visibility = GONE
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (getController() == null) {
            throw IllegalStateException(YandexQuickPay.NOT_INITED_ERROR_MSG)
        }
        loadWidget()
        subscribeToReloadTrigger()
        subscribeToHideTrigger()
        startPeriodicRefresh()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        reloadSubscriptionJob?.cancel()
        reloadSubscriptionJob = null
        hideSubscriptionJob?.cancel()
        hideSubscriptionJob = null
        refreshJob?.cancel()
        refreshJob = null
    }

    private fun subscribeToReloadTrigger() {
        val lifecycleOwner = findViewTreeLifecycleOwner() ?: return
        val controller = getController() ?: return

        reloadSubscriptionJob = lifecycleOwner.lifecycleScope.launch {
            controller.reloadTrigger.collect {
                loadWidget()
            }
        }
    }

    private fun subscribeToHideTrigger() {
        val lifecycleOwner = findViewTreeLifecycleOwner() ?: return
        val controller = getController() ?: return

        hideSubscriptionJob = lifecycleOwner.lifecycleScope.launch {
            controller.hideTrigger.collect {
                removeAllViews()
                visibility = GONE
            }
        }
    }

    private fun startPeriodicRefresh() {
        if (refreshIntervalMs <= 0L) return
        val lifecycleOwner = findViewTreeLifecycleOwner() ?: return

        refreshJob = lifecycleOwner.lifecycleScope.launch {
            lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    delay(refreshIntervalMs)
                    loadWidget()
                }
            }
        }
    }

    private fun loadWidget() {
        val controller = getController() ?: return

        val lifecycleOwner = findViewTreeLifecycleOwner()
        val scope = lifecycleOwner?.lifecycleScope ?: return

        scope.launch {
            controller.loadWidget()
                .fold(
                    onSuccess = { view: View ->
                        removeAllViews()
                        addView(view)
                        visibility = VISIBLE
                    },
                    onFailure = { throwable: Throwable ->
                        removeAllViews()
                        visibility = GONE
                        reportLoadError(throwable)
                    },
                )
        }
    }
}
