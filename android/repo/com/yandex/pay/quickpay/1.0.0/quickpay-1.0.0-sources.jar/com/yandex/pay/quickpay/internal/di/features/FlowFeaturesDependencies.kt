package com.yandex.pay.quickpay.internal.di.features

import com.yandex.fintechsdk.features.bdui.api.dependencies.BduiDependencies
import com.yandex.fintechsdk.features.error.api.dependencies.ErrorDependencies

internal interface FlowFeaturesDependencies : BduiDependencies, ErrorDependencies
