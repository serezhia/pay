package com.yandex.pay.quickpay.api

import android.annotation.SuppressLint
import android.app.Application
import android.os.Build
import androidx.annotation.ChecksSdkIntAtLeast
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import com.yandex.fintechsdk.data.auth.api.AuthState
import com.yandex.pay.quickpay.BuildConfig
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsErrorKeys
import com.yandex.pay.quickpay.internal.delegate.QuickPayDelegate
import com.yandex.pay.quickpay.internal.di.QuickPayComponent
import com.yandex.pay.quickpay.internal.extensions.generateAuthSessionWithRedraw
import com.yandex.fintechsdk.core.security.api.biometric.AuthenticationStatus
import com.yandex.pay.quickpay.internal.widget.WidgetController
import java.lang.ref.WeakReference

/**
 * Entry point for Yandex Quick Payment SDK
 */
public object YandexQuickPay {
    /**
     * Yandex Quick Payment SDK library version
     */
    public const val LIBRARY_VERSION: String = BuildConfig.VERSION_NAME

    /**
     * Yandex Quick Payment SDK localization
     */
    public var locale: QuickPayLocale = QuickPayLocale.SYSTEM

    /**
     * Yandex Quick Payment theme for screens
     */
    public var theme: QuickPayThemeColorScheme = QuickPayThemeColorScheme.SYSTEM

    /**
     * Check Yandex Quick Payment accessibility on this device
     */
    public val isSupported: Boolean
        @SuppressLint("ObsoleteSdkInt")
        @ChecksSdkIntAtLeast(api = Build.VERSION_CODES.N)
        get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N

    @Volatile
    internal var activityRef: WeakReference<FragmentActivity>? = null

    @Volatile
    private var applicationContext: Application? = null

    @Volatile
    private var quickpayConfig: QuickPayConfig? = null

    @Volatile
    private var stateListenerRef: WeakReference<QuickPaymentStateListener>? = null

    @Volatile
    private var delegate: QuickPayDelegate? = null

    @Volatile
    internal var widgetController: WidgetController? = null

    @Volatile
    private var fragmentManagerRef: WeakReference<FragmentManager>? = null

    private val component: QuickPayComponent?
        get() = delegate?.componentStore?.component

    /**
     * Initialize SDK
     *
     * Can be called multiple times to update configuration and listener.
     * The listener is stored as a WeakReference to prevent memory leaks.
     *
     * @param context Application context
     * @param config SDK configuration
     * @param quickPaymentStateListener Listener for payment state changes.
     *        Keep a strong reference to this listener to prevent it from being garbage collected.
     */
    public fun initialize(
        config: QuickPayConfig,
        context: Application,
        quickPaymentStateListener: QuickPaymentStateListener,
    ) {
        synchronized(this) {
            applicationContext = context
            quickpayConfig = config
            stateListenerRef = WeakReference(quickPaymentStateListener)
            delegate = QuickPayDelegate(
                application = context,
                config = config,
                stateListener = quickPaymentStateListener,
            )
            widgetController = delegate?.getWidgetController()
        }
    }

    /**
     * Initialize UI components
     *
     * @param activity Needed for starting auth and biometric prompt
     * @param fragmentManager FragmentManager for showing bottom sheets
     */
    public suspend fun initUi(
        activity: FragmentActivity,
        fragmentManager: FragmentManager,
    ) {
        activityRef = WeakReference(activity)
        fragmentManagerRef = WeakReference(fragmentManager)

        val component = component ?: return

        // Initialize auth launcher
        component.authorizationManager.initAuthLauncher(
            activityResultCaller = activity,
            context = component.context,
        )
    }

    /**
     * Check if quick payment is enabled for current user
     *
     * @return Current payment enabled state, false if request fails
     * @throws IllegalStateException if not initialized
     */
    public suspend fun isQuickPaymentEnabled(): IsPaymentEnabled {
        val component = component ?: throw IllegalStateException(NOT_INITED_ERROR_MSG)

        val cachedState = component.settingsRepository.getLocalEnabledState()
        if (cachedState != null) {
            return IsPaymentEnabled(value = cachedState)
        }

        runCatching {
            val activity = activityRef?.get() ?: return@runCatching
            component.authorizationManager.ensureBstIfNeeded(
                activity = activity,
                withRedraw = false,
            )
        }.onFailure { error ->
            component.analyticsReporter.reportError(
                key = QuickPayAnalyticsErrorKeys.GENERATE_BST,
                throwable = error,
            )
        }

        val settings = component.settingsRepository.getSettingsFromBackend().getOrNull()
        val isEnabled = settings?.isEnabled ?: false

        component.settingsRepository.saveLocalEnabledState(isEnabled = isEnabled)

        return IsPaymentEnabled(value = isEnabled)
    }

    /**
     * Enable quick payment for user
     * Shows biometric prompt or login if needed
     *
     * @return Result of the operation
     * @throws IllegalStateException if not initialized
     */
    public suspend fun enableQuickPayment(): Result<Unit> {
        return runCatching {
            val activity = activityRef?.get() ?: throw IllegalStateException(NOT_INITED_ERROR_MSG)
            val component = component ?: throw IllegalStateException(NOT_INITED_ERROR_MSG)
            val merchantId = quickpayConfig?.merchantId ?: throw IllegalStateException(NOT_INITED_ERROR_MSG)

            // Check authentication availability (biometric OR device credential) and show error to user if needed
            when (component.userFeedbackPresenter.checkBiometricAndShowErrorIfNeeded()) {
                AuthenticationStatus.NoHardware -> {
                    throw IllegalStateException(AUTH_NO_HARDWARE_ERROR_MSG)
                }
                AuthenticationStatus.NotEnrolled -> {
                    throw IllegalStateException(AUTH_NOT_ENROLLED_ERROR_MSG)
                }
                AuthenticationStatus.Unavailable -> {
                    throw IllegalStateException(AUTH_UNAVAILABLE_ERROR_MSG)
                }
                AuthenticationStatus.Available -> {
                    // Continue with the flow
                }
            }

            component.analyticsReporter.reportMainScreenConnectButtonClicked()

            // Ensure user is authorized (will launch OAuth if needed)
            component.authorizationManager.ensureAuthorized().getOrThrow()

            component.authorizationManager.generateBst(
                activity = activity,
                merchantId = merchantId,
                withRedraw = false,
            ).getOrThrow()

            component.settingsRepository.updateSettingsOnBackend(
                isEnabled = true,
                selectedMethod = null,
            ).getOrThrow()

            notifyPaymentEnabledStateChanged(isEnabled = true)

            widgetController?.triggerReload()
            Unit
        }.also { result ->
            result.exceptionOrNull()?.let { error ->
                component?.analyticsReporter?.reportError(
                    key = QuickPayAnalyticsErrorKeys.ENABLE_QUICK_PAYMENT,
                    throwable = error,
                )
            }
        }
    }

    /**
     * Disable quick payment for user
     *
     * @return Result of the operation
     * @throws IllegalStateException if not initialized
     */
    public suspend fun disableQuickPayment(): Result<Unit> {
        return runCatching {
            val component = component ?: throw IllegalStateException(NOT_INITED_ERROR_MSG)

            // Auto-generate BST if OAuth exists but BST is missing
            runCatching {
                val activity = activityRef?.get() ?: return@runCatching
                component.authorizationManager.ensureBstIfNeeded(
                    activity = activity,
                    withRedraw = false,
                )
            }.onFailure { error ->
                component.analyticsReporter.reportError(
                    key = QuickPayAnalyticsErrorKeys.GENERATE_BST,
                    throwable = error,
                )
            }

            component.settingsRepository.updateSettingsOnBackend(
                isEnabled = false,
                selectedMethod = null,
            ).getOrThrow()

            notifyPaymentEnabledStateChanged(isEnabled = false)

            widgetController?.triggerReload()
            Unit
        }.also { result ->
            result.exceptionOrNull()?.let { error ->
                component?.analyticsReporter?.reportError(
                    key = QuickPayAnalyticsErrorKeys.DISABLE_QUICK_PAYMENT,
                    throwable = error,
                )
            }
        }
    }

    /**
     * Logout user and clear all stored credentials
     *
     * After calling this method, user will need to re-authorize
     * via [enableQuickPayment] to use quick payment again.
     */
    public fun logout() {
        component?.paymentProcessManager?.stopPolling()
        component?.authRepository?.clearCredentials()
        component?.dpopRepository?.clearCachedAuthSession()
        component?.settingsRepository?.clearLocalEnabledState()
        notifyPaymentEnabledStateChanged(isEnabled = false)
        widgetController?.triggerReload()
    }

    /**
     * Create new payment session or get it if not expired
     * Shows biometric prompt if needed
     *
     * @return Payment session ID
     * @throws IllegalStateException if not initialized
     * @throws RuntimeException if payment session creation fails
     */
    public suspend fun getPaymentSessionId(): String {
        try {
        val component = component ?: throw RuntimeException(NOT_INITED_ERROR_MSG)
        val activity = activityRef?.get() ?: throw IllegalStateException(ACTIVITY_NOT_AVAILABLE_ERROR_MSG)
        val authState = component.authRepository.authState.value

        if (authState !is AuthState.Authorized) {
            throw IllegalStateException(USER_NOT_AUTHORIZED_ERROR_MSG)
        }

        val merchantId = quickpayConfig?.merchantId
            ?: throw RuntimeException("SDK not initialized")

        // Clear previous session extras before creating new BST
        component.bottomSheetHolder.clearExtras()

        val bst = component.dpopRepository.generateAuthSessionWithRedraw(
            activity = activity,
            authToken = authState.credentials.token,
            merchantId = merchantId,
        ).getOrElse { error ->
            throw RuntimeException(BST_GENERATION_ERROR_MSG.format(error.message), error)
        }

        // Start orders polling
        delegate?.startOrderPolling()

        return bst
        } catch (error: Throwable) {
            component?.analyticsReporter?.reportError(
                key = QuickPayAnalyticsErrorKeys.GET_PAYMENT_SESSION,
                throwable = error,
            )
            throw error
        }
    }

    /**
     * Get current state listener
     *
     * @return Current listener or null if it was garbage collected
     */
    internal fun getStateListener(): QuickPaymentStateListener? = stateListenerRef?.get()

    /**
     * Get FragmentManager for internal use
     *
     * @return FragmentManager or null if not initialized or garbage collected
     */
    internal fun getFragmentManager(): FragmentManager? = fragmentManagerRef?.get()

    /**
     * Get last notified payment enabled state for analytics
     *
     * @return Current payment enabled state or null if not set
     */
    internal fun getLastNotifiedPaymentEnabledState(): Boolean? =
        component?.settingsRepository?.getLocalEnabledState()

    /**
     * Notify state listener about payment enabled state change.
     * Only notifies if the state actually changed to avoid duplicate callbacks.
     */
    internal fun notifyPaymentEnabledStateChanged(isEnabled: Boolean) {
        val lastState = getLastNotifiedPaymentEnabledState()

        if (lastState != isEnabled) {
            component?.settingsRepository?.saveLocalEnabledState(isEnabled = isEnabled)
            stateListenerRef?.get()?.onPaymentEnabledStateChanged(IsPaymentEnabled(value = isEnabled))
        }
    }

    internal fun reportWidgetLoadError(throwable: Throwable) {
        component?.analyticsReporter?.reportError(
            key = QuickPayAnalyticsErrorKeys.LOAD_WIDGET,
            throwable = throwable,
        )
    }

    internal const val NOT_INITED_ERROR_MSG = "YandexQuickPay must be " +
        "initialized before use. Call initialize() first."

    private const val ACTIVITY_NOT_AVAILABLE_ERROR_MSG = "Activity not available"
    private const val USER_NOT_AUTHORIZED_ERROR_MSG = "User is not authorized. Call enableQuickPayment() first."
    private const val BST_GENERATION_ERROR_MSG = "Failed to generate session: %s"
    private const val AUTH_NO_HARDWARE_ERROR_MSG = "Device does not have authentication hardware (biometric or device lock)"
    private const val AUTH_NOT_ENROLLED_ERROR_MSG = "Authentication not enrolled on device (biometric or device lock)"
    private const val AUTH_UNAVAILABLE_ERROR_MSG = "Authentication unavailable"
}
