package com.yandex.pay.quickpay.internal.di.features.bdui;

import com.yandex.fintechsdk.core.ui.impl.api.activity.InsetsConfig;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiFeatureModule_Companion_ProvideInsetsConfigFactory implements Factory<InsetsConfig> {
  @Override
  public InsetsConfig get() {
    return provideInsetsConfig();
  }

  public static BduiFeatureModule_Companion_ProvideInsetsConfigFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static InsetsConfig provideInsetsConfig() {
    return Preconditions.checkNotNullFromProvides(BduiFeatureModule.Companion.provideInsetsConfig());
  }

  private static final class InstanceHolder {
    static final BduiFeatureModule_Companion_ProvideInsetsConfigFactory INSTANCE = new BduiFeatureModule_Companion_ProvideInsetsConfigFactory();
  }
}
