package com.yandex.pay.quickpay.internal.di.adapters.flex

import com.yandex.fintechsdk.adapters.flex.sdk.api.FlexAdapter
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.core.utils.api.adapter.AdapterFinder
import dagger.Module
import dagger.Provides

@Module
internal interface FlexAdapterModule {

    companion object {
        @FlowScope
        @Provides
        fun provideFlexAdapter(adapterFinder: AdapterFinder): FlexAdapter? {
            return adapterFinder.find(
                adapterClass = FlexAdapter::class.java,
                factoryClassName = "com.yandex.fintechsdk.adapters.flex.sdk.impl.FlexAdapterFactory",
            )
        }
    }
}
