package com.yandex.pay.quickpay.internal.di.core.network.auth;

import com.yandex.fintechsdk.data.auth.api.AuthRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class AuthTokenProviderImpl_Factory implements Factory<AuthTokenProviderImpl> {
  private final Provider<AuthRepository> authRepositoryProvider;

  private AuthTokenProviderImpl_Factory(Provider<AuthRepository> authRepositoryProvider) {
    this.authRepositoryProvider = authRepositoryProvider;
  }

  @Override
  public AuthTokenProviderImpl get() {
    return newInstance(authRepositoryProvider.get());
  }

  public static AuthTokenProviderImpl_Factory create(
      Provider<AuthRepository> authRepositoryProvider) {
    return new AuthTokenProviderImpl_Factory(authRepositoryProvider);
  }

  public static AuthTokenProviderImpl newInstance(AuthRepository authRepository) {
    return new AuthTokenProviderImpl(authRepository);
  }
}
