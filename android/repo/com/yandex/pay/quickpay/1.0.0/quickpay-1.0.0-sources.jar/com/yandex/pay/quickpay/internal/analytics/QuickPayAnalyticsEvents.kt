package com.yandex.pay.quickpay.internal.analytics

import com.yandex.fintechsdk.core.analytics.api.event.Event

internal sealed class QuickPayAnalyticsEvent(
    name: String,
    params: Map<String, String> = emptyMap(),
) : Event(name = name, params = params) {

    /**
     * User sees screen with quick payment offer or with toggle
     * Should be called on widget load and on SDK state changes
     */
    class MainScreenOpened(
        source: String,
        puid: Long?,
    ) : QuickPayAnalyticsEvent(
        name = EVENT_MAIN_SCREEN_OPENED,
        params = buildMap {
            put(PARAM_SOURCE, source)
            puid?.let { put(PARAM_PUID, it.toString()) }
        },
    )

    /**
     * User clicks "Connect" button on the offer screen
     */
    data object MainScreenConnectButtonClicked : QuickPayAnalyticsEvent(
        name = EVENT_MAIN_SCREEN_CONNECT_BUTTON_CLICKED,
    )

    /**
     * Authorization process started
     */
    data object AuthProcessStarted : QuickPayAnalyticsEvent(
        name = EVENT_AUTH_PROCESS_STARTED,
    )

    /**
     * User successfully authorized and granted access
     */
    data object AuthProcessCompleted : QuickPayAnalyticsEvent(
        name = EVENT_AUTH_PROCESS_COMPLETED,
    )

    /**
     * Authorization process was interrupted at any step
     */
    class AuthProcessFailed(
        reason: String? = null,
    ) : QuickPayAnalyticsEvent(
        name = EVENT_AUTH_PROCESS_FAILED,
        params = buildMap {
            reason?.let { put(PARAM_REASON, it) }
        },
    )

    /**
     * Payment completed successfully
     */
    data object PaymentProcessCompleted : QuickPayAnalyticsEvent(
        name = EVENT_PAYMENT_PROCESS_COMPLETED,
    )

    /**
     * Payment failed at any step
     */
    data object PaymentProcessFailed : QuickPayAnalyticsEvent(
        name = EVENT_PAYMENT_PROCESS_FAILED,
    )

    /**
     * Payment bottom sheet was closed/swiped away
     */
    data object PaymentProcessScreenClosed : QuickPayAnalyticsEvent(
        name = EVENT_PAYMENT_PROCESS_SCREEN_CLOSED,
    )

    /**
     * BST token expired (401/1004)
     */
    data object TokenExpired : QuickPayAnalyticsEvent(
        name = EVENT_TOKEN_EXPIRED,
    )

    /**
     * Re-authorization required due to 409 Conflict (token binding conflict)
     */
    data object ReauthorizationRequired : QuickPayAnalyticsEvent(
        name = EVENT_REAUTHORIZATION_REQUIRED,
    )

    companion object {
        // Event names
        private const val EVENT_MAIN_SCREEN_OPENED = "Main_Screen_Opened"
        private const val EVENT_MAIN_SCREEN_CONNECT_BUTTON_CLICKED = "Main_Screen_Connect_Button_Clicked"
        private const val EVENT_AUTH_PROCESS_STARTED = "Auth_Process_Started"
        private const val EVENT_AUTH_PROCESS_COMPLETED = "Auth_Process_Completed"
        private const val EVENT_AUTH_PROCESS_FAILED = "Auth_Process_Failed"
        private const val EVENT_PAYMENT_PROCESS_COMPLETED = "Payment_Process_Completed"
        private const val EVENT_PAYMENT_PROCESS_FAILED = "Payment_Process_Failed"
        private const val EVENT_PAYMENT_PROCESS_SCREEN_CLOSED = "Payment_Process_Screen_Closed"
        private const val EVENT_TOKEN_EXPIRED = "Token_Expired"
        private const val EVENT_REAUTHORIZATION_REQUIRED = "Reauthorization_Required"

        // Parameter keys
        private const val PARAM_SOURCE = "source"
        private const val PARAM_PUID = "puid"
        private const val PARAM_REASON = "reason"
    }
}
