package com.yandex.pay.quickpay.internal.analytics

import com.yandex.fintechsdk.core.analytics.api.Analytics
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.auth.api.AuthState
import javax.inject.Inject

@FlowScope
internal class QuickPayAnalyticsReporter @Inject constructor(
    private val analytics: Analytics,
    private val authRepository: AuthRepository,
) {

    fun reportMainScreenOpened(source: String) {
        val puid = getUid()

        analytics.reportProductEvent(
            QuickPayAnalyticsEvent.MainScreenOpened(
                source = source,
                puid = puid,
            ),
        )
    }

    fun reportMainScreenConnectButtonClicked() {
        analytics.reportProductEvent(QuickPayAnalyticsEvent.MainScreenConnectButtonClicked)
    }

    fun reportAuthProcessStarted() {
        analytics.reportProductEvent(QuickPayAnalyticsEvent.AuthProcessStarted)
    }

    fun reportAuthProcessCompleted() {
        analytics.reportProductEvent(QuickPayAnalyticsEvent.AuthProcessCompleted)
    }

    fun reportAuthProcessFailed(reason: String? = null) {
        analytics.reportProductEvent(
            QuickPayAnalyticsEvent.AuthProcessFailed(reason = reason),
        )
    }

    fun reportPaymentProcessCompleted() {
        analytics.reportProductEvent(QuickPayAnalyticsEvent.PaymentProcessCompleted)
    }

    fun reportPaymentProcessFailed() {
        analytics.reportProductEvent(QuickPayAnalyticsEvent.PaymentProcessFailed)
    }

    fun reportPaymentProcessScreenClosed() {
        analytics.reportProductEvent(QuickPayAnalyticsEvent.PaymentProcessScreenClosed)
    }

    fun reportTokenExpired() {
        analytics.reportProductEvent(QuickPayAnalyticsEvent.TokenExpired)
    }

    fun reportReauthorizationRequired() {
        analytics.reportProductEvent(QuickPayAnalyticsEvent.ReauthorizationRequired)
    }

    fun reportError(key: String, throwable: Throwable) {
        analytics.reportRuntimeError(key = key, exception = throwable)
    }

    private fun getUid(): Long? {
        val authState = authRepository.authState.value

        return when (authState) {
            is AuthState.Authorized -> authState.credentials.uid.takeIf { it != -1L }
            is AuthState.GotUid -> authState.uid
            AuthState.Initial,
            is AuthState.Unauthorized -> null
        }
    }
}
