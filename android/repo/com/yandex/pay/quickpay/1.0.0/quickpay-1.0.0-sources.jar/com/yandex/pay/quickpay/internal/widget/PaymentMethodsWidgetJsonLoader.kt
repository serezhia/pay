package com.yandex.pay.quickpay.internal.widget

import com.yandex.fintechsdk.adapters.divkit.sdk.api.loader.DivViewJsonLoader
import com.yandex.fintechsdk.data.quickpay.api.widget.QuickPayWidgetRepository
import org.json.JSONObject
import javax.inject.Inject

internal class PaymentMethodsWidgetJsonLoader @Inject constructor(
    private val quickPayWidgetRepository: QuickPayWidgetRepository,
) : DivViewJsonLoader {

    override suspend fun loadJson(): Result<JSONObject> {
        return quickPayWidgetRepository.loadWidget()
    }
}
