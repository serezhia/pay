package com.yandex.pay.quickpay.internal.di.core.navigation;

import com.yandex.fintechsdk.core.navigation.impl.api.router.RouterImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CoreNavigationModule_Companion_ProvideRouterImplFactory implements Factory<RouterImpl> {
  @Override
  public RouterImpl get() {
    return provideRouterImpl();
  }

  public static CoreNavigationModule_Companion_ProvideRouterImplFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static RouterImpl provideRouterImpl() {
    return Preconditions.checkNotNullFromProvides(CoreNavigationModule.Companion.provideRouterImpl());
  }

  private static final class InstanceHolder {
    static final CoreNavigationModule_Companion_ProvideRouterImplFactory INSTANCE = new CoreNavigationModule_Companion_ProvideRouterImplFactory();
  }
}
