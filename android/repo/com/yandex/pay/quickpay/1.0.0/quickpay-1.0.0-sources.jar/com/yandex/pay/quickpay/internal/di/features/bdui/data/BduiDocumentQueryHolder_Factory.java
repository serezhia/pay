package com.yandex.pay.quickpay.internal.di.features.bdui.data;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiDocumentQueryHolder_Factory implements Factory<BduiDocumentQueryHolder> {
  @Override
  public BduiDocumentQueryHolder get() {
    return newInstance();
  }

  public static BduiDocumentQueryHolder_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static BduiDocumentQueryHolder newInstance() {
    return new BduiDocumentQueryHolder();
  }

  private static final class InstanceHolder {
    static final BduiDocumentQueryHolder_Factory INSTANCE = new BduiDocumentQueryHolder_Factory();
  }
}
