package com.yandex.pay.quickpay.internal.di.core.coroutine

import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.pay.quickpay.internal.di.FlowCoroutineScope
import dagger.Module
import dagger.Provides
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

@Module
internal object FlowCoroutineModule {

    @FlowScope
    @FlowCoroutineScope
    @Provides
    fun provideFlowCoroutineScope(): CoroutineScope {
        return CoroutineScope(SupervisorJob() + Dispatchers.Main)
    }
}

