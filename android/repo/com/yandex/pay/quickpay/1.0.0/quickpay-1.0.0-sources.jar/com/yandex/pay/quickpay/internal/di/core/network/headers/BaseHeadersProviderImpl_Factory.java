package com.yandex.pay.quickpay.internal.di.core.network.headers;

import android.content.Context;
import com.yandex.fintechsdk.core.network.impl.api.frontback.FrontbackServiceTokenProvider;
import com.yandex.fintechsdk.core.utils.api.session.SessionId;
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider;
import com.yandex.fintechsdk.data.auth.api.dpop.DpopRepository;
import com.yandex.fintechsdk.entities.environment.PayEnvironment;
import com.yandex.pay.quickpay.api.QuickPayConfig;
import dagger.Lazy;
import dagger.internal.DaggerGenerated;
import dagger.internal.DoubleCheck;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BaseHeadersProviderImpl_Factory implements Factory<BaseHeadersProviderImpl> {
  private final Provider<Context> contextProvider;

  private final Provider<QuickPayConfig> configProvider;

  private final Provider<DpopRepository> dpopRepositoryProvider;

  private final Provider<PayEnvironment> environmentProvider;

  private final Provider<FrontbackServiceTokenProvider> frontbackServiceTokenProvider;

  private final Provider<SessionId> sessionIdProvider;

  private final Provider<UserAgentProvider> userAgentProvider;

  private BaseHeadersProviderImpl_Factory(Provider<Context> contextProvider,
      Provider<QuickPayConfig> configProvider, Provider<DpopRepository> dpopRepositoryProvider,
      Provider<PayEnvironment> environmentProvider,
      Provider<FrontbackServiceTokenProvider> frontbackServiceTokenProvider,
      Provider<SessionId> sessionIdProvider, Provider<UserAgentProvider> userAgentProvider) {
    this.contextProvider = contextProvider;
    this.configProvider = configProvider;
    this.dpopRepositoryProvider = dpopRepositoryProvider;
    this.environmentProvider = environmentProvider;
    this.frontbackServiceTokenProvider = frontbackServiceTokenProvider;
    this.sessionIdProvider = sessionIdProvider;
    this.userAgentProvider = userAgentProvider;
  }

  @Override
  public BaseHeadersProviderImpl get() {
    return newInstance(contextProvider.get(), configProvider.get(), DoubleCheck.lazy(dpopRepositoryProvider), environmentProvider.get(), frontbackServiceTokenProvider.get(), sessionIdProvider.get(), userAgentProvider.get());
  }

  public static BaseHeadersProviderImpl_Factory create(Provider<Context> contextProvider,
      Provider<QuickPayConfig> configProvider, Provider<DpopRepository> dpopRepositoryProvider,
      Provider<PayEnvironment> environmentProvider,
      Provider<FrontbackServiceTokenProvider> frontbackServiceTokenProvider,
      Provider<SessionId> sessionIdProvider, Provider<UserAgentProvider> userAgentProvider) {
    return new BaseHeadersProviderImpl_Factory(contextProvider, configProvider, dpopRepositoryProvider, environmentProvider, frontbackServiceTokenProvider, sessionIdProvider, userAgentProvider);
  }

  public static BaseHeadersProviderImpl newInstance(Context context, QuickPayConfig config,
      Lazy<DpopRepository> dpopRepository, PayEnvironment environment,
      FrontbackServiceTokenProvider frontbackServiceTokenProvider, SessionId sessionId,
      UserAgentProvider userAgentProvider) {
    return new BaseHeadersProviderImpl(context, config, dpopRepository, environment, frontbackServiceTokenProvider, sessionId, userAgentProvider);
  }
}
