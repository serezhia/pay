package com.yandex.pay.quickpay.internal.di.core.network.auth

import com.yandex.fintechsdk.core.network.api.auth.AuthTokenProvider
import com.yandex.fintechsdk.data.auth.api.AuthRepository
import com.yandex.fintechsdk.data.auth.api.AuthState
import javax.inject.Inject

internal class AuthTokenProviderImpl @Inject constructor(
    private val authRepository: AuthRepository,
) : AuthTokenProvider {

    override fun getToken(): String? {
        return (authRepository.authState.value as? AuthState.Authorized)?.credentials?.token
    }
}

