package com.yandex.pay.quickpay.api

import android.content.Context
import android.util.AttributeSet
import com.yandex.pay.quickpay.internal.widget.BaseWidgetController

public class YandexPaymentMethodsWidget @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : BaseQuickPayWidget(context, attrs, defStyleAttr) {

    internal override fun getController(): BaseWidgetController? = YandexQuickPay.widgetController

    internal override fun reportLoadError(throwable: Throwable) {
        YandexQuickPay.reportWidgetLoadError(throwable = throwable)
    }
}
