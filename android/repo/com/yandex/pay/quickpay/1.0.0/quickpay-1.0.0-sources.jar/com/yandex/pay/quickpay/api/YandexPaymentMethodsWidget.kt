package com.yandex.pay.quickpay.api

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Widget for displaying and managing payment methods
 *
 */
public class YandexPaymentMethodsWidget @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr) {

    private var reloadSubscriptionJob: Job? = null
    private var hideSubscriptionJob: Job? = null

    init {
        visibility = GONE
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (YandexQuickPay.widgetController == null) {
            throw IllegalStateException(YandexQuickPay.NOT_INITED_ERROR_MSG)
        }
        loadWidget()
        subscribeToReloadTrigger()
        subscribeToHideTrigger()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        reloadSubscriptionJob?.cancel()
        reloadSubscriptionJob = null
        hideSubscriptionJob?.cancel()
        hideSubscriptionJob = null
    }

    private fun subscribeToReloadTrigger() {
        val lifecycleOwner = context as? LifecycleOwner ?: return
        val controller = YandexQuickPay.widgetController ?: return

        reloadSubscriptionJob = lifecycleOwner.lifecycleScope.launch {
            controller.reloadTrigger.collect {
                reloadWidget()
            }
        }
    }

    private fun subscribeToHideTrigger() {
        val lifecycleOwner = context as? LifecycleOwner ?: return
        val controller = YandexQuickPay.widgetController ?: return

        hideSubscriptionJob = lifecycleOwner.lifecycleScope.launch {
            controller.hideTrigger.collect {
                removeAllViews()
                visibility = GONE
            }
        }
    }

    private fun loadWidget() {
        val controller = YandexQuickPay.widgetController ?: return

        val lifecycleOwner = context as? LifecycleOwner
        val scope = lifecycleOwner?.lifecycleScope ?: return

        scope.launch {
            controller.loadWidget()
                .fold(
                    onSuccess = { view: View ->
                        removeAllViews()
                        addView(view)
                        visibility = VISIBLE
                    },
                    onFailure = { throwable: Throwable ->
                        removeAllViews()
                        visibility = GONE
                        YandexQuickPay.reportWidgetLoadError(throwable = throwable)
                    },
                )
        }
    }

    private fun reloadWidget() {
        loadWidget()
    }
}
