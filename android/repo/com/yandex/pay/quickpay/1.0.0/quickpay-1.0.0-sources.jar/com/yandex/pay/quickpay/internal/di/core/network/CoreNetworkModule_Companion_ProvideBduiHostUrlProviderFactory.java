package com.yandex.pay.quickpay.internal.di.core.network;

import com.yandex.fintechsdk.core.network.api.host.FrontbackUrlProvider;
import com.yandex.fintechsdk.features.bdui.api.dependencies.BduiHostUrlProvider;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CoreNetworkModule_Companion_ProvideBduiHostUrlProviderFactory implements Factory<BduiHostUrlProvider> {
  private final Provider<FrontbackUrlProvider> frontbackUrlProvider;

  private CoreNetworkModule_Companion_ProvideBduiHostUrlProviderFactory(
      Provider<FrontbackUrlProvider> frontbackUrlProvider) {
    this.frontbackUrlProvider = frontbackUrlProvider;
  }

  @Override
  public BduiHostUrlProvider get() {
    return provideBduiHostUrlProvider(frontbackUrlProvider.get());
  }

  public static CoreNetworkModule_Companion_ProvideBduiHostUrlProviderFactory create(
      Provider<FrontbackUrlProvider> frontbackUrlProvider) {
    return new CoreNetworkModule_Companion_ProvideBduiHostUrlProviderFactory(frontbackUrlProvider);
  }

  public static BduiHostUrlProvider provideBduiHostUrlProvider(
      FrontbackUrlProvider frontbackUrlProvider) {
    return Preconditions.checkNotNullFromProvides(CoreNetworkModule.Companion.provideBduiHostUrlProvider(frontbackUrlProvider));
  }
}
