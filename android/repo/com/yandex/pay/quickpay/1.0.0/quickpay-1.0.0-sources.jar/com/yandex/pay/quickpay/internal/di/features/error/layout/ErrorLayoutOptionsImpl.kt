package com.yandex.pay.quickpay.internal.di.features.error.layout

import com.yandex.fintechsdk.features.error.api.dependencies.layout.ErrorLayoutOptions
import javax.inject.Inject

internal class ErrorLayoutOptionsImpl @Inject constructor(): ErrorLayoutOptions {
    override val ignoreInsets = false
}
