package com.yandex.pay.quickpay.internal.widget;

import com.yandex.fintechsdk.data.quickpay.api.widget.QuickPayActivePaymentMethodBadgeRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ActivePaymentMethodBadgeJsonLoader_Factory implements Factory<ActivePaymentMethodBadgeJsonLoader> {
  private final Provider<QuickPayActivePaymentMethodBadgeRepository> quickPayActivePaymentMethodBadgeRepositoryProvider;

  private ActivePaymentMethodBadgeJsonLoader_Factory(
      Provider<QuickPayActivePaymentMethodBadgeRepository> quickPayActivePaymentMethodBadgeRepositoryProvider) {
    this.quickPayActivePaymentMethodBadgeRepositoryProvider = quickPayActivePaymentMethodBadgeRepositoryProvider;
  }

  @Override
  public ActivePaymentMethodBadgeJsonLoader get() {
    return newInstance(quickPayActivePaymentMethodBadgeRepositoryProvider.get());
  }

  public static ActivePaymentMethodBadgeJsonLoader_Factory create(
      Provider<QuickPayActivePaymentMethodBadgeRepository> quickPayActivePaymentMethodBadgeRepositoryProvider) {
    return new ActivePaymentMethodBadgeJsonLoader_Factory(quickPayActivePaymentMethodBadgeRepositoryProvider);
  }

  public static ActivePaymentMethodBadgeJsonLoader newInstance(
      QuickPayActivePaymentMethodBadgeRepository quickPayActivePaymentMethodBadgeRepository) {
    return new ActivePaymentMethodBadgeJsonLoader(quickPayActivePaymentMethodBadgeRepository);
  }
}
