package com.yandex.pay.quickpay.internal.di.core.network;

import com.yandex.fintechsdk.entities.environment.PayEnvironment;
import com.yandex.pay.quickpay.api.QuickPayConfig;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CoreNetworkModule_Companion_ProvidePayEnvironmentFactory implements Factory<PayEnvironment> {
  private final Provider<QuickPayConfig> configProvider;

  private CoreNetworkModule_Companion_ProvidePayEnvironmentFactory(
      Provider<QuickPayConfig> configProvider) {
    this.configProvider = configProvider;
  }

  @Override
  public PayEnvironment get() {
    return providePayEnvironment(configProvider.get());
  }

  public static CoreNetworkModule_Companion_ProvidePayEnvironmentFactory create(
      Provider<QuickPayConfig> configProvider) {
    return new CoreNetworkModule_Companion_ProvidePayEnvironmentFactory(configProvider);
  }

  public static PayEnvironment providePayEnvironment(QuickPayConfig config) {
    return Preconditions.checkNotNullFromProvides(CoreNetworkModule.Companion.providePayEnvironment(config));
  }
}
