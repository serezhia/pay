package com.yandex.pay.quickpay.api

/**
 * Defines a language for quick payment UI
 */
public enum class QuickPayLocale {
    /**
     * Language adapt by system configuration
     */
    SYSTEM,

    /**
     * Russian language
     */
    RU,

    /**
     * English language
     */
    EN,
}

