package com.yandex.pay.quickpay.api

import android.content.Context
import android.util.AttributeSet
import com.yandex.pay.quickpay.internal.widget.BaseWidgetController

public class YandexActivePaymentMethodBadge @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : BaseQuickPayWidget(context, attrs, defStyleAttr) {

    internal override val refreshIntervalMs: Long = REFRESH_INTERVAL_MS

    internal override fun getController(): BaseWidgetController? = YandexQuickPay.activePaymentMethodBadgeController

    internal override fun reportLoadError(throwable: Throwable) {
        YandexQuickPay.reportActivePaymentMethodBadgeLoadError(throwable = throwable)
    }

    private companion object {
        private const val REFRESH_INTERVAL_MS = 10_000L
    }
}
