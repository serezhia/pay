package com.yandex.pay.quickpay.internal.widget

import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter
import javax.inject.Inject

@FlowScope
internal class ActivePaymentMethodBadgeController @Inject constructor(
    activePaymentMethodBadgeJsonLoader: ActivePaymentMethodBadgeJsonLoader,
    analyticsReporter: QuickPayAnalyticsReporter,
    divKitAdapter: DivKitAdapter,
) : BaseWidgetController(
    analyticsReporter = analyticsReporter,
    analyticsSource = SOURCE_ACTIVE_PAYMENT,
    divKitAdapter = divKitAdapter,
    jsonLoader = activePaymentMethodBadgeJsonLoader,
) {

    private companion object {
        private const val SOURCE_ACTIVE_PAYMENT = "active_payment"
    }
}
