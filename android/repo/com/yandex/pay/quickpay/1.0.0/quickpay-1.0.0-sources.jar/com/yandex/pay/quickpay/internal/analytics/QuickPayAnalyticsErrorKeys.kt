package com.yandex.pay.quickpay.internal.analytics

/**
 * Error keys for ErrorBooster reporting.
 * All error keys should be defined here for consistency.
 */
internal object QuickPayAnalyticsErrorKeys {
    const val SHOW_PENDING_ORDERS = "QuickPayDelegate.showPendingOrders"
    const val LOAD_WIDGET = "YandexPaymentMethodsWidget.loadWidget"
    const val BDUI_LOAD = "BduiNavigatorImpl.onError"
    const val POLLING_ERROR = "PaymentProcessManager.pollingError"
    const val ENABLE_QUICK_PAYMENT = "YandexQuickPay.enableQuickPayment"
    const val DISABLE_QUICK_PAYMENT = "YandexQuickPay.disableQuickPayment"
    const val GENERATE_BST = "YandexQuickPay.generateBst"
    const val GET_PAYMENT_SESSION = "YandexQuickPay.getPaymentSessionId"
}

