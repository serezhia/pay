package com.yandex.pay.quickpay.internal.di.core.network

import com.yandex.fintechsdk.core.network.api.auth.AuthTokenProvider
import com.yandex.fintechsdk.core.network.api.host.FrontbackUrlProvider
import com.yandex.fintechsdk.core.network.impl.api.di.NetworkModule
import com.yandex.fintechsdk.core.network.impl.api.frontback.FrontbackServiceTokenProvider
import com.yandex.fintechsdk.core.network.impl.api.headers.BaseHeadersProvider
import com.yandex.fintechsdk.entities.environment.DefaultEnvironment
import com.yandex.fintechsdk.entities.environment.PayEnvironment
import com.yandex.fintechsdk.features.bdui.api.dependencies.BduiHostUrlProvider
import com.yandex.pay.quickpay.BuildConfig
import com.yandex.pay.quickpay.api.QuickPayConfig
import com.yandex.pay.quickpay.api.QuickPayEnvironment
import com.yandex.pay.quickpay.internal.di.core.network.auth.AuthTokenProviderImpl
import com.yandex.pay.quickpay.internal.di.core.network.frontback.FrontbackServiceTokenProviderImpl
import com.yandex.pay.quickpay.internal.di.core.network.headers.BaseHeadersProviderImpl
import dagger.Binds
import dagger.Module
import dagger.Provides

@Module(
    includes = [NetworkModule::class],
)
internal abstract class CoreNetworkModule {

    @Binds
    abstract fun bindAuthTokenProvider(impl: AuthTokenProviderImpl): AuthTokenProvider

    @Binds
    abstract fun bindBaseHeadersProvider(impl: BaseHeadersProviderImpl): BaseHeadersProvider

    @Binds
    abstract fun bindFrontbackServiceTokenProvider(
        impl: FrontbackServiceTokenProviderImpl,
    ): FrontbackServiceTokenProvider

    companion object {

        @Provides
        fun provideBduiHostUrlProvider(frontbackUrlProvider: FrontbackUrlProvider): BduiHostUrlProvider {
            return object : BduiHostUrlProvider {
                override fun getHostUrl(): String = frontbackUrlProvider.getHostUrl()
            }
        }

        @Provides
        fun provideEnvironment(): DefaultEnvironment {
            return if (BuildConfig.DEBUG)
                DefaultEnvironment.TESTING
            else
                DefaultEnvironment.PRODUCTION
        }

        @Provides
        fun providePayEnvironment(config: QuickPayConfig): PayEnvironment {
            if (BuildConfig.DEBUG) return PayEnvironment.TESTING

            return when(config.environment) {
                QuickPayEnvironment.PRODUCTION -> PayEnvironment.PRODUCTION
                QuickPayEnvironment.SANDBOX -> PayEnvironment.SANDBOX
            }
        }
    }
}
