package com.yandex.pay.quickpay.internal.data

import com.yandex.fintechsdk.data.quickpay.api.MerchantIdProvider
import com.yandex.pay.quickpay.api.QuickPayConfig
import javax.inject.Inject

internal class MerchantIdProviderImpl @Inject constructor(
    private val config: QuickPayConfig,
) : MerchantIdProvider {

    override fun getMerchantId(): String {
        return config.merchantId
    }
}

