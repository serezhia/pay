package com.yandex.pay.quickpay.internal.di.core.coroutine;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlinx.coroutines.CoroutineScope;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata("com.yandex.pay.quickpay.internal.di.FlowCoroutineScope")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlowCoroutineModule_ProvideFlowCoroutineScopeFactory implements Factory<CoroutineScope> {
  @Override
  public CoroutineScope get() {
    return provideFlowCoroutineScope();
  }

  public static FlowCoroutineModule_ProvideFlowCoroutineScopeFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static CoroutineScope provideFlowCoroutineScope() {
    return Preconditions.checkNotNullFromProvides(FlowCoroutineModule.INSTANCE.provideFlowCoroutineScope());
  }

  private static final class InstanceHolder {
    static final FlowCoroutineModule_ProvideFlowCoroutineScopeFactory INSTANCE = new FlowCoroutineModule_ProvideFlowCoroutineScopeFactory();
  }
}
