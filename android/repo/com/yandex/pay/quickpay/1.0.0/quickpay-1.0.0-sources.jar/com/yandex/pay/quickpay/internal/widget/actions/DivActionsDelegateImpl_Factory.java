package com.yandex.pay.quickpay.internal.widget.actions;

import com.yandex.fintechsdk.data.quickpay.api.settings.QuickPaySettingsRepository;
import com.yandex.pay.quickpay.internal.presentation.QuickPayBottomSheetHolder;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import kotlinx.coroutines.CoroutineScope;

@ScopeMetadata
@QualifierMetadata("com.yandex.fintechsdk.core.divkit.api.di.DivkitCoroutineScope")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DivActionsDelegateImpl_Factory implements Factory<DivActionsDelegateImpl> {
  private final Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider;

  private final Provider<CoroutineScope> coroutineScopeProvider;

  private final Provider<QuickPaySettingsRepository> settingsRepositoryProvider;

  private DivActionsDelegateImpl_Factory(
      Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider,
      Provider<CoroutineScope> coroutineScopeProvider,
      Provider<QuickPaySettingsRepository> settingsRepositoryProvider) {
    this.bottomSheetHolderProvider = bottomSheetHolderProvider;
    this.coroutineScopeProvider = coroutineScopeProvider;
    this.settingsRepositoryProvider = settingsRepositoryProvider;
  }

  @Override
  public DivActionsDelegateImpl get() {
    return newInstance(bottomSheetHolderProvider.get(), coroutineScopeProvider.get(), settingsRepositoryProvider.get());
  }

  public static DivActionsDelegateImpl_Factory create(
      Provider<QuickPayBottomSheetHolder> bottomSheetHolderProvider,
      Provider<CoroutineScope> coroutineScopeProvider,
      Provider<QuickPaySettingsRepository> settingsRepositoryProvider) {
    return new DivActionsDelegateImpl_Factory(bottomSheetHolderProvider, coroutineScopeProvider, settingsRepositoryProvider);
  }

  public static DivActionsDelegateImpl newInstance(QuickPayBottomSheetHolder bottomSheetHolder,
      CoroutineScope coroutineScope, QuickPaySettingsRepository settingsRepository) {
    return new DivActionsDelegateImpl(bottomSheetHolder, coroutineScope, settingsRepository);
  }
}
