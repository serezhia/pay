package com.yandex.pay.quickpay.internal.di.adapters.divkit;

import android.content.Context;
import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitDependencies;
import com.yandex.fintechsdk.core.bdui.api.theme.BduiThemeProvider;
import com.yandex.fintechsdk.core.divkit.api.action.DivActionHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.Map;
import javax.annotation.processing.Generated;
import okhttp3.OkHttpClient;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class DivKitAdapterModule_ProvideDivKitDependenciesFactory implements Factory<DivKitDependencies> {
  private final DivKitAdapterModule module;

  private final Provider<Context> contextProvider;

  private final Provider<Map<String, DivActionHandler>> divActionHandlersProvider;

  private final Provider<OkHttpClient.Builder> okHttpClientBuilderProvider;

  private final Provider<BduiThemeProvider> themeProvider;

  private DivKitAdapterModule_ProvideDivKitDependenciesFactory(DivKitAdapterModule module,
      Provider<Context> contextProvider,
      Provider<Map<String, DivActionHandler>> divActionHandlersProvider,
      Provider<OkHttpClient.Builder> okHttpClientBuilderProvider,
      Provider<BduiThemeProvider> themeProvider) {
    this.module = module;
    this.contextProvider = contextProvider;
    this.divActionHandlersProvider = divActionHandlersProvider;
    this.okHttpClientBuilderProvider = okHttpClientBuilderProvider;
    this.themeProvider = themeProvider;
  }

  @Override
  public DivKitDependencies get() {
    return provideDivKitDependencies(module, contextProvider.get(), divActionHandlersProvider.get(), okHttpClientBuilderProvider.get(), themeProvider.get());
  }

  public static DivKitAdapterModule_ProvideDivKitDependenciesFactory create(
      DivKitAdapterModule module, Provider<Context> contextProvider,
      Provider<Map<String, DivActionHandler>> divActionHandlersProvider,
      Provider<OkHttpClient.Builder> okHttpClientBuilderProvider,
      Provider<BduiThemeProvider> themeProvider) {
    return new DivKitAdapterModule_ProvideDivKitDependenciesFactory(module, contextProvider, divActionHandlersProvider, okHttpClientBuilderProvider, themeProvider);
  }

  public static DivKitDependencies provideDivKitDependencies(DivKitAdapterModule instance,
      Context context, Map<String, DivActionHandler> divActionHandlers,
      OkHttpClient.Builder okHttpClientBuilder, BduiThemeProvider themeProvider) {
    return Preconditions.checkNotNullFromProvides(instance.provideDivKitDependencies(context, divActionHandlers, okHttpClientBuilder, themeProvider));
  }
}
