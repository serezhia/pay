package com.yandex.pay.quickpay.internal.di.features.bdui.action

import androidx.fragment.app.FragmentActivity
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DeviceChallengeSignatureProvider
import javax.inject.Inject

internal class DeviceChallengeSignatureProviderImpl @Inject constructor() : DeviceChallengeSignatureProvider {
    override fun getSignature(
        activity: FragmentActivity,
        deviceChallengePostDelay: Int,
        deviceChallengeStartDelay: Int,
        paymentMethodId: String,
        purchaseToken: String,
        completion: (data: String?, signature: String?) -> Unit,
    ) = Unit
}
