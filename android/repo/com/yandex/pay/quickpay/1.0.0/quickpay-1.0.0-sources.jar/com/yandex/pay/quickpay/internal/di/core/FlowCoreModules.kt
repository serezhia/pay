package com.yandex.pay.quickpay.internal.di.core

import com.yandex.fintechsdk.core.sharedprefs.impl.CoreSharedPrefsModule
import com.yandex.fintechsdk.core.utils.impl.api.di.UtilsModule
import com.yandex.fintechsdk.security.impl.api.SecurityModule
import com.yandex.pay.quickpay.internal.di.core.analytics.CoreAnalyticsModule
import com.yandex.pay.quickpay.internal.di.core.coroutine.FlowCoroutineModule
import com.yandex.pay.quickpay.internal.di.core.navigation.CoreNavigationModule
import com.yandex.pay.quickpay.internal.di.core.network.CoreNetworkModule
import dagger.Module

@Module(
    includes = [
        CoreAnalyticsModule::class,
        CoreNavigationModule::class,
        CoreNetworkModule::class,
        CoreSharedPrefsModule::class,
        FlowCoroutineModule::class,
        SecurityModule::class,
        UtilsModule::class,
    ],
)
internal interface FlowCoreModules

