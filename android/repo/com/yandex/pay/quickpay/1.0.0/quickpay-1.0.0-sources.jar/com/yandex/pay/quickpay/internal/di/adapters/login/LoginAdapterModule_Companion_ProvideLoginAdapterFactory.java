package com.yandex.pay.quickpay.internal.di.adapters.login;

import com.yandex.fitnechsdk.adapters.login.sdk.api.LoginAdapter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class LoginAdapterModule_Companion_ProvideLoginAdapterFactory implements Factory<LoginAdapter> {
  @Override
  public LoginAdapter get() {
    return provideLoginAdapter();
  }

  public static LoginAdapterModule_Companion_ProvideLoginAdapterFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static LoginAdapter provideLoginAdapter() {
    return Preconditions.checkNotNullFromProvides(LoginAdapterModule.Companion.provideLoginAdapter());
  }

  private static final class InstanceHolder {
    static final LoginAdapterModule_Companion_ProvideLoginAdapterFactory INSTANCE = new LoginAdapterModule_Companion_ProvideLoginAdapterFactory();
  }
}
