package com.yandex.pay.quickpay.internal.extensions

import androidx.fragment.app.FragmentActivity
import com.yandex.fintechsdk.data.auth.api.dpop.DpopRepository
import com.yandex.pay.quickpay.api.YandexQuickPay

internal suspend fun DpopRepository.generateAuthSessionWithRedraw(
    activity: FragmentActivity,
    authToken: String,
    merchantId: String,
): Result<String> {
    return generateAuthSession(
        activity = activity,
        authToken = authToken,
        merchantId = merchantId,
    ).also {
        YandexQuickPay.widgetController?.triggerReload()
    }
}

