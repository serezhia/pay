package com.yandex.pay.quickpay.internal.di.core.analytics.errorbooster

import com.yandex.fintechsdk.core.analytics.impl.external.api.errorbooster.ErrorBoosterProjectNameProvider
import javax.inject.Inject

internal class ErrorBoosterProjectNameProviderImpl @Inject constructor() : ErrorBoosterProjectNameProvider {

    override fun get(): String {
        return PROJECT_NAME
    }

    private companion object {
        const val PROJECT_NAME = "YandexQuickPayAndroid"
    }
}

