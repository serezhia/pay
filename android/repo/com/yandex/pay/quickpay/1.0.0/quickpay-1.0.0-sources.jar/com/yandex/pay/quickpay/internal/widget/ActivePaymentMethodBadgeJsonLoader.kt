package com.yandex.pay.quickpay.internal.widget

import com.yandex.fintechsdk.adapters.divkit.sdk.api.loader.DivViewJsonLoader
import com.yandex.fintechsdk.data.quickpay.api.widget.QuickPayActivePaymentMethodBadgeRepository
import org.json.JSONObject
import javax.inject.Inject

internal class ActivePaymentMethodBadgeJsonLoader @Inject constructor(
    private val quickPayActivePaymentMethodBadgeRepository: QuickPayActivePaymentMethodBadgeRepository,
) : DivViewJsonLoader {

    override suspend fun loadJson(): Result<JSONObject> {
        return quickPayActivePaymentMethodBadgeRepository.loadWidget()
    }
}
