package com.yandex.pay.quickpay.internal.di.data;

import com.yandex.fintechsdk.data.card.api.binding.CardBindingRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlowDataModules_ProvideCardBindingRepositoryFactory implements Factory<CardBindingRepository> {
  @Override
  public CardBindingRepository get() {
    return provideCardBindingRepository();
  }

  public static FlowDataModules_ProvideCardBindingRepositoryFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static CardBindingRepository provideCardBindingRepository() {
    return Preconditions.checkNotNullFromProvides(FlowDataModules.INSTANCE.provideCardBindingRepository());
  }

  private static final class InstanceHolder {
    static final FlowDataModules_ProvideCardBindingRepositoryFactory INSTANCE = new FlowDataModules_ProvideCardBindingRepositoryFactory();
  }
}
