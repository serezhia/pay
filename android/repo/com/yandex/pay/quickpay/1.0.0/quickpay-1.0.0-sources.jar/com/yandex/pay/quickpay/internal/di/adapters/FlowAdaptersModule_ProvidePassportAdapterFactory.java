package com.yandex.pay.quickpay.internal.di.adapters;

import com.yandex.finsdtechsdk.adapters.passport.sdk.api.PassportAdapter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlowAdaptersModule_ProvidePassportAdapterFactory implements Factory<PassportAdapter> {
  private final FlowAdaptersModule module;

  private FlowAdaptersModule_ProvidePassportAdapterFactory(FlowAdaptersModule module) {
    this.module = module;
  }

  @Override
  @Nullable
  public PassportAdapter get() {
    return providePassportAdapter(module);
  }

  public static FlowAdaptersModule_ProvidePassportAdapterFactory create(FlowAdaptersModule module) {
    return new FlowAdaptersModule_ProvidePassportAdapterFactory(module);
  }

  @Nullable
  public static PassportAdapter providePassportAdapter(FlowAdaptersModule instance) {
    return instance.providePassportAdapter();
  }
}
