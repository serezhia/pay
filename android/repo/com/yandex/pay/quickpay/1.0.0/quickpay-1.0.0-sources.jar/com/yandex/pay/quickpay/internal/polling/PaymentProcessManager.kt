package com.yandex.pay.quickpay.internal.polling

import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.core.network.api.exception.NetworkException
import com.yandex.fintechsdk.data.quickpay.api.orders.OrdersRepository
import com.yandex.fintechsdk.data.quickpay.api.orders.model.Order
import com.yandex.fintechsdk.data.quickpay.api.orders.model.OrderStatus
import com.yandex.pay.quickpay.api.QuickPayResult
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsErrorKeys
import com.yandex.pay.quickpay.internal.analytics.QuickPayAnalyticsReporter
import com.yandex.pay.quickpay.internal.di.FlowCoroutineScope
import java.net.HttpURLConnection
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

@FlowScope
internal class PaymentProcessManager @Inject constructor(
    private val ordersRepository: OrdersRepository,
    private val analyticsReporter: QuickPayAnalyticsReporter,
    @FlowCoroutineScope private val scope: CoroutineScope,
) {

    private var activeOrdersPollingJob: Job? = null
    private var orderStatusPollingJob: Job? = null
    private var orderStatusCollectorJob: Job? = null

    private val _events = MutableSharedFlow<QuickPaymentEvent>(
        extraBufferCapacity = 3,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    val events: SharedFlow<QuickPaymentEvent> = _events.asSharedFlow()

    private var currentOrder: Order? = null
    private var pendingResult: QuickPayResult? = null
    private val pollingMode = AtomicReference(PollingMode.IDLE)
    private val isDismissedDuringProgress = AtomicBoolean(false)

    /**
     * Emit pending payment result if available.
     * Should be called when payment flow UI is dismissed.
     */
    @Synchronized
    fun emitPendingResult() {
        if (currentOrder?.status == OrderStatus.IN_PROGRESS) {
            isDismissedDuringProgress.set(true)
            return
        }

        pendingResult?.let { result ->
            reportPaymentResult(result = result)
            _events.tryEmit(value = QuickPaymentEvent.PaymentFinished(result = result))
            pendingResult = null
        }
    }

    /**
     * Start polling for active orders
     */
    @Synchronized
    fun startActiveOrderPolling() {
        cancelAllJobs()
        pollingMode.set(PollingMode.ACTIVE_ORDERS)

        activeOrdersPollingJob = scope.launch {
            try {
                val orders = ordersRepository.pollActiveOrders()
                handleActiveOrdersResult(orders = orders)
            } catch (e: CancellationException) {
                throw e
            } catch (error: Throwable) {
                handlePollingError(error = error)
            }
        }
    }

    /**
     * Show pending order without polling.
     * Sets up the order for display and emits events.
     */
    fun showPendingOrder(order: Order) {
        currentOrder = order
        pendingResult = order.status.toQuickPayResult()
        emitShowPaymentStatusScreen(transactionId = order.transactionId, paymentUrl = order.url)
    }

    /**
     * Stop all polling and reset state
     */
    @Synchronized
    fun stopPolling() {
        cancelAllJobs()
        pollingMode.set(PollingMode.IDLE)
    }

    /**
     * Pause polling without resetting state.
     * Should be called when app goes to background.
     */
    @Synchronized
    fun pausePolling() {
        cancelAllJobs()
    }

    private fun cancelAllJobs() {
        activeOrdersPollingJob?.cancel()
        orderStatusPollingJob?.cancel()
        orderStatusCollectorJob?.cancel()
        activeOrdersPollingJob = null
        orderStatusPollingJob = null
        orderStatusCollectorJob = null
    }

    /**
     * Resume polling if it was active before going to background.
     * Should be called when app returns to foreground.
     */
    @Synchronized
    fun resumePollingIfNeeded() {
        when (pollingMode.get()) {
            PollingMode.ACTIVE_ORDERS -> {
                if (activeOrdersPollingJob?.isActive != true) {
                    restartActiveOrdersPolling()
                }
            }
            PollingMode.ORDER_STATUS -> {
                val order = currentOrder ?: return
                if (orderStatusPollingJob?.isActive != true) {
                    restartOrderStatusPolling(order = order)
                }
            }
            PollingMode.IDLE -> Unit
        }
    }

    private fun restartActiveOrdersPolling() {
        activeOrdersPollingJob = scope.launch {
            try {
                val orders = ordersRepository.pollActiveOrders()
                handleActiveOrdersResult(orders = orders)
            } catch (e: CancellationException) {
                throw e
            } catch (error: Throwable) {
                handlePollingError(error = error)
            }
        }
    }

    private fun restartOrderStatusPolling(order: Order) {
        // Check if order is already in terminal state to avoid restarting polling for completed orders
        val orderStatus = order.status
        if (orderStatus == OrderStatus.SUCCESS || orderStatus == OrderStatus.FAIL) {
            return
        }

        orderStatusCollectorJob = scope.launch {
            ordersRepository.orderStatusFlow.collect { updatedOrder ->
                handleOrderStatusResult(order = updatedOrder)
            }
        }

        orderStatusPollingJob = scope.launch {
            try {
                ordersRepository.pollOrderStatus(
                    transactionId = order.transactionId,
                    paymentUrl = order.url,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (error: Throwable) {
                handlePollingError(error = error)
            }
        }
    }

    fun getCurrentTransactionId(): String? = currentOrder?.transactionId

    private fun emitShowPaymentStatusScreen(transactionId: String, paymentUrl: String) {
        _events.tryEmit(
            value = QuickPaymentEvent.ShowPaymentStatusScreen(
                transactionId = transactionId,
                paymentUrl = paymentUrl,
            ),
        )
    }

    private fun handleActiveOrdersResult(orders: List<Order>) {
        if (orders.isEmpty()) {
            pollingMode.set(PollingMode.IDLE)
            _events.tryEmit(value = QuickPaymentEvent.SetPaymentInProgress(isInProgress = false))
            return
        }

        val order = orders.firstOrNull()
        if (order != null) {
            isDismissedDuringProgress.set(false)
            currentOrder = order
            _events.tryEmit(value = QuickPaymentEvent.WidgetRefresh)
            _events.tryEmit(value = QuickPaymentEvent.SetPaymentInProgress(isInProgress = true))
            emitShowPaymentStatusScreen(transactionId = order.transactionId, paymentUrl = order.url)
            startOrderStatusPolling(order = order)
        }
    }

    @Synchronized
    private fun startOrderStatusPolling(order: Order) {
        activeOrdersPollingJob?.cancel()
        activeOrdersPollingJob = null
        pollingMode.set(PollingMode.ORDER_STATUS)

        orderStatusCollectorJob = scope.launch {
            ordersRepository.orderStatusFlow.collect { updatedOrder ->
                handleOrderStatusResult(order = updatedOrder)
            }
        }

        orderStatusPollingJob = scope.launch {
            try {
                ordersRepository.pollOrderStatus(
                    transactionId = order.transactionId,
                    paymentUrl = order.url,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (error: Throwable) {
                handlePollingError(error = error)
            }
        }
    }

    private fun handleOrderStatusResult(order: Order) {
        currentOrder = order
        pendingResult = order.status.toQuickPayResult()

        when (order.status) {
            OrderStatus.USER_INTERACTION -> {
                isDismissedDuringProgress.set(false)
                emitShowPaymentStatusScreen(transactionId = order.transactionId, paymentUrl = order.url)
            }
            OrderStatus.IN_PROGRESS -> {
                if (!isDismissedDuringProgress.get()) {
                    emitShowPaymentStatusScreen(transactionId = order.transactionId, paymentUrl = order.url)
                }
            }
            OrderStatus.SUCCESS, OrderStatus.FAIL -> {
                isDismissedDuringProgress.set(false)
                stopPolling()
                emitShowPaymentStatusScreen(transactionId = order.transactionId, paymentUrl = order.url)
            }
            OrderStatus.NEW -> {
                // Do nothing, continue polling
            }
        }
    }

    private fun reportPaymentResult(result: QuickPayResult) {
        when (result) {
            QuickPayResult.Success -> analyticsReporter.reportPaymentProcessCompleted()
            QuickPayResult.Failure -> analyticsReporter.reportPaymentProcessFailed()
        }
    }

    private fun handlePollingError(error: Throwable) {
        stopPolling()

        val isTokenError = when (error) {
            is NetworkException.BadCodeException ->
                error.code == HttpURLConnection.HTTP_UNAUTHORIZED ||
                error.code == BST_EXPIRED_ERROR_CODE
            is NetworkException.OkHttpCommonException ->
                true  // Timeout or other network errors mean expired token
            else -> false
        }

        if (isTokenError) {
            analyticsReporter.reportTokenExpired()
            _events.tryEmit(value = QuickPaymentEvent.TokenExpired)
        } else {
            analyticsReporter.reportError(
                key = QuickPayAnalyticsErrorKeys.POLLING_ERROR,
                throwable = error,
            )
            _events.tryEmit(value = QuickPaymentEvent.PollingError)
        }
    }

    private fun OrderStatus.toQuickPayResult(): QuickPayResult? = when (this) {
        OrderStatus.SUCCESS -> QuickPayResult.Success
        OrderStatus.FAIL -> QuickPayResult.Failure
        else -> null
    }

    private companion object {
        const val BST_EXPIRED_ERROR_CODE = 1004
    }

    private enum class PollingMode {
        IDLE,
        ACTIVE_ORDERS,
        ORDER_STATUS,
    }
}
