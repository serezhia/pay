package com.yandex.pay.quickpay.internal.di.auth;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class QuickPayAuthOptionsProviderImpl_Factory implements Factory<QuickPayAuthOptionsProviderImpl> {
  @Override
  public QuickPayAuthOptionsProviderImpl get() {
    return newInstance();
  }

  public static QuickPayAuthOptionsProviderImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static QuickPayAuthOptionsProviderImpl newInstance() {
    return new QuickPayAuthOptionsProviderImpl();
  }

  private static final class InstanceHolder {
    static final QuickPayAuthOptionsProviderImpl_Factory INSTANCE = new QuickPayAuthOptionsProviderImpl_Factory();
  }
}
