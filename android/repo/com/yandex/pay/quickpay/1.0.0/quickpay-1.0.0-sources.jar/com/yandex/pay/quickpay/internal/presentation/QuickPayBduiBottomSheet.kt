package com.yandex.pay.quickpay.internal.presentation

import android.app.Dialog
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.graphics.Rect
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import com.google.android.material.shape.MaterialShapeDrawable
import com.google.android.material.shape.ShapeAppearanceModel
import kotlin.math.roundToInt
import androidx.fragment.app.FragmentContainerView
import androidx.fragment.app.FragmentManager
import androidx.navigation.fragment.NavHostFragment
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.R as MaterialR
import com.yandex.fintechsdk.core.architecture.api.feature.dependencies.FeatureDependencies
import com.yandex.fintechsdk.core.architecture.api.feature.dependencies.FeatureDependenciesResolver
import com.yandex.fintechsdk.core.navigation.impl.api.navigationcontroller.NavigationController
import com.yandex.fintechsdk.features.bdui.R as BduiR
import com.yandex.pay.quickpay.api.QuickPayThemeColorScheme
import com.yandex.pay.quickpay.internal.di.QuickPayComponent

internal class QuickPayBduiBottomSheet : BottomSheetDialogFragment(), FeatureDependenciesResolver {

    private var component: QuickPayComponent? = null
    private var containerId: Int = View.NO_ID
    private var onDismissCallback: (() -> Unit)? = null
    private var theme: QuickPayThemeColorScheme = QuickPayThemeColorScheme.SYSTEM

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureStyle()
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState) as BottomSheetDialog

        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<FrameLayout>(
                com.google.android.material.R.id.design_bottom_sheet,
            )
            bottomSheet?.let { sheet ->
                val behavior = BottomSheetBehavior.from(sheet)
                val availableHeight = computeAvailableHeight(dialog = dialog)
                val targetHeight = (availableHeight * BOTTOM_SHEET_HEIGHT_RATIO).roundToInt()
                sheet.layoutParams.height = targetHeight
                behavior.peekHeight = targetHeight
                behavior.state = BottomSheetBehavior.STATE_EXPANDED
                behavior.skipCollapsed = true
                behavior.isDraggable = true

                setupBottomSheetCallback(behavior = behavior)

                applyRoundedCorners(sheet = sheet)
            }
        }

        return dialog
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        return FragmentContainerView(requireContext()).apply {
            id = View.generateViewId()
            containerId = id
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (savedInstanceState == null) {
            setupNavigation()
        }
    }

    private fun setupNavigation() {
        val navHostFragment = NavHostFragment()

        childFragmentManager.beginTransaction()
            .replace(containerId, navHostFragment)
            .commitNow()

        val navController = navHostFragment.navController

        component?.router?.setNavigationController(
            NavigationController(
                navController = navController,
                onEmptyBackStack = { close() },
            ),
        )

        val navGraph = navController.navInflater.inflate(BduiR.navigation.finsdk_bdui_graph)

        component?.featureGraphProviders?.forEach { featureGraphProvider ->
            val featureGraph = featureGraphProvider.provideFeatureGraph(navController = navController)
            if (featureGraph.route != navGraph.route) {
                navGraph.addDestination(featureGraph)
            }
        }

        navController.graph = navGraph
    }

    fun setComponent(component: QuickPayComponent) {
        this.component = component
    }

    fun close() {
        dismiss()
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        onDismissCallback?.invoke()
    }

    @Suppress("UNCHECKED_CAST")
    override fun <T : FeatureDependencies> resolveDependencies(): T {
        return component as? T ?: error("Component not set")
    }

    private fun computeAvailableHeight(dialog: Dialog): Int {
        val root = dialog.window?.decorView ?: requireView()
        val rect = Rect()
        root.getWindowVisibleDisplayFrame(rect)
        return rect.height()
    }

    private fun applyRoundedCorners(sheet: FrameLayout) {
        val cornerRadius = CORNER_RADIUS_DP * resources.displayMetrics.density

        val backgroundColor = TypedValue().let { typedValue ->
            requireContext().theme.resolveAttribute(
                MaterialR.attr.colorSurface,
                typedValue,
                true,
            )
            typedValue.data
        }

        val shapeAppearanceModel = ShapeAppearanceModel.builder()
            .setTopLeftCornerSize(cornerRadius)
            .setTopRightCornerSize(cornerRadius)
            .build()

        val shapeDrawable = MaterialShapeDrawable(shapeAppearanceModel).apply {
            fillColor = ColorStateList.valueOf(backgroundColor)
        }

        sheet.background = shapeDrawable

        sheet.clipToOutline = true
        sheet.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerRadius)
            }
        }
    }

    private fun setupBottomSheetCallback(behavior: BottomSheetBehavior<FrameLayout>) {
        behavior.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {
                if (newState == BottomSheetBehavior.STATE_DRAGGING) {
                    // Allow dragging only from the top area, not from scrollable content
                }
            }

            override fun onSlide(bottomSheet: View, slideOffset: Float) {}
        })
    }

    private fun configureStyle() {
        val themeResId = when (theme) {
            QuickPayThemeColorScheme.DARK -> MaterialR.style.Theme_Material3_Dark_BottomSheetDialog
            QuickPayThemeColorScheme.LIGHT -> MaterialR.style.Theme_Material3_Light_BottomSheetDialog
            QuickPayThemeColorScheme.SYSTEM -> MaterialR.style.ThemeOverlay_Material3_BottomSheetDialog
        }
        setStyle(STYLE_NORMAL, themeResId)
    }

    companion object {
        private const val BOTTOM_SHEET_HEIGHT_RATIO = 0.95f
        private const val CORNER_RADIUS_DP = 16f
        private const val TAG = "QuickPayBduiBottomSheet"

        fun show(
            component: QuickPayComponent,
            fragmentManager: FragmentManager,
            onDismiss: () -> Unit,
            theme: QuickPayThemeColorScheme,
        ): QuickPayBduiBottomSheet {
            return QuickPayBduiBottomSheet().apply {
                this.component = component
                this.onDismissCallback = onDismiss
                this.theme = theme
                show(fragmentManager, TAG)
            }
        }
    }
}
