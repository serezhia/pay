package com.yandex.pay.quickpay.internal.di.features.bdui

import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraHeadersProvider
import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraQueriesProvider
import com.yandex.fintechsdk.core.bdui.api.query.BduiDocumentQuery
import com.yandex.fintechsdk.core.bdui.api.spinner.IsSpinnerPreviewEnabled
import com.yandex.fintechsdk.core.bdui.api.theme.BduiThemeProvider
import com.yandex.fintechsdk.core.divkit.api.network.RemoteActionBaseQueriesProvider
import com.yandex.fintechsdk.core.ui.impl.api.activity.InsetsConfig
import com.yandex.fintechsdk.core.ui.impl.api.shimmers.ShimmersLayoutProvider
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.BduiNavigator
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.BduiActionsDelegate
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DeviceChallengeSignatureProvider
import com.yandex.fintechsdk.features.bdui.api.dependencies.navigation.action.DevicePubkeyProvider
import com.yandex.fintechsdk.features.bdui.api.di.BduiModule
import com.yandex.pay.quickpay.internal.di.features.bdui.action.BduiActionsDelegateImpl
import com.yandex.pay.quickpay.internal.di.features.bdui.action.DeviceChallengeSignatureProviderImpl
import com.yandex.pay.quickpay.internal.di.features.bdui.action.DevicePubkeyProviderImpl
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiDocumentQueryHolder
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiExtraHeadersProviderImpl
import com.yandex.pay.quickpay.internal.di.features.bdui.data.BduiExtraQueriesProviderImpl
import com.yandex.pay.quickpay.internal.di.features.bdui.navigation.BduiNavigatorImpl
import com.yandex.pay.quickpay.internal.di.features.bdui.theme.BduiThemeProviderImpl
import com.yandex.pay.quickpay.internal.di.features.shimmers.ShimmersLayoutProviderImpl
import dagger.Binds
import dagger.Module
import dagger.Provides

@Module(
    includes = [BduiModule::class],
)
internal interface BduiFeatureModule {

    @Binds
    fun bindBduiActionsDelegate(delegate: BduiActionsDelegateImpl): BduiActionsDelegate

    @Binds
    fun bindBduiExtraHeadersProvider(provider: BduiExtraHeadersProviderImpl): BduiExtraHeadersProvider

    @Binds
    fun bindBduiExtraQueriesProvider(provider: BduiExtraQueriesProviderImpl): BduiExtraQueriesProvider

    @Binds
    fun bindRemoteActionBaseQueriesProvider(provider: BduiExtraQueriesProviderImpl): RemoteActionBaseQueriesProvider

    @Binds
    fun bindBduiNavigator(navigator: BduiNavigatorImpl): BduiNavigator

    @Binds
    fun bindBduiThemeProvider(provider: BduiThemeProviderImpl): BduiThemeProvider

    @Binds
    fun bindDevicePubkeyProvider(delegate: DevicePubkeyProviderImpl): DevicePubkeyProvider

    @Binds
    fun bindDeviceChallengeSignatureProvider(
        delegate: DeviceChallengeSignatureProviderImpl,
    ): DeviceChallengeSignatureProvider

    @Binds
    fun bindShimmerLayoutProvider(
        provider: ShimmersLayoutProviderImpl,
    ): ShimmersLayoutProvider

    companion object {
        private const val PAYMENT_STATUS_SCREEN_PATH = "pay/v1/screens/quickpay/payment/status"

        @Provides
        fun provideInitialDocumentQuery(holder: BduiDocumentQueryHolder): BduiDocumentQuery {
            return holder.get() ?: BduiDocumentQuery(path = PAYMENT_STATUS_SCREEN_PATH)
        }

        @Provides
        fun provideIsSpinnerPreviewEnabled(): IsSpinnerPreviewEnabled {
            return IsSpinnerPreviewEnabled(value = true)
        }

        @Provides
        fun provideInsetsConfig(): InsetsConfig {
            return InsetsConfig(
                isBottomSheet = true,
                bottomSheetTopMarginDp = 16f,
            )
        }
    }
}

