package com.yandex.pay.quickpay.internal.di.adapters;

import com.yandex.fintechsdk.adapters.yb.sdk.api.YbAdapter;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.jetbrains.annotations.Nullable;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class FlowAdaptersModule_ProvideYbAdapterFactory implements Factory<YbAdapter> {
  private final FlowAdaptersModule module;

  private FlowAdaptersModule_ProvideYbAdapterFactory(FlowAdaptersModule module) {
    this.module = module;
  }

  @Override
  @Nullable
  public YbAdapter get() {
    return provideYbAdapter(module);
  }

  public static FlowAdaptersModule_ProvideYbAdapterFactory create(FlowAdaptersModule module) {
    return new FlowAdaptersModule_ProvideYbAdapterFactory(module);
  }

  @Nullable
  public static YbAdapter provideYbAdapter(FlowAdaptersModule instance) {
    return instance.provideYbAdapter();
  }
}
