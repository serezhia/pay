package com.yandex.pay.quickpay.internal.di.features.bdui.data

import com.yandex.fintechsdk.core.bdui.api.network.BduiExtraQueriesProvider
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fintechsdk.core.divkit.api.network.RemoteActionBaseQueriesProvider
import javax.inject.Inject

@FlowScope
internal class BduiExtraQueriesProviderImpl @Inject constructor() :
    BduiExtraQueriesProvider,
    RemoteActionBaseQueriesProvider {

    private var extraQueries: Map<String, String> = emptyMap()

    override fun getQueries(): Map<String, String> = extraQueries

    override fun getBaseQueries(): Map<String, String> = extraQueries

    fun addExtraQueries(queries: Map<String, String>) {
        extraQueries = extraQueries + queries.filterKeys { it !in extraQueries }
    }

    fun clearExtraQueries() {
        extraQueries = emptyMap()
    }
}
