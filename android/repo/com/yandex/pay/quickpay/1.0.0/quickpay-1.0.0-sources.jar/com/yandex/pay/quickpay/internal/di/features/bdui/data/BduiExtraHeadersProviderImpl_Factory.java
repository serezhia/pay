package com.yandex.pay.quickpay.internal.di.features.bdui.data;

import android.content.Context;
import com.yandex.fintechsdk.core.network.impl.api.frontback.FrontbackServiceTokenProvider;
import com.yandex.fintechsdk.core.utils.api.session.SessionId;
import com.yandex.fintechsdk.core.utils.api.useragent.UserAgentProvider;
import com.yandex.fintechsdk.data.auth.api.dpop.DpopRepository;
import com.yandex.fintechsdk.data.quickpay.api.MerchantIdProvider;
import com.yandex.fintechsdk.entities.environment.PayEnvironment;
import dagger.Lazy;
import dagger.internal.DaggerGenerated;
import dagger.internal.DoubleCheck;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata("com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class BduiExtraHeadersProviderImpl_Factory implements Factory<BduiExtraHeadersProviderImpl> {
  private final Provider<Context> contextProvider;

  private final Provider<DpopRepository> dpopRepositoryProvider;

  private final Provider<PayEnvironment> environmentProvider;

  private final Provider<FrontbackServiceTokenProvider> frontbackServiceTokenProvider;

  private final Provider<MerchantIdProvider> merchantIdProvider;

  private final Provider<SessionId> sessionIdProvider;

  private final Provider<UserAgentProvider> userAgentProvider;

  private BduiExtraHeadersProviderImpl_Factory(Provider<Context> contextProvider,
      Provider<DpopRepository> dpopRepositoryProvider, Provider<PayEnvironment> environmentProvider,
      Provider<FrontbackServiceTokenProvider> frontbackServiceTokenProvider,
      Provider<MerchantIdProvider> merchantIdProvider, Provider<SessionId> sessionIdProvider,
      Provider<UserAgentProvider> userAgentProvider) {
    this.contextProvider = contextProvider;
    this.dpopRepositoryProvider = dpopRepositoryProvider;
    this.environmentProvider = environmentProvider;
    this.frontbackServiceTokenProvider = frontbackServiceTokenProvider;
    this.merchantIdProvider = merchantIdProvider;
    this.sessionIdProvider = sessionIdProvider;
    this.userAgentProvider = userAgentProvider;
  }

  @Override
  public BduiExtraHeadersProviderImpl get() {
    return newInstance(contextProvider.get(), DoubleCheck.lazy(dpopRepositoryProvider), environmentProvider.get(), frontbackServiceTokenProvider.get(), merchantIdProvider.get(), sessionIdProvider.get(), userAgentProvider.get());
  }

  public static BduiExtraHeadersProviderImpl_Factory create(Provider<Context> contextProvider,
      Provider<DpopRepository> dpopRepositoryProvider, Provider<PayEnvironment> environmentProvider,
      Provider<FrontbackServiceTokenProvider> frontbackServiceTokenProvider,
      Provider<MerchantIdProvider> merchantIdProvider, Provider<SessionId> sessionIdProvider,
      Provider<UserAgentProvider> userAgentProvider) {
    return new BduiExtraHeadersProviderImpl_Factory(contextProvider, dpopRepositoryProvider, environmentProvider, frontbackServiceTokenProvider, merchantIdProvider, sessionIdProvider, userAgentProvider);
  }

  public static BduiExtraHeadersProviderImpl newInstance(Context context,
      Lazy<DpopRepository> dpopRepository, PayEnvironment environment,
      FrontbackServiceTokenProvider frontbackServiceTokenProvider,
      MerchantIdProvider merchantIdProvider, SessionId sessionId,
      UserAgentProvider userAgentProvider) {
    return new BduiExtraHeadersProviderImpl(context, dpopRepository, environment, frontbackServiceTokenProvider, merchantIdProvider, sessionId, userAgentProvider);
  }
}
