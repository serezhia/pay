package com.yandex.pay.quickpay.internal.di.features.shimmers

import com.yandex.fintechsdk.core.ui.impl.api.shimmers.ShimmersLayoutIdentifiers
import com.yandex.fintechsdk.core.ui.impl.api.shimmers.ShimmersLayoutProvider
import com.yandex.pay.quickpay.R
import javax.inject.Inject

/**
 * Custom splash UI provider implementation for payment-kit flow.
 * This provides a custom loading screen with a close button instead of the default shimmer UI.
 */
internal class ShimmersLayoutProviderImpl @Inject constructor() : ShimmersLayoutProvider {

    override fun getLayoutIdentifiers(): ShimmersLayoutIdentifiers {
        return ShimmersLayoutIdentifiers(
            backbuttonId = R.id.finsdkBackButton,
            bottomBarId = R.id.finsdkBottomBar,
            contentId = R.layout.finsdk_quickpayment_fragment_shimmers,
        )
    }
}
