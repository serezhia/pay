package com.yandex.pay.quickpay.internal.di.adapters.divkit

import android.content.Context
import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitAdapter
import com.yandex.fintechsdk.adapters.divkit.sdk.api.DivKitDependencies
import com.yandex.fintechsdk.adapters.divkit.sdk.api.version.DivKitVersionProvider
import com.yandex.fintechsdk.adapters.divkit.sdk.impl.api.DivKitAdapterFactory
import com.yandex.fintechsdk.adapters.divkit.sdk.impl.api.DivKitVersionProviderImpl
import com.yandex.fintechsdk.core.bdui.api.theme.BduiThemeProvider
import com.yandex.fintechsdk.core.divkit.api.action.DivActionHandler
import com.yandex.fintechsdk.core.di.impl.api.context.ApplicationContext
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import dagger.Module
import dagger.Provides
import okhttp3.OkHttpClient

@Module
internal class DivKitAdapterModule {

    @Provides
    @FlowScope
    fun provideDivKitAdapter(): DivKitAdapter {
        return DivKitAdapterFactory().create()
    }

    @Provides
    @FlowScope
    fun provideDivKitDependencies(
        @ApplicationContext context: Context,
        divActionHandlers: Map<String, @JvmSuppressWildcards DivActionHandler>,
        okHttpClientBuilder: OkHttpClient.Builder,
        themeProvider: BduiThemeProvider,
    ): DivKitDependencies {
        return DivKitDependencies(
            applicationContext = context,
            divActionHandlers = divActionHandlers,
            okHttpClientBuilder = okHttpClientBuilder,
            themeProvider = themeProvider,
        )
    }

    @Provides
    @FlowScope
    fun provideDivKitVersionProvider(): DivKitVersionProvider {
        return DivKitVersionProviderImpl()
    }
}
