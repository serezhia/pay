package com.yandex.pay.quickpay.internal.di.adapters.login

import com.yandex.fintechsdk.adapters.login.sdk.impl.LoginAdapterFactory
import com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope
import com.yandex.fitnechsdk.adapters.login.sdk.api.LoginAdapter
import dagger.Module
import dagger.Provides

@Module
internal interface LoginAdapterModule {

    companion object {
        @FlowScope
        @Provides
        fun provideLoginAdapter(): LoginAdapter {
            return LoginAdapterFactory().create()
        }
    }
}
