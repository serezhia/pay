package com.yandex.pay.quickpay.internal.di.features.shimmers;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ShimmersLayoutProviderImpl_Factory implements Factory<ShimmersLayoutProviderImpl> {
  @Override
  public ShimmersLayoutProviderImpl get() {
    return newInstance();
  }

  public static ShimmersLayoutProviderImpl_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static ShimmersLayoutProviderImpl newInstance() {
    return new ShimmersLayoutProviderImpl();
  }

  private static final class InstanceHolder {
    static final ShimmersLayoutProviderImpl_Factory INSTANCE = new ShimmersLayoutProviderImpl_Factory();
  }
}
