package com.yandex.pay.quickpay.internal.analytics;

import com.yandex.fintechsdk.core.analytics.api.Analytics;
import com.yandex.fintechsdk.data.auth.api.AuthRepository;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("com.yandex.fintechsdk.core.di.impl.api.scopes.FlowScope")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class QuickPayAnalyticsReporter_Factory implements Factory<QuickPayAnalyticsReporter> {
  private final Provider<Analytics> analyticsProvider;

  private final Provider<AuthRepository> authRepositoryProvider;

  private QuickPayAnalyticsReporter_Factory(Provider<Analytics> analyticsProvider,
      Provider<AuthRepository> authRepositoryProvider) {
    this.analyticsProvider = analyticsProvider;
    this.authRepositoryProvider = authRepositoryProvider;
  }

  @Override
  public QuickPayAnalyticsReporter get() {
    return newInstance(analyticsProvider.get(), authRepositoryProvider.get());
  }

  public static QuickPayAnalyticsReporter_Factory create(Provider<Analytics> analyticsProvider,
      Provider<AuthRepository> authRepositoryProvider) {
    return new QuickPayAnalyticsReporter_Factory(analyticsProvider, authRepositoryProvider);
  }

  public static QuickPayAnalyticsReporter newInstance(Analytics analytics,
      AuthRepository authRepository) {
    return new QuickPayAnalyticsReporter(analytics, authRepository);
  }
}
