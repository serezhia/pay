package com.yandex.pay.quickpay.internal.extensions

import com.yandex.pay.quickpay.api.QuickPayLocale
import java.util.Locale

internal fun QuickPayLocale.toLanguageCode(): String = when (this) {
    QuickPayLocale.RU -> "ru"
    QuickPayLocale.EN -> "en"
    QuickPayLocale.SYSTEM -> Locale.getDefault().language
}

